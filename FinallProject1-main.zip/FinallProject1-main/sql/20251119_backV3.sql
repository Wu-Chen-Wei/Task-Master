CREATE DATABASE IF NOT EXISTS `finallproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `finallproject`;

-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: finallproject
-- ------------------------------------------------------
-- Server version	8.0.43
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;

/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;

/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;

/*!50503 SET NAMES utf8 */;

/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;

/*!40103 SET TIME_ZONE='+00:00' */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `automationrules`
--
DROP TABLE IF EXISTS `automationrules`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `automationrules` (
    `RuleID` int NOT NULL AUTO_INCREMENT,
    `ProjectID` int NOT NULL,
    `MissionID` int NOT NULL,
    `Name` varchar(255) NOT NULL,
    `Descriptions` varchar(255) NOT NULL,
    `TriggerDefinition` json NOT NULL,
    `ActionDefinition` json NOT NULL,
    `IsEnabled` tinyint (1) NOT NULL DEFAULT '1',
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`RuleID`),
    KEY `ProjectID` (`ProjectID`),
    KEY `MissionID` (`MissionID`),
    CONSTRAINT `automationrules_ibfk_1` FOREIGN KEY (`ProjectID`) REFERENCES `projects` (`ProjectID`) ON DELETE CASCADE,
    CONSTRAINT `automationrules_ibfk_2` FOREIGN KEY (`MissionID`) REFERENCES `missions` (`MissionID`) ON DELETE CASCADE
  ) ENGINE = InnoDB AUTO_INCREMENT = 8 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `automationrules`
--
LOCK TABLES `automationrules` WRITE;

/*!40000 ALTER TABLE `automationrules` DISABLE KEYS */;

INSERT INTO
  `automationrules`
VALUES
  (
    1,
    1,
    1,
    'When urgent bug is closed, notify PM',
    '當一個任務被標記為『Urgent』且狀態改為『Closed』時，\r\n系統自動發送通知給使用者 #2',
    '{\"tag\": \"Urgent\", \"trigger\": \"status_changed\", \"to_status\": \"Closed\"}',
    '{\"action\": \"send_notification\", \"recipient_user_id\": 2}',
    1,
    '2025-11-13 06:11:37'
  ),
  (
    2,
    1,
    1,
    'adfdaf',
    'adsfasdf',
    '{\"tag\": \"Urgent\", \"trigger\": \"project_members_change\", \"to_status\": \"Closed\"}',
    '{\"action\": \"send_email\", \"recipient_user_id\": 2}',
    1,
    '2025-11-17 05:46:32'
  ),
  (
    3,
    1,
    1,
    '專案建立',
    '專案建立祭出email',
    '{\"tag\": \"Urgent\", \"trigger\": \"project_created\", \"to_status\": \"Closed\"}',
    '{\"action\": \"send_email\", \"recipient_user_id\": 2}',
    1,
    NULL
  ),
  (
    4,
    1,
    1,
    '專案變更',
    '專案變更',
    '{\"tag\": \"Urgent\", \"trigger\": \"project_changed\", \"to_status\": \"Closed\"}',
    '{\"action\": \"send_notification\", \"recipient_user_id\": 2}',
    1,
    NULL
  ),
  (
    5,
    1,
    1,
    '專案成員變更',
    '專案成員變更',
    '{\"tag\": \"Urgent\", \"trigger\": \"project_members_change\", \"to_status\": \"Closed\"}',
    '{\"action\": \"send_notification\", \"recipient_user_id\": 2}',
    1,
    '2025-11-17 05:57:03'
  ),
  (
    6,
    1,
    1,
    '專案狀態變更',
    '專案成員變更',
    '{\"tag\": \"Urgent\", \"trigger\": \"project_status_changed\", \"to_status\": \"Closed\"}',
    '{\"action\": \"send_notification\", \"recipient_user_id\": 2}',
    1,
    NULL
  ),
  (
    7,
    1,
    1,
    '專案成員變更',
    '專案成員變更',
    '{\"tag\": \"Urgent\", \"trigger\": \"project_members_change\", \"to_status\": \"Closed\"}',
    '{\"action\": \"send_email\", \"recipient_user_id\": 2}',
    1,
    NULL
  );

/*!40000 ALTER TABLE `automationrules` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `kanbansettings`
--
DROP TABLE IF EXISTS `kanbansettings`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `kanbansettings` (
    `SettingID` int NOT NULL AUTO_INCREMENT,
    `UserID` int NOT NULL,
    `ProjectID` int NOT NULL,
    `ColumnOrder` json DEFAULT NULL,
    `CreatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`SettingID`),
    UNIQUE KEY `uk_user_project` (`UserID`, `ProjectID`),
    KEY `ProjectID` (`ProjectID`),
    CONSTRAINT `kanbansettings_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`) ON DELETE CASCADE,
    CONSTRAINT `kanbansettings_ibfk_2` FOREIGN KEY (`ProjectID`) REFERENCES `projects` (`ProjectID`) ON DELETE CASCADE
  ) ENGINE = InnoDB AUTO_INCREMENT = 3 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kanbansettings`
--
LOCK TABLES `kanbansettings` WRITE;

/*!40000 ALTER TABLE `kanbansettings` DISABLE KEYS */;

INSERT INTO
  `kanbansettings`
VALUES
  (
    1,
    2,
    1,
    '[\"Open\", \"In Progress\", \"Testing\", \"Closed\", \"Reopened\"]',
    '2025-10-14 01:33:19',
    NULL
  ),
  (
    2,
    1,
    1,
    '[\"Open\", \"In Progress\", \"Testing\", \"Closed\", \"Reopened\"]',
    '2025-11-08 08:20:20',
    NULL
  );

/*!40000 ALTER TABLE `kanbansettings` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `metricsdaily`
--
DROP TABLE IF EXISTS `metricsdaily`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `metricsdaily` (
    `MetricsID` int NOT NULL AUTO_INCREMENT,
    `ProjectID` int NOT NULL,
    `Date` date NOT NULL,
    `OpenMissions` int DEFAULT '0',
    `InProgressMissions` int DEFAULT '0',
    `ResolvedMissions` int DEFAULT '0',
    `ClosedMissions` int DEFAULT '0',
    `BugCount` int DEFAULT '0',
    `AvgResolveTimeHours` decimal(10, 2) DEFAULT '0.00',
    `CreatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`MetricsID`),
    UNIQUE KEY `uk_project_date` (`ProjectID`, `Date`),
    CONSTRAINT `metricsdaily_ibfk_1` FOREIGN KEY (`ProjectID`) REFERENCES `projects` (`ProjectID`) ON DELETE CASCADE
  ) ENGINE = InnoDB AUTO_INCREMENT = 3 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metricsdaily`
--
LOCK TABLES `metricsdaily` WRITE;

/*!40000 ALTER TABLE `metricsdaily` DISABLE KEYS */;

INSERT INTO
  `metricsdaily`
VALUES
  (
    1,
    1,
    '2025-10-06',
    5,
    1,
    0,
    0,
    0,
    0.00,
    '2025-10-14 01:33:19'
  ),
  (
    2,
    1,
    '2025-10-07',
    4,
    2,
    0,
    0,
    0,
    0.00,
    '2025-10-14 01:33:19'
  );

/*!40000 ALTER TABLE `metricsdaily` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `missionattachments`
--
DROP TABLE IF EXISTS `missionattachments`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `missionattachments` (
    `AttachmentID` int NOT NULL AUTO_INCREMENT,
    `MissionID` int NOT NULL,
    `UserID` int NOT NULL,
    `FileName` varchar(255) NOT NULL,
    `FilePath` varchar(512) NOT NULL,
    `FileSize` int DEFAULT NULL,
    `FileType` varchar(100) DEFAULT NULL,
    `UploadedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`AttachmentID`),
    KEY `MissionID` (`MissionID`),
    KEY `UserID` (`UserID`),
    CONSTRAINT `missionattachments_ibfk_1` FOREIGN KEY (`MissionID`) REFERENCES `missions` (`MissionID`) ON DELETE CASCADE,
    CONSTRAINT `missionattachments_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`) ON DELETE CASCADE
  ) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `missionattachments`
--
LOCK TABLES `missionattachments` WRITE;

/*!40000 ALTER TABLE `missionattachments` DISABLE KEYS */;

INSERT INTO
  `missionattachments`
VALUES
  (
    1,
    1,
    6,
    'safari-bug.png',
    '/uploads/missions/1/safari-bug.png',
    NULL,
    NULL,
    '2025-10-14 01:33:19',
    NULL
  );

/*!40000 ALTER TABLE `missionattachments` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `missioncomments`
--
DROP TABLE IF EXISTS `missioncomments`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `missioncomments` (
    `CommentID` int NOT NULL AUTO_INCREMENT,
    `MissionID` int NOT NULL,
    `UserID` int NOT NULL,
    `Content` text NOT NULL,
    `CreatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`CommentID`),
    KEY `MissionID` (`MissionID`),
    KEY `UserID` (`UserID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 11 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `missioncomments`
--
LOCK TABLES `missioncomments` WRITE;

/*!40000 ALTER TABLE `missioncomments` DISABLE KEYS */;

INSERT INTO
  `missioncomments`
VALUES
  (
    1,
    1,
    2,
    '這個問題影響到 Demo，請 Alice 優先處理。',
    '2025-10-14 01:33:19',
    NULL
  ),
  (
    2,
    1,
    4,
    '收到，正在處理中，預計明天完成。',
    '2025-10-14 01:33:19',
    NULL
  ),
  (
    3,
    4,
    2,
    '請 Alice 優先處理這個 API，後端需要它來做忘記密碼頁面。',
    '2025-10-15 01:01:00',
    NULL
  ),
  (
    4,
    4,
    4,
    '收到，正在規劃 schema。',
    '2025-10-15 01:30:00',
    NULL
  ),
  (
    5,
    5,
    6,
    '附上截圖，請 Alice 參考。',
    '2025-10-15 02:31:00',
    NULL
  ),
  (
    6,
    6,
    3,
    'OK, I am on it.',
    '2025-10-16 03:05:00',
    NULL
  ),
  (
    7,
    9,
    5,
    '正在追查 production log，看起來是金流 service 壞了。',
    '2025-10-17 02:20:00',
    NULL
  ),
  (
    8,
    11,
    6,
    '我這邊驗證失敗，狀態改為 Reopened，請 Alice 再次確認。',
    '2025-10-18 08:01:00',
    NULL
  ),
  (
    9,
    11,
    4,
    '奇怪，我本機測試是正常的。我再檢查看看 cache 問題。',
    '2025-10-18 08:05:00',
    NULL
  ),
  (
    10,
    13,
    6,
    'QA 驗證通過，任務關閉。',
    '2025-10-15 09:00:00',
    NULL
  );

/*!40000 ALTER TABLE `missioncomments` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `missionhistory`
--
DROP TABLE IF EXISTS `missionhistory`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `missionhistory` (
    `HistoryID` int NOT NULL AUTO_INCREMENT,
    `MissionID` int NOT NULL,
    `UserID` int DEFAULT NULL,
    `FieldChanged` varchar(50) NOT NULL,
    `OldValue` text,
    `NewValue` text,
    `ChangedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`HistoryID`),
    KEY `MissionID` (`MissionID`),
    KEY `UserID` (`UserID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 112 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `missionhistory`
--
LOCK TABLES `missionhistory` WRITE;

/*!40000 ALTER TABLE `missionhistory` DISABLE KEYS */;

INSERT INTO
  `missionhistory`
VALUES
  (
    1,
    1,
    2,
    'AssigneeID',
    NULL,
    '4',
    '2025-10-14 01:33:19'
  ),
  (
    2,
    1,
    4,
    'Status',
    'Open',
    'In Progress',
    '2025-10-14 01:33:19'
  ),
  (
    3,
    1,
    1,
    'Status',
    'Closed',
    'Closed',
    '2025-11-08 08:33:06'
  ),
  (
    4,
    1,
    1,
    'Status',
    'Closed',
    'Closed',
    '2025-11-08 08:33:49'
  ),
  (
    5,
    1,
    6,
    'Status',
    'Closed',
    'Testing',
    '2025-11-08 22:30:25'
  ),
  (
    6,
    12,
    1,
    'Status',
    'Open',
    'In Progress',
    '2025-11-09 03:18:10'
  ),
  (
    7,
    9,
    1,
    'Status',
    'In Progress',
    'Testing',
    '2025-11-09 03:18:27'
  ),
  (
    8,
    9,
    1,
    'Status',
    'Testing',
    'In Progress',
    '2025-11-09 03:18:29'
  ),
  (
    9,
    9,
    1,
    'Status',
    'In Progress',
    'Testing',
    '2025-11-09 03:18:31'
  ),
  (
    10,
    10,
    1,
    'Status',
    'Open',
    'In Progress',
    '2025-11-09 03:20:09'
  ),
  (
    11,
    3,
    1,
    'Status',
    'Open',
    'In Progress',
    '2025-11-09 03:20:11'
  ),
  (
    12,
    10,
    1,
    'Status',
    'In Progress',
    'Open',
    '2025-11-09 03:20:12'
  ),
  (
    13,
    9,
    1,
    'Status',
    'Testing',
    'Open',
    '2025-11-09 03:20:20'
  ),
  (
    14,
    3,
    1,
    'Status',
    'In Progress',
    'Testing',
    '2025-11-09 03:20:27'
  ),
  (
    15,
    3,
    1,
    'Status',
    'Testing',
    'Closed',
    '2025-11-09 03:20:33'
  ),
  (
    16,
    3,
    1,
    'Status',
    'Closed',
    'Testing',
    '2025-11-09 03:20:38'
  ),
  (
    17,
    11,
    1,
    'Status',
    'Reopened',
    'Testing',
    '2025-11-09 03:28:04'
  ),
  (
    18,
    1,
    1,
    'Status',
    'Testing',
    'Reopened',
    '2025-11-09 03:28:05'
  ),
  (
    19,
    1,
    2,
    'Status',
    'Reopened',
    'Closed',
    '2025-11-09 03:59:25'
  ),
  (
    20,
    13,
    1,
    'Status',
    'Closed',
    'Reopened',
    '2025-11-09 04:01:05'
  ),
  (
    21,
    13,
    1,
    'Status',
    'Reopened',
    'Closed',
    '2025-11-09 04:01:07'
  ),
  (
    22,
    3,
    2,
    'Status',
    'Testing',
    'Testing',
    '2025-11-09 04:02:00'
  ),
  (
    23,
    3,
    2,
    'Status',
    'Testing',
    'In Progress',
    '2025-11-09 04:02:01'
  ),
  (
    24,
    3,
    2,
    'Status',
    'In Progress',
    'Testing',
    '2025-11-09 04:02:03'
  ),
  (
    25,
    3,
    2,
    'Status',
    'Testing',
    'Reopened',
    '2025-11-09 04:02:03'
  ),
  (
    26,
    3,
    2,
    'Status',
    'Reopened',
    'In Progress',
    '2025-11-09 04:02:04'
  ),
  (
    27,
    10,
    2,
    'Status',
    'Open',
    'Testing',
    '2025-11-09 04:02:05'
  ),
  (
    28,
    10,
    2,
    'Status',
    'Testing',
    'Reopened',
    '2025-11-09 04:02:06'
  ),
  (
    29,
    10,
    2,
    'Status',
    'Reopened',
    'Closed',
    '2025-11-09 04:02:07'
  ),
  (
    30,
    10,
    2,
    'Status',
    'Closed',
    'Reopened',
    '2025-11-09 04:02:08'
  ),
  (
    31,
    10,
    2,
    'Status',
    'Reopened',
    'Testing',
    '2025-11-09 04:02:09'
  ),
  (
    32,
    13,
    2,
    'Status',
    'Closed',
    'Reopened',
    '2025-11-09 04:23:11'
  ),
  (
    33,
    7,
    2,
    'Status',
    'Open',
    'In Progress',
    '2025-11-09 04:24:13'
  ),
  (
    34,
    6,
    2,
    'Status',
    'In Progress',
    'Testing',
    '2025-11-09 04:24:13'
  ),
  (
    35,
    5,
    2,
    'Status',
    'Testing',
    'Reopened',
    '2025-11-09 04:24:14'
  ),
  (
    36,
    13,
    2,
    'Status',
    'Reopened',
    'Closed',
    '2025-11-09 04:24:15'
  ),
  (
    37,
    1,
    2,
    'Status',
    'Closed',
    'Reopened',
    '2025-11-09 04:24:15'
  ),
  (
    38,
    1,
    2,
    'Status',
    'Reopened',
    'Testing',
    '2025-11-09 04:24:16'
  ),
  (
    39,
    5,
    1,
    'Status',
    'Reopened',
    'Closed',
    '2025-11-09 04:24:57'
  ),
  (
    40,
    5,
    1,
    'Status',
    'Closed',
    'Reopened',
    '2025-11-09 04:24:58'
  ),
  (
    41,
    5,
    1,
    'Status',
    'Reopened',
    'In Progress',
    '2025-11-09 04:24:59'
  ),
  (
    42,
    1,
    1,
    'Status',
    'Testing',
    'Reopened',
    '2025-11-09 04:25:00'
  ),
  (
    43,
    6,
    1,
    'Status',
    'Testing',
    'Closed',
    '2025-11-09 04:25:01'
  ),
  (
    44,
    2,
    1,
    'Status',
    'Open',
    'Reopened',
    '2025-11-09 04:25:02'
  ),
  (
    45,
    10,
    1,
    'Status',
    'Testing',
    'Reopened',
    '2025-11-09 04:25:06'
  ),
  (
    46,
    3,
    1,
    'Status',
    'In Progress',
    'Closed',
    '2025-11-09 04:25:07'
  ),
  (
    47,
    3,
    1,
    'Status',
    'Closed',
    'Testing',
    '2025-11-09 04:25:08'
  ),
  (
    48,
    10,
    1,
    'Status',
    'Reopened',
    'In Progress',
    '2025-11-09 04:25:09'
  ),
  (
    49,
    7,
    1,
    'Status',
    'In Progress',
    'Testing',
    '2025-11-11 05:35:45'
  ),
  (
    50,
    7,
    1,
    'Status',
    'Testing',
    'In Progress',
    '2025-11-11 05:35:46'
  ),
  (
    51,
    13,
    1,
    'Status',
    'Closed',
    'Testing',
    '2025-11-11 05:35:47'
  ),
  (
    52,
    2,
    1,
    'Status',
    'Reopened',
    'Closed',
    '2025-11-11 05:35:49'
  ),
  (
    53,
    6,
    1,
    'Status',
    'Closed',
    'Testing',
    '2025-11-11 05:35:51'
  ),
  (
    54,
    6,
    1,
    'Status',
    'Testing',
    'Closed',
    '2025-11-11 05:35:52'
  ),
  (
    55,
    13,
    1,
    'Status',
    'Testing',
    'Closed',
    '2025-11-11 05:35:53'
  ),
  (
    56,
    14,
    1,
    'Status',
    'Open',
    'Testing',
    '2025-11-11 05:36:01'
  ),
  (
    57,
    14,
    1,
    'Status',
    'Testing',
    'Open',
    '2025-11-11 05:36:01'
  ),
  (
    58,
    12,
    1,
    'Status',
    'In Progress',
    'Testing',
    '2025-11-11 05:36:02'
  ),
  (
    59,
    12,
    1,
    'Status',
    'Testing',
    'In Progress',
    '2025-11-11 05:36:03'
  ),
  (
    60,
    5,
    1,
    'Status',
    'In Progress',
    'Testing',
    '2025-11-11 05:36:06'
  ),
  (
    61,
    2,
    1,
    'Status',
    'Closed',
    'In Progress',
    '2025-11-11 05:36:07'
  ),
  (
    62,
    5,
    1,
    'Status',
    'Testing',
    'Closed',
    '2025-11-11 05:36:08'
  ),
  (
    63,
    6,
    1,
    'Status',
    'Closed',
    'Testing',
    '2025-11-11 05:36:09'
  ),
  (
    64,
    13,
    1,
    'Status',
    'Closed',
    'Reopened',
    '2025-11-11 05:36:20'
  ),
  (
    65,
    6,
    1,
    'Status',
    'Testing',
    'Closed',
    '2025-11-11 05:36:21'
  ),
  (
    66,
    5,
    1,
    'Status',
    'Closed',
    'Testing',
    '2025-11-11 05:36:22'
  ),
  (
    67,
    1,
    1,
    'Status',
    'Reopened',
    'Closed',
    '2025-11-11 07:26:31'
  ),
  (
    68,
    1,
    1,
    'Status',
    'Closed',
    'Reopened',
    '2025-11-11 07:26:32'
  ),
  (
    69,
    5,
    1,
    'Status',
    'Testing',
    'Closed',
    '2025-11-11 07:26:35'
  ),
  (
    70,
    11,
    1,
    'Status',
    'Testing',
    'Closed',
    '2025-11-13 02:31:56'
  ),
  (
    71,
    6,
    1,
    'Status',
    'Closed',
    'Closed',
    '2025-11-13 02:31:57'
  ),
  (
    72,
    11,
    1,
    'Status',
    'Closed',
    'Testing',
    '2025-11-13 02:31:58'
  ),
  (
    73,
    11,
    1,
    'Status',
    'Testing',
    'Closed',
    '2025-11-13 06:07:04'
  ),
  (
    74,
    1,
    1,
    'Status',
    'Reopened',
    'Testing',
    '2025-11-13 06:07:05'
  ),
  (
    75,
    13,
    1,
    'Status',
    'Reopened',
    'Testing',
    '2025-11-13 06:07:10'
  ),
  (
    76,
    6,
    1,
    'Status',
    'Closed',
    'Reopened',
    '2025-11-13 06:07:11'
  ),
  (
    77,
    5,
    1,
    'Status',
    'Closed',
    'Reopened',
    '2025-11-13 06:07:12'
  ),
  (
    78,
    5,
    1,
    'Status',
    'Reopened',
    'Closed',
    '2025-11-13 06:07:15'
  ),
  (
    79,
    5,
    1,
    'Status',
    'Closed',
    'Reopened',
    '2025-11-15 06:29:51'
  ),
  (
    80,
    5,
    1,
    'Status',
    'Reopened',
    'Closed',
    '2025-11-15 06:29:52'
  ),
  (
    81,
    5,
    1,
    'Status',
    'Closed',
    'Testing',
    '2025-11-15 06:29:52'
  ),
  (
    82,
    13,
    1,
    'Status',
    'Testing',
    'Closed',
    '2025-11-15 06:29:53'
  ),
  (
    83,
    13,
    1,
    'Status',
    'Closed',
    'Reopened',
    '2025-11-15 06:29:53'
  ),
  (
    84,
    13,
    1,
    'Status',
    'Reopened',
    'Closed',
    '2025-11-15 06:29:54'
  ),
  (
    85,
    13,
    1,
    'Status',
    'Closed',
    'Testing',
    '2025-11-15 06:29:55'
  ),
  (
    86,
    5,
    1,
    'Status',
    'Testing',
    'Closed',
    '2025-11-15 06:29:56'
  ),
  (
    87,
    5,
    1,
    'Status',
    'Closed',
    'Testing',
    '2025-11-15 06:29:58'
  ),
  (
    88,
    7,
    1,
    'Status',
    'In Progress',
    'Closed',
    '2025-11-15 06:29:59'
  ),
  (
    89,
    7,
    1,
    'Status',
    'Closed',
    'Reopened',
    '2025-11-17 01:09:08'
  ),
  (
    90,
    6,
    1,
    'Status',
    'Reopened',
    'Closed',
    '2025-11-17 01:09:09'
  ),
  (
    91,
    3,
    1,
    'Status',
    'Testing',
    'Closed',
    '2025-11-18 01:05:42'
  ),
  (
    92,
    3,
    1,
    'Status',
    'Closed',
    'Testing',
    '2025-11-18 01:05:43'
  ),
  (
    93,
    10,
    1,
    'Status',
    'In Progress',
    'Testing',
    '2025-11-18 01:05:46'
  ),
  (
    94,
    6,
    1,
    'Status',
    'Closed',
    'In Progress',
    '2025-11-18 01:05:47'
  ),
  (
    95,
    10,
    1,
    'Status',
    'Testing',
    'In Progress',
    '2025-11-18 01:05:47'
  ),
  (
    96,
    7,
    1,
    'Status',
    'Reopened',
    'Testing',
    '2025-11-18 01:05:49'
  ),
  (
    97,
    18,
    4,
    'Status',
    '',
    'Testing',
    '2025-11-18 01:26:50'
  ),
  (
    98,
    18,
    6,
    'Status',
    'Testing',
    'Closed',
    '2025-11-18 01:27:14'
  ),
  (
    99,
    18,
    1,
    'Status',
    'Closed',
    'Testing',
    '2025-11-18 01:28:07'
  ),
  (
    100,
    18,
    1,
    'Status',
    'Testing',
    'In Progress',
    '2025-11-18 01:28:08'
  ),
  (
    101,
    18,
    1,
    'Status',
    'In Progress',
    'Open',
    '2025-11-18 01:28:09'
  ),
  (
    102,
    18,
    1,
    'Status',
    'Open',
    'In Progress',
    '2025-11-18 01:28:09'
  ),
  (
    103,
    18,
    1,
    'Status',
    'In Progress',
    'Testing',
    '2025-11-18 01:28:10'
  ),
  (
    104,
    18,
    1,
    'Status',
    'Testing',
    'In Progress',
    '2025-11-18 01:28:11'
  ),
  (
    105,
    18,
    1,
    'Status',
    'In Progress',
    'Open',
    '2025-11-18 01:28:12'
  ),
  (
    106,
    18,
    1,
    'Status',
    'Open',
    'In Progress',
    '2025-11-18 01:28:13'
  ),
  (
    107,
    19,
    4,
    'Status',
    '',
    'Testing',
    '2025-11-18 06:07:31'
  ),
  (
    108,
    19,
    6,
    'Status',
    'Testing',
    'Closed',
    '2025-11-18 06:07:48'
  ),
  (
    109,
    21,
    4,
    'Status',
    '',
    'In Progress',
    '2025-11-19 06:05:06'
  ),
  (
    110,
    21,
    6,
    'Status',
    '',
    'Testing',
    '2025-11-19 06:05:57'
  ),
  (
    111,
    21,
    6,
    'Status',
    'Testing',
    'Closed',
    '2025-11-19 06:06:14'
  );

/*!40000 ALTER TABLE `missionhistory` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `missions`
--
DROP TABLE IF EXISTS `missions`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `missions` (
    `MissionID` int NOT NULL AUTO_INCREMENT,
    `ProjectID` int NOT NULL,
    `Title` varchar(255) NOT NULL,
    `Description` text,
    `Status` enum (
      'Open',
      'In Progress',
      'Testing',
      'Reopened',
      'Closed'
    ) NOT NULL DEFAULT 'Open',
    `Priority` enum ('Low', 'Medium', 'High', 'Critical') NOT NULL DEFAULT 'Medium',
    `ReporterID` int NOT NULL,
    `AssigneeID` int DEFAULT NULL,
    `StartDate` date DEFAULT NULL,
    `DueDate` date DEFAULT NULL,
    `QASignedByUserID` int DEFAULT NULL,
    `QASignedAt` timestamp NULL DEFAULT NULL,
    `CreatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    `UpdatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`MissionID`),
    KEY `ProjectID` (`ProjectID`),
    KEY `ReporterID` (`ReporterID`),
    KEY `AssigneeID` (`AssigneeID`),
    KEY `QASignedByUserID` (`QASignedByUserID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 22 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `missions`
--
LOCK TABLES `missions` WRITE;

/*!40000 ALTER TABLE `missions` DISABLE KEYS */;

INSERT INTO
  `missions`
VALUES
  (
    1,
    1,
    '使用者登入頁面樣式跑版',
    '在 Safari 瀏覽器下，登入按鈕會超出邊界。',
    'Closed',
    'High',
    6,
    4,
    NULL,
    '2025-10-20',
    6,
    '2025-11-17 03:55:34',
    '2025-10-14 01:33:19',
    '2025-11-17 03:56:05',
    NULL
  ),
  (
    2,
    1,
    '建立使用者資料庫結構',
    '根據規格書 P.5 設計並建立 User Profile 相關的資料表。',
    'In Progress',
    'Medium',
    3,
    5,
    NULL,
    '2025-11-05',
    NULL,
    NULL,
    '2025-10-14 01:33:19',
    '2025-11-11 05:36:07',
    NULL
  ),
  (
    3,
    1,
    'API /v1/tickets 無法回傳座位資訊',
    '特定場次的座位資訊為空，導致前端無法渲染。',
    'Testing',
    'High',
    1,
    5,
    NULL,
    '2025-10-15',
    NULL,
    NULL,
    '2025-10-14 01:33:19',
    '2025-11-18 01:05:43',
    NULL
  ),
  (
    4,
    1,
    '實作忘記密碼 API',
    '需要建立 /api/v1/auth/forgot-password 路由',
    'Open',
    'Medium',
    2,
    4,
    '2025-10-15',
    '2025-10-22',
    NULL,
    NULL,
    '2025-10-15 01:00:00',
    '2025-10-15 01:00:00',
    NULL
  ),
  (
    5,
    1,
    'QA 測試報告 #122 - RWD 跑版',
    '在 iPhone 12 Mini 裝置上，首頁選單會超出螢幕寬度。',
    'Testing',
    'Medium',
    6,
    4,
    '2025-10-15',
    '2025-10-18',
    NULL,
    NULL,
    '2025-10-15 02:30:00',
    '2025-11-15 06:29:58',
    NULL
  ),
  (
    6,
    2,
    '更新首頁 UI/UX 設計',
    '根據 Zeplin 上的 v2.0 設計稿，更新 Landing Page 視覺。',
    'In Progress',
    'High',
    2,
    3,
    '2025-10-16',
    '2025-10-25',
    NULL,
    NULL,
    '2025-10-16 03:00:00',
    '2025-11-18 01:05:47',
    NULL
  ),
  (
    7,
    2,
    '資料庫效能調校 (User Table)',
    'users 資料表在 JOIN projectmembers 時查詢過慢，請檢查 index。',
    'Testing',
    'Low',
    3,
    5,
    '2025-10-16',
    '2025-10-24',
    NULL,
    NULL,
    '2025-10-16 06:20:00',
    '2025-11-18 01:05:49',
    NULL
  ),
  (
    8,
    2,
    '完成付款流程串接 (Stripe)',
    '串接 Stripe API，處理月費訂閱邏輯。',
    'Open',
    'Critical',
    2,
    4,
    '2025-10-17',
    '2025-10-30',
    NULL,
    NULL,
    '2025-10-17 01:00:00',
    '2025-10-17 01:00:00',
    NULL
  ),
  (
    9,
    2,
    '票務系統無法處理退票',
    'Andromeda 系統的 /api/tickets/refund 路由回傳 500 錯誤。',
    'Open',
    'High',
    1,
    5,
    '2025-10-17',
    '2025-10-19',
    NULL,
    NULL,
    '2025-10-17 02:15:00',
    '2025-11-09 03:20:20',
    NULL
  ),
  (
    10,
    2,
    '新增座位圖預覽功能',
    '在選票頁面，需要增加一個即時的座位圖預覽 modal。',
    'In Progress',
    'Medium',
    1,
    5,
    '2025-10-18',
    '2025-11-10',
    NULL,
    NULL,
    '2025-10-18 07:00:00',
    '2025-11-18 01:05:47',
    NULL
  ),
  (
    18,
    11,
    '協助處理看板任務上的畫面呈現',
    '協助處理看板任務上的畫面呈現',
    'In Progress',
    'Medium',
    3,
    6,
    '2025-11-18',
    '2025-11-20',
    6,
    '2025-11-18 01:27:14',
    '2025-11-18 01:26:14',
    '2025-11-18 01:28:13',
    NULL
  ),
  (
    20,
    15,
    '[Backend] 訂單微服務 (Order Service) 專案初始化與 API 介面定義',
    '依據「企業級 ERP 系統重構計畫」的架構設計圖，請建立訂單模組 (Order Module) 的獨立微服務專案。此任務不包含完整的商業邏輯實作，重點在於專案結構確立與介面規範 (Contract) 的產出，以便前端與測試人員同步作業。\n\n具體執行項目 (Action Items)：\n\n專案初始化：\n\n使用 NestJS (TypeScript) 建立 service-order 專案。\n\n設定 Dockerfile 與 docker-compose.yml，確保本地端可一鍵啟動開發環境。\n\n資料庫設計 (Schema Design)：\n\n在 PostgreSQL 中設計 orders 與 order_items 資料表。\n\n使用 TypeORM 或 Prisma 定義 Entity 模型，並產出初步的 Migration 檔案。\n\nAPI 介面實作 (Interface Definition)：\n\n定義以下 API 的 Request/Response DTO (Data Transfer Object)：\n\nPOST /api/v1/orders (建立訂單)\n\nGET /api/v1/orders/{id} (查詢訂單詳情)\n\nPATCH /api/v1/orders/{id}/status (更新訂單狀態)\n\n整合 Swagger (OpenAPI)，自動生成線上 API 文件。',
    'Open',
    'Medium',
    3,
    4,
    '2025-11-20',
    '2025-11-30',
    NULL,
    NULL,
    '2025-11-19 05:56:59',
    '2025-11-19 05:56:59',
    NULL
  ),
  (
    21,
    16,
    '[Backend] 優惠券搶購核心機制實作：Redis Lua Script 與非同步寫入',
    '根據專案需求，我們預期會有 50,000 人同時在線搶購。直接讀寫關聯式資料庫 (MySQL/PostgreSQL) 會導致鎖死 (Deadlock) 或崩潰。 此任務需實作「優惠券搶購」的核心邏輯，利用 Redis 原子性操作 (Atomic Operations) 來處理庫存扣減，並將實際訂單寫入透過 Message Queue 非同步處理。\n\n具體執行項目 (Action Items)：\n\nRedis 架構設計：\n\n設計 Key 的命名規範 (e.g., event:2025_summer:coupon:inventory).\n\n撰寫 Lua Script：確保「檢查庫存」與「扣減庫存」兩個動作在 Redis 中是原子執行 (Atomic execution)，徹底杜絕超賣風險。\n非同步寫入實作 (Async Processing)：\n設定 Message Queue (如 RabbitMQ 或 Redis Stream)。\n當 Redis 扣減成功後，將 user_id 與 coupon_id 丟入 Queue，由 Worker 慢慢寫入 Database，避免資料庫瞬間過載。\n單元壓力測試 (Micro-benchmark)：\n撰寫簡單的 script，模擬 1000 個 concurrent requests 同時搶 10 張票，驗證庫存是否準確歸零且無負數。',
    'Closed',
    'Medium',
    3,
    6,
    '2025-11-19',
    '2025-11-30',
    6,
    '2025-11-19 06:06:14',
    '2025-11-19 06:03:25',
    '2025-11-19 06:06:14',
    NULL
  );

/*!40000 ALTER TABLE `missions` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `missiontags`
--
DROP TABLE IF EXISTS `missiontags`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `missiontags` (
    `MissionID` int NOT NULL,
    `TagID` int NOT NULL,
    PRIMARY KEY (`MissionID`, `TagID`),
    KEY `TagID` (`TagID`)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `missiontags`
--
LOCK TABLES `missiontags` WRITE;

/*!40000 ALTER TABLE `missiontags` DISABLE KEYS */;

INSERT INTO
  `missiontags`
VALUES
  (1, 1),
  (2, 2),
  (2, 3),
  (3, 4),
  (1, 7);

/*!40000 ALTER TABLE `missiontags` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `notification_settings`
--
DROP TABLE IF EXISTS `notification_settings`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `notification_settings` (
    `SettingID` int NOT NULL AUTO_INCREMENT,
    `CronIntervalMinutes` int NOT NULL DEFAULT '10',
    `NotifyBeforeMinutes` int NOT NULL DEFAULT '360',
    `IsEnabled` tinyint (1) NOT NULL DEFAULT '1',
    `UpdatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`SettingID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_settings`
--
LOCK TABLES `notification_settings` WRITE;

/*!40000 ALTER TABLE `notification_settings` DISABLE KEYS */;

INSERT INTO
  `notification_settings`
VALUES
  (1, 5, 1440, 1, '2025-11-17 13:55:02');

/*!40000 ALTER TABLE `notification_settings` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `notificationlog`
--
DROP TABLE IF EXISTS `notificationlog`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `notificationlog` (
    `LogID` int NOT NULL AUTO_INCREMENT,
    `Channel` enum ('Email', 'Slack', 'Webhook', 'Teams') NOT NULL,
    `Recipient` varchar(255) NOT NULL,
    `Content` text,
    `Status` enum ('Sent', 'Failed') NOT NULL,
    `ErrorMessage` text,
    `SentAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`LogID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificationlog`
--
LOCK TABLES `notificationlog` WRITE;

/*!40000 ALTER TABLE `notificationlog` DISABLE KEYS */;

INSERT INTO
  `notificationlog`
VALUES
  (
    1,
    'Email',
    'rd.alice@example.com',
    'You were assigned Mission #1',
    'Sent',
    NULL,
    '2025-10-14 01:33:19'
  );

/*!40000 ALTER TABLE `notificationlog` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `notifications`
--
DROP TABLE IF EXISTS `notifications`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `notifications` (
    `NotificationID` int NOT NULL AUTO_INCREMENT,
    `UserID` int NOT NULL,
    `ProjectID` int NOT NULL,
    `MissionID` int DEFAULT NULL,
    `Content` text NOT NULL,
    `Link` varchar(255) DEFAULT NULL,
    `IsRead` tinyint (1) NOT NULL DEFAULT '0',
    `CreatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`NotificationID`),
    KEY `UserID` (`UserID`),
    KEY `ProjectID` (`ProjectID`),
    KEY `MissionID` (`MissionID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 47 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--
LOCK TABLES `notifications` WRITE;

/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;

INSERT INTO
  `notifications`
VALUES
  (
    1,
    4,
    1,
    1,
    'Jane Doe (PM) 指派了此任務給您',
    '/projects/1/missions/1',
    0,
    '2025-10-14 01:33:19',
    NULL
  ),
  (
    2,
    5,
    1,
    2,
    'Tom Smith (RD_Leader) 指派了此任務給您',
    '/projects/1/missions/2',
    1,
    '2025-10-14 01:33:19',
    '2025-11-11 05:42:41'
  ),
  (
    3,
    1,
    3,
    NULL,
    '1 已建立專案，並交由 1 負責。',
    NULL,
    1,
    '2025-11-11 05:42:14',
    NULL
  ),
  (
    4,
    1,
    4,
    NULL,
    '2 已建立專案，並交由 2 負責。',
    NULL,
    0,
    '2025-11-13 03:11:51',
    NULL
  ),
  (
    5,
    3,
    5,
    NULL,
    'System Admin 已建立專案，並交由 Tom Smith 負責。',
    NULL,
    1,
    '2025-11-13 03:17:50',
    '2025-11-13 06:11:16'
  ),
  (
    6,
    1,
    6,
    NULL,
    'System Admin 已建立專案，並交由 System Admin 負責。',
    NULL,
    1,
    '2025-11-13 06:09:56',
    NULL
  ),
  (
    7,
    1,
    7,
    NULL,
    'System Admin1 已建立專案，並交由 System Admin1 負責。',
    NULL,
    0,
    '2025-11-17 03:47:18',
    NULL
  ),
  (
    8,
    1,
    7,
    NULL,
    'System Admin1 已於 [3615615] 新增附件 å¤§å°é¡_ä¼åæ¸_v3_Finall_ç¬¬äºçµ.docx 。',
    NULL,
    0,
    '2025-11-17 03:48:06',
    NULL
  ),
  (
    9,
    1,
    7,
    NULL,
    '[3615615] 專案中的附件 (å¤§å°é¡_ä¼åæ¸_v3_Finall_ç¬¬äºçµ.docx) 已被 System Admin1 刪除。',
    NULL,
    0,
    '2025-11-17 03:48:15',
    NULL
  ),
  (
    10,
    1,
    7,
    NULL,
    'System Admin1 從 [3615615] 專案中移除了成員 Alice Johnson。',
    NULL,
    0,
    '2025-11-17 03:48:26',
    NULL
  ),
  (
    11,
    1,
    7,
    NULL,
    'System Admin1 從 [3615615] 專案中移除了成員 Charlie Brown。',
    NULL,
    0,
    '2025-11-17 03:48:32',
    NULL
  ),
  (
    12,
    1,
    7,
    NULL,
    'System Admin1 已新增或更新成員 Alice Johnson至 [3615615] 專案，角色: RDL。',
    NULL,
    0,
    '2025-11-17 03:48:38',
    NULL
  ),
  (
    13,
    1,
    7,
    NULL,
    'System Admin1 已新增或更新成員 Charlie Brown至 [3615615] 專案，角色: QA。',
    NULL,
    0,
    '2025-11-17 03:48:46',
    NULL
  ),
  (
    14,
    1,
    7,
    NULL,
    '[3615615]專案狀態從 10 轉換到 20。',
    NULL,
    0,
    '2025-11-17 03:49:04',
    NULL
  ),
  (
    15,
    3,
    8,
    NULL,
    'Jane Doe 已建立專案，並交由 Tom Smith 負責。',
    NULL,
    0,
    '2025-11-17 03:51:29',
    NULL
  ),
  (
    16,
    1,
    8,
    NULL,
    'Jane Doe 已於 [qqqqqqqqqq] 新增附件 åäººèªå³_åæ¦æ¡Tedliu_V6_software_enginner.docx 。',
    NULL,
    0,
    '2025-11-17 03:51:47',
    NULL
  ),
  (
    17,
    1,
    8,
    NULL,
    'Jane Doe 已新增或更新成員 New QA Memb11至 [qqqqqqqqqq] 專案，角色: 未知使用者。',
    NULL,
    0,
    '2025-11-17 03:51:57',
    NULL
  ),
  (
    18,
    1,
    8,
    NULL,
    'Jane Doe已將[qqqqqqqqqq]專案已更新',
    NULL,
    0,
    '2025-11-17 03:52:24',
    NULL
  ),
  (
    19,
    1,
    8,
    NULL,
    '專案經理轉讓操作：由 Jane Doe 轉讓給 System Admin1。',
    NULL,
    0,
    '2025-11-17 03:52:48',
    NULL
  ),
  (
    20,
    3,
    9,
    NULL,
    'Jane Doe 已建立專案，並交由 Tom Smith 負責。',
    NULL,
    0,
    '2025-11-17 03:53:17',
    NULL
  ),
  (
    21,
    1,
    9,
    NULL,
    '[qqqqqqqqqq]專案狀態從 10 轉換到 20。',
    NULL,
    0,
    '2025-11-17 03:53:27',
    NULL
  ),
  (
    22,
    1,
    9,
    NULL,
    '[qqqqqqqqqq]專案狀態從 20 轉換到 30。',
    NULL,
    0,
    '2025-11-17 03:53:31',
    NULL
  ),
  (
    23,
    1,
    9,
    NULL,
    '[qqqqqqqqqq]專案狀態從 30 轉換到 40。',
    NULL,
    0,
    '2025-11-17 03:56:13',
    NULL
  ),
  (
    24,
    1,
    9,
    NULL,
    'RDL Tom Smith 對專案[qqqqqqqqqq]執行最終蓋章確認。',
    NULL,
    0,
    '2025-11-17 03:56:42',
    NULL
  ),
  (
    25,
    1,
    9,
    NULL,
    '[qqqqqqqqqq]專案狀態從 50 轉換到 60。',
    NULL,
    0,
    '2025-11-17 03:56:50',
    NULL
  ),
  (
    26,
    1,
    4,
    NULL,
    'Jane Doe 已於 [45978978] 新增附件 111.jpg 。',
    NULL,
    0,
    '2025-11-17 04:39:19',
    NULL
  ),
  (
    27,
    1,
    10,
    NULL,
    'System Admin1已將[ghdgh]專案已更新',
    NULL,
    0,
    '2025-11-17 05:56:32',
    NULL
  ),
  (
    28,
    1,
    11,
    NULL,
    '[看板任務]專案狀態從 10 轉換到 20。',
    NULL,
    0,
    '2025-11-18 01:24:33',
    NULL
  ),
  (
    29,
    1,
    11,
    NULL,
    '[看板任務]專案狀態從 20 轉換到 30。',
    NULL,
    0,
    '2025-11-18 01:26:20',
    NULL
  ),
  (
    30,
    1,
    11,
    NULL,
    '[看板任務]專案狀態從 30 轉換到 40。',
    NULL,
    0,
    '2025-11-18 01:27:18',
    NULL
  ),
  (
    31,
    1,
    11,
    NULL,
    '[看板任務]專案狀態從 50 轉換到 60。',
    NULL,
    0,
    '2025-11-18 01:27:41',
    NULL
  ),
  (
    32,
    1,
    12,
    NULL,
    'Jane Doe 已刪除 [123] 專案。',
    NULL,
    0,
    '2025-11-18 05:37:28',
    NULL
  ),
  (
    33,
    1,
    13,
    NULL,
    'Jane Doe 已於 [Test] 新增附件 87.txt 。',
    NULL,
    0,
    '2025-11-18 06:00:32',
    NULL
  ),
  (
    34,
    1,
    13,
    NULL,
    '[Test]專案狀態從 10 轉換到 20。',
    NULL,
    0,
    '2025-11-18 06:01:04',
    NULL
  ),
  (
    35,
    1,
    13,
    NULL,
    '[Test]專案狀態從 20 轉換到 30。',
    NULL,
    0,
    '2025-11-18 06:02:57',
    NULL
  ),
  (
    36,
    1,
    13,
    NULL,
    '[Test]專案狀態從 30 轉換到 40。',
    NULL,
    0,
    '2025-11-18 06:08:10',
    NULL
  ),
  (
    37,
    1,
    13,
    NULL,
    '[Test]專案狀態從 50 轉換到 60。',
    NULL,
    0,
    '2025-11-18 06:09:46',
    NULL
  ),
  (
    38,
    1,
    15,
    NULL,
    'Jane Doe 已於 [企業級 ERP 系統重構計畫] 新增附件 Project1_SPEC.txt 。',
    NULL,
    0,
    '2025-11-19 05:43:28',
    NULL
  ),
  (
    39,
    1,
    16,
    NULL,
    'Quen Lin 已於 [2025 夏季新品活動頁面開發與高併發壓測 (2025 Summer Event Site Dev & Stress Test)] 新增附件 Project2_SPEC.txt 。',
    NULL,
    0,
    '2025-11-19 05:53:26',
    NULL
  ),
  (
    40,
    1,
    15,
    NULL,
    '[企業級 ERP 系統重構計畫]專案狀態從 10 轉換到 20。',
    NULL,
    0,
    '2025-11-19 05:54:30',
    NULL
  ),
  (
    41,
    1,
    15,
    NULL,
    '[企業級 ERP 系統重構計畫]專案狀態從 20 轉換到 30。',
    NULL,
    0,
    '2025-11-19 05:57:09',
    NULL
  ),
  (
    42,
    1,
    16,
    NULL,
    '[2025 夏季新品活動頁面開發與高併發壓測 (2025 Summer Event Site Dev & Stress Test)]專案狀態從 10 轉換到 20。',
    NULL,
    0,
    '2025-11-19 05:57:43',
    NULL
  ),
  (
    43,
    1,
    16,
    NULL,
    '[2025 夏季新品活動頁面開發與高併發壓測 (2025 Summer Event Site Dev & Stress Test)]專案狀態從 20 轉換到 30。',
    NULL,
    0,
    '2025-11-19 06:03:30',
    NULL
  ),
  (
    44,
    1,
    16,
    NULL,
    '[2025 夏季新品活動頁面開發與高併發壓測 (2025 Summer Event Site Dev & Stress Test)]專案狀態從 30 轉換到 40。',
    NULL,
    0,
    '2025-11-19 06:06:35',
    NULL
  ),
  (
    45,
    1,
    15,
    NULL,
    'Jane Doe已將[企業級 ERP 系統重構計畫]專案已更新',
    NULL,
    0,
    '2025-11-19 07:17:16',
    NULL
  ),
  (
    46,
    1,
    16,
    NULL,
    'Quen Lin已將[2025 夏季新品活動頁面開發與高併發壓測 (2025 Summer Event Site Dev & Stress Test)]專案已更新',
    NULL,
    0,
    '2025-11-19 07:19:58',
    NULL
  );

/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `permissions`
--
DROP TABLE IF EXISTS `permissions`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `permissions` (
    `PermissionID` int NOT NULL AUTO_INCREMENT,
    `PermissionName` varchar(100) NOT NULL,
    `Description` text,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`PermissionID`),
    UNIQUE KEY `PermissionName` (`PermissionName`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 14 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--
LOCK TABLES `permissions` WRITE;

/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;

INSERT INTO
  `permissions`
VALUES
  (1, 'manage_users', '管理所有使用者帳號（建立/停用）', NULL),
  (2, 'manage_roles_permissions', '管理角色與權限分配', NULL),
  (3, 'create_project', '建立新專案', NULL),
  (4, 'edit_project', '編輯專案資訊', NULL),
  (5, 'delete_project', '刪除專案', NULL),
  (6, 'manage_project_members', '管理專案成員', NULL),
  (7, 'create_issue', '建立 Issue', NULL),
  (8, 'edit_issue', '編輯 Issue', NULL),
  (9, 'delete_issue', '刪除 Issue', NULL),
  (10, 'assign_issue', '指派 Issue 給他人', NULL),
  (11, 'change_issue_status', '變更 Issue 狀態', NULL),
  (12, 'close_issue', '關閉/驗證已解決的 Issue', NULL),
  (13, 'view_reports', '查看專案報表', NULL);

/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `projectattachments`
--
DROP TABLE IF EXISTS `projectattachments`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `projectattachments` (
    `AttachmentID` int NOT NULL AUTO_INCREMENT,
    `ProjectID` int NOT NULL,
    `FileName` varchar(255) NOT NULL,
    `FilePath` varchar(512) NOT NULL,
    `UploadedByUserID` int NOT NULL,
    `UploadedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`AttachmentID`),
    KEY `ProjectID` (`ProjectID`),
    KEY `UploadedByUserID` (`UploadedByUserID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 8 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectattachments`
--
LOCK TABLES `projectattachments` WRITE;

/*!40000 ALTER TABLE `projectattachments` DISABLE KEYS */;

INSERT INTO
  `projectattachments`
VALUES
  (
    1,
    1,
    'Project_Phoenix_Specs.pdf',
    '/uploads/projects/1/specs.pdf',
    2,
    '2025-10-14 01:33:19',
    NULL
  ),
  (
    2,
    7,
    'å¤§å°é¡_ä¼åæ¸_v3_Finall_ç¬¬äºçµ.docx',
    '/uploads/大專題_企劃書_v3_Finall_第二組-1763351286740.docx',
    1,
    '2025-11-17 03:48:06',
    '2025-11-17 03:48:15'
  ),
  (
    3,
    8,
    'åäººèªå³_åæ¦æ¡Tedliu_V6_software_enginner.docx',
    '/uploads/個人自傳_劉敦桐Tedliu_V6_software_enginner-1763351507441.docx',
    1,
    '2025-11-17 03:51:47',
    NULL
  ),
  (
    4,
    4,
    '111.jpg',
    '/uploads/111-1763354359684.jpg',
    2,
    '2025-11-17 04:39:19',
    NULL
  ),
  (
    5,
    13,
    '87.txt',
    '/uploads/87-1763445632943.txt',
    2,
    '2025-11-18 06:00:32',
    NULL
  ),
  (
    6,
    15,
    'Project1_SPEC.txt',
    '/uploads/Project1_SPEC-1763531008656.txt',
    2,
    '2025-11-19 05:43:28',
    NULL
  ),
  (
    7,
    16,
    'Project2_SPEC.txt',
    '/uploads/Project2_SPEC-1763531606751.txt',
    25,
    '2025-11-19 05:53:26',
    NULL
  );

/*!40000 ALTER TABLE `projectattachments` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `projecthistory`
--
DROP TABLE IF EXISTS `projecthistory`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `projecthistory` (
    `HistoryID` int NOT NULL AUTO_INCREMENT,
    `ProjectID` int NOT NULL,
    `ChangedByUserID` int NOT NULL,
    `ChangeType` varchar(50) NOT NULL,
    `Detail` text,
    `OldValue` text,
    `NewValue` text,
    `ChangedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`HistoryID`),
    KEY `ProjectID` (`ProjectID`),
    KEY `ChangedByUserID` (`ChangedByUserID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 79 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projecthistory`
--
LOCK TABLES `projecthistory` WRITE;

/*!40000 ALTER TABLE `projecthistory` DISABLE KEYS */;

INSERT INTO
  `projecthistory`
VALUES
  (
    1,
    1,
    1,
    'Project Created',
    'Project initialized by System Admin.',
    NULL,
    NULL,
    '2025-10-14 01:33:19'
  ),
  (
    2,
    3,
    1,
    'PROJECT_CREATED',
    'System Admin已建立專案，並交由 1 負責。',
    NULL,
    NULL,
    '2025-11-11 05:42:14'
  ),
  (
    3,
    4,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 2 負責。',
    NULL,
    NULL,
    '2025-11-13 03:11:50'
  ),
  (
    4,
    5,
    1,
    'PROJECT_CREATED',
    'System Admin已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-13 03:17:50'
  ),
  (
    5,
    6,
    1,
    'PROJECT_CREATED',
    'System Admin已建立專案，並交由 System Admin 負責。',
    NULL,
    NULL,
    '2025-11-13 06:09:56'
  ),
  (
    6,
    7,
    1,
    'PROJECT_CREATED',
    'System Admin1已建立專案，並交由 System Admin1 負責。',
    NULL,
    NULL,
    '2025-11-17 03:47:18'
  ),
  (
    7,
    7,
    1,
    'ATTACHMENT_UPDATE',
    '附件 å¤§å°é¡_ä¼åæ¸_v3_Finall_ç¬¬äºçµ.docx 新增成功。',
    NULL,
    '{\"attachmentId\":\"2\",\"fileName\":\"å¤§å°é¡_ä¼åæ¸_v3_Finall_ç¬¬äºçµ.docx\",\"filePath\":\"/uploads/大專題_企劃書_v3_Finall_第二組-1763351286740.docx\"}',
    '2025-11-17 03:48:06'
  ),
  (
    8,
    7,
    1,
    'ATTACHMENT_UPDATE',
    '附件 2 (å¤§å°é¡_ä¼åæ¸_v3_Finall_ç¬¬äºçµ.docx) 被軟刪除。',
    '{\"attachmentId\":\"2\",\"fileName\":\"å¤§å°é¡_ä¼åæ¸_v3_Finall_ç¬¬äºçµ.docx\"}',
    NULL,
    '2025-11-17 03:48:15'
  ),
  (
    9,
    7,
    1,
    'PROJECT_PROJECTMEMBERS_UPDATE',
    '從專案中移除了成員 4。',
    '4',
    NULL,
    '2025-11-17 03:48:26'
  ),
  (
    10,
    7,
    1,
    'PROJECT_PROJECTMEMBERS_UPDATE',
    '從專案中移除了成員 6。',
    '6',
    NULL,
    '2025-11-17 03:48:32'
  ),
  (
    11,
    7,
    1,
    'PROJECT_PROJECTMEMBERS_UPDATE',
    '新增或更新成員 4，角色: 5。',
    NULL,
    '5',
    '2025-11-17 03:48:38'
  ),
  (
    12,
    7,
    1,
    'PROJECT_PROJECTMEMBERS_UPDATE',
    '新增或更新成員 6，角色: 6。',
    NULL,
    '6',
    '2025-11-17 03:48:46'
  ),
  (
    13,
    7,
    1,
    'STATE_TRANSITION',
    '專案狀態從 10 轉換到 20。',
    '10',
    '20',
    '2025-11-17 03:49:04'
  ),
  (
    14,
    8,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-17 03:51:29'
  ),
  (
    15,
    8,
    2,
    'ATTACHMENT_UPDATE',
    '附件 åäººèªå³_åæ¦æ¡Tedliu_V6_software_enginner.docx 新增成功。',
    NULL,
    '{\"attachmentId\":\"3\",\"fileName\":\"åäººèªå³_åæ¦æ¡Tedliu_V6_software_enginner.docx\",\"filePath\":\"/uploads/個人自傳_劉敦桐Tedliu_V6_software_enginner-1763351507441.docx\"}',
    '2025-11-17 03:51:47'
  ),
  (
    16,
    8,
    2,
    'PROJECT_PROJECTMEMBERS_UPDATE',
    '新增或更新成員 17，角色: 6。',
    NULL,
    '6',
    '2025-11-17 03:51:57'
  ),
  (
    17,
    8,
    2,
    'PROJECT_NAME_UPDATE',
    '變更 projectName。',
    'qqqqqqqqqq',
    'aaaaaaaaaaaaaaaaa',
    '2025-11-17 03:52:24'
  ),
  (
    18,
    8,
    2,
    'DESCRIPTION_UPDATE',
    '變更 description。',
    'qqqqqqqqqqqqqqqqqq',
    'aaaaaaaaaaaaaa',
    '2025-11-17 03:52:26'
  ),
  (
    19,
    8,
    2,
    'DATE_UPDATE',
    '變更 startDate。',
    'Sat Nov 01 2025 00:00:00 GMT+0800 (台北標準時間)',
    '2025-10-31',
    '2025-11-17 03:52:26'
  ),
  (
    20,
    8,
    2,
    'DATE_UPDATE',
    '變更 endDate。',
    'Thu Nov 06 2025 00:00:00 GMT+0800 (台北標準時間)',
    '2026-03-05',
    '2025-11-17 03:52:26'
  ),
  (
    21,
    8,
    2,
    'PROJECT_TAG_UPDATE',
    '變更 ProjectTagID。',
    '5',
    '1',
    '2025-11-17 03:52:26'
  ),
  (
    22,
    8,
    2,
    'PM_TRANSFER',
    '專案經理轉讓操作：由 2 轉讓給 1。',
    '2',
    '1',
    '2025-11-17 03:52:48'
  ),
  (
    23,
    9,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-17 03:53:17'
  ),
  (
    24,
    9,
    2,
    'STATE_TRANSITION',
    '專案狀態從 10 轉換到 20。',
    '10',
    '20',
    '2025-11-17 03:53:27'
  ),
  (
    25,
    9,
    3,
    'STATE_TRANSITION',
    '專案狀態從 20 轉換到 30。',
    '20',
    '30',
    '2025-11-17 03:53:31'
  ),
  (
    26,
    9,
    2,
    'STATE_TRANSITION',
    '專案狀態從 30 轉換到 40。',
    '30',
    '40',
    '2025-11-17 03:56:13'
  ),
  (
    27,
    9,
    3,
    'RDL_STAMP',
    'RDL 3 對專案執行最終蓋章確認。',
    NULL,
    '{\"RDLApprovedByUserID\":3,\"RDLApprovedAt\":\"2025-11-17 03:56:42\"}',
    '2025-11-17 03:56:42'
  ),
  (
    28,
    9,
    3,
    'STATE_TRANSITION',
    'RDL蓋章，狀態從 40 轉換到 50 (Completed)。',
    '40',
    '50',
    '2025-11-17 03:56:42'
  ),
  (
    29,
    9,
    2,
    'STATE_TRANSITION',
    '專案狀態從 50 轉換到 60。',
    '50',
    '60',
    '2025-11-17 03:56:50'
  ),
  (
    30,
    4,
    2,
    'ATTACHMENT_UPDATE',
    '附件 111.jpg 新增成功。',
    NULL,
    '{\"attachmentId\":\"4\",\"fileName\":\"111.jpg\",\"filePath\":\"/uploads/111-1763354359684.jpg\"}',
    '2025-11-17 04:39:19'
  ),
  (
    31,
    10,
    1,
    'PROJECT_CREATED',
    'System Admin1已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-17 05:52:40'
  ),
  (
    32,
    10,
    1,
    'PROJECT_NAME_UPDATE',
    '變更 projectName。',
    'ghdgh',
    'hgjfhjgfjfgh',
    '2025-11-17 05:56:32'
  ),
  (
    33,
    10,
    1,
    'DATE_UPDATE',
    '變更 startDate。',
    'Mon Nov 17 2025 00:00:00 GMT+0800 (台北標準時間)',
    '2025-11-16',
    '2025-11-17 05:56:32'
  ),
  (
    34,
    10,
    1,
    'DATE_UPDATE',
    '變更 endDate。',
    'Mon Nov 17 2025 00:00:00 GMT+0800 (台北標準時間)',
    '2025-11-17',
    '2025-11-17 05:56:32'
  ),
  (
    35,
    10,
    1,
    'PROJECT_PROJECTMEMBERS_UPDATE',
    '從專案中移除了成員 6。',
    '6',
    NULL,
    '2025-11-17 05:57:35'
  ),
  (
    36,
    11,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-18 01:18:57'
  ),
  (
    37,
    11,
    2,
    'STATE_TRANSITION',
    '專案狀態從 10 轉換到 20。',
    '10',
    '20',
    '2025-11-18 01:24:33'
  ),
  (
    38,
    11,
    3,
    'STATE_TRANSITION',
    '專案狀態從 20 轉換到 30。',
    '20',
    '30',
    '2025-11-18 01:26:20'
  ),
  (
    39,
    11,
    4,
    'STATE_TRANSITION',
    '專案狀態從 30 轉換到 40。',
    '30',
    '40',
    '2025-11-18 01:27:18'
  ),
  (
    40,
    11,
    3,
    'RDL_STAMP',
    'RDL 3 對專案執行最終蓋章確認。',
    NULL,
    '{\"RDLApprovedByUserID\":3,\"RDLApprovedAt\":\"2025-11-18 01:27:35\"}',
    '2025-11-18 01:27:35'
  ),
  (
    41,
    11,
    3,
    'STATE_TRANSITION',
    'RDL蓋章，狀態從 40 轉換到 50 (Completed)。',
    '40',
    '50',
    '2025-11-18 01:27:35'
  ),
  (
    42,
    11,
    2,
    'STATE_TRANSITION',
    '專案狀態從 50 轉換到 60。',
    '50',
    '60',
    '2025-11-18 01:27:41'
  ),
  (
    43,
    12,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-18 05:22:12'
  ),
  (
    44,
    12,
    2,
    'PROJECT_DELETED',
    '專案執行軟刪除。',
    NULL,
    NULL,
    '2025-11-18 05:37:28'
  ),
  (
    45,
    13,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-18 06:00:26'
  ),
  (
    46,
    13,
    2,
    'ATTACHMENT_UPDATE',
    '附件 87.txt 新增成功。',
    NULL,
    '{\"attachmentId\":\"5\",\"fileName\":\"87.txt\",\"filePath\":\"/uploads/87-1763445632943.txt\"}',
    '2025-11-18 06:00:32'
  ),
  (
    47,
    13,
    2,
    'STATE_TRANSITION',
    '專案狀態從 10 轉換到 20。',
    '10',
    '20',
    '2025-11-18 06:01:04'
  ),
  (
    48,
    13,
    3,
    'PROJECT_PROJECTMEMBERS_UPDATE',
    '新增或更新成員 5，角色: 5。',
    NULL,
    '5',
    '2025-11-18 06:02:37'
  ),
  (
    49,
    13,
    3,
    'STATE_TRANSITION',
    '專案狀態從 20 轉換到 30。',
    '20',
    '30',
    '2025-11-18 06:02:57'
  ),
  (
    50,
    13,
    4,
    'STATE_TRANSITION',
    '專案狀態從 30 轉換到 40。',
    '30',
    '40',
    '2025-11-18 06:08:10'
  ),
  (
    51,
    13,
    3,
    'RDL_STAMP',
    'RDL 3 對專案執行最終蓋章確認。',
    NULL,
    '{\"RDLApprovedByUserID\":3,\"RDLApprovedAt\":\"2025-11-18 06:09:17\"}',
    '2025-11-18 06:09:17'
  ),
  (
    52,
    13,
    3,
    'STATE_TRANSITION',
    'RDL蓋章，狀態從 40 轉換到 50 (Completed)。',
    '40',
    '50',
    '2025-11-18 06:09:17'
  ),
  (
    53,
    13,
    2,
    'STATE_TRANSITION',
    '專案狀態從 50 轉換到 60。',
    '50',
    '60',
    '2025-11-18 06:09:46'
  ),
  (
    54,
    14,
    25,
    'PROJECT_CREATED',
    'PM2已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-18 06:25:06'
  ),
  (
    55,
    15,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-19 05:43:21'
  ),
  (
    56,
    15,
    2,
    'ATTACHMENT_UPDATE',
    '附件 Project1_SPEC.txt 新增成功。',
    NULL,
    '{\"attachmentId\":\"6\",\"fileName\":\"Project1_SPEC.txt\",\"filePath\":\"/uploads/Project1_SPEC-1763531008656.txt\"}',
    '2025-11-19 05:43:28'
  ),
  (
    57,
    16,
    25,
    'PROJECT_CREATED',
    'Quen Lin已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-19 05:53:20'
  ),
  (
    58,
    16,
    25,
    'ATTACHMENT_UPDATE',
    '附件 Project2_SPEC.txt 新增成功。',
    NULL,
    '{\"attachmentId\":\"7\",\"fileName\":\"Project2_SPEC.txt\",\"filePath\":\"/uploads/Project2_SPEC-1763531606751.txt\"}',
    '2025-11-19 05:53:26'
  ),
  (
    59,
    15,
    2,
    'PROJECT_PROJECTMEMBERS_UPDATE',
    '新增或更新成員 5，角色: 5。',
    NULL,
    '5',
    '2025-11-19 05:54:04'
  ),
  (
    60,
    15,
    2,
    'STATE_TRANSITION',
    '專案狀態從 10 轉換到 20。',
    '10',
    '20',
    '2025-11-19 05:54:30'
  ),
  (
    61,
    15,
    3,
    'STATE_TRANSITION',
    '專案狀態從 20 轉換到 30。',
    '20',
    '30',
    '2025-11-19 05:57:09'
  ),
  (
    62,
    16,
    25,
    'STATE_TRANSITION',
    '專案狀態從 10 轉換到 20。',
    '10',
    '20',
    '2025-11-19 05:57:43'
  ),
  (
    63,
    16,
    3,
    'STATE_TRANSITION',
    '專案狀態從 20 轉換到 30。',
    '20',
    '30',
    '2025-11-19 06:03:30'
  ),
  (
    64,
    16,
    3,
    'STATE_TRANSITION',
    '專案狀態從 30 轉換到 40。',
    '30',
    '40',
    '2025-11-19 06:06:35'
  ),
  (
    65,
    17,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom SmithXX 負責。',
    NULL,
    NULL,
    '2025-11-19 06:31:24'
  ),
  (
    66,
    18,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-19 06:31:58'
  ),
  (
    67,
    19,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-19 06:32:30'
  ),
  (
    68,
    20,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-19 06:33:59'
  ),
  (
    69,
    21,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-19 06:36:33'
  ),
  (
    70,
    22,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-19 06:43:17'
  ),
  (
    71,
    23,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-19 06:43:53'
  ),
  (
    72,
    24,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-19 06:45:24'
  ),
  (
    73,
    15,
    2,
    'DATE_UPDATE',
    '變更 startDate。',
    'Thu Nov 20 2025 00:00:00 GMT+0800 (Taiwan Standard Time)',
    '2025-11-19',
    '2025-11-19 07:17:16'
  ),
  (
    74,
    15,
    2,
    'DATE_UPDATE',
    '變更 endDate。',
    'Sun Nov 30 2025 00:00:00 GMT+0800 (Taiwan Standard Time)',
    '2025-11-25',
    '2025-11-19 07:17:16'
  ),
  (
    75,
    16,
    25,
    'PROJECT_NAME_UPDATE',
    '變更 projectName。',
    '2025 夏季新品活動頁面開發與高併發壓測 (2025 Summer Event Site Dev & Stress Test)',
    '2025 夏季新品活動頁面開發與高併發壓測 ',
    '2025-11-19 07:19:58'
  ),
  (
    76,
    16,
    25,
    'DATE_UPDATE',
    '變更 startDate。',
    'Thu Nov 20 2025 00:00:00 GMT+0800 (Taiwan Standard Time)',
    '2025-11-19',
    '2025-11-19 07:19:58'
  ),
  (
    77,
    16,
    25,
    'DATE_UPDATE',
    '變更 endDate。',
    'Sun Nov 30 2025 00:00:00 GMT+0800 (Taiwan Standard Time)',
    '2025-11-26',
    '2025-11-19 07:19:58'
  ),
  (
    78,
    25,
    2,
    'PROJECT_CREATED',
    'Jane Doe已建立專案，並交由 Tom Smith 負責。',
    NULL,
    NULL,
    '2025-11-19 08:01:32'
  );

/*!40000 ALTER TABLE `projecthistory` ENABLE KEYS */;

UNLOCK TABLES;

--/*  */
-- Table structure for table `projectmembers`
--
DROP TABLE IF EXISTS `projectmembers`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `projectmembers` (
    `ProjectMemberID` int NOT NULL AUTO_INCREMENT,
    `ProjectID` int NOT NULL,
    `UserID` int NOT NULL,
    `RoleID` int NOT NULL,
    `JoinedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`ProjectMemberID`),
    UNIQUE KEY `uk_project_user` (`ProjectID`, `UserID`),
    KEY `UserID` (`UserID`),
    KEY `RoleID` (`RoleID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 118 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectmembers`
--
LOCK TABLES `projectmembers` WRITE;

/*!40000 ALTER TABLE `projectmembers` DISABLE KEYS */;

INSERT INTO
  `projectmembers`
VALUES
  (1, 1, 2, 3, '2025-10-14 01:33:19'),
  (2, 1, 3, 4, '2025-10-14 01:33:19'),
  (3, 1, 4, 5, '2025-10-14 01:33:19'),
  (4, 1, 6, 6, '2025-10-14 01:33:19'),
  (5, 2, 1, 1, '2025-10-14 01:33:19'),
  (6, 2, 5, 5, '2025-10-14 01:33:19'),
  (7, 3, 1, 3, '2025-11-11 05:42:14'),
  (8, 3, 3, 4, '2025-11-11 05:42:14'),
  (9, 3, 4, 5, '2025-11-11 05:42:14'),
  (10, 3, 5, 5, '2025-11-11 05:42:14'),
  (11, 3, 6, 6, '2025-11-11 05:42:14'),
  (12, 4, 2, 3, '2025-11-13 03:11:50'),
  (13, 4, 3, 4, '2025-11-13 03:11:50'),
  (14, 4, 4, 5, '2025-11-13 03:11:50'),
  (15, 4, 5, 5, '2025-11-13 03:11:50'),
  (16, 4, 6, 6, '2025-11-13 03:11:50'),
  (17, 4, 15, 6, '2025-11-13 03:11:50'),
  (18, 4, 17, 6, '2025-11-13 03:11:50'),
  (19, 5, 1, 3, '2025-11-13 03:17:50'),
  (20, 5, 3, 4, '2025-11-13 03:17:50'),
  (21, 5, 4, 5, '2025-11-13 03:17:50'),
  (22, 5, 5, 5, '2025-11-13 03:17:50'),
  (23, 5, 15, 6, '2025-11-13 03:17:50'),
  (24, 5, 17, 6, '2025-11-13 03:17:50'),
  (25, 6, 1, 4, '2025-11-13 06:09:56'),
  (26, 6, 5, 5, '2025-11-13 06:09:56'),
  (27, 6, 15, 6, '2025-11-13 06:09:56'),
  (29, 7, 1, 4, '2025-11-17 03:47:18'),
  (31, 7, 5, 5, '2025-11-17 03:47:18'),
  (33, 7, 15, 6, '2025-11-17 03:47:18'),
  (34, 7, 17, 6, '2025-11-17 03:47:18'),
  (36, 7, 4, 5, '2025-11-17 03:48:38'),
  (37, 7, 6, 6, '2025-11-17 03:48:46'),
  (39, 8, 3, 4, '2025-11-17 03:51:29'),
  (40, 8, 4, 5, '2025-11-17 03:51:29'),
  (41, 8, 6, 6, '2025-11-17 03:51:29'),
  (42, 8, 15, 6, '2025-11-17 03:51:29'),
  (43, 8, 17, 6, '2025-11-17 03:51:57'),
  (44, 8, 1, 3, '2025-11-17 03:52:51'),
  (45, 9, 2, 3, '2025-11-17 03:53:17'),
  (46, 9, 3, 4, '2025-11-17 03:53:17'),
  (47, 9, 5, 5, '2025-11-17 03:53:17'),
  (48, 9, 15, 6, '2025-11-17 03:53:17'),
  (49, 10, 1, 3, '2025-11-17 05:52:40'),
  (50, 10, 3, 4, '2025-11-17 05:52:40'),
  (51, 10, 4, 5, '2025-11-17 05:52:40'),
  (52, 10, 5, 5, '2025-11-17 05:52:40'),
  (54, 10, 15, 6, '2025-11-17 05:52:40'),
  (55, 11, 2, 3, '2025-11-18 01:18:57'),
  (56, 11, 3, 4, '2025-11-18 01:18:57'),
  (57, 11, 4, 5, '2025-11-18 01:18:57'),
  (58, 11, 6, 6, '2025-11-18 01:18:57'),
  (59, 12, 2, 3, '2025-11-18 05:22:12'),
  (60, 12, 3, 4, '2025-11-18 05:22:12'),
  (61, 12, 4, 5, '2025-11-18 05:22:12'),
  (62, 12, 6, 6, '2025-11-18 05:22:12'),
  (63, 13, 2, 3, '2025-11-18 06:00:26'),
  (64, 13, 3, 4, '2025-11-18 06:00:26'),
  (65, 13, 4, 5, '2025-11-18 06:00:26'),
  (66, 13, 6, 6, '2025-11-18 06:00:26'),
  (67, 13, 5, 5, '2025-11-18 06:02:37'),
  (68, 14, 25, 3, '2025-11-18 06:25:06'),
  (69, 14, 3, 4, '2025-11-18 06:25:06'),
  (70, 14, 5, 5, '2025-11-18 06:25:06'),
  (71, 14, 6, 6, '2025-11-18 06:25:06'),
  (72, 15, 2, 3, '2025-11-19 05:43:21'),
  (73, 15, 3, 4, '2025-11-19 05:43:21'),
  (74, 15, 4, 5, '2025-11-19 05:43:21'),
  (75, 15, 6, 6, '2025-11-19 05:43:21'),
  (76, 16, 25, 3, '2025-11-19 05:53:20'),
  (77, 16, 3, 4, '2025-11-19 05:53:20'),
  (78, 16, 4, 5, '2025-11-19 05:53:20'),
  (79, 16, 5, 5, '2025-11-19 05:53:20'),
  (80, 16, 6, 6, '2025-11-19 05:53:20'),
  (81, 15, 5, 5, '2025-11-19 05:54:04'),
  (82, 17, 2, 3, '2025-11-19 06:31:24'),
  (83, 17, 1, 4, '2025-11-19 06:31:24'),
  (84, 17, 4, 5, '2025-11-19 06:31:24'),
  (85, 17, 6, 6, '2025-11-19 06:31:24'),
  (86, 18, 2, 3, '2025-11-19 06:31:58'),
  (87, 18, 3, 4, '2025-11-19 06:31:58'),
  (88, 18, 4, 5, '2025-11-19 06:31:58'),
  (89, 18, 6, 6, '2025-11-19 06:31:58'),
  (90, 19, 2, 3, '2025-11-19 06:32:30'),
  (91, 19, 3, 4, '2025-11-19 06:32:30'),
  (92, 19, 4, 5, '2025-11-19 06:32:30'),
  (93, 19, 6, 6, '2025-11-19 06:32:30'),
  (94, 20, 2, 3, '2025-11-19 06:33:59'),
  (95, 20, 3, 4, '2025-11-19 06:33:59'),
  (96, 20, 4, 5, '2025-11-19 06:33:59'),
  (97, 20, 6, 6, '2025-11-19 06:33:59'),
  (98, 21, 2, 3, '2025-11-19 06:36:33'),
  (99, 21, 3, 4, '2025-11-19 06:36:33'),
  (100, 21, 4, 5, '2025-11-19 06:36:33'),
  (101, 21, 6, 6, '2025-11-19 06:36:33'),
  (102, 22, 2, 3, '2025-11-19 06:43:17'),
  (103, 22, 3, 4, '2025-11-19 06:43:17'),
  (104, 22, 4, 5, '2025-11-19 06:43:17'),
  (105, 22, 6, 6, '2025-11-19 06:43:17'),
  (106, 23, 2, 3, '2025-11-19 06:43:53'),
  (107, 23, 3, 4, '2025-11-19 06:43:53'),
  (108, 23, 4, 5, '2025-11-19 06:43:53'),
  (109, 23, 6, 6, '2025-11-19 06:43:53'),
  (110, 24, 2, 3, '2025-11-19 06:45:24'),
  (111, 24, 3, 4, '2025-11-19 06:45:24'),
  (112, 24, 4, 5, '2025-11-19 06:45:24'),
  (113, 24, 6, 6, '2025-11-19 06:45:24'),
  (114, 25, 2, 3, '2025-11-19 08:01:32'),
  (115, 25, 3, 4, '2025-11-19 08:01:32'),
  (116, 25, 4, 5, '2025-11-19 08:01:32'),
  (117, 25, 6, 6, '2025-11-19 08:01:32');

/*!40000 ALTER TABLE `projectmembers` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `projects`
--
DROP TABLE IF EXISTS `projects`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `projects` (
    `ProjectID` int NOT NULL AUTO_INCREMENT,
    `ProjectName` varchar(255) NOT NULL,
    `Description` text,
    `OwnerUserID` int NOT NULL,
    `StartDate` date DEFAULT NULL,
    `EndDate` date DEFAULT NULL,
    `IsEndDateNotified` int NOT NULL DEFAULT '0',
    `CurrentStateID` int DEFAULT NULL,
    `RDLApprovedByUserID` int DEFAULT NULL,
    `RDLApprovedAt` timestamp NULL DEFAULT NULL,
    `ProjectTagID` int DEFAULT NULL,
    `CreatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    `UpdatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`ProjectID`),
    KEY `idx_project_tag` (`ProjectTagID`),
    KEY `OwnerUserID` (`OwnerUserID`),
    KEY `RDLApprovedByUserID` (`RDLApprovedByUserID`),
    KEY `fk_projects_current_state` (`CurrentStateID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 26 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--
LOCK TABLES `projects` WRITE;

/*!40000 ALTER TABLE `projects` DISABLE KEYS */;

INSERT INTO
  `projects`
VALUES
  (
    1,
    'Project Phoenix CRM',
    '一個全新的客戶關係管理系統 Web App 開發專案',
    2,
    '2025-10-01',
    '2026-03-31',
    0,
    1,
    NULL,
    NULL,
    5,
    '2025-10-14 01:33:19',
    '2025-10-14 01:33:19',
    NULL
  ),
  (
    2,
    'Andromeda Ticketing System',
    '舊有票務系統的日常維護與 Bug 修復',
    1,
    '2025-09-15',
    NULL,
    0,
    6,
    NULL,
    NULL,
    2,
    '2025-10-14 01:33:19',
    '2025-10-14 01:33:19',
    NULL
  ),
  (
    3,
    'AI 智能客服機器人導入',
    '整合 OpenAI GPT-4 模型至公司官網客服系統。目標為降低 50% 的人工客服負擔，需訓練專屬 Knowledge Base 以回答產品常見問題。',
    3,
    '2025-12-01',
    '2026-02-28',
    0,
    10,
    NULL,
    NULL,
    6,
    '2025-11-19 06:00:00',
    '2025-11-19 06:00:00',
    NULL
  ),
  (
    4,
    'iOS App 3.0 全面改版',
    '將 App 架構從 UIKit 遷移至 SwiftUI，並支援 iOS 19 新特性（如 Widget 互動）。包含介面深色模式 (Dark Mode) 優化與效能提升。',
    4,
    '2025-11-15',
    '2026-01-20',
    0,
    20,
    NULL,
    NULL,
    1,
    '2025-11-19 06:05:00',
    '2025-11-19 06:05:00',
    NULL
  ),
  (
    5,
    '辦公室網路基礎建設升級',
    '汰換舊有路由器，全面升級至 Wi-Fi 7 環境。包含防火牆規則重設與 Guest Network 隔離設定，以提升內部資訊安全。',
    1,
    '2025-11-01',
    '2025-11-15',
    1,
    50,
    3,
    '2025-11-15 02:00:00',
    5,
    '2025-11-19 06:10:00',
    '2025-11-19 06:25:02',
    NULL
  ),
  (
    6,
    '年度資安滲透測試 (Penetration Test)',
    '委託外部白帽駭客團隊針對主網站與 API 進行滲透測試。產出弱點掃描報告並由內部團隊進行修補（Fix Vulnerabilities）。',
    2,
    '2025-11-25',
    '2025-12-10',
    0,
    10,
    NULL,
    NULL,
    2,
    '2025-11-19 06:15:00',
    '2025-11-19 06:15:00',
    NULL
  ),
  (
    7,
    '官方部落格 SEO 優化專案',
    '針對 Core Web Vitals 進行效能調優（LCP < 2.5s）。內容策略調整與關鍵字佈局，目標提升自然搜尋流量 (Organic Traffic) 30%。',
    25,
    '2025-10-20',
    '2025-12-20',
    0,
    30,
    NULL,
    NULL,
    6,
    '2025-11-19 06:20:00',
    '2025-11-19 06:20:00',
    NULL
  ),
  (
    8,
    '舊版會計系統資料封存',
    '將 2020 年以前的歷史財務資料從 Oracle 資料庫遷移至冷儲存 (Cold Storage)，並開發唯讀查詢介面供稽核使用。',
    7,
    '2025-10-01',
    '2025-10-31',
    0,
    60,
    3,
    '2025-11-01 01:00:00',
    3,
    '2025-11-19 06:25:00',
    '2025-11-19 06:25:00',
    NULL
  ),
  (
    9,
    '倉庫溫濕度 IoT 監控平台',
    '接收來自倉庫感測器 (MQTT) 的溫濕度數據，即時顯示於儀表板。當數值異常時，透過 Line Notify 發送警報給倉管人員。',
    5,
    '2025-12-05',
    '2026-01-15',
    0,
    10,
    NULL,
    NULL,
    4,
    '2025-11-19 06:30:00',
    '2025-11-19 06:30:00',
    NULL
  ),
  (
    10,
    '人資考勤系統 API 串接',
    '串接打卡機硬體與 HR 系統，自動計算工時與加班費。需處理排班邏輯與國定假日判定，減少每月人工結算錯誤率。',
    6,
    '2025-11-18',
    '2025-12-18',
    0,
    30,
    NULL,
    NULL,
    2,
    '2025-11-19 06:35:00',
    '2025-11-19 06:35:00',
    NULL
  ),
  (
    11,
    '看板任務',
    '看板任務',
    2,
    '2025-11-18',
    '2025-11-30',
    0,
    60,
    3,
    '2025-11-17 17:27:35',
    5,
    '2025-11-18 01:18:57',
    '2025-11-19 07:18:00',
    NULL
  ),
  (
    15,
    '企業級 ERP 系統重構計畫',
    '本專案旨在將舊有的 ERP 系統遷移至微服務架構。主要工作包含：後端 API 重新設計、資料庫正規化優化，以及導入 Docker 容器化部署流程，預計能提升系統回應速度 40%。',
    2,
    '2025-11-19',
    '2025-11-25',
    0,
    30,
    NULL,
    NULL,
    5,
    '2025-11-19 05:43:21',
    '2025-11-19 07:17:16',
    NULL
  ),
  (
    16,
    '2025 夏季新品活動頁面開發與高併發壓測 ',
    '1. 專案資訊 (Basic Info)\n\n專案代號：DEV-2025-S01\n\n專案時程：2025/11/20 - 2025/11/30 (核心功能衝刺週 / Core Feature Sprint)\n\n技術負責人：Mike Chang (Tech Lead)\n\n2. 專案背景 配合行銷部「城市綠洲」活動，預期活動首日將有超過 50,000 人同時在線搶購新品與領取優惠券。現有商城架構無法負荷瞬間高流量，需獨立開發活動 Landing Page 並導入 Queue 機制，確保系統不崩潰。\n\n3. 本期執行內容 (Sprint Scope: 11/20-11/30)\n\n前端切版與互動實作 (11/20-11/22)：\n\n架構搭建：使用 Nuxt.js 或 Next.js 建立專案，設定 SSR 以優化 SEO。\n\n視覺實作：完成「城市綠洲」主題的主視覺視差滾動 (Parallax Scrolling) 與 RWD 響應式切版。\n\n效能優化：圖片 WebP 格式轉換與 Lazy Loading 設定。\n\n後端 API 開發與快取機制 (11/23-11/27)：\n\n優惠券 API：開發 POST /api/coupon/claim 接口，需實作 Redis Lua Script 以防止超賣 (Over-selling)。\n\n商品庫存同步：建立獨立的 Read-Model 資料庫，將熱門商品資訊快取至 Redis，降低主資料庫負載。\n\n排隊機制：實作簡單的等待室 (Waiting Room) 邏輯，當連線數超過閾值時進行限流。\n\n壓力測試與部署設定 (11/28-11/30)：\n\n容器化部署：撰寫 K8s Deployment YAML，設定 HPA (Horizontal Pod Autoscaler) 自動擴展規則（CPU > 60% 自動加開 Pod）。\n\n壓力測試：使用 k6 或 JMeter 模擬 10,000 VU (Virtual Users) 同時搶購，目標回應時間 (p95) < 800ms。\n\n4. 交付項目\n\n前端 Repository (Git Tag: v1.0.0-release)。\n\n後端 API 文件 (Swagger/OpenAPI)。\n\n壓力測試報告 (包含 TPS、Error Rate 分析)。\n\n系統部署架構圖 (Infrastructure Diagram)。',
    25,
    '2025-11-19',
    '2025-11-26',
    0,
    40,
    NULL,
    NULL,
    5,
    '2025-11-19 05:53:20',
    '2025-11-19 07:19:58',
    NULL
  ),
  (
    17,
    'AI 智能客服機器人導入',
    '描述：整合 OpenAI GPT-4 模型至公司官網客服系統。目標為降低 50% 的人工客服負擔，需訓練專屬 Knowledge Base 以回答產品常見問題。',
    2,
    '2025-11-19',
    '2026-01-30',
    0,
    10,
    NULL,
    NULL,
    1,
    '2025-11-19 06:31:24',
    '2025-11-19 06:31:24',
    NULL
  ),
  (
    18,
    '即時銷售數據戰情室開發 (Real-time Sales Dashboard)',
    '為業務部門開發基於 React 與 D3.js 的視覺化儀表板。需串接 Data Warehouse API，即時呈現各區業績達成率、熱銷商品排行與庫存預警，輔助管理層進行快速決策。',
    2,
    '2025-11-20',
    '2025-12-31',
    0,
    10,
    NULL,
    NULL,
    1,
    '2025-11-19 06:31:58',
    '2025-11-19 06:31:58',
    NULL
  ),
  (
    19,
    '人資考勤系統 API 串接',
    '串接打卡機硬體與 HR 系統，自動計算工時與加班費。需處理排班邏輯與國定假日判定，減少每月人工結算錯誤率。',
    2,
    '2025-12-01',
    '2025-12-05',
    0,
    10,
    NULL,
    NULL,
    1,
    '2025-11-19 06:32:30',
    '2025-11-19 06:32:30',
    NULL
  ),
  (
    20,
    '倉庫溫濕度 IoT 監控平台',
    '接收來自倉庫感測器 (MQTT) 的溫濕度數據，即時顯示於儀表板。當數值異常時，透過 Line Notify 發送警報給倉管人員。',
    2,
    '2025-12-01',
    '2025-12-12',
    0,
    10,
    NULL,
    NULL,
    1,
    '2025-11-19 06:33:59',
    '2025-11-19 06:33:59',
    NULL
  ),
  (
    21,
    '舊版會計系統資料封存',
    '將 2020 年以前的歷史財務資料從 Oracle 資料庫遷移至冷儲存 (Cold Storage)，並開發唯讀查詢介面供稽核使用',
    2,
    '2025-12-01',
    '2025-12-07',
    0,
    10,
    NULL,
    NULL,
    1,
    '2025-11-19 06:36:33',
    '2025-11-19 06:36:33',
    NULL
  ),
  (
    22,
    '官方部落格 SEO 優化專案',
    '針對 Core Web Vitals 進行效能調優（LCP < 2.5s）。內容策略調整與關鍵字佈局，目標提升自然搜尋流量 (Organic Traffic) 30%。',
    2,
    '2025-12-08',
    '2025-12-19',
    0,
    10,
    NULL,
    NULL,
    1,
    '2025-11-19 06:43:17',
    '2025-11-19 06:43:17',
    NULL
  ),
  (
    23,
    '年度資安滲透測試 (Penetration Test)',
    '委託外部白帽駭客團隊針對主網站與 API 進行滲透測試。產出弱點掃描報告並由內部團隊進行修補（Fix Vulnerabilities）',
    2,
    '2026-01-01',
    '2026-01-12',
    0,
    10,
    NULL,
    NULL,
    1,
    '2025-11-19 06:43:53',
    '2025-11-19 06:43:53',
    NULL
  ),
  (
    24,
    '企業數據倉儲雲端遷移 (Cloud Data Warehouse Migration)',
    '將現有的地端 SQL Server 數據遷移至 Google BigQuery 雲端平台。包含 ETL 流程重寫 (使用 Python/Airflow)、資料清理與敏感個資加密處理，旨在提升 BI 報表查詢效能並降低地端硬體維護成本',
    2,
    '2026-01-26',
    '2026-01-30',
    0,
    10,
    NULL,
    NULL,
    1,
    '2025-11-19 06:45:24',
    '2025-11-19 06:45:24',
    NULL
  ),
  (
    25,
    '多元支付整合與結帳流程優化 (Multi-Payment Integration)',
    '新增支援 LINE Pay、街口支付 (JKOPAY) 與 Apple Pay 等行動支付選項。同時優化結帳頁面 UX，減少跳出率，並確保交易資料傳輸符合 PCI-DSS 資安規範。',
    2,
    '2025-11-19',
    '2025-11-28',
    0,
    10,
    NULL,
    NULL,
    5,
    '2025-11-19 08:01:32',
    '2025-11-19 08:01:32',
    NULL
  );

/*!40000 ALTER TABLE `projects` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `projecttags`
--
DROP TABLE IF EXISTS `projecttags`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `projecttags` (
    `ProjectID` int NOT NULL,
    `TagID` int NOT NULL,
    PRIMARY KEY (`ProjectID`, `TagID`),
    KEY `TagID` (`TagID`)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projecttags`
--
LOCK TABLES `projecttags` WRITE;

/*!40000 ALTER TABLE `projecttags` DISABLE KEYS */;

INSERT INTO
  `projecttags`
VALUES
  (1, 2);

/*!40000 ALTER TABLE `projecttags` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `reminders`
--
DROP TABLE IF EXISTS `reminders`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `reminders` (
    `ReminderID` int NOT NULL AUTO_INCREMENT,
    `ProjectID` int NOT NULL,
    `MissionID` int NOT NULL,
    `UserID` int NOT NULL,
    `ReminderTime` datetime NOT NULL,
    `IsSent` tinyint (1) DEFAULT '0',
    `CreatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`ReminderID`),
    KEY `ProjectID` (`ProjectID`),
    KEY `MissionID` (`MissionID`),
    KEY `UserID` (`UserID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminders`
--
LOCK TABLES `reminders` WRITE;

/*!40000 ALTER TABLE `reminders` DISABLE KEYS */;

INSERT INTO
  `reminders`
VALUES
  (
    1,
    3,
    2,
    5,
    '2025-10-14 10:00:00',
    1,
    '2025-10-14 01:33:19',
    NULL
  );

/*!40000 ALTER TABLE `reminders` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `reports`
--
DROP TABLE IF EXISTS `reports`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `reports` (
    `ReportID` int NOT NULL AUTO_INCREMENT,
    `ProjectID` int NOT NULL,
    `GeneratedByUserID` int DEFAULT NULL,
    `ReportType` varchar(100) DEFAULT NULL,
    `GeneratedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    `Data` json DEFAULT NULL,
    PRIMARY KEY (`ReportID`),
    KEY `ProjectID` (`ProjectID`),
    KEY `GeneratedByUserID` (`GeneratedByUserID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--
LOCK TABLES `reports` WRITE;

/*!40000 ALTER TABLE `reports` DISABLE KEYS */;

INSERT INTO
  `reports`
VALUES
  (
    1,
    1,
    2,
    'Weekly Status Report',
    '2025-10-14 01:33:19',
    NULL,
    '{\"new_bugs\": 3, \"in_progress\": 2, \"completed_tasks\": 5}'
  );

/*!40000 ALTER TABLE `reports` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `rolepermissions`
--
DROP TABLE IF EXISTS `rolepermissions`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `rolepermissions` (
    `RoleID` int NOT NULL,
    `PermissionID` int NOT NULL,
    PRIMARY KEY (`RoleID`, `PermissionID`),
    KEY `PermissionID` (`PermissionID`)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rolepermissions`
--
LOCK TABLES `rolepermissions` WRITE;

/*!40000 ALTER TABLE `rolepermissions` DISABLE KEYS */;

INSERT INTO
  `rolepermissions`
VALUES
  (1, 1),
  (2, 1),
  (1, 2),
  (1, 3),
  (3, 3),
  (1, 4),
  (3, 4),
  (1, 5),
  (1, 6),
  (3, 6),
  (1, 7),
  (4, 7),
  (6, 7),
  (1, 8),
  (4, 8),
  (5, 8),
  (6, 8),
  (1, 9),
  (1, 10),
  (3, 10),
  (4, 10),
  (1, 11),
  (4, 11),
  (5, 11),
  (6, 11),
  (1, 12),
  (6, 12),
  (1, 13),
  (3, 13),
  (4, 13);

/*!40000 ALTER TABLE `rolepermissions` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `roles`
--
DROP TABLE IF EXISTS `roles`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `roles` (
    `RoleID` int NOT NULL AUTO_INCREMENT,
    `RoleName` varchar(50) NOT NULL,
    `Description` text,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`RoleID`),
    UNIQUE KEY `RoleName` (`RoleName`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 8 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--
LOCK TABLES `roles` WRITE;

/*!40000 ALTER TABLE `roles` DISABLE KEYS */;

INSERT INTO
  `roles`
VALUES
  (1, 'Admin', '系統最高管理員，擁有所有權限', NULL),
  (2, 'AccountAdmin', '帳號管理員，負責建立與停用使用者帳號', NULL),
  (3, 'PM', '專案經理，負責管理專案與指派任務', NULL),
  (4, 'RDL', '研發組長，負責技術任務分配與審核', NULL),
  (5, 'RD', '研發人員，負責處理被指派的任務', NULL),
  (6, 'QA', '品質保證人員，負責回報問題與驗證修復', NULL);

/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `tags`
--
DROP TABLE IF EXISTS `tags`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `tags` (
    `TagID` int NOT NULL AUTO_INCREMENT,
    `TagName` varchar(50) NOT NULL,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`TagID`),
    UNIQUE KEY `TagName` (`TagName`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 8 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--
LOCK TABLES `tags` WRITE;

/*!40000 ALTER TABLE `tags` DISABLE KEYS */;

INSERT INTO
  `tags`
VALUES
  (1, 'UI', NULL),
  (2, 'Backend', NULL),
  (3, 'Database', NULL),
  (4, 'API', NULL),
  (5, 'Urgent', NULL),
  (6, 'Feature', NULL),
  (7, 'BugFix', NULL);

/*!40000 ALTER TABLE `tags` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `userglobalroles`
--
DROP TABLE IF EXISTS `userglobalroles`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `userglobalroles` (
    `UserID` int NOT NULL,
    `RoleID` int NOT NULL,
    PRIMARY KEY (`UserID`, `RoleID`),
    KEY `RoleID` (`RoleID`)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userglobalroles`
--
LOCK TABLES `userglobalroles` WRITE;

/*!40000 ALTER TABLE `userglobalroles` DISABLE KEYS */;

INSERT INTO
  `userglobalroles`
VALUES
  (1, 1),
  (15, 1),
  (7, 2),
  (18, 2),
  (2, 3),
  (23, 3),
  (25, 3),
  (3, 4),
  (19, 4),
  (20, 4),
  (4, 5),
  (5, 5),
  (6, 6),
  (17, 6);

/*!40000 ALTER TABLE `userglobalroles` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `users`
--
DROP TABLE IF EXISTS `users`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `users` (
    `UserID` int NOT NULL AUTO_INCREMENT,
    `Email` varchar(255) NOT NULL,
    `PasswordHash` varchar(255) DEFAULT NULL,
    `FullName` varchar(255) NOT NULL,
    `AvatarURL` varchar(255) DEFAULT NULL,
    `Title` varchar(100) DEFAULT NULL,
    `Status` enum ('Active', 'Suspended', 'Archived') NOT NULL DEFAULT 'Active',
    `EmailVerified` tinyint (1) NOT NULL DEFAULT '0',
    `Provider` enum ('local', 'google', 'facebook', 'github') NOT NULL DEFAULT 'local',
    `ProviderUserID` varchar(255) DEFAULT NULL,
    `ProviderAccessToken` text,
    `ProviderRefreshToken` text,
    `VerificationToken` varchar(255) DEFAULT NULL,
    `VerificationTokenExpiry` timestamp NULL DEFAULT NULL,
    `ResetPasswordToken` varchar(255) DEFAULT NULL,
    `ResetPasswordTokenExpiry` timestamp NULL DEFAULT NULL,
    `CreatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    `UpdatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `NotificationEmail` varchar(255) DEFAULT NULL COMMENT '接收通知的 Email（可選，不影響登入）',
    PRIMARY KEY (`UserID`),
    UNIQUE KEY `Email` (`Email`),
    UNIQUE KEY `unique_provider_user` (`Provider`, `ProviderUserID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 26 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--
LOCK TABLES `users` WRITE;

/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO
  `users`
VALUES
  (
    1,
    'zse811022@gmail.com',
    '$2b$12$gYMV3lFxFXurDaRrlvAn1Oyt4LbNCZwZl7Z2CilB2F1ydqvRr/99O',
    'Tom SmithXX',
    NULL,
    'System Administrator',
    'Active',
    1,
    'local',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2025-10-14 01:33:19',
    '2025-11-17 05:47:53',
    'edward06160202@gmail.com'
  ),
  (
    2,
    'jept19921022@gmail.com',
    '$2b$12$gYMV3lFxFXurDaRrlvAn1Oyt4LbNCZwZl7Z2CilB2F1ydqvRr/99O',
    'Jane Doe',
    NULL,
    'Project Manager',
    'Active',
    1,
    'local',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2025-10-14 01:33:19',
    '2025-10-14 01:33:19',
    NULL
  ),
  (
    3,
    'x06082010@gmail.com',
    '$2b$12$gYMV3lFxFXurDaRrlvAn1Oyt4LbNCZwZl7Z2CilB2F1ydqvRr/99O',
    'Tom Smith',
    NULL,
    'RD Leader',
    'Active',
    1,
    'local',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2025-10-14 01:33:19',
    '2025-11-17 04:36:37',
    '123456789@gmail.com'
  ),
  (
    4,
    'kevin27385940@gmail.com',
    '$2b$12$gYMV3lFxFXurDaRrlvAn1Oyt4LbNCZwZl7Z2CilB2F1ydqvRr/99O',
    'Alice Johnson',
    'https://i.pravatar.cc/300?img=1',
    'Lead Developer',
    'Active',
    1,
    'local',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2025-10-14 01:33:19',
    '2025-10-14 01:33:19',
    NULL
  ),
  (
    5,
    'linx71203@gmail.com',
    '$2b$12$gYMV3lFxFXurDaRrlvAn1Oyt4LbNCZwZl7Z2CilB2F1ydqvRr/99O',
    'Bob Williams',
    NULL,
    'Junior Developer',
    'Active',
    1,
    'local',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2025-10-14 01:33:19',
    '2025-10-14 01:33:19',
    NULL
  ),
  (
    6,
    'cce1123tp@gmail.com',
    '$2b$12$gYMV3lFxFXurDaRrlvAn1Oyt4LbNCZwZl7Z2CilB2F1ydqvRr/99O',
    'Charlie Brown',
    NULL,
    'QA Engineer',
    'Active',
    1,
    'local',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2025-10-14 01:33:19',
    '2025-11-17 05:48:36',
    'is.hsu0202@yahoo.com.tw'
  ),
  (
    7,
    'account.admin@example.com',
    '$2b$12$gYMV3lFxFXurDaRrlvAn1Oyt4LbNCZwZl7Z2CilB2F1ydqvRr/99O',
    'Account Admin',
    NULL,
    'Account Administrator',
    'Active',
    1,
    'local',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2025-10-14 01:33:19',
    '2025-10-14 01:33:19',
    NULL
  ),
  (
    22,
    'txt@gmail.com',
    '$2b$12$d1dmUwgYCTeNZRhLgR./rOTu3HpUI/w.3hH1ZjM4AP5vtkW7wHGHi',
    'Ted',
    NULL,
    'RDL',
    'Active',
    0,
    'local',
    NULL,
    NULL,
    NULL,
    '9c96e018c877a26d222ad25e7206fd1baf39b972c0bcdd93ea731c61bcfbd849',
    '2025-11-19 01:05:04',
    NULL,
    NULL,
    '2025-11-18 01:05:03',
    '2025-11-18 01:05:03',
    'dddd@gmail.com'
  ),
  (
    23,
    'txt1@gmail.com',
    '$2b$12$sKw/UNetPLKW4/sWukCug.LSt02rWHNOh03KO3nX6TDq7ioyhHMyS',
    'Daniel',
    NULL,
    'RD',
    'Active',
    0,
    'local',
    NULL,
    NULL,
    NULL,
    '4ffbea3cec2ed776ad498dd43d3c2ce8c0adf371b68bd946f67bcbc7d9c42f80',
    '2025-11-19 01:11:54',
    NULL,
    NULL,
    '2025-11-18 01:11:53',
    '2025-11-18 01:12:02',
    NULL
  ),
  (
    24,
    'ubuntu19921022@gmail.com',
    '$2b$12$gYMV3lFxFXurDaRrlvAn1Oyt4LbNCZwZl7Z2CilB2F1ydqvRr/99O',
    'Quen X',
    NULL,
    'QA',
    'Active',
    0,
    'local',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2025-11-18 01:53:04',
    '2025-11-18 01:54:41',
    NULL
  ),
  (
    25,
    'pm1@gmail.com',
    '$2b$12$Ww.ql/Opaj0mj9dYMc5qROlRsaog3MbQ63QgbTQxfhdBS7ZhV1DLy',
    'Quen Lin',
    NULL,
    'Project Manager',
    'Active',
    1,
    'local',
    NULL,
    NULL,
    NULL,
    '1612bfc9b6c06b03d7922432f7eb6c7bdcc76bd119d3647118dc3456a4210cac',
    '2025-11-19 06:15:58',
    NULL,
    NULL,
    '2025-11-18 06:15:58',
    '2025-11-18 06:17:03',
    NULL
  );

/*!40000 ALTER TABLE `users` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `userworkload`
--
DROP TABLE IF EXISTS `userworkload`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `userworkload` (
    `WorkloadID` int NOT NULL AUTO_INCREMENT,
    `UserID` int NOT NULL,
    `ProjectID` int NOT NULL,
    `OpenMissionCount` int DEFAULT '0',
    `InProgressMissionCount` int DEFAULT '0',
    `UpdatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`WorkloadID`),
    UNIQUE KEY `uk_user_project` (`UserID`, `ProjectID`),
    KEY `ProjectID` (`ProjectID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 4 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userworkload`
--
LOCK TABLES `userworkload` WRITE;

/*!40000 ALTER TABLE `userworkload` DISABLE KEYS */;

INSERT INTO
  `userworkload`
VALUES
  (1, 4, 1, 0, 1, '2025-10-14 01:33:19'),
  (2, 5, 1, 1, 0, '2025-10-14 01:33:19'),
  (3, 5, 2, 1, 0, '2025-10-14 01:33:19');

/*!40000 ALTER TABLE `userworkload` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `workflows`
--
DROP TABLE IF EXISTS `workflows`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `workflows` (
    `WorkflowID` int NOT NULL AUTO_INCREMENT,
    `ProjectID` int DEFAULT NULL,
    `Name` varchar(100) NOT NULL,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`WorkflowID`),
    UNIQUE KEY `ProjectID` (`ProjectID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 3 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows`
--
LOCK TABLES `workflows` WRITE;

/*!40000 ALTER TABLE `workflows` DISABLE KEYS */;

INSERT INTO
  `workflows`
VALUES
  (1, 1, 'Phoenix Workflow', NULL),
  (2, 2, 'Andromeda Workflow', NULL);

/*!40000 ALTER TABLE `workflows` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `workflowstates`
--
DROP TABLE IF EXISTS `workflowstates`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `workflowstates` (
    `StateID` int NOT NULL AUTO_INCREMENT,
    `WorkflowID` int NOT NULL,
    `StateName` enum (
      'Unstarted',
      'PendingReview',
      'Active',
      'ReadyForClosure',
      'Completed',
      'Archived'
    ) NOT NULL,
    `StateOrder` int NOT NULL,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`StateID`),
    KEY `WorkflowID` (`WorkflowID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 61 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflowstates`
--
LOCK TABLES `workflowstates` WRITE;

/*!40000 ALTER TABLE `workflowstates` DISABLE KEYS */;

INSERT INTO
  `workflowstates`
VALUES
  (10, 1, 'Unstarted', 1, NULL),
  (11, 2, 'Unstarted', 1, NULL),
  (20, 1, 'PendingReview', 2, NULL),
  (21, 2, 'Active', 2, NULL),
  (30, 1, 'Active', 3, NULL),
  (31, 2, 'Completed', 3, NULL),
  (40, 1, 'ReadyForClosure', 4, NULL),
  (50, 1, 'Completed', 5, NULL),
  (60, 1, 'Archived', 6, NULL);

/*!40000 ALTER TABLE `workflowstates` ENABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `workflowtransitions`
--
DROP TABLE IF EXISTS `workflowtransitions`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!50503 SET character_set_client = utf8mb4 */;

CREATE TABLE
  `workflowtransitions` (
    `TransitionID` int NOT NULL AUTO_INCREMENT,
    `WorkflowID` int NOT NULL,
    `FromStateID` int NOT NULL,
    `ToStateID` int NOT NULL,
    `DeletedAt` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`TransitionID`),
    KEY `WorkflowID` (`WorkflowID`),
    KEY `FromStateID` (`FromStateID`),
    KEY `ToStateID` (`ToStateID`)
  ) ENGINE = InnoDB AUTO_INCREMENT = 6 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflowtransitions`
--
LOCK TABLES `workflowtransitions` WRITE;

/*!40000 ALTER TABLE `workflowtransitions` DISABLE KEYS */;

INSERT INTO
  `workflowtransitions`
VALUES
  (1, 1, 1, 2, NULL),
  (2, 1, 2, 3, NULL),
  (3, 1, 3, 4, NULL),
  (4, 2, 5, 6, NULL),
  (5, 2, 6, 7, NULL);

/*!40000 ALTER TABLE `workflowtransitions` ENABLE KEYS */;

UNLOCK TABLES;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;

/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;

/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-19 16:05:50