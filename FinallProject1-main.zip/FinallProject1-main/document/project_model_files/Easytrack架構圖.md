# Easytrack 專案架構圖

這份文件描述了 Easytrack 專案的整體技術架構，涵蓋前端、後端和資料庫。

## 1. 總體架構圖

使用 Mermaid 語法繪製高層次的架構圖，展示各個主要組件之間的互動關係。

```mermaid
graph TD
    subgraph "使用者端 (Client)"
        A[使用者 Browser]
    end

    subgraph "前端 (Frontend)"
        B[Next.js / React]
    end

    subgraph "後端 (Backend)"
        C[Node.js / Express API]
    end

    subgraph "資料庫 (Database)"
        D[SQL Database]
    end

    A -- "瀏覽網頁 (HTTP)" --> B
    B -- "API 請求 (RESTful API)" --> C
    C -- "資料庫查詢 (SQL)" --> D
    D -- "查詢結果" --> C
    C -- "JSON 回應" --> B
    B -- "渲染頁面" --> A
```

## 2. 組件說明

### 2.1. 前端 (Frontend)

- **框架**: [Next.js](https://nextjs.org/) (基於 [React](https://react.dev/))
- **語言**: TypeScript
- **目錄**: `frontend/`
- **主要職責**:
    - **使用者介面 (UI)**: 提供專案管理、任務追蹤、儀表板等所有視覺介面。
    - **客戶端邏輯**: 處理使用者互動、表單驗證、狀態管理。
    - **路由管理**: 使用 Next.js 的 App Router (`/src/app`) 進行頁面導航。
    - **身分驗證**:
        - 透過 `AuthContext` 和 `useAuth` hook 管理使用者登入狀態。
        - 使用 `middleware.ts` 保護需要登入才能存取的頁面。
    - **API 串接**: 呼叫後端提供的 RESTful API 來獲取及操作資料。
- **關鍵組件**:
    - `Sidebar.tsx`: 側邊導航欄。
    - `KanbanColumn.tsx` & `KanbanCard.tsx`: 看板功能的核心組件。
    - `MissionCard.tsx`: 任務卡片。
    - `IssueStatusChart.tsx` & `PriorityPieChart.tsx`: 儀表板的統計圖表。

### 2.2. 後端 (Backend)

- **環境**: [Node.js](https://nodejs.org/)
- **框架**: [Express.js](https://expressjs.com/) (推斷)
- **語言**: TypeScript
- **目錄**: `backend/`
- **主要職責**:
    - **提供 API**: 設計並實現 RESTful API 供前端呼叫，處理所有業務邏輯。
    - **身分驗證與授權**:
        - 使用 JWT (JSON Web Tokens) 進行使用者驗證 (`auth.controller.ts`)。
        - 支援 Google 第三方登入 (`google-auth.controller.ts`)。
        - 實現基於角色的權限管理 (`role.controller.ts`)。
    - **資料庫互動**: 連接並操作 SQL 資料庫，執行增刪改查 (CRUD) 操作。
    - **檔案上傳**: 透過 `multer` 中介軟體處理檔案（如使用者頭像）上傳。
- **模組化結構 (`src/`)**:
    - `member`: 處理使用者、角色、認證相關功能。
    - `project`: 處理專案相關功能。
    - `Mission`: 處理任務相關功能。
    - `Dashboard`: 提供儀表板所需的統計數據 API。
    - `Notification`: 處理通知功能。

### 2.3. 資料庫 (Database)

- **類型**: SQL 資料庫 (例如 MySQL, PostgreSQL)
- **目錄**: `sql/`
- **主要職責**:
    - **資料持久化**: 儲存應用程式的所有核心資料，包括：
        - 使用者 (`Users`)
        - 角色與權限 (`Roles`, `Permissions`)
        - 專案 (`Projects`)
        - 任務 (`Missions`)
        - 附件 (`Attachments`)
        - 評論與歷史紀錄 (`Comments`, `Histories`)
    - **資料庫綱要**: `sql/` 目錄中的 `.sql` 檔案定義了資料表的結構、關聯和初始資料。

## 3. 資料流與互動

1.  **使用者訪問**: 使用者在瀏覽器中輸入網址，請求被送到 Next.js 伺服器。
2.  **頁面渲染**:
    - Next.js 根據路由渲染對應的 React 頁面。
    - 對於受保護的頁面，`middleware.ts` 會檢查請求中是否包含有效的 JWT。若無，則重導向至登入頁面。
3.  **API 請求**:
    - 頁面上的組件（如 `useEffect` hook）觸發 API 請求（例如：`fetch('/api/projects')`）。
    - 請求透過網路傳送到後端 Node.js/Express 伺服器。
4.  **後端處理**:
    - Express 的路由系統將請求導向對應的 `Controller`。
    - `Controller` 呼叫 `Service` 執行業務邏輯。
    - `Service` 與資料庫模型互動，產生 SQL 查詢。
5.  **資料庫操作**: 後端伺服器向 SQL 資料庫發送查詢，獲取或修改資料。
6.  **API 回應**:
    - 資料庫返回結果給後端伺服器。
    - 後端將結果包裝成 JSON 格式，回傳給前端。
7.  **UI 更新**:
    - 前端 React 應用程式接收到 JSON 資料。
    - 透過 `useState` 或 `AuthContext` 等狀態管理機制更新應用程式狀態。
    - React 根據新的狀態重新渲染 UI，將最新資料顯示給使用者。

## 4. 詳細檔案結構樹

這是在 `backend` 和 `frontend` 中核心應用程式邏輯的檔案結構。

```text
C:.
├── backend/
│   ├── package.json
│   ├── tsconfig.json
│   └── src/
│       ├── app.ts
│       ├── index.ts
│       ├── config/
│       │   ├── db.ts
│       │   └── multer.config.ts
│       ├── Dashboard/
│       │   ├── service.ts
│       │   └── routes/
│       │       └── mission.routes.ts
│       ├── member/
│       │   ├── controllers/
│       │   │   ├── auth.controller.ts
│       │   │   ├── google-auth.controller.ts
│       │   │   ├── role.controller.ts
│       │   │   └── user.controller.ts
│       │   ├── middlewares/
│       │   ├── routes/
│       │   ├── schemas/
│       │   ├── services/
│       │   └── ...
│       ├── Mission/
│       │   ├── controllers/
│       │   ├── models/
│       │   ├── routes/
│       │   └── services/
│       ├── Notification/
│       │   ├── routes/
│       │   └── services/
│       └── project/
│           ├── controllers/
│           ├── middlewares/
│           ├── models/
│           ├── routes/
│           └── services/
│
└── frontend/
    ├── package.json
    ├── next.config.ts
    ├── tsconfig.json
    └── src/
        ├── app/
        │   ├── layout.tsx
        │   ├── globals.css
        │   ├── dashboard/
        │   ├── login/
        │   ├── projects/
        │   ├── Missions/
        │   ├── profile/
        │   ├── register/
        │   └── ... (其他頁面)
        ├── components/
        │   ├── KanbanCard.tsx
        │   ├── MissionCard.tsx
        │   ├── Sidebar.tsx
        │   ├── AddUserModal.tsx
        │   ├── EditUserModal.tsx
        │   └── ui/
        ├── contexts/
        │   └── AuthContext.tsx
        ├── hooks/
        │   └── useAuth.ts
        ├── lib/
        │   ├── kanban.ts
        │   └── utils.ts
        └── Middleware/
            └── middleware.ts
```
