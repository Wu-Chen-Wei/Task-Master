/**
 * 認證與權限驗證中間件
 * 保護需要登入或特定權限的 API 端點
 */

import { Request, Response, NextFunction } from 'express';
import mysql from 'mysql2/promise';
import { JWTUtil } from '../utils/jwt';

// 擴展 Express Request 型別，加入使用者資訊
// ⭐ 擴展 Express Request 介面
declare global {
  namespace Express {
    interface Request {
      user?: {
        userID: number;
        email: string;
        roles: string[];  // ⭐ 加入角色陣列
      };
    }
  }
}

/**
 * 認證中間件 - 驗證使用者是否已登入
 * 使用方式：router.get('/protected', authenticate, controller)
 */
export const authenticate = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    // 步驟 1: 從 Header 中提取 Token
    const authHeader = req.headers.authorization;
    const token = JWTUtil.extractTokenFromHeader(authHeader);

    if (!token) {
      res.status(401).json({
        success: false,
        message: '請先登入'
      });
      return;
    }

    // 步驟 2: 驗證 Token
    const decoded = JWTUtil.verifyToken(token);
    if (!decoded) {
      res.status(401).json({
        success: false,
        message: 'Token 無效或已過期，請重新登入'
      });
      return;
    }

    // ⭐ 將使用者資訊（包含角色）附加到 request
    req.user = {
      userID: JWTUtil.getUserIDAsNumber(decoded),
      email: decoded.email,
      roles: decoded.roles || []  // ⭐ 角色陣列
    };

    next();

  } catch (error) {
    console.error('認證中間件錯誤:', error);
    res.status(500).json({
      success: false,
      message: '伺服器內部錯誤'
    });
  }
};

/**
 * 權限驗證中間件工廠函數
 * 檢查使用者是否有特定權限
 * 
 * @param pool 資料庫連線池
 * @param requiredPermission 需要的權限名稱
 * @returns Express 中間件函數
 * 
 * 使用方式：
 * router.post('/users', authenticate, authorize(pool, 'manage_users'), controller)
 */
export const authorize = (pool: mysql.Pool, requiredPermission: string) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      // 確認使用者已通過認證
      if (!req.user) {
        res.status(401).json({
          success: false,
          message: '請先登入'
        });
        return;
      }

      const userID = req.user.userID;

      // 步驟 1: 查詢使用者的全域角色
      const [roleRows] = await pool.execute(
        `SELECT r.RoleID, r.RoleName
         FROM UserGlobalRoles ugr
         JOIN Roles r ON ugr.RoleID = r.RoleID
         WHERE ugr.UserID = ?`,
        [userID]
      );

      const userRoles = roleRows as Array<{ RoleID: number; RoleName: string }>;

      if (userRoles.length === 0) {
        res.status(403).json({
          success: false,
          message: '您沒有權限執行此操作'
        });
        return;
      }

      // 步驟 2: 查詢這些角色是否有所需的權限
      const roleIDs = userRoles.map(role => role.RoleID);
      const placeholders = roleIDs.map(() => '?').join(',');

      const [permRows] = await pool.execute(
        `SELECT COUNT(*) as count
         FROM RolePermissions rp
         JOIN Permissions p ON rp.PermissionID = p.PermissionID
         WHERE rp.RoleID IN (${placeholders})
         AND p.PermissionName = ?`,
        [...roleIDs, requiredPermission]
      );

      const permResult = permRows as Array<{ count: number }>;

      // 步驟 3: 檢查是否有權限
      if (permResult[0].count === 0) {
        res.status(403).json({
          success: false,
          message: '您沒有權限執行此操作'
        });
        return;
      }

      // 有權限，繼續執行
      next();

    } catch (error) {
      console.error('權限驗證中間件錯誤:', error);
      res.status(500).json({
        success: false,
        message: '伺服器內部錯誤'
      });
    }
  };
};

/**
 * 檢查使用者是否為管理員（SystemAdmin 或 AccountAdmin）
 * 
 * @param pool 資料庫連線池
 * @returns Express 中間件函數
 * 
 * 使用方式：
 * router.delete('/users/:id', authenticate, requireAdmin(pool), controller)
 */
export const requireAdmin = (pool: mysql.Pool) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.user) {
        res.status(401).json({
          success: false,
          message: '請先登入'
        });
        return;
      }

      const userID = req.user.userID;

      // 查詢使用者是否有管理員角色
      const [rows] = await pool.execute(
        `SELECT COUNT(*) as count
         FROM UserGlobalRoles ugr
         JOIN Roles r ON ugr.RoleID = r.RoleID
         WHERE ugr.UserID = ?
         AND r.RoleName IN ('Admin', 'AccountAdmin')`,
        [userID]
      );

      const result = rows as Array<{ count: number }>;

      if (result[0].count === 0) {
        res.status(403).json({
          success: false,
          message: '此操作需要管理員權限'
        });
        return;
      }

      next();

    } catch (error) {
      console.error('管理員驗證中間件錯誤:', error);
      res.status(500).json({
        success: false,
        message: '伺服器內部錯誤'
      });
    }
  };
};