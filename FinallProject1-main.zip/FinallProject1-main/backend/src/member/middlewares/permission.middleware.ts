/**
 * 權限檢查中間件
 * 檢查使用者是否有特定角色或權限
 */
import { Request, Response, NextFunction } from 'express';
import mysql from 'mysql2/promise';

/**
 * 檢查使用者是否有特定角色
 * @param allowedRoles 允許的角色陣列
 * 
 * @example
 * router.post('/projects', authenticate, requireRole(['PM', 'SystemAdmin']), createProject);
 */
export const requireRole = (allowedRoles: string[]) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    try {
      const user = req.user;

      // 檢查使用者是否已登入
      if (!user) {
        res.status(401).json({
          success: false,
          message: '請先登入'
        });
        return;
      }

      // 檢查使用者是否有角色資訊
      if (!user.roles || user.roles.length === 0) {
        res.status(403).json({
          success: false,
          message: '權限不足：無角色資訊'
        });
        return;
      }

      // 檢查使用者是否有任一允許的角色
      const hasRole = user.roles.some(role => allowedRoles.includes(role));

      if (!hasRole) {
        res.status(403).json({
          success: false,
          message: `權限不足，需要以下角色之一：${allowedRoles.join(', ')}`,
          requiredRoles: allowedRoles,
          userRoles: user.roles
        });
        return;
      }

      // 權限檢查通過，繼續執行
      next();
    } catch (error) {
      console.error('角色檢查中間件發生錯誤:', error);
      res.status(500).json({
        success: false,
        message: '伺服器內部錯誤'
      });
    }
  };
};

/**
 * 檢查使用者是否有特定權限
 * @param pool 資料庫連線池
 * @param requiredPermission 需要的權限名稱
 * 
 * @example
 * router.put('/projects/:id', authenticate, requirePermission(pool, 'edit_project'), updateProject);
 */
export const requirePermission = (pool: mysql.Pool, requiredPermission: string) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = req.user;

      // 檢查使用者是否已登入
      if (!user) {
        res.status(401).json({
          success: false,
          message: '請先登入'
        });
        return;
      }

      // 查詢使用者的所有權限
      const [rows] = await pool.execute(
        `SELECT DISTINCT p.PermissionName
         FROM userglobalroles ugr
         JOIN rolepermissions rp ON ugr.RoleID = rp.RoleID
         JOIN permissions p ON rp.PermissionID = p.PermissionID
         WHERE ugr.UserID = ?`,
        [user.userID]
      );

      const permissions = (rows as Array<{ PermissionName: string }>)
        .map(row => row.PermissionName);

      // 檢查是否有需要的權限
      if (!permissions.includes(requiredPermission)) {
        res.status(403).json({
          success: false,
          message: `權限不足，需要權限：${requiredPermission}`,
          requiredPermission: requiredPermission,
          userPermissions: permissions
        });
        return;
      }

      // 權限檢查通過，繼續執行
      next();
    } catch (error) {
      console.error('權限檢查中間件發生錯誤:', error);
      res.status(500).json({
        success: false,
        message: '伺服器內部錯誤'
      });
    }
  };
};

/**
 * 檢查使用者是否有多個權限之一
 * @param pool 資料庫連線池
 * @param requiredPermissions 需要的權限陣列（任一即可）
 * 
 * @example
 * router.get('/projects/:id', authenticate, requireAnyPermission(pool, ['create_project', 'view_reports']), getProject);
 */
export const requireAnyPermission = (pool: mysql.Pool, requiredPermissions: string[]) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = req.user;

      // 檢查使用者是否已登入
      if (!user) {
        res.status(401).json({
          success: false,
          message: '請先登入'
        });
        return;
      }

      // 查詢使用者的所有權限
      const [rows] = await pool.execute(
        `SELECT DISTINCT p.PermissionName
         FROM userglobalroles ugr
         JOIN rolepermissions rp ON ugr.RoleID = rp.RoleID
         JOIN permissions p ON rp.PermissionID = p.PermissionID
         WHERE ugr.UserID = ?`,
        [user.userID]
      );

      const permissions = (rows as Array<{ PermissionName: string }>)
        .map(row => row.PermissionName);

      // 檢查是否有任一需要的權限
      const hasPermission = requiredPermissions.some(perm => permissions.includes(perm));

      if (!hasPermission) {
        res.status(403).json({
          success: false,
          message: `權限不足，需要以下權限之一：${requiredPermissions.join(', ')}`,
          requiredPermissions: requiredPermissions,
          userPermissions: permissions
        });
        return;
      }

      // 權限檢查通過，繼續執行
      next();
    } catch (error) {
      console.error('權限檢查中間件發生錯誤:', error);
      res.status(500).json({
        success: false,
        message: '伺服器內部錯誤'
      });
    }
  };
};

/**
 * 檢查使用者是否擁有所有指定權限
 * @param pool 資料庫連線池
 * @param requiredPermissions 需要的權限陣列（必須全部擁有）
 * 
 * @example
 * router.delete('/projects/:id', authenticate, requireAllPermissions(pool, ['delete_project', 'manage_project_members']), deleteProject);
 */
export const requireAllPermissions = (pool: mysql.Pool, requiredPermissions: string[]) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = req.user;

      // 檢查使用者是否已登入
      if (!user) {
        res.status(401).json({
          success: false,
          message: '請先登入'
        });
        return;
      }

      // 查詢使用者的所有權限
      const [rows] = await pool.execute(
        `SELECT DISTINCT p.PermissionName
         FROM userglobalroles ugr
         JOIN rolepermissions rp ON ugr.RoleID = rp.RoleID
         JOIN permissions p ON rp.PermissionID = p.PermissionID
         WHERE ugr.UserID = ?`,
        [user.userID]
      );

      const permissions = (rows as Array<{ PermissionName: string }>)
        .map(row => row.PermissionName);

      // 檢查是否擁有所有需要的權限
      const missingPermissions = requiredPermissions.filter(
        perm => !permissions.includes(perm)
      );

      if (missingPermissions.length > 0) {
        res.status(403).json({
          success: false,
          message: `權限不足，缺少以下權限：${missingPermissions.join(', ')}`,
          requiredPermissions: requiredPermissions,
          missingPermissions: missingPermissions,
          userPermissions: permissions
        });
        return;
      }

      // 權限檢查通過，繼續執行
      next();
    } catch (error) {
      console.error('權限檢查中間件發生錯誤:', error);
      res.status(500).json({
        success: false,
        message: '伺服器內部錯誤'
      });
    }
  };
};