/**
 * 認證相關的 TypeScript 型別定義
 */

/**
 * JWT Token Payload 介面
 */
export interface JWTPayload {
  userID: string;
  email: string;
  roles?: string[];  // ⭐ 角色陣列
  iat?: number;      // issued at
  exp?: number;      // expiration time
  iss?: string;      // issuer
  aud?: string;      // audience
}

/**
 * 登入請求介面
 */
export interface LoginRequest {
  email: string;
  password: string;
}

/**
 * 登入回應介面
 */
export interface LoginResponse {
  success: boolean;
  message: string;
  token?: string;
  user?: AuthenticatedUser;
}

/**
 * 已認證使用者資訊介面
 */
export interface AuthenticatedUser {
  userID: number;
  Email: string;
  FullName: string;
  AvatarURL?: string;
  Title?: string;
  Status: string;
  EmailVerified: boolean;
  Roles?: string[];  // ⭐ 新增角色陣列
}



/**
 * 忘記密碼請求介面
 */
export interface ForgotPasswordRequest {
  email: string;
}

/**
 * 重設密碼請求介面
 */
export interface ResetPasswordRequest {
  token: string;
  newPassword: string;
}

/**
 * 修改密碼請求介面
 */
export interface ChangePasswordRequest {
  oldPassword: string;
  newPassword: string;
}