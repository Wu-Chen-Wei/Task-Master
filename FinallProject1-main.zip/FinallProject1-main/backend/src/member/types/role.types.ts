/**
 * 角色管理相關的 TypeScript 型別定義
 */

/**
 * 角色資料結構
 */
export interface Role {
  RoleID: number;           // 角色 ID
  RoleName: string;         // 角色名稱
  Description?: string;     // 角色描述
}

/**
 * 建立角色的請求資料
 */
export interface CreateRoleRequest {
  roleName: string;         // 角色名稱（必填）
  description?: string;     // 角色描述（選填）
}

/**
 * 更新角色的請求資料
 */
export interface UpdateRoleRequest {
  roleName?: string;        // 新的角色名稱（選填）
  description?: string;     // 新的角色描述（選填）
}

/**
 * 角色操作的回應格式
 */
export interface RoleResponse {
  success: boolean;         // 操作是否成功
  message: string;          // 回應訊息
  role?: Role;              // 角色資料（單筆操作時）
  roles?: Role[];           // 角色列表（查詢多筆時）
}