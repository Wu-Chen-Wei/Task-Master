/**
 * 使用者相關的 TypeScript 型別定義
 * 用於確保資料結構的型別安全
 */

/**
 * 建立新使用者時的請求資料結構
 * 對應前端註冊表單送來的資料
 */
export interface CreateUserRequest {
  email: string; // 使用者 Email (必填)
  fullName: string; // 使用者姓名 (必填)
  password: string; // 明文密碼 (必填，後端會加密)
  title?: string; // 職稱 (選填),
  notificationEmail?: string;
}

/**
 * 資料庫中的使用者資料結構
 * 對應 Users 資料表的欄位
 */
export interface User {
  UserID: number; // 使用者 ID (主鍵)
  Email: string; // Email 地址 (唯一)
  FullName: string; // 使用者姓名
  AvatarURL?: string; // 頭像網址 (可為空)
  Title?: string; // 職稱 (可為空)
  Status: "Active" | "Suspended" | "Archived"; // 帳號狀態
  EmailVerified: boolean; // Email 是否已驗證
  CreatedAt: Date; // 建立時間
  UpdatedAt: Date; // 最後更新時間
  NotificationEmail?: string; // ✅ 已加
}

/**
 * 建立使用者後的回應資料結構
 * 回傳給前端的標準格式
 */
export interface CreateUserResponse {
  success: boolean; // 操作是否成功
  message: string; // 回應訊息
  user?: Omit<User, "PasswordHash">; // 使用者資料 (不包含密碼雜湊)
}
