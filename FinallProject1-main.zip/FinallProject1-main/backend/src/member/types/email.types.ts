/**
 * Email 相關的 TypeScript 型別定義
 */

/**
 * Email 發送設定
 */
export interface EmailConfig {
  service: string;          // 'gmail'
  user: string;            // Gmail 帳號
  pass: string;            // Gmail App Password 或 OAuth2 token
  from: string;            // 寄件者顯示名稱
}

/**
 * 基本 Email 資料結構
 */
export interface EmailData {
  to: string;              // 收件者 Email
  subject: string;         // 信件主旨
  html: string;           // HTML 內容
  text?: string;          // 純文字內容（選填）
}

/**
 * 帳號驗證信的資料
 */
export interface VerificationEmailData {
  to: string;             // 收件者 Email
  userName: string;       // 使用者姓名
  verificationToken: string; // 驗證 Token
  verificationUrl: string;   // 完整的驗證網址
}

/**
 * 密碼重設信的資料
 */
export interface PasswordResetEmailData {
  to: string;             // 收件者 Email
  userName: string;       // 使用者姓名
  resetToken: string;     // 重設 Token
  resetUrl: string;       // 完整的重設網址
}

/**
 * 系統通知信的資料
 */
export interface NotificationEmailData {
  to: string;             // 收件者 Email
  userName: string;       // 使用者姓名
  title: string;          // 通知標題
  content: string;        // 通知內容
  actionUrl?: string;     // 相關連結（選填）
}

/**
 * Email 發送結果
 */
export interface EmailSendResult {
  success: boolean;       // 是否發送成功
  messageId?: string;     // 信件 ID（成功時）
  error?: string;         // 錯誤訊息（失敗時）
}

/**
 * Email 範本類型
 */
export type EmailTemplateType = 
  | 'verification'      // 帳號驗證
  | 'passwordReset'     // 密碼重設
  | 'notification';     // 系統通知