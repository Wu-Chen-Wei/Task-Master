/**
 * 使用者輸入資料驗證工具
 * 使用 Zod 進行型別安全的資料驗證
 */

import { z } from 'zod';

/**
 * 使用者註冊資料的驗證規則
 * 定義每個欄位的驗證條件和錯誤訊息
 */
export const userRegistrationSchema = z.object({
  // Email 驗證：必須是有效格式，長度限制，自動轉小寫和去空白
  email: z
    .string()
    .email('請輸入有效的 Email 地址')
    .max(255, 'Email 長度不能超過 255 字元')
    .transform(email => email.toLowerCase().trim()),

  // 姓名驗證：不能為空，長度限制，自動去除前後空白
  fullName: z
    .string()
    .min(1, '姓名不能為空')
    .max(255, '姓名長度不能超過 255 字元')
    .trim(),

  // 密碼驗證：長度限制，必須包含大小寫字母和數字
  password: z
    .string()
    .min(8, '密碼至少需要 8 個字元')
    .max(128, '密碼長度不能超過 128 字元')
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
      '密碼必須包含大小寫字母和數字'
    ),

  // 職稱驗證：選填欄位，長度限制，自動去除前後空白
  title: z
    .string()
    .max(100, '職稱長度不能超過 100 字元')
    .trim()
    .optional(),
  notificationEmail: z
    .string()
    .email("通知 Email 格式不正確")
    .max(255, "Email 長度不能超過 255 字元")
    .optional(), 

});

/**
 * 刷新 Token 延長有效期
 * POST /api/auth/refresh
 * 
 * Headers: Authorization: Bearer <old-token>
 * 
 * 成功回應範例：
 * {
 *   "success": true,
 *   "message": "Token 刷新成功",
 *   "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
 *   "user": { ... }
 * }
 */
export const userLoginSchema = z.object({
  // Email 驗證：必須是有效格式，自動轉小寫和去空白
  email: z
    .string()
    .email('請輸入有效的 Email 地址')
    .max(255, 'Email 長度不能超過 255 字元')
    .transform(email => email.toLowerCase().trim()),

  // 密碼驗證：不能為空（登入時不需要複雜驗證，因為可能是舊密碼）
  password: z
    .string()
    .min(1, '密碼不能為空')
    .max(128, '密碼長度不能超過 128 字元')
});

/**
 * 忘記密碼資料的驗證規則
 * 只需要驗證 Email 格式
 */
export const forgotPasswordSchema = z.object({
  // Email 驗證：必須是有效格式，自動轉小寫和去空白
  email: z
    .string()
    .email('請輸入有效的 Email 地址')
    .max(255, 'Email 長度不能超過 255 字元')
    .transform(email => email.toLowerCase().trim())
});

/**
 * 重設密碼資料的驗證規則
 * 驗證 Token 和新密碼
 */
export const resetPasswordSchema = z.object({
  // Token 驗證：不能為空，長度檢查
  token: z
    .string()
    .min(1, '重設密碼 Token 不能為空')
    .max(255, 'Token 格式錯誤'),

  // 新密碼驗證：與註冊時相同的複雜度要求
  newPassword: z
    .string()
    .min(8, '新密碼至少需要 8 個字元')
    .max(128, '新密碼長度不能超過 128 字元')
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
      '新密碼必須包含大小寫字母和數字'
    )
});

/**
 * 修改密碼資料的驗證規則
 * 需要驗證舊密碼和新密碼
 */
export const changePasswordSchema = z.object({
  // 舊密碼驗證：不能為空（不檢查複雜度）
  oldPassword: z
    .string()
    .min(1, '請輸入目前的密碼')
    .max(128, '密碼長度錯誤'),

  // 新密碼驗證：複雜度要求
  newPassword: z
    .string()
    .min(8, '新密碼至少需要 8 個字元')
    .max(128, '新密碼長度不能超過 128 字元')
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
      '新密碼必須包含大小寫字母和數字'
    )
}).refine(
  (data) => data.oldPassword !== data.newPassword,
  {
    message: '新密碼不能與舊密碼相同',
    path: ['newPassword']
  }
);

/**
 * 更新個人資料驗證規則
 */
export const updateProfileSchema = z.object({
  FullName: z.string()
    .min(1, '姓名不能為空')
    .max(255, '姓名長度不能超過 255 字元')
    .optional(),
  
  AvatarURL: z.string()
    .url('請提供有效的頭像網址')
    .max(255, '頭像網址長度不能超過 255 字元')
    .optional(),
  
  Title: z.string()
    .max(100, '職稱長度不能超過 100 字元')
    .optional(),
  
  NotificationEmail: z.string()
    .email('請輸入有效的通知 Email 地址')
    .max(255, '通知 Email 長度不能超過 255 字元')
    .optional()
}).refine(
  (data) => data.FullName || data.AvatarURL || data.Title || data.NotificationEmail,
  {
    message: '至少需要提供一項要更新的資料'
  }
);

/**
 * 從 Zod schema 推導出的 TypeScript 型別
 * 確保驗證後的資料型別正確
 */
export type UserRegistrationData = z.infer<typeof userRegistrationSchema>;
export type UserLoginData = z.infer<typeof userLoginSchema>;
export type ForgotPasswordData = z.infer<typeof forgotPasswordSchema>;
export type ResetPasswordData = z.infer<typeof resetPasswordSchema>;
export type ChangePasswordData = z.infer<typeof changePasswordSchema>;

/**
 * 建立角色資料的驗證規則
 */
export const createRoleSchema = z.object({
  // 角色名稱驗證：不能為空，長度限制，自動去除前後空白
  roleName: z
    .string()
    .min(1, '角色名稱不能為空')
    .max(50, '角色名稱長度不能超過 50 字元')
    .trim()
    .regex(/^[a-zA-Z_]+$/, '角色名稱只能包含英文字母和底線'),

  // 角色描述驗證：選填，自動去除前後空白
  description: z
    .string()
    .max(500, '角色描述長度不能超過 500 字元')
    .trim()
    .optional()
});

/**
 * 更新角色資料的驗證規則
 */
export const updateRoleSchema = z.object({
  // 角色名稱驗證：選填，但如果提供則需符合規則
  roleName: z
    .string()
    .min(1, '角色名稱不能為空')
    .max(50, '角色名稱長度不能超過 50 字元')
    .trim()
    .regex(/^[a-zA-Z_]+$/, '角色名稱只能包含英文字母和底線')
    .optional(),

  // 角色描述驗證：選填
  description: z
    .string()
    .max(500, '角色描述長度不能超過 500 字元')
    .trim()
    .optional()
}).refine(
  (data) => data.roleName !== undefined || data.description !== undefined,
  {
    message: '至少需要提供角色名稱或描述其中一項',
    path: ['roleName']
  }
);

/**
 * 從 Zod schema 推導出角色相關的 TypeScript 型別
 */
export type CreateRoleData = z.infer<typeof createRoleSchema>;
export type UpdateRoleData = z.infer<typeof updateRoleSchema>;