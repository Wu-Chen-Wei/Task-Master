/**
 * JWT Token 工具類別
 * 處理 Token 的產生、驗證和解析
 */

import jwt from "jsonwebtoken";
import {JWTPayload} from "../types/auth.types.js";

export class JWTUtil {
  // JWT 密鑰，從環境變數讀取
  private static readonly SECRET_KEY =
    process.env.JWT_SECRET || "your-default-secret-key";

  // Token 有效期限（預設 7 天）
  private static readonly EXPIRES_IN = (process.env.JWT_EXPIRES_IN ||
    "7d") as jwt.SignOptions["expiresIn"];

  /**
   * 產生 JWT Token
   * @param payload 要包含在 Token 中的使用者資訊
   * @returns JWT Token 字串
   */
  static generateToken(payload: {
    userID: number;
    email: string;
    roles?: string[]; // ⭐ 新增：可選的角色陣列
  }): string {
    try {
      const tokenPayload: Omit<JWTPayload, "iat" | "exp" | "iss" | "aud"> = {
        userID: payload.userID.toString(), // 轉換為字串
        email: payload.email,
        roles: payload.roles || [], // ⭐ 加入角色陣列，預設為空陣列
      };

      const options: jwt.SignOptions = {
        expiresIn: this.EXPIRES_IN,
        issuer: "project-management-system",
        audience: "project-users",
      };

      return jwt.sign(tokenPayload, this.SECRET_KEY, options);
    } catch (error) {
      console.error("產生 JWT Token 時發生錯誤:", error);
      throw new Error("Token 產生失敗");
    }
  }

  /**
   * 驗證 JWT Token 是否有效
   * @param token JWT Token 字串
   * @returns 解析後的 payload 或 null（如果無效）
   */
  static verifyToken(token: string): JWTPayload | null {
    try {
      const decoded = jwt.verify(token, this.SECRET_KEY, {
        issuer: "project-management-system",
        audience: "project-users",
      }) as JWTPayload;

      return decoded;
    } catch (error) {
      if (error instanceof jwt.TokenExpiredError) {
        console.log("JWT Token 已過期");
      } else if (error instanceof jwt.JsonWebTokenError) {
        console.log("JWT Token 格式無效");
      } else {
        console.error("驗證 JWT Token 時發生錯誤:", error);
      }
      return null;
    }
  }

  /**
   * 解析 Token 但不驗證（用於檢查過期時間等）
   * @param token JWT Token 字串
   * @returns 解析後的 payload 或 null
   */
  static decodeToken(token: string): JWTPayload | null {
    try {
      const decoded = jwt.decode(token) as JWTPayload;
      return decoded;
    } catch (error) {
      console.error("解析 JWT Token 時發生錯誤:", error);
      return null;
    }
  }

  /**
   * 檢查 Token 是否即將過期（剩餘時間少於指定分鐘數）
   * @param token JWT Token 字串
   * @param minutesBeforeExpiry 過期前幾分鐘算作即將過期（預設 30 分鐘）
   * @returns true 表示即將過期，false 表示還有足夠時間
   */
  static isTokenExpiringSoon(
    token: string,
    minutesBeforeExpiry: number = 30
  ): boolean {
    const decoded = this.decodeToken(token);
    if (!decoded || !decoded.exp) {
      return true; // 無法解析或沒有過期時間，視為即將過期
    }

    const now = Math.floor(Date.now() / 1000); // 當前時間（秒）
    const timeUntilExpiry = decoded.exp - now;
    const minutesUntilExpiry = timeUntilExpiry / 60;

    return minutesUntilExpiry <= minutesBeforeExpiry;
  }

  /**
   * 從 HTTP Authorization Header 中提取 Token
   * @param authHeader Authorization Header 的值（格式：'Bearer <token>'）
   * @returns Token 字串或 null
   */
  static extractTokenFromHeader(authHeader: string | undefined): string | null {
    if (!authHeader) {
      return null;
    }

    // 檢查是否符合 'Bearer <token>' 格式
    const parts = authHeader.split(" ");
    if (parts.length !== 2 || parts[0] !== "Bearer") {
      return null;
    }

    return parts[1];
  }

  /**
   * 輔助方法：將 JWT payload 中的 userID 從字串轉換回數字
   * @param payload JWT payload
   * @returns userID 數字值
   */
  static getUserIDAsNumber(payload: JWTPayload): number {
    return parseInt(payload.userID, 10);
  }

  /**
   * ⭐ 新增：檢查使用者是否有特定角色
   * @param payload JWT payload
   * @param requiredRole 需要的角色名稱
   * @returns true 表示有該角色，false 表示沒有
   */
  static hasRole(payload: JWTPayload, requiredRole: string): boolean {
    if (!payload.roles || payload.roles.length === 0) {
      return false;
    }
    return payload.roles.includes(requiredRole);
  }

  /**
   * ⭐ 新增：檢查使用者是否有任一指定角色
   * @param payload JWT payload
   * @param requiredRoles 需要的角色陣列（任一即可）
   * @returns true 表示有任一角色，false 表示都沒有
   */
  static hasAnyRole(payload: JWTPayload, requiredRoles: string[]): boolean {
    if (!payload.roles || payload.roles.length === 0) {
      return false;
    }
    return payload.roles.some((role) => requiredRoles.includes(role));
  }

  /**
   * ⭐ 新增：檢查使用者是否擁有所有指定角色
   * @param payload JWT payload
   * @param requiredRoles 需要的角色陣列（必須全部擁有）
   * @returns true 表示擁有所有角色，false 表示缺少至少一個
   */
  static hasAllRoles(payload: JWTPayload, requiredRoles: string[]): boolean {
    if (!payload.roles || payload.roles.length === 0) {
      return false;
    }
    return requiredRoles.every((role) => payload.roles!.includes(role));
  }
}
