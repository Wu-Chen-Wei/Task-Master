/**
 * 加密與安全工具類別
 * 處理密碼雜湊、Token 產生等安全相關功能
 */

import bcrypt from 'bcrypt';
import crypto from 'crypto';

export class CryptoUtil {
  // bcrypt 雜湊輪數，數字越高越安全但運算越慢
  private static readonly SALT_ROUNDS = 12;

  /**
   * 將明文密碼進行雜湊加密
   * @param password 明文密碼
   * @returns 加密後的密碼雜湊值
   */
  static async hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, this.SALT_ROUNDS);
  }

  /**
   * 驗證密碼是否正確
   * @param password 使用者輸入的明文密碼
   * @param hash 資料庫中儲存的密碼雜湊值
   * @returns 密碼是否正確
   */
  static async verifyPassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
  }

  /**
   * 產生安全的隨機 Token
   * 用於 Email 驗證、密碼重設等功能
   * @returns 64 字元的十六進位隨機字串
   */
  static generateSecureToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  /**
   * 產生 Token 過期時間
   * @param hoursFromNow 從現在開始幾小時後過期（預設 24 小時）
   * @returns Token 過期的時間點
   */
  static generateTokenExpiry(hoursFromNow: number = 24): Date {
    const expiry = new Date();
    expiry.setHours(expiry.getHours() + hoursFromNow);
    return expiry;
  }
}