/**
 * 專案路由
 */
import { Router } from 'express';
import mysql from 'mysql2/promise';
import { authenticate } from '../middlewares/auth.middleware.js';
import { requireRole, requirePermission, requireAnyPermission } from '../middlewares/permission.middleware.js';
// import { ProjectController } from '../controllers/project.controller.js';  // 您的 Controller

export const member_createProjectRoutes = (pool: mysql.Pool): Router => {
  const router = Router();
  // const projectController = new ProjectController(pool);

  // ====================================
  // 📌 範例 1: 使用角色檢查
  // ====================================
  
  // 建立專案 - 只有 PM 和 SystemAdmin 可以
  router.post('/',
    authenticate,                              // 1. 先驗證登入
    requireRole(['PM', 'Admin']),        // 2. 再檢查角色
    (req, res) => {                            // 3. 執行邏輯
      res.json({ 
        success: true, 
        message: '建立專案成功',
        user: req.user  // 可以取得使用者資訊
      });
    }
  );

  // ====================================
  // 📌 範例 2: 使用權限檢查
  // ====================================
  
  // 編輯專案 - 需要 edit_project 權限
  router.put('/:projectId',
    authenticate,
    requirePermission(pool, 'edit_project'),
    (req, res) => {
      res.json({ 
        success: true, 
        message: '編輯專案成功' 
      });
    }
  );

  // 刪除專案 - 需要 delete_project 權限（只有 SystemAdmin 有）
  router.delete('/:projectId',
    authenticate,
    requirePermission(pool, 'delete_project'),
    (req, res) => {
      res.json({ 
        success: true, 
        message: '刪除專案成功' 
      });
    }
  );

  // ====================================
  // 📌 範例 3: 使用多個權限之一
  // ====================================
  
  // 查看專案詳情 - PM, RD_Leader, SystemAdmin 都可以
  router.get('/:projectId',
    authenticate,
    requireAnyPermission(pool, ['create_project', 'view_reports']),
    (req, res) => {
      res.json({ 
        success: true, 
        message: '取得專案詳情成功' 
      });
    }
  );

  // ====================================
  // 📌 範例 4: 只需要登入即可
  // ====================================
  
  // 查看所有專案列表 - 任何登入使用者都可以
  router.get('/',
    authenticate,  // 只需要登入
    (req, res) => {
      res.json({ 
        success: true, 
        message: '取得專案列表成功',
        userRoles: req.user?.roles  // 可以看到使用者的角色
      });
    }
  );

  return router;
};