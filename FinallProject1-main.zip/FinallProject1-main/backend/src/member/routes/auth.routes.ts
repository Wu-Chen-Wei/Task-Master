/**
 * 認證路由設定
 * 定義所有與使用者認證相關的 API 端點
 */

import { Router } from "express";
import { AuthController } from "../controllers/auth.controller.js";
import { GoogleAuthController } from "../controllers/google-auth.controller.js";
import { AuthService } from "../services/auth.service.js";
import { GoogleAuthService } from "../services/google-auth.service.js";
/* import { authenticate } from '../member/middlewares/auth.middleware.js'; */
import { authenticate } from "../middlewares/auth.middleware.js";
import mysql from "mysql2/promise";
/**
 * 建立認證路由的工廠函數
 * @param pool 資料庫連線池物件
 * @returns 設定好的 Express Router
 */
export const member_createAuthRoutes = (pool: mysql.Pool): Router => {
  const router = Router();

  // 建立服務層和控制器實例
  const authService = new AuthService(pool);
  const authController = new AuthController(authService);

  const googleAuthService = new GoogleAuthService(pool);
  const googleAuthController = new GoogleAuthController(googleAuthService);

  /**
   * 使用者登入
   * POST /api/auth/login
   *
   * 請求體範例：
   * {
   *   "email": "user@example.com",
   *   "password": "Password123"
   * }
   *
   * 成功回應範例：
   * {
   *   "success": true,
   *   "message": "登入成功",
   *   "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
   *   "user": {
   *     "UserID": 8,
   *     "Email": "user@example.com",
   *     "FullName": "使用者姓名"
   *   }
   * }
   */
  router.post("/login", authController.login);

  /**
   * 使用者登出
   * POST /api/auth/logout
   *
   * Headers: Authorization: Bearer <token>
   *
   * 回應範例：
   * {
   *   "success": true,
   *   "message": "登出成功"
   * }
   */
  router.post("/logout", authController.logout);

  /**
   * 驗證 Token 有效性
   * GET /api/auth/verify
   *
   * Headers: Authorization: Bearer <token>
   *
   * 成功回應範例：
   * {
   *   "success": true,
   *   "message": "Token 驗證成功",
   *   "user": {
   *     "UserID": 8,
   *     "Email": "user@example.com",
   *     "FullName": "使用者姓名"
   *   }
   * }
   */
  router.get("/verify", authController.verifyToken);

  /**
   * 刷新 Token
   * POST /api/auth/refresh
   *
   * Headers: Authorization: Bearer <old-token>
   *
   * 成功回應範例：
   * {
   *   "success": true,
   *   "message": "Token 刷新成功",
   *   "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
   *   "user": { ... }
   * }
   */
  router.post("/refresh", authController.refreshToken);

  /**
   * 取得當前登入使用者資料
   * GET /api/auth/me
   *
   * Headers: Authorization: Bearer <token>
   *
   * 成功回應範例：
   * {
   *   "success": true,
   *   "message": "取得使用者資料成功",
   *   "user": {
   *     "UserID": 8,
   *     "Email": "user@example.com",
   *     "FullName": "使用者姓名",
   *     "EmailVerified": true
   *   }
   * }
   */
  console.log("🔵 註冊 /me 路由");
  router.get("/me", authController.getCurrentUser);
  console.log('✅ 註冊 GET /api/auth/me 路由');

  /**
   * 忘記密碼
   * POST /api/auth/forgot-password
   *
   * 請求體範例：
   * {
   *   "email": "user@example.com"
   * }
   *
   * 成功回應範例：
   * {
   *   "success": true,
   *   "message": "重設密碼連結已發送至您的信箱",
   *   "resetToken": "abc123..." (僅開發模式顯示)
   * }
   */
  router.post("/forgot-password", authController.forgotPassword);

  /**
   * 重設密碼
   * POST /api/auth/reset-password
   *
   * 請求體範例：
   * {
   *   "token": "重設密碼的 Token",
   *   "newPassword": "NewPassword123"
   * }
   *
   * 成功回應範例：
   * {
   *   "success": true,
   *   "message": "密碼重設成功，請使用新密碼登入"
   * }
   */
  router.post("/reset-password", authController.resetPassword);

  /**
   * 修改密碼
   * POST /api/auth/change-password
   *
   * Headers: Authorization: Bearer <token>
   *
   * 請求體範例：
   * {
   *   "oldPassword": "OldPassword123",
   *   "newPassword": "NewPassword123"
   * }
   *
   * 成功回應範例：
   * {
   *   "success": true,
   *   "message": "密碼修改成功"
   * }
   */
  router.post("/change-password", authController.changePassword);
  // === Google OAuth 端點 ⭐ 新增 ===

  /**
   * 取得 Google OAuth 登入 URL
   * GET /api/auth/google/auth-url
   */
  router.get("/google/auth-url", googleAuthController.getGoogleAuthUrl);

  /**
   * 處理 Google OAuth 回調
   * POST /api/auth/google/callback
   */
  router.get("/google/callback", googleAuthController.handleGoogleCallback);

  /**
   * Google 登入
   * POST /api/auth/google
   */
  router.post("/google", googleAuthController.googleLogin);
  /**
   * Google OAuth 認證入口（重導向到 Google）
   * GET /api/auth/google
   */
  router.get("/google", googleAuthController.getGoogleAuthUrl);

  /**
   * 連結 Google 帳號
   * POST /api/auth/google/link
   */
  router.post(
    "/google/link",
    authenticate,
    googleAuthController.linkGoogleAccount
  );

  return router;
};

/**
 * 路由使用方式說明：
 *
 * 在主要的 app.ts 檔案中：
 *
 * import { createAuthRoutes } from './routes/auth.routes.js';
 *
 * const authRoutes = createAuthRoutes(dbPool);
 * app.use('/api/auth', authRoutes);
 *
 * 這樣就會建立以下端點：
 * - POST   /api/auth/login           - 使用者登入
 * - POST   /api/auth/logout          - 使用者登出
 * - GET    /api/auth/verify          - 驗證 Token
 * - POST   /api/auth/refresh         - 刷新 Token
 * - GET    /api/auth/me              - 取得當前使用者資料
 * - POST   /api/auth/forgot-password - 忘記密碼
 * - POST   /api/auth/reset-password  - 重設密碼
 * - POST   /api/auth/change-password - 修改密碼
 *
 * 需要 Token 驗證的端點（在 Header 中加入）：
 * Authorization: Bearer <your-jwt-token>
 * - /api/auth/logout
 * - /api/auth/verify
 * - /api/auth/refresh
 * - /api/auth/me
 * - /api/auth/change-password
 *
 * 密碼管理流程：
 * 1. 忘記密碼：POST /forgot-password → 取得 resetToken
 * 2. 重設密碼：POST /reset-password + resetToken
 * 3. 修改密碼：POST /change-password + 舊密碼 + Token
 */
