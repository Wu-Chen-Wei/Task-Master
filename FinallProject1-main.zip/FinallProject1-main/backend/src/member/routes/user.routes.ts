/**
 * 使用者路由設定
 * 定義所有與使用者相關的 API 端點
 */

import { Router } from "express";
import { UserController } from "../controllers/user.controller.js";
import { UserService } from "../services/user.service.js";
import { authenticate, authorize } from "../middlewares/auth.middleware.js";
import { avatarUpload } from "../..//config/multer.config.js";
import mysql from "mysql2/promise";

/**
 * 建立使用者路由的工廠函數
 * @param pool 資料庫連線池物件
 * @returns 設定好的 Express Router
 */
export const member_createUserRoutes = (pool: mysql.Pool): Router => {
  const router = Router();

  // 建立服務層和控制器實例
  const userService = new UserService(pool);
  const userController = new UserController(userService, pool);

  // ==================== 公開端點（不需認證） ====================
  router.post("/register", userController.register);
  router.get("/verify-email", userController.verifyEmail); // ← 改成 GET
  router.post("/resend-verification", userController.resendVerificationEmail);
  router.get("/check-email", userController.checkEmailAvailability);

  // ==================== 需要登入的端點 ====================
  router.get("/team-members", authenticate, userController.getTeamMembers);

  // ⭐ 取得個人資料（自己的資料）
  router.get("/me", authenticate, userController.getMyProfile);

  // ⭐ 更新個人資料（自己的資料）
  router.patch("/me", authenticate, userController.updateMyProfile);

  // 更新個人資料（自己的資料）
  router.patch("/profile", authenticate, userController.updateProfile);

  // ⭐ 上傳頭像（需要登入）
  router.post(
    "/me/avatar",
    authenticate,
    avatarUpload.single("avatar"), // ⭐ multer 中介層，欄位名稱是 "avatar"
    userController.uploadAvatar
  );

  // ==================== 管理員端點（需要 manage_users 權限）====================

  // ⭐ 重要：具體路由必須在通用路由 (/:id) 之前定義！

  // 1. 取得所有使用者
  router.get(
    "/",
    authenticate,
    authorize(pool, "manage_users"),
    userController.getAllUsers
  );

  // 2. 建立新使用者（管理員）
  router.post(
    "/admin",
    authenticate,
    authorize(pool, "manage_users"),
    userController.adminCreateUser
  );

  // 3. 更新使用者狀態（具體路由）
  router.patch(
    "/:id/status",
    authenticate,
    authorize(pool, "manage_users"),
    userController.updateUserStatus
  );

  // 4. 取得使用者角色（具體路由）
  router.get(
    "/:id/roles",
    authenticate,
    authorize(pool, "manage_users"),
    userController.getUserRoles
  );

  // 5. 指派使用者角色（具體路由）
  router.put(
    "/:id/roles",
    authenticate,
    authorize(pool, "manage_users"),
    userController.assignGlobalRoles
  );

  // ⭐ 6. 更新使用者資料（通用路由，必須放在最後）
  router.patch(
    "/:id",
    authenticate,
    authorize(pool, "manage_users"),
    userController.updateUser
  );
  // 審核使用者 (需要 manage_users 權限)
  router.post(
    "/:id/approve",
    authenticate,
    authorize(pool, "manage_users"),
    (req, res) => userController.approveUser(req, res)
  );

  // 7. 取得單一使用者（通用路由，必須放在最後）
  router.get("/:id", authenticate, userController.getUserById);

  return router;
};
