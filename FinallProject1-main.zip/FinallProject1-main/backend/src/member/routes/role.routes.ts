/**
 * 角色路由設定
 * 定義所有與角色管理相關的 API 端點
 */

import { Router } from 'express';
import { RoleController } from '../controllers/role.controller.js';
import { RoleService } from '../services/role.service.js';
import mysql from 'mysql2/promise';

/**
 * 建立角色路由的工廠函數
 * @param pool 資料庫連線池物件
 * @returns 設定好的 Express Router
 */
export const member_createRoleRoutes = (pool: mysql.Pool): Router => {
  const router = Router();
  
  // 建立服務層和控制器實例
  const roleService = new RoleService(pool);
  const roleController = new RoleController(roleService);

  /**
   * 取得所有角色列表
   * GET /api/roles
   * 
   * 回應範例：
   * {
   *   "success": true,
   *   "message": "查詢角色列表成功",
   *   "roles": [
   *     {
   *       "RoleID": 1,
   *       "RoleName": "SystemAdmin",
   *       "Description": "系統最高管理員"
   *     }
   *   ]
   * }
   */
  router.get('/', roleController.getAllRoles);

  /**
   * 根據 ID 取得特定角色
   * GET /api/roles/:id
   * 
   * 範例：GET /api/roles/1
   * 
   * 回應範例：
   * {
   *   "success": true,
   *   "message": "查詢角色成功",
   *   "role": {
   *     "RoleID": 1,
   *     "RoleName": "SystemAdmin",
   *     "Description": "系統最高管理員"
   *   }
   * }
   */
  router.get('/:id', roleController.getRoleById);

  /**
   * 建立新角色
   * POST /api/roles
   * 
   * 請求體範例：
   * {
   *   "roleName": "ProjectManager",
   *   "description": "專案經理角色"
   * }
   * 
   * 回應範例：
   * {
   *   "success": true,
   *   "message": "角色建立成功",
   *   "role": {
   *     "RoleID": 7,
   *     "RoleName": "ProjectManager",
   *     "Description": "專案經理角色"
   *   }
   * }
   */
  router.post('/', roleController.createRole);

  /**
   * 更新角色
   * PUT /api/roles/:id
   * 
   * 請求體範例：
   * {
   *   "roleName": "Senior_PM",
   *   "description": "資深專案經理"
   * }
   * 
   * 回應範例：
   * {
   *   "success": true,
   *   "message": "角色更新成功",
   *   "role": {
   *     "RoleID": 7,
   *     "RoleName": "Senior_PM",
   *     "Description": "資深專案經理"
   *   }
   * }
   */
  router.put('/:id', roleController.updateRole);

  /**
   * 刪除角色
   * DELETE /api/roles/:id
   * 
   * 範例：DELETE /api/roles/7
   * 
   * 回應範例：
   * {
   *   "success": true,
   *   "message": "角色刪除成功"
   * }
   */
  router.delete('/:id', roleController.deleteRole);

  return router;
};

/**
 * 路由使用方式說明：
 * 
 * 在主要的 app.ts 檔案中：
 * 
 * import { createRoleRoutes } from './routes/role.routes.js';
 * 
 * const roleRoutes = createRoleRoutes(dbPool);
 * app.use('/api/roles', roleRoutes);
 * 
 * 這樣就會建立以下端點：
 * - GET    /api/roles           - 取得所有角色
 * - GET    /api/roles/:id       - 取得特定角色
 * - POST   /api/roles           - 建立新角色
 * - PUT    /api/roles/:id       - 更新角色
 * - DELETE /api/roles/:id       - 刪除角色
 * 
 * 注意：這些端點應該要加上權限驗證中間件，確保只有管理員可以操作
 */