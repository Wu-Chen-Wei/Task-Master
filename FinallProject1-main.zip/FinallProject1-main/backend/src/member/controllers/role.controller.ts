/**
 * 角色控制器
 * 處理角色管理相關的 HTTP 請求和回應
 */

import { Request, Response } from 'express';
import { RoleService } from '../services/role.service.js';
import { createRoleSchema, updateRoleSchema } from '../utils/validation.js';
import { CreateRoleRequest, UpdateRoleRequest } from '../types/role.types.js';

export class RoleController {
  constructor(private roleService: RoleService) {}

  /**
   * 取得所有角色列表
   * GET /api/roles
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  getAllRoles = async (req: Request, res: Response): Promise<void> => {
    try {
      const result = await this.roleService.getAllRoles();

      if (result.success) {
        res.status(200).json(result);
      } else {
        res.status(500).json(result);
      }

    } catch (error) {
      console.error('取得角色列表時發生錯誤:', error);
      
      res.status(500).json({
        success: false,
        message: '伺服器內部錯誤'
      });
    }
  };

  /**
   * 根據 ID 取得特定角色
   * GET /api/roles/:id
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  getRoleById = async (req: Request, res: Response): Promise<void> => {
    try {
      // 步驟 1: 驗證 URL 參數
      const roleID = parseInt(req.params.id);
      
      if (isNaN(roleID) || roleID <= 0) {
        res.status(400).json({
          success: false,
          message: '無效的角色 ID'
        });
        return;
      }

      // 步驟 2: 查詢角色
      const result = await this.roleService.getRoleById(roleID);

      if (result.success) {
        res.status(200).json(result);
      } else {
        res.status(404).json(result);
      }

    } catch (error) {
      console.error('查詢角色時發生錯誤:', error);
      
      res.status(500).json({
        success: false,
        message: '伺服器內部錯誤'
      });
    }
  };

  /**
   * 建立新角色
   * POST /api/roles
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  createRole = async (req: Request, res: Response): Promise<void> => {
    try {
      // 步驟 1: 驗證請求資料格式
      const validationResult = createRoleSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        const errorMessages = validationResult.error.issues.map((err: any) => ({
          field: err.path.join('.'),
          message: err.message
        }));

        res.status(400).json({
          success: false,
          message: '輸入資料格式錯誤',
          errors: errorMessages
        });
        return;
      }

      // 步驟 2: 取得驗證通過的資料
      const roleData: CreateRoleRequest = validationResult.data;

      // 步驟 3: 呼叫服務層建立角色
      const result = await this.roleService.createRole(roleData);

      // 步驟 4: 根據結果回傳適當的 HTTP 狀態碼
      if (result.success) {
        res.status(201).json(result);
      } else {
        res.status(400).json(result);
      }

    } catch (error) {
      console.error('建立角色時發生錯誤:', error);
      
      res.status(500).json({
        success: false,
        message: '伺服器內部錯誤'
      });
    }
  };

  /**
   * 更新角色
   * PUT /api/roles/:id
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  updateRole = async (req: Request, res: Response): Promise<void> => {
    try {
      // 步驟 1: 驗證 URL 參數
      const roleID = parseInt(req.params.id);
      
      if (isNaN(roleID) || roleID <= 0) {
        res.status(400).json({
          success: false,
          message: '無效的角色 ID'
        });
        return;
      }

      // 步驟 2: 驗證請求資料格式
      const validationResult = updateRoleSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        const errorMessages = validationResult.error.issues.map((err: any) => ({
          field: err.path.join('.'),
          message: err.message
        }));

        res.status(400).json({
          success: false,
          message: '輸入資料格式錯誤',
          errors: errorMessages
        });
        return;
      }

      // 步驟 3: 取得驗證通過的資料
      const updateData: UpdateRoleRequest = validationResult.data;

      // 步驟 4: 呼叫服務層更新角色
      const result = await this.roleService.updateRole(roleID, updateData);

      // 步驟 5: 根據結果回傳適當的 HTTP 狀態碼
      if (result.success) {
        res.status(200).json(result);
      } else {
        res.status(400).json(result);
      }

    } catch (error) {
      console.error('更新角色時發生錯誤:', error);
      
      res.status(500).json({
        success: false,
        message: '伺服器內部錯誤'
      });
    }
  };

  /**
   * 刪除角色
   * DELETE /api/roles/:id
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  deleteRole = async (req: Request, res: Response): Promise<void> => {
    try {
      // 步驟 1: 驗證 URL 參數
      const roleID = parseInt(req.params.id);
      
      if (isNaN(roleID) || roleID <= 0) {
        res.status(400).json({
          success: false,
          message: '無效的角色 ID'
        });
        return;
      }

      // 步驟 2: 呼叫服務層刪除角色
      const result = await this.roleService.deleteRole(roleID);

      // 步驟 3: 根據結果回傳適當的 HTTP 狀態碼
      if (result.success) {
        res.status(200).json(result);
      } else {
        res.status(400).json(result);
      }

    } catch (error) {
      console.error('刪除角色時發生錯誤:', error);
      
      res.status(500).json({
        success: false,
        message: '伺服器內部錯誤'
      });
    }
  };
}