/**
 * Google OAuth Controller
 * 
 * ✅ 功能說明：
 *   - 接收前端請求（例如 Google 登入、帳號綁定）
 *   - 驗證輸入資料是否正確
 *   - 呼叫對應的 Service 處理業務邏輯
 *   - 回傳結果給前端
 * 
 * ⚙️ 對應的 Service 檔案：
 *   src/member/services/google-auth.service.ts
 */

import { Request, Response } from 'express';
import { GoogleAuthService } from '../services/google-auth.service.js';

export class GoogleAuthController {
  constructor(private googleAuthService: GoogleAuthService) {}

  /**
   * 🌐 Google 登入端點
   * 路由：POST /api/auth/google
   * 功能：
   *   - 前端傳入 Google 登入後取得的 `id_token`
   *   - 驗證 token 是否存在
   *   - 呼叫 Service 的 googleLogin() 進行登入或自動註冊
   * 回傳：
   *   - JWT Token + 使用者資訊（若成功）
   */
  googleLogin = async (req: Request, res: Response): Promise<void> => {
    try {
      // 從請求中取得 Google ID Token
      const { token } = req.body;

      // ✅ Step 1: 檢查是否有傳入 Token
      if (!token) {
        res.status(400).json({
          success: false,
          message: "缺少 Google Token",
        });
        return;
      }

      // ✅ Step 2: 呼叫 Service 層進行 Google 登入邏輯
      const result = await this.googleAuthService.googleLogin(token);

      // ✅ Step 3: 根據執行結果回傳 HTTP 狀態碼
      res.status(result.success ? 200 : 400).json(result);

    } catch (error) {
      console.error("🔴 Google 登入 Controller 發生錯誤:", error);

      // 若發生非預期錯誤（例如 DB、API 錯誤），回傳 500
      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };

  /**
   * ⚙️（可選功能）取得 Google OAuth 登入 URL
   * 路由：GET /api/auth/google/auth-url
   * 功能：
   *   - 若使用「導向式登入（Redirect Flow）」才會用到
   *   - 產生使用者可前往 Google 登入的網址
   * 
   * ❗目前你的專案屬於「Token Flow」登入（前端直接傳 token），
   *   所以這段在現階段不需要。
   */
  getGoogleAuthUrl = async (req: Request, res: Response): Promise<void> => {
    try {
      const result = await this.googleAuthService.getGoogleAuthUrl();
      res.status(200).json(result);
    } catch (error) {
      console.error('取得 Google Auth URL 錯誤:', error);
      res.status(500).json({
        success: false,
        message: '產生 Google 登入連結失敗'
      });
    }
  };

  /**
   * ⚙️（可選功能）處理 Google OAuth 回調
   * 路由：POST /api/auth/google/callback
   * 功能：
   *   - 若使用導向式登入，Google 會帶一個 `code` 回來
   *   - 後端用這個 code 去向 Google 交換 Token，再登入
   * 
   * ❗目前你的專案屬於「非導向式登入」，這段可先略過。
   */
  handleGoogleCallback = async (req: Request, res: Response): Promise<void> => {
    try {
      // ⭐ 重點：從 req.query 取得 code（不是 req.body）
      const code = req.query.code as string;

      if (!code) {
        res.status(400).json({
          success: false,
          message: '缺少授權碼'
        });
        return;
      }

      console.log('📥 收到 Google 授權碼:', code);

      // ⭐ 呼叫 Service
      const result = await this.googleAuthService.handleGoogleCallback(code);
      
      console.log('✅ Service 回應:', result);

      // ⭐ 根據結果重導向
      if (result.success && result.data) {
        const token = result.data.token;
        const frontendUrl = `http://localhost:3000/auth/callback?token=${token}`;
        
        console.log('🔄 重導向到:', frontendUrl);
        res.redirect(frontendUrl);
      } else {
        const errorMessage = encodeURIComponent(result.message || 'Google 登入失敗');
        console.log('❌ 失敗原因:', result.message);
        res.redirect(`http://localhost:3000/login?error=${errorMessage}`);
      }

    } catch (error) {
      console.error('🔴 Controller 錯誤:', error);
      res.redirect('http://localhost:3000/login?error=登入失敗');
    }
  };


  /**
   * 🔗 Google 帳號連結端點（需登入）
   * 路由：POST /api/auth/google/link
   * 功能：
   *   - 讓已登入的使用者「綁定」Google 帳號
   *   - 可用於現有帳號 + Google OAuth 同步登入
   * 步驟：
   *   1️⃣ 驗證請求中是否有 Google Token
   *   2️⃣ 驗證使用者是否登入（從 JWT middleware 取得 userID）
   *   3️⃣ 呼叫 Service 執行連結邏輯
   */
  linkGoogleAccount = async (req: Request, res: Response): Promise<void> => {
    try {
      const { token } = req.body;
      const userID = (req as any).user?.userID; // ✅ 從 authenticate middleware 取得目前登入使用者 ID

      // ✅ Step 1: 驗證輸入
      if (!token) {
        res.status(400).json({
          success: false,
          message: "缺少 Google Token",
        });
        return;
      }

      // ✅ Step 2: 驗證使用者是否登入
      if (!userID) {
        res.status(401).json({
          success: false,
          message: "請先登入",
        });
        return;
      }

      // ✅ Step 3: 呼叫 Service 執行綁定邏輯
      const result = await this.googleAuthService.linkGoogleAccount(userID, token);

      res.status(result.success ? 200 : 400).json(result);

    } catch (error) {
      console.error("🔴 連結 Google 帳號 Controller 發生錯誤:", error);

      // 非預期錯誤
      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };
}
