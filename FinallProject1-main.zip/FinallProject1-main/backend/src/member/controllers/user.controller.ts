/**
 * 使用者控制器
 * 處理使用者相關的 HTTP 請求和回應
 */

import { Request, Response } from "express";
import { UserService } from "../services/user.service.js";
import {
  userRegistrationSchema,
  updateProfileSchema,
} from "../utils/validation.js";
import { UpdateProfileData } from "../schemas/user.schema.js";
import { CreateUserRequest } from "../types/user.types.js";
import mysql from "mysql2/promise"; //

export class UserController {
  private userService: UserService;
  private pool: mysql.Pool; // ⭐ 新增 pool 屬性

  constructor(userService: UserService, pool: mysql.Pool) {
    // ⭐ 修改建構子
    this.userService = userService;
    this.pool = pool; // ⭐ 儲存 pool
  }
  /**
   * 取得團隊成員列表（供任務指派用）
   * 只回傳基本資訊，不含敏感資料
   */
  /**
   * 取得團隊成員列表（供任務指派用）
   */
  /**
   * 取得團隊成員列表（供任務指派用）
   */
  getTeamMembers = async (req: Request, res: Response) => {
    // ✅ 使用箭頭函數
    try {
      console.log("🔵 getTeamMembers 被呼叫");

      const [users] = await this.pool.query<any[]>(
        `SELECT 
        u.UserID,
        u.FullName,
        u.Email,
        u.Title,
        u.AvatarURL,
        GROUP_CONCAT(DISTINCT r.RoleName) as Roles
      FROM users u
      LEFT JOIN userglobalroles ugr ON u.UserID = ugr.UserID
      LEFT JOIN roles r ON ugr.RoleID = r.RoleID
      WHERE u.Status = 'Active'
      GROUP BY u.UserID, u.FullName, u.Email, u.Title, u.AvatarURL
      ORDER BY u.FullName`
      );

      console.log("✅ 查詢到", users.length, "位使用者");

      // 將 Roles 從字串轉成陣列
      const formattedUsers = users.map((user: any) => ({
        UserID: user.UserID,
        FullName: user.FullName,
        Email: user.Email,
        Title: user.Title,
        AvatarURL: user.AvatarURL,
        Roles: user.Roles ? user.Roles.split(",") : [],
      }));

      console.log("📋 格式化後的使用者:", formattedUsers);

      res.json({
        success: true,
        data: formattedUsers,
      });
    } catch (error) {
      console.error("❌ getTeamMembers error:", error);
      res.status(500).json({
        success: false,
        message: "取得團隊成員失敗",
        error: error instanceof Error ? error.message : "未知錯誤",
      });
    }
  }; // ✅ 注意是用 = 而不是傳統的方法定義

  /**
   * 使用者註冊端點
   * POST /api/users/register
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  register = async (req: Request, res: Response): Promise<void> => {
    try {
      // 步驟 1: 驗證請求資料格式
      const validationResult = userRegistrationSchema.safeParse(req.body);

      if (!validationResult.success) {
        // 如果驗證失敗，回傳詳細的錯誤訊息
        const errorMessages = validationResult.error.issues.map((err: any) => ({
          field: err.path.join("."),
          message: err.message,
        }));

        res.status(400).json({
          success: false,
          message: "輸入資料格式錯誤",
          errors: errorMessages,
        });
        return;
      }

      // 步驟 2: 取得驗證通過的資料
      const userData: CreateUserRequest = validationResult.data;

      // 步驟 3: 呼叫服務層建立使用者
      const result = await this.userService.createUser(userData);

      // 步驟 4: 根據結果回傳適當的 HTTP 狀態碼
      if (result.success) {
        // 註冊成功 - 201 Created
        res.status(201).json(result);
      } else {
        // 註冊失敗（如 Email 重複）- 400 Bad Request
        res.status(400).json(result);
      }
    } catch (error) {
      // 步驟 5: 處理未預期的伺服器錯誤
      console.error("使用者註冊時發生未預期錯誤:", error);

      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤，請稍後再試",
      });
    }
  };

  /**
   * 取得使用者資料端點
   * GET /api/users/:id
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  getUserById = async (req: Request, res: Response): Promise<void> => {
    try {
      // 步驟 1: 驗證 URL 參數
      const userID = parseInt(req.params.id);

      if (isNaN(userID) || userID <= 0) {
        res.status(400).json({
          success: false,
          message: "無效的使用者 ID",
        });
        return;
      }

      // 步驟 2: 查詢使用者資料
      const user = await this.userService.getUserById(userID);

      if (!user) {
        res.status(404).json({
          success: false,
          message: "找不到指定的使用者",
        });
        return;
      }

      // 步驟 3: 回傳使用者資料
      res.status(200).json({
        success: true,
        message: "查詢成功",
        user: user,
      });
    } catch (error) {
      console.error("查詢使用者時發生錯誤:", error);

      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };

  /**
   * 檢查 Email 是否可用端點
   * GET /api/users/check-email?email=xxx
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  checkEmailAvailability = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    try {
      // 步驟 1: 取得查詢參數中的 Email
      const email = req.query.email as string;

      if (!email || typeof email !== "string") {
        res.status(400).json({
          success: false,
          message: "請提供有效的 Email 地址",
        });
        return;
      }

      // 步驟 2: 檢查 Email 是否已存在
      const emailExists = await this.userService.checkEmailExists(email);

      res.status(200).json({
        success: true,
        available: !emailExists,
        message: emailExists ? "Email 已被使用" : "Email 可以使用",
      });
    } catch (error) {
      console.error("檢查 Email 可用性時發生錯誤:", error);

      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };

  /**
   * Email 驗證端點
   * POST /api/users/verify-email
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  /**
   * Email 驗證端點
   * GET /api/users/verify-email?token=xxx  ← 改成 GET
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  /**
   * 驗證 Email
   */
  verifyEmail = async (req: Request, res: Response): Promise<void> => {
    try {
      const { token } = req.query;

      if (!token || typeof token !== "string") {
        res.status(400).json({
          success: false,
          message: "缺少驗證 Token",
        });
        return;
      }

      // ⭐ Service 直接回傳完整使用者資料
      const result = await this.userService.verifyEmail(token);

      if (result.success) {
        res.status(200).json({
          success: true,
          message: result.message,
          user: result.user, // ⭐ 直接使用 Service 回傳的資料
        });
      } else {
        res.status(400).json({
          success: false,
          message: result.message,
        });
      }
    } catch (error) {
      console.error("❌ Controller: 驗證 Email 時發生錯誤:", error);
      res.status(500).json({
        success: false,
        message: "驗證過程發生錯誤",
      });
    }
  };
  /**
   * 重新發送驗證信端點
   * POST /api/users/resend-verification
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  /**
   * ⭐ 新增：重新發送驗證信端點
   * POST /api/users/resend-verification
   */
  resendVerificationEmail = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    try {
      const { email } = req.body;

      console.log("🔵 Controller: 重新發送驗證信", { email });

      if (!email || typeof email !== "string") {
        res.status(400).json({
          success: false,
          message: "請提供有效的 Email",
        });
        return;
      }

      const result = await this.userService.resendVerificationEmail(email);

      console.log("🔵 Controller: 重新發送結果", result);

      if (result.success) {
        console.log("✅ Controller: 驗證信已重新發送");
        res.status(200).json(result);
      } else {
        console.log("❌ Controller: 重新發送失敗", result.message);
        res.status(400).json(result);
      }
    } catch (error) {
      console.error("❌ Controller: 重新發送驗證信時發生錯誤:", error);
      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };
  /**
   * 以下方法請加入到 UserController 類別中
   */

  /**
   * 管理員建立使用者端點
   * POST /api/users/admin
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  adminCreateUser = async (req: Request, res: Response): Promise<void> => {
    try {
      // 步驟 1: 驗證請求資料格式
      const validationResult = userRegistrationSchema.safeParse(req.body);

      if (!validationResult.success) {
        const errorMessages = validationResult.error.issues.map((err: any) => ({
          field: err.path.join("."),
          message: err.message,
        }));

        res.status(400).json({
          success: false,
          message: "輸入資料格式錯誤",
          errors: errorMessages,
        });
        return;
      }

      // ⭐ 步驟 2: 取得角色名稱陣列（改為 roles）
      const { email, fullName, password, title, roles = [] } = req.body;

      // 驗證 roles 格式
      if (!Array.isArray(roles)) {
        res.status(400).json({
          success: false,
          message: "roles 必須是陣列",
        });
        return;
      }

      // 檢查是否所有元素都是字串
      if (
        roles.length > 0 &&
        !roles.every((role: any) => typeof role === "string")
      ) {
        res.status(400).json({
          success: false,
          message: "roles 陣列中的所有元素必須是角色名稱（字串）",
        });
        return;
      }

      // ⭐ 步驟 3: 呼叫服務層建立使用者（傳遞 roles）
      const result = await this.userService.adminCreateUser(
        { email, fullName, password, title },
        roles // ⭐ 傳遞角色名稱陣列
      );

      // 步驟 4: 根據結果回傳適當的狀態碼
      if (result.success) {
        res.status(201).json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      console.error("管理員建立使用者時發生錯誤:", error);

      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };
  /**
/**
 * 更新使用者狀態
 * PATCH /api/users/:id/status
 * 需要權限: manage_users
 */
  updateUserStatus = async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = parseInt(req.params.id, 10);
      const { status } = req.body;

      console.log("🔵 Controller: 更新使用者狀態", { userId, status });

      // 驗證狀態值
      const validStatuses = ["Active", "Suspended", "Archived"];
      if (!status) {
        res.status(400).json({
          success: false,
          message: "缺少狀態參數",
        });
        return;
      }

      if (!validStatuses.includes(status)) {
        res.status(400).json({
          success: false,
          message: `狀態必須是 ${validStatuses.join(", ")} 其中之一`,
        });
        return;
      }

      // 驗證 userId
      if (isNaN(userId) || userId <= 0) {
        res.status(400).json({
          success: false,
          message: "無效的使用者 ID",
        });
        return;
      }

      // 呼叫 Service 更新狀態（回傳 boolean）
      const success = await this.userService.updateUserStatus(userId, status);

      if (success) {
        console.log("✅ Controller: 使用者狀態更新成功");
        res.status(200).json({
          success: true,
          message: "使用者狀態更新成功",
        });
      } else {
        console.log("❌ Controller: 使用者不存在或未更新");
        res.status(404).json({
          success: false,
          message: "使用者不存在或狀態未變更",
        });
      }
    } catch (error) {
      console.error("❌ Controller: 更新使用者狀態錯誤:", error);
      res.status(500).json({
        success: false,
        message: "更新使用者狀態失敗",
        error:
          process.env.NODE_ENV === "development"
            ? (error as Error).message
            : undefined,
      });
    }
  };

  /**
   * 指派全域角色給使用者端點
   * PUT /api/users/:id/roles
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  assignGlobalRoles = async (req: Request, res: Response): Promise<void> => {
    try {
      const targetUserID = parseInt(req.params.id);

      if (isNaN(targetUserID)) {
        res.status(400).json({
          success: false,
          message: "無效的使用者 ID",
        });
        return;
      }

      // ⭐ 驗證請求資料（改為 roles）
      const { roles } = req.body;

      if (!Array.isArray(roles) || roles.length === 0) {
        res.status(400).json({
          success: false,
          message: "roles 必須是非空的角色名稱陣列",
        });
        return;
      }

      // 檢查是否所有元素都是字串
      if (!roles.every((role) => typeof role === "string")) {
        res.status(400).json({
          success: false,
          message: "roles 陣列中的所有元素必須是角色名稱（字串）",
        });
        return;
      }

      // 呼叫服務層指派角色
      const result = await this.userService.assignGlobalRoles(
        targetUserID,
        roles
      );

      if (result.success) {
        res.status(200).json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      console.error("指派角色時發生錯誤:", error);
      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };

  /**
   * 查詢使用者的全域角色
   * GET /api/users/:id/roles
   */
  getUserRoles = async (req: Request, res: Response): Promise<void> => {
    try {
      const targetUserID = parseInt(req.params.id);

      if (isNaN(targetUserID)) {
        res.status(400).json({
          success: false,
          message: "無效的使用者 ID",
        });
        return;
      }

      // 查詢使用者角色
      const [rows] = await this.userService["pool"].execute(
        `SELECT r.RoleID, r.RoleName, r.Description
       FROM UserGlobalRoles ugr
       JOIN Roles r ON ugr.RoleID = r.RoleID
       WHERE ugr.UserID = ?`,
        [targetUserID]
      );

      res.status(200).json({
        success: true,
        roles: rows,
      });
    } catch (error) {
      console.error("查詢使用者角色時發生錯誤:", error);
      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };

  /**
   * 更新個人資料端點
   * PATCH /api/users/profile
   */
  updateProfile = async (req: Request, res: Response): Promise<void> => {
    try {
      // 從 JWT 取得使用者 ID
      const userID = (req as any).user?.userID;

      if (!userID) {
        res.status(401).json({
          success: false,
          message: "未授權:無法識別使用者身份",
        });
        return;
      }

      // 驗證請求資料
      const validationResult = updateProfileSchema.safeParse(req.body);

      if (!validationResult.success) {
        const errorMessages = validationResult.error.issues.map((err: any) => ({
          field: err.path.join("."),
          message: err.message,
        }));

        res.status(400).json({
          success: false,
          message: "輸入資料格式錯誤",
          errors: errorMessages,
        });
        return;
      }

      // ⭐ 直接使用驗證後的資料（已經是大寫格式）
      const profileData = validationResult.data;

      // 呼叫服務層更新
      const result = await this.userService.updateProfile(userID, profileData);

      // 回傳結果
      if (result.success) {
        res.status(200).json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      console.error("更新個人資料時發生錯誤:", error);
      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };
  /**
   * 取得所有使用者列表
   * GET /api/users
   * 需要權限: manage_users
   */
  /**
   * 取得所有使用者列表
   * GET /api/users
   * 需要權限: manage_users
   */
  /**
   * 取得所有使用者列表
   * GET /api/users?page=1&pageSize=9&search=&status=Active
   * 需要權限: manage_users
   */
  getAllUsers = async (req: Request, res: Response): Promise<void> => {
    try {
      console.log("🔵 Controller: 開始取得使用者列表");

      // ⭐ 從 query 取得參數
      const page = parseInt(req.query.page as string) || 1;
      const pageSize = parseInt(req.query.pageSize as string) || 10;
      const search = (req.query.search as string) || "";
      const status = (req.query.status as string) || "";

      console.log("🔵 Controller: 查詢參數", {
        page,
        pageSize,
        search,
        status,
      });

      // ⭐ 傳遞給 Service
      const result = await this.userService.getAllUsers({
        page,
        pageSize,
        search,
        status,
      });

      console.log("✅ Controller: 取得使用者列表成功", {
        total: result.total,
        page: result.page,
        totalPages: result.totalPages,
        returned: result.users.length,
      });

      // ⭐ 回傳完整結果
      res.status(200).json({
        success: true,
        users: result.users,
        total: result.total,
        page: result.page,
        pageSize: result.pageSize,
        totalPages: result.totalPages,
      });
    } catch (error) {
      console.error("❌ Controller: 取得使用者列表錯誤:", error);
      res.status(500).json({
        success: false,
        message: "取得使用者列表失敗",
      });
    }
  };
  /**
   * 更新使用者狀態
   * PATCH /api/users/:id/status
   * 需要權限: manage_users
   */
  /**
   * 更新使用者資料
   * PATCH /api/users/:id
   * 需要權限: manage_users
   */
  updateUser = async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = parseInt(req.params.id, 10);
      const { fullName, title, status } = req.body;

      console.log("🔵 Controller: 更新使用者資料", {
        userId,
        fullName,
        title,
        status,
      });

      // 驗證 userId
      if (isNaN(userId) || userId <= 0) {
        res.status(400).json({
          success: false,
          message: "無效的使用者 ID",
        });
        return;
      }

      // 驗證必填欄位
      if (!fullName) {
        res.status(400).json({
          success: false,
          message: "姓名為必填欄位",
        });
        return;
      }

      // 驗證狀態值（如果有提供）
      if (status) {
        const validStatuses = ["Active", "Suspended", "Archived"];
        if (!validStatuses.includes(status)) {
          res.status(400).json({
            success: false,
            message: `狀態必須是 ${validStatuses.join(", ")} 其中之一`,
          });
          return;
        }
      }

      // 呼叫 Service 更新使用者
      const success = await this.userService.updateUser(userId, {
        fullName,
        title,
        status,
      });

      if (success) {
        console.log("✅ Controller: 使用者資料更新成功");
        res.status(200).json({
          success: true,
          message: "使用者資料更新成功",
        });
      } else {
        console.log("❌ Controller: 使用者不存在");
        res.status(404).json({
          success: false,
          message: "使用者不存在",
        });
      }
    } catch (error) {
      console.error("❌ Controller: 更新使用者資料錯誤:", error);
      res.status(500).json({
        success: false,
        message: "更新使用者資料失敗",
      });
    }
  };
  /**
   * 取得當前登入使用者的個人資料
   */
  getMyProfile = async (req: Request, res: Response): Promise<void> => {
    try {
      // ⭐ 從 JWT middleware 取得使用者 ID
      const userId = (req as any).user?.userID;

      if (!userId) {
        res.status(401).json({
          success: false,
          message: "未登入",
        });
        return;
      }

      console.log("🔵 Controller: 取得個人資料", { userId });

      // 查詢使用者資料
      const [userRows] = await this.pool.execute(
        `SELECT UserID, Email, FullName, Title, AvatarURL, EmailVerified, Status, CreatedAt
       FROM Users WHERE UserID = ?`,
        [userId]
      );

      const users = userRows as any[];

      if (users.length === 0) {
        res.status(404).json({
          success: false,
          message: "使用者不存在",
        });
        return;
      }

      const user = users[0];

      // 查詢使用者角色
      const [roleRows] = await this.pool.execute(
        `SELECT r.RoleName 
       FROM userglobalroles ugr
       JOIN roles r ON ugr.RoleID = r.RoleID
       WHERE ugr.UserID = ?`,
        [userId]
      );

      const roles = (roleRows as any[]).map((row) => row.RoleName);

      console.log("✅ Controller: 個人資料查詢成功");

      res.json({
        success: true,
        user: {
          userID: user.UserID,
          Email: user.Email,
          FullName: user.FullName,
          Title: user.Title,
          AvatarURL: user.AvatarURL,
          EmailVerified: Boolean(user.EmailVerified),
          Status: user.Status,
          CreatedAt: user.CreatedAt,
          Roles: roles,
        },
      });
    } catch (error) {
      console.error("❌ Controller: 取得個人資料錯誤:", error);
      res.status(500).json({
        success: false,
        message: "取得個人資料失敗",
      });
    }
  };

  /**
   * 更新當前登入使用者的個人資料
   */
  updateMyProfile = async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = (req as any).user?.userID;

      if (!userId) {
        res.status(401).json({
          success: false,
          message: "未登入",
        });
        return;
      }

      const { fullName, title } = req.body;

      console.log("🔵 Controller: 更新個人資料", { userId, fullName, title });

      // 呼叫 Service
      const result = await this.userService.updateProfile(userId, {
        FullName: fullName,
        Title: title,
      });

      if (result.success) {
        console.log("✅ Controller: 個人資料更新成功");
        res.json({
          success: true,
          message: result.message,
          user: result.user,
        });
      } else {
        res.status(400).json({
          success: false,
          message: result.message,
        });
      }
    } catch (error) {
      console.error("❌ Controller: 更新個人資料錯誤:", error);
      res.status(500).json({
        success: false,
        message: "更新個人資料失敗",
      });
    }
  };
  /**
   * 上傳頭像
   */
  uploadAvatar = async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = (req as any).user?.userID;

      if (!userId) {
        res.status(401).json({
          success: false,
          message: "未登入",
        });
        return;
      }

      // ⭐ multer 會把檔案資訊放在 req.file
      const file = req.file;

      if (!file) {
        res.status(400).json({
          success: false,
          message: "請選擇圖片檔案",
        });
        return;
      }

      console.log("🔵 Controller: 上傳頭像", {
        userId,
        filename: file.filename,
      });

      // ⭐ 生成圖片的 URL
      const avatarURL = `http://localhost:4000/uploads/avatars/${file.filename}`;

      // ⭐ 更新資料庫
      const result = await this.userService.updateProfile(userId, {
        AvatarURL: avatarURL,
      });

      if (result.success) {
        console.log("✅ Controller: 頭像上傳成功");
        res.json({
          success: true,
          message: "頭像上傳成功",
          avatarURL: avatarURL,
          user: result.user,
        });
      } else {
        res.status(400).json({
          success: false,
          message: result.message,
        });
      }
    } catch (error) {
      console.error("❌ Controller: 上傳頭像錯誤:", error);
      res.status(500).json({
        success: false,
        message: "上傳失敗",
      });
    }
  };
  /**
   * 審核使用者（管理員操作）
   * POST /api/users/:id/approve
   * 需要權限: manage_users
   */
  approveUser = async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = parseInt(req.params.id, 10);
      const { roleNames } = req.body;

      console.log("🔵 Controller: 審核使用者", { userId, roleNames });

      // 驗證 userId
      if (isNaN(userId) || userId <= 0) {
        res.status(400).json({
          success: false,
          message: "無效的使用者 ID",
        });
        return;
      }

      // 驗證 roleNames
      if (!Array.isArray(roleNames) || roleNames.length === 0) {
        res.status(400).json({
          success: false,
          message: "請提供至少一個角色名稱",
        });
        return;
      }

      // 檢查是否所有元素都是字串
      if (!roleNames.every((role: any) => typeof role === "string")) {
        res.status(400).json({
          success: false,
          message: "角色名稱必須是字串",
        });
        return;
      }

      // 呼叫 Service
      const result = await this.userService.approveUser(userId, roleNames);

      if (result.success) {
        console.log("✅ Controller: 使用者審核成功");
        res.status(200).json(result);
      } else {
        console.log("❌ Controller: 審核失敗", result.message);
        res.status(400).json(result);
      }
    } catch (error) {
      console.error("❌ Controller: 審核使用者錯誤:", error);
      res.status(500).json({
        success: false,
        message: "審核使用者失敗",
      });
    }
  };
}
