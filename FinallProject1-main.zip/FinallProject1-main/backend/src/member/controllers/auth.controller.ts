/**
 * 認證控制器
 * 處理登入、登出、Token 驗證等 HTTP 請求
 */

import { Request, Response } from "express";
import { AuthService } from "../services/auth.service.js";
import {
  userLoginSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
  changePasswordSchema,
} from "../utils/validation.js";
import { JWTUtil } from "../utils/jwt.js";
import {
  LoginRequest,
  ForgotPasswordRequest,
  ResetPasswordRequest,
  ChangePasswordRequest,
} from "../types/auth.types.js";

export class AuthController {
  constructor(private authService: AuthService) {}

  /**
   * 使用者登入端點
   * POST /api/auth/login
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  login = async (req: Request, res: Response): Promise<void> => {
    try {
      // 步驟 1: 驗證請求資料格式
      const validationResult = userLoginSchema.safeParse(req.body);

      if (!validationResult.success) {
        // 如果驗證失敗，回傳詳細的錯誤訊息
        const errorMessages = validationResult.error.issues.map((err: any) => ({
          field: err.path.join("."),
          message: err.message,
        }));

        res.status(400).json({
          success: false,
          message: "輸入資料格式錯誤",
          errors: errorMessages,
        });
        return;
      }

      // 步驟 2: 取得驗證通過的資料
      const loginData: LoginRequest = validationResult.data;

      // 步驟 3: 呼叫服務層進行登入
      const result = await this.authService.login(loginData);

      // 步驟 4: 根據結果回傳適當的 HTTP 狀態碼
      if (result.success) {
        // 登入成功 - 200 OK
        res.status(200).json(result);
      } else {
        // 登入失敗 - 401 Unauthorized
        res.status(401).json(result);
      }
    } catch (error) {
      // 步驟 5: 處理未預期的伺服器錯誤
      console.error("使用者登入時發生未預期錯誤:", error);

      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤，請稍後再試",
      });
    }
  };

  /**
   * 使用者登出端點
   * POST /api/auth/logout
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  logout = async (req: Request, res: Response): Promise<void> => {
    try {
      // 呼叫服務層進行登出
      const result = await this.authService.logout();

      res.status(200).json(result);
    } catch (error) {
      console.error("使用者登出時發生錯誤:", error);

      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };

  /**
   * 驗證使用者身分端點（檢查 Token 是否有效）
   * GET /api/auth/verify
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  verifyToken = async (req: Request, res: Response): Promise<void> => {
    try {
      // 步驟 1: 從 Header 中提取 Token
      const authHeader = req.headers.authorization;
      const token = JWTUtil.extractTokenFromHeader(authHeader);

      if (!token) {
        res.status(401).json({
          success: false,
          message: "未提供認證 Token",
        });
        return;
      }

      // 步驟 2: 驗證 Token 並取得使用者資料
      const user = await this.authService.verifyTokenAndGetUser(token);

      if (!user) {
        res.status(401).json({
          success: false,
          message: "Token 無效或已過期",
        });
        return;
      }

      // 步驟 3: 回傳使用者資料
      res.status(200).json({
        success: true,
        message: "Token 驗證成功",
        user: user,
      });
    } catch (error) {
      console.error("驗證 Token 時發生錯誤:", error);

      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };

  /**
   * 刷新 Token 端點
   * POST /api/auth/refresh
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  refreshToken = async (req: Request, res: Response): Promise<void> => {
    try {
      // 步驟 1: 從 Header 中提取舊 Token
      const authHeader = req.headers.authorization;
      const oldToken = JWTUtil.extractTokenFromHeader(authHeader);

      if (!oldToken) {
        res.status(401).json({
          success: false,
          message: "未提供認證 Token",
        });
        return;
      }

      // 步驟 2: 刷新 Token
      const result = await this.authService.refreshToken(oldToken);

      // 步驟 3: 根據結果回傳適當的狀態碼
      if (result.success) {
        res.status(200).json(result);
      } else {
        res.status(401).json(result);
      }
    } catch (error) {
      console.error("刷新 Token 時發生錯誤:", error);

      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };

  /**
   * 取得當前登入使用者資料端點
   * GET /api/auth/me
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  getCurrentUser = async (req: Request, res: Response): Promise<void> => {
    try {
      console.log("🔵 getCurrentUser 被呼叫");
      console.log("🔵 Headers:", req.headers);
      // 步驟 1: 從 Header 中提取 Token
      const authHeader = req.headers.authorization;
      const token = JWTUtil.extractTokenFromHeader(authHeader);

      if (!token) {
        res.status(401).json({
          success: false,
          message: "未提供認證 Token",
        });
        return;
      }

      // 步驟 2: 驗證 Token 並取得使用者資料
      const user = await this.authService.verifyTokenAndGetUser(token);

      if (!user) {
        res.status(401).json({
          success: false,
          message: "Token 無效或已過期",
        });
        return;
      }

      // 步驟 3: 回傳當前使用者資料
      res.status(200).json({
        success: true,
        message: "取得使用者資料成功",
        user: user,
      });
    } catch (error) {
      console.error("取得當前使用者資料時發生錯誤:", error);

      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };

  /**
   * 忘記密碼端點
   * POST /api/auth/forgot-password
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  forgotPassword = async (req: Request, res: Response): Promise<void> => {
    try {
      // 步驟 1: 驗證請求資料格式
      const validationResult = forgotPasswordSchema.safeParse(req.body);

      if (!validationResult.success) {
        const errorMessages = validationResult.error.issues.map((err: any) => ({
          field: err.path.join("."),
          message: err.message,
        }));

        res.status(400).json({
          success: false,
          message: "輸入資料格式錯誤",
          errors: errorMessages,
        });
        return;
      }

      // 步驟 2: 取得驗證通過的資料
      const forgotPasswordData: ForgotPasswordRequest = validationResult.data;

      // 步驟 3: 呼叫服務層處理忘記密碼
      const result = await this.authService.forgotPassword(
        forgotPasswordData.email
      );

      // 步驟 4: 統一回傳 200 狀態碼（安全考量）
      res.status(200).json({
        success: result.success,
        message: result.message,
        // 開發階段顯示 resetToken，正式環境應移除
        ...(process.env.NODE_ENV === "development" &&
          result.resetToken && {
            resetToken: result.resetToken,
          }),
      });
    } catch (error) {
      console.error("處理忘記密碼請求時發生錯誤:", error);

      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };

  /**
   * 重設密碼端點
   * POST /api/auth/reset-password
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  resetPassword = async (req: Request, res: Response): Promise<void> => {
    try {
      // 步驟 1: 驗證請求資料格式
      const validationResult = resetPasswordSchema.safeParse(req.body);

      if (!validationResult.success) {
        const errorMessages = validationResult.error.issues.map((err: any) => ({
          field: err.path.join("."),
          message: err.message,
        }));

        res.status(400).json({
          success: false,
          message: "輸入資料格式錯誤",
          errors: errorMessages,
        });
        return;
      }

      // 步驟 2: 取得驗證通過的資料
      const resetPasswordData: ResetPasswordRequest = validationResult.data;

      // 步驟 3: 呼叫服務層重設密碼
      const result = await this.authService.resetPassword(
        resetPasswordData.token,
        resetPasswordData.newPassword
      );

      // 步驟 4: 根據結果回傳適當的狀態碼
      if (result.success) {
        res.status(200).json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      console.error("重設密碼時發生錯誤:", error);

      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };

  /**
   * 修改密碼端點
   * POST /api/auth/change-password
   * @param req Express 請求物件
   * @param res Express 回應物件
   */
  changePassword = async (req: Request, res: Response): Promise<void> => {
    try {
      // 步驟 1: 從 Header 中提取 Token 並驗證使用者身分
      const authHeader = req.headers.authorization;
      const token = JWTUtil.extractTokenFromHeader(authHeader);

      if (!token) {
        res.status(401).json({
          success: false,
          message: "未提供認證 Token",
        });
        return;
      }

      // 驗證 Token 並取得使用者資料
      const user = await this.authService.verifyTokenAndGetUser(token);
      if (!user) {
        res.status(401).json({
          success: false,
          message: "Token 無效或已過期",
        });
        return;
      }

      // 步驟 2: 驗證請求資料格式
      const validationResult = changePasswordSchema.safeParse(req.body);

      if (!validationResult.success) {
        const errorMessages = validationResult.error.issues.map((err: any) => ({
          field: err.path.join("."),
          message: err.message,
        }));

        res.status(400).json({
          success: false,
          message: "輸入資料格式錯誤",
          errors: errorMessages,
        });
        return;
      }

      // 步驟 3: 取得驗證通過的資料
      const changePasswordData: ChangePasswordRequest = validationResult.data;

      // 步驟 4: 呼叫服務層修改密碼
      const result = await this.authService.changePassword(
        user.userID,
        changePasswordData.oldPassword,
        changePasswordData.newPassword
      );

      // 步驟 5: 根據結果回傳適當的狀態碼
      if (result.success) {
        res.status(200).json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      console.error("修改密碼時發生錯誤:", error);

      res.status(500).json({
        success: false,
        message: "伺服器內部錯誤",
      });
    }
  };
  // ⭐ 新增：Google OAuth 認證
  googleAuth = async (req: Request, res: Response): Promise<void> => {
    try {
      // 目前先返回提示訊息
      res.status(501).json({
        success: false,
        message: "Google OAuth 功能尚未完成設定",
        hint: "需要先在 Google Cloud Console 設定 OAuth 2.0 Client ID",
      });
    } catch (error) {
      console.error("Google Auth 錯誤:", error);
      res.status(500).json({
        success: false,
        message: "Google 認證失敗",
      });
    }
  };

  // ⭐ 新增：Google OAuth Callback
  googleCallback = async (req: Request, res: Response): Promise<void> => {
    try {
      res.status(501).json({
        success: false,
        message: "Google OAuth Callback 尚未完成設定",
      });
    } catch (error) {
      console.error("Google Callback 錯誤:", error);
      res.status(500).json({
        success: false,
        message: "Google 認證回調失敗",
      });
    }
  };
}
