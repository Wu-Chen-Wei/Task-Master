/**
 * 使用者相關的驗證 Schema
 */
import { z } from "zod";

/**
 * 更新個人資料的驗證規則
 * ⭐ 使用大寫開頭，對應資料庫欄位
 */
export const updateProfileSchema = z.object({
  FullName: z  // ⭐ 改成大寫 F
    .string()
    .min(1, "姓名不能為空")
    .max(255, "姓名長度不能超過 255 字元")
    .optional(),
  
  Title: z  // ⭐ 改成大寫 T
    .string()
    .max(100, "職稱長度不能超過 100 字元")
    .optional()
    .nullable(),
  
  AvatarURL: z  // ⭐ 改成大寫 A 和 URL
    .string()
    .url("頭像網址格式不正確")
    .max(255, "頭像網址長度不能超過 255 字元")
    .optional()
    .nullable(),
});

export type UpdateProfileData = z.infer<typeof updateProfileSchema>;