/**
 * Google OAuth 認證服務
 * 處理 Google 登入相關的業務邏輯
 */

import mysql from 'mysql2/promise';
import { OAuth2Client } from 'google-auth-library';
import { JWTUtil } from '../utils/jwt.js';

// Google OAuth Client 初始化
const client = new OAuth2Client(
  process.env.GOOGLE_LOGIN_CLIENT_ID,
  process.env.GOOGLE_LOGIN_CLIENT_SECRET,
  process.env.GOOGLE_LOGIN_REDIRECT_URI || 'http://localhost:4000/callback.html'
);

// Google Token Payload 介面
interface GoogleTokenPayload {
  sub: string;          // Google User ID
  email: string;        // Email
  name: string;         // 全名
  picture?: string;     // 頭像 URL
  email_verified: boolean;
}

export class GoogleAuthService {
  constructor(private pool: mysql.Pool) {}

  /**
   * 驗證 Google ID Token
   * @param token Google ID Token
   * @returns Google 使用者資訊
   */
  async verifyGoogleToken(token: string): Promise<GoogleTokenPayload | null> {
    try {
      const ticket = await client.verifyIdToken({
        idToken: token,
        audience: process.env.GOOGLE_CLIENT_ID,
      });

      const payload = ticket.getPayload();
      
      if (!payload) {
        return null;
      }

      return {
        sub: payload.sub,
        email: payload.email || '',
        name: payload.name || '',
        picture: payload.picture,
        email_verified: payload.email_verified || false,
      };

    } catch (error) {
      console.error('驗證 Google Token 時發生錯誤:', error);
      return null;
    }
  }

  /**
   * Google 登入或註冊
   * @param googleToken Google ID Token
   * @returns 登入結果（包含 JWT Token 和使用者資訊）
   */
  async googleLogin(googleToken: string): Promise<{
    success: boolean;
    message: string;
    token?: string;
    user?: any;
    isNewUser?: boolean;
  }> {
    const connection = await this.pool.getConnection();

    try {
      // 步驟 1: 驗證 Google Token
      const googleUser = await this.verifyGoogleToken(googleToken);

      if (!googleUser) {
        return {
          success: false,
          message: 'Google Token 驗證失敗'
        };
      }

      // 步驟 2: 檢查使用者是否已存在（根據 Provider 和 ProviderUserID）
      const [rows] = await connection.execute(
        `SELECT UserID, Email, FullName, AvatarURL, Title, Status, EmailVerified, Provider
         FROM Users 
         WHERE Provider = 'google' AND ProviderUserID = ?`,
        [googleUser.sub]
      );

      const users = rows as Array<{
        UserID: number;
        Email: string;
        FullName: string;
        AvatarURL?: string;
        Title?: string;
        Status: string;
        EmailVerified: boolean;
        Provider: string;
      }>;

      let user;
      let isNewUser = false;

      if (users.length > 0) {
        // 使用者已存在 - 直接登入
        user = users[0];

        // 檢查帳號狀態
        if (user.Status !== 'Active') {
          return {
            success: false,
            message: '帳號已被停用或封存，請聯繫管理員'
          };
        }

        console.log(`Google 使用者登入: ${user.Email} (UserID: ${user.UserID})`);

      } else {
        // 新使用者 - 自動註冊
        await connection.beginTransaction();

        try {
          // 檢查 Email 是否已被其他帳號使用（例如本地註冊）
          const [emailCheck] = await connection.execute(
            'SELECT UserID, Provider FROM Users WHERE Email = ?',
            [googleUser.email]
          );

          const existingUsers = emailCheck as Array<{ UserID: number; Provider: string }>;

          if (existingUsers.length > 0) {
            await connection.rollback();
            return {
              success: false,
              message: `此 Email 已被 ${existingUsers[0].Provider} 帳號使用，請使用該方式登入`
            };
          }

          // 建立新使用者
          const [result] = await connection.execute(
            `INSERT INTO Users 
             (Email, FullName, AvatarURL, Provider, ProviderUserID, EmailVerified, Status)
             VALUES (?, ?, ?, 'google', ?, TRUE, 'Active')`,
            [
              googleUser.email,
              googleUser.name,
              googleUser.picture || null,
              googleUser.sub
            ]
          );

          const insertResult = result as mysql.ResultSetHeader;
          const newUserID = insertResult.insertId;

          // 查詢新建立的使用者
          const [newUserRows] = await connection.execute(
            `SELECT UserID, Email, FullName, AvatarURL, Title, Status, EmailVerified, Provider
             FROM Users WHERE UserID = ?`,
            [newUserID]
          );

          const newUsers = newUserRows as any[];
          user = newUsers[0];
          isNewUser = true;

          await connection.commit();

          console.log(`新 Google 使用者註冊成功: ${user.Email} (UserID: ${newUserID})`);

        } catch (error) {
          await connection.rollback();
          throw error;
        }
      }

      // 步驟 3: 產生 JWT Token
      const jwtToken = JWTUtil.generateToken({
        userID: user.UserID,
        email: user.Email
      });

      return {
        success: true,
        message: isNewUser ? 'Google 註冊成功' : 'Google 登入成功',
        token: jwtToken,
        user: {
          UserID: user.UserID,
          Email: user.Email,
          FullName: user.FullName,
          AvatarURL: user.AvatarURL,
          Title: user.Title,
          Status: user.Status,
          EmailVerified: user.EmailVerified
        },
        isNewUser
      };

    } catch (error) {
      console.error('Google 登入時發生錯誤:', error);
      return {
        success: false,
        message: '登入失敗，請稍後再試'
      };
    } finally {
      connection.release();
    }
  }

  /**
   * 取得 Google OAuth 登入 URL
   * @returns Google 授權 URL
   */
  async getGoogleAuthUrl(): Promise<{
    success: boolean;
    data?: { authUrl: string };
    message?: string;
  }> {
    try {
      const authUrl = client.generateAuthUrl({
        access_type: 'offline',
        scope: [
          'https://www.googleapis.com/auth/userinfo.profile',
          'https://www.googleapis.com/auth/userinfo.email'
        ],
        include_granted_scopes: true
      });
      
      return {
        success: true,
        data: { authUrl }
      };
    } catch (error) {
      console.error('產生 Google Auth URL 錯誤:', error);
      return {
        success: false,
        message: '產生 Google 登入連結失敗'
      };
    }
  }

  /**
   * 處理 Google OAuth 回調
   * @param code 授權碼
   * @returns 登入結果
   */
  async handleGoogleCallback(code: string): Promise<{
    success: boolean;
    message: string;
    data?: { token: string; user: any };
  }> {
    try {
      // 使用授權碼取得 tokens
      const { tokens } = await client.getToken(code);
      client.setCredentials(tokens);
      
      // 取得使用者資訊
      const userInfoResponse = await client.request({
        url: 'https://www.googleapis.com/oauth2/v2/userinfo'
      });
      
      const googleUser = userInfoResponse.data as any;
      
      if (!googleUser.email || !googleUser.verified_email) {
        return {
          success: false,
          message: 'Google 帳號信箱未驗證'
        };
      }
      
      // 使用現有的 googleLogin 邏輯
      const loginResult = await this.processGoogleUser(googleUser);
      
      return loginResult;
    } catch (error) {
      console.error('Google 回調處理錯誤:', error);
      return {
        success: false,
        message: 'Google 登入失敗'
      };
    }
  }

  /**
   * 處理 Google 使用者登入/註冊邏輯
   * @param googleUser Google 使用者資訊
   * @returns 登入結果
   */
  private async processGoogleUser(googleUser: any): Promise<{
    success: boolean;
    message: string;
    data?: { token: string; user: any };
  }> {
    const connection = await this.pool.getConnection();
    
    try {
      // 檢查使用者是否已存在
      const [rows] = await connection.execute(
        `SELECT UserID, Email, FullName, AvatarURL, Title, Status, EmailVerified, Provider
         FROM Users 
         WHERE Email = ?`,
        [googleUser.email]
      );
      
      const users = rows as any[];
      let user;
      let isNewUser = false;
      
      if (users.length > 0) {
        user = users[0];
        
        // 更新 Google ID 如果還沒有
        if (user.Provider === 'local') {
          await connection.execute(
            'UPDATE Users SET Provider = ?, ProviderUserID = ?, EmailVerified = TRUE WHERE UserID = ?',
            ['google', googleUser.id, user.UserID]
          );
        }
      } else {
        // 建立新使用者
        const [result] = await connection.execute(
          `INSERT INTO Users 
           (Email, FullName, AvatarURL, Provider, ProviderUserID, EmailVerified, Status)
           VALUES (?, ?, ?, 'google', ?, TRUE, 'Active')`,
          [
            googleUser.email,
            googleUser.name || googleUser.email,
            googleUser.picture || null,
            googleUser.id
          ]
        );
        
        const insertResult = result as mysql.ResultSetHeader;
        const newUserID = insertResult.insertId;
        
        const [newUserRows] = await connection.execute(
          'SELECT UserID, Email, FullName, AvatarURL, Title, Status, EmailVerified, Provider FROM Users WHERE UserID = ?',
          [newUserID]
        );
        
        user = (newUserRows as any[])[0];
        isNewUser = true;
      }
      
      // 產生 JWT Token
      const jwtToken = JWTUtil.generateToken({
        userID: user.UserID,
        email: user.Email
      });
      
      return {
        success: true,
        message: isNewUser ? 'Google 註冊成功' : 'Google 登入成功',
        data: {
          token: jwtToken,
          user: {
            userId: user.UserID,
            email: user.Email,
            fullName: user.FullName,
            avatarUrl: user.AvatarURL,
            emailVerified: user.EmailVerified,
            provider: user.Provider
          }
        }
      };
    } catch (error) {
      console.error('處理 Google 使用者錯誤:', error);
      return {
        success: false,
        message: '登入失敗，請稍後再試'
      };
    } finally {
      connection.release();
    }
  }

  /**
   * 將現有本地帳號連結到 Google
   * @param userID 使用者 ID
   * @param googleToken Google ID Token
   * @returns 連結結果
   */
  async linkGoogleAccount(userID: number, googleToken: string): Promise<{
    success: boolean;
    message: string;
  }> {
    const connection = await this.pool.getConnection();

    try {
      await connection.beginTransaction();

      // 驗證 Google Token
      const googleUser = await this.verifyGoogleToken(googleToken);

      if (!googleUser) {
        await connection.rollback();
        return {
          success: false,
          message: 'Google Token 驗證失敗'
        };
      }

      // 檢查使用者是否存在
      const [userRows] = await connection.execute(
        'SELECT UserID, Email, Provider FROM Users WHERE UserID = ?',
        [userID]
      );

      const users = userRows as Array<{ UserID: number; Email: string; Provider: string }>;

      if (users.length === 0) {
        await connection.rollback();
        return {
          success: false,
          message: '使用者不存在'
        };
      }

      const user = users[0];

      // 檢查是否已經是 Google 帳號
      if (user.Provider === 'google') {
        await connection.rollback();
        return {
          success: false,
          message: '此帳號已經是 Google 帳號'
        };
      }

      // 檢查 Google ID 是否已被其他帳號使用
      const [googleCheck] = await connection.execute(
        'SELECT UserID FROM Users WHERE Provider = ? AND ProviderUserID = ?',
        ['google', googleUser.sub]
      );

      const existingGoogleUsers = googleCheck as Array<{ UserID: number }>;

      if (existingGoogleUsers.length > 0) {
        await connection.rollback();
        return {
          success: false,
          message: '此 Google 帳號已連結到其他使用者'
        };
      }

      // 更新使用者資料，連結 Google 帳號
      await connection.execute(
        `UPDATE Users 
         SET Provider = 'google', ProviderUserID = ?, AvatarURL = COALESCE(AvatarURL, ?)
         WHERE UserID = ?`,
        [googleUser.sub, googleUser.picture, userID]
      );

      await connection.commit();

      console.log(`使用者 ${userID} 已成功連結 Google 帳號`);

      return {
        success: true,
        message: 'Google 帳號連結成功'
      };

    } catch (error) {
      await connection.rollback();
      console.error('連結 Google 帳號時發生錯誤:', error);
      return {
        success: false,
        message: '連結失敗，請稍後再試'
      };
    } finally {
      connection.release();
    }
  }
}