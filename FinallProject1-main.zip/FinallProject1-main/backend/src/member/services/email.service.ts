/**
 * Email 服務類別
 * 使用 Nodemailer + Gmail SMTP 發送各種類型的 Email
 */

import nodemailer from 'nodemailer';
import { 
  EmailData, 
  EmailSendResult, 
  VerificationEmailData, 
  PasswordResetEmailData,
  NotificationEmailData 
} from '../types/email.types.js';

export class EmailService {
  private transporter: nodemailer.Transporter;
  private fromEmail: string;

  constructor() {
    // 從環境變數讀取 Gmail 設定
    this.fromEmail = process.env.EMAIL_FROM || process.env.GMAIL_USER || 'noreply@yourproject.com';
    
    // 建立 Nodemailer transporter (使用 OAuth2)
    this.transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        type: 'OAuth2',
        user: process.env.GMAIL_USER,
        clientId: process.env.GOOGLE_MAIL_CLIENT_ID,
        clientSecret: process.env.GOOGLE_MAIL_CLIENT_SECRET,
        refreshToken: process.env.GOOGLE_MAIL_REFRESH_TOKEN
      }
    });

    // 驗證 SMTP 連線設定
    this.verifyConnection();
  }

  /**
   * 驗證 SMTP 連線是否正常
   */
  private async verifyConnection(): Promise<void> {
    try {
      await this.transporter.verify();
      console.log('✅ Email SMTP 連線驗證成功');
    } catch (error) {
      console.error('❌ Email SMTP 連線驗證失敗:', error);
    }
  }

  /**
   * 發送基本 Email
   * @param emailData Email 資料
   * @returns 發送結果
   */
  private async sendEmail(emailData: EmailData): Promise<EmailSendResult> {
    try {
      const mailOptions = {
        from: `"專案管理系統" <${this.fromEmail}>`,
        to: emailData.to,
        subject: emailData.subject,
        html: emailData.html,
        text: emailData.text
      };

      const info = await this.transporter.sendMail(mailOptions);
      
      console.log(`📧 Email 發送成功: ${emailData.subject} -> ${emailData.to}`);
      
      return {
        success: true,
        messageId: info.messageId
      };

    } catch (error) {
      console.error('📧 Email 發送失敗:', error);
      
      return {
        success: false,
        error: error instanceof Error ? error.message : '未知錯誤'
      };
    }
  }

  /**
   * 發送帳號驗證信
   * @param data 驗證信資料
   * @returns 發送結果
   */
  async sendVerificationEmail(data: VerificationEmailData): Promise<EmailSendResult> {
    const subject = '請驗證您的帳號 - 專案管理系統';
    
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          .container { max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif; }
          .header { background-color: #4CAF50; color: white; padding: 20px; text-align: center; }
          .content { padding: 30px; background-color: #f9f9f9; }
          .button { 
            display: inline-block; 
            background-color: #4CAF50; 
            color: white; 
            padding: 12px 30px; 
            text-decoration: none; 
            border-radius: 5px; 
            margin: 20px 0;
          }
          .footer { padding: 20px; text-align: center; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>歡迎加入專案管理系統</h1>
          </div>
          <div class="content">
            <h2>親愛的 ${data.userName}，</h2>
            <p>感謝您註冊我們的專案管理系統！請點擊下方按鈕來驗證您的帳號：</p>
            
            <div style="text-align: center;">
              <a href="${data.verificationUrl}" class="button">驗證我的帳號</a>
            </div>
            
            <p>或複製以下連結到瀏覽器：</p>
            <p style="word-break: break-all; background-color: #eee; padding: 10px;">
              ${data.verificationUrl}
            </p>
            
            <p><strong>注意：</strong>此驗證連結將在 24 小時後過期。</p>
            
            <p>如果您沒有註冊此帳號，請忽略此信件。</p>
          </div>
          <div class="footer">
            <p>此信件由系統自動發送，請勿直接回覆。</p>
            <p>© 2025 專案管理系統</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const text = `
      歡迎加入專案管理系統！
      
      親愛的 ${data.userName}，
      
      請點擊以下連結來驗證您的帳號：
      ${data.verificationUrl}
      
      此驗證連結將在 24 小時後過期。
      
      如果您沒有註冊此帳號，請忽略此信件。
    `;

    return this.sendEmail({
      to: data.to,
      subject,
      html,
      text
    });
  }

  /**
   * 發送密碼重設信
   * @param data 重設信資料
   * @returns 發送結果
   */
  async sendPasswordResetEmail(data: PasswordResetEmailData): Promise<EmailSendResult> {
    const subject = '重設您的密碼 - 專案管理系統';
    
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          .container { max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif; }
          .header { background-color: #FF9800; color: white; padding: 20px; text-align: center; }
          .content { padding: 30px; background-color: #f9f9f9; }
          .button { 
            display: inline-block; 
            background-color: #FF9800; 
            color: white; 
            padding: 12px 30px; 
            text-decoration: none; 
            border-radius: 5px; 
            margin: 20px 0;
          }
          .warning { 
            background-color: #fff3cd; 
            border: 1px solid #ffeaa7; 
            padding: 15px; 
            border-radius: 5px; 
            margin: 20px 0;
          }
          .footer { padding: 20px; text-align: center; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>密碼重設請求</h1>
          </div>
          <div class="content">
            <h2>親愛的 ${data.userName}，</h2>
            <p>我們收到您的密碼重設請求。請點擊下方按鈕來設定新密碼：</p>
            
            <div style="text-align: center;">
              <a href="${data.resetUrl}" class="button">重設我的密碼</a>
            </div>
            
            <p>或複製以下連結到瀏覽器：</p>
            <p style="word-break: break-all; background-color: #eee; padding: 10px;">
              ${data.resetUrl}
            </p>
            
            <div class="warning">
              <strong>重要提醒：</strong>
              <ul>
                <li>此重設連結將在 <strong>1 小時</strong> 後過期</li>
                <li>每個重設連結只能使用一次</li>
                <li>如果您沒有請求重設密碼，請忽略此信件</li>
              </ul>
            </div>
            
            <p>為了您的帳號安全，請勿將此連結分享給他人。</p>
          </div>
          <div class="footer">
            <p>此信件由系統自動發送，請勿直接回覆。</p>
            <p>© 2025 專案管理系統</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const text = `
      密碼重設請求
      
      親愛的 ${data.userName}，
      
      請點擊以下連結來重設您的密碼：
      ${data.resetUrl}
      
      重要提醒：
      - 此連結將在 1 小時後過期
      - 每個連結只能使用一次
      - 如果您沒有請求重設密碼，請忽略此信件
      
      為了您的帳號安全，請勿將此連結分享給他人。
    `;

    return this.sendEmail({
      to: data.to,
      subject,
      html,
      text
    });
  }

  /**
   * 發送系統通知信
   * @param data 通知信資料
   * @returns 發送結果
   */
  async sendNotificationEmail(data: NotificationEmailData): Promise<EmailSendResult> {
    const subject = `${data.title} - 專案管理系統`;
    
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          .container { max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif; }
          .header { background-color: #2196F3; color: white; padding: 20px; text-align: center; }
          .content { padding: 30px; background-color: #f9f9f9; }
          .button { 
            display: inline-block; 
            background-color: #2196F3; 
            color: white; 
            padding: 12px 30px; 
            text-decoration: none; 
            border-radius: 5px; 
            margin: 20px 0;
          }
          .footer { padding: 20px; text-align: center; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>${data.title}</h1>
          </div>
          <div class="content">
            <h2>親愛的 ${data.userName}，</h2>
            <div style="line-height: 1.6;">
              ${data.content}
            </div>
            
            ${data.actionUrl ? `
            <div style="text-align: center;">
              <a href="${data.actionUrl}" class="button">查看詳情</a>
            </div>
            ` : ''}
          </div>
          <div class="footer">
            <p>此信件由系統自動發送，請勿直接回覆。</p>
            <p>© 2025 專案管理系統</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const text = `
      ${data.title}
      
      親愛的 ${data.userName}，
      
      ${data.content.replace(/<[^>]*>/g, '')}
      
      ${data.actionUrl ? `查看詳情：${data.actionUrl}` : ''}
    `;

    return this.sendEmail({
      to: data.to,
      subject,
      html,
      text
    });
  }
}