/**
 * 認證服務類別
 * 處理所有與使用者登入、登出相關的業務邏輯
 */

import mysql from "mysql2/promise";
import { CryptoUtil } from "../utils/crypto.js";
import { JWTUtil } from "../utils/jwt.js";
import { EmailService } from "../services/email.service.js";
import {
  LoginRequest,
  LoginResponse,
  AuthenticatedUser,
} from "../types/auth.types.js";

export class AuthService {
  private emailService: EmailService;

  constructor(private pool: mysql.Pool) {
    this.emailService = new EmailService();
  }

  /**
   * 使用者登入
   * @param loginData 登入資料（Email 和密碼）
   * @returns 登入結果（包含 JWT Token 和使用者資訊）
   */
  async login(loginData: LoginRequest): Promise<LoginResponse> {
    try {
      // 步驟 1: 根據 Email 查詢使用者
      const [rows] = await this.pool.execute(
        `SELECT UserID, Email, PasswordHash, FullName, AvatarURL, Title, 
        Status, EmailVerified, Provider 
 FROM Users WHERE Email = ?`,
        [loginData.email]
      );

      const users = rows as Array<{
        UserID: number;
        Email: string;
        PasswordHash: string;
        FullName: string;
        AvatarURL?: string;
        Title?: string;
        Status: string;
        EmailVerified: boolean;
        Provider?: string;
      }>;

      // 步驟 2: 檢查使用者是否存在
      if (users.length === 0) {
        return {
          success: false,
          message: "Email 或密碼錯誤",
        };
      }

      const user = users[0];

      // 步驟 3: 檢查帳號狀態
      if (user.Status !== "Active") {
        return {
          success: false,
          message: "帳號已被停用或封存，請聯繫管理員",
        };
      }

      // 步驟 3.1: 檢查是否為本地註冊
      if (user.Provider && user.Provider !== "local") {
        return {
          success: false,
          message: `此帳號使用 ${user.Provider} 登入，請使用相應的登入方式`,
        };
      }

      // 步驟 3.2: 檢查密碼是否存在
      if (!user.PasswordHash) {
        return {
          success: false,
          message: "此帳號未設定密碼，請使用 OAuth 登入",
        };
      }

      // 步驟 4: 驗證密碼
      const isPasswordValid = await CryptoUtil.verifyPassword(
        loginData.password,
        user.PasswordHash
      );

      if (!isPasswordValid) {
        return {
          success: false,
          message: "Email 或密碼錯誤",
        };
      }

      // ⭐ 步驟 5: 查詢使用者的全域角色
      const [roleRows] = await this.pool.execute(
        `SELECT r.RoleName 
       FROM userglobalroles ugr
       JOIN roles r ON ugr.RoleID = r.RoleID
       WHERE ugr.UserID = ?`,
        [user.UserID]
      );

      const roles = (roleRows as Array<{ RoleName: string }>).map(
        (row) => row.RoleName
      );

      // ⭐ 步驟 6: 產生 JWT Token（包含角色資訊）
      const token = JWTUtil.generateToken({
        userID: user.UserID,
        email: user.Email,
        roles: roles, // ⭐ 加入角色陣列
      });

      // 步驟 7: 回傳成功結果（不包含密碼雜湊）
      return {
        success: true,
        message: "登入成功",
        token: token,
        user: {
          userID: user.UserID,
          Email: user.Email,
          FullName: user.FullName,
          AvatarURL: user.AvatarURL,
          Title: user.Title,
          Status: user.Status,
          EmailVerified: user.EmailVerified,
          Roles: roles, //也回傳角色給前端
        },
      };
    } catch (error) {
      console.error("使用者登入時發生錯誤:", error);
      return {
        success: false,
        message: "登入失敗，請稍後再試",
      };
    }
  }

  /**
   * 驗證 JWT Token 並取得使用者資訊
   * @param token JWT Token 字串
   * @returns 使用者資訊或 null（如果 Token 無效）
   */
  /**
   * 驗證 JWT Token 並取得使用者資訊
   * @param token JWT Token 字串
   * @returns 使用者資訊或 null（如果 Token 無效）
   */
  async verifyTokenAndGetUser(
    token: string
  ): Promise<AuthenticatedUser | null> {
    try {
      // 步驟 1: 驗證 JWT Token
      const decoded = JWTUtil.verifyToken(token);
      if (!decoded) {
        return null;
      }
      console.log("Decoded JWT Payload:", decoded);

      // 步驟 2: 從資料庫重新取得使用者資料（確保最新狀態）
      const userID = JWTUtil.getUserIDAsNumber(decoded);
      const [rows] = await this.pool.execute(
        `SELECT UserID, Email, FullName, AvatarURL, Title, Status, EmailVerified 
       FROM Users WHERE UserID = ? AND Status = 'Active'`,
        [userID]
      );

      const users = rows as AuthenticatedUser[];

      // 步驟 3: 檢查使用者是否仍然存在且為活躍狀態
      if (users.length === 0) {
        return null;
      }

      // ✅ 步驟 4: 查詢使用者的全域角色
      const [roleRows] = await this.pool.execute(
        `SELECT r.RoleName 
       FROM userglobalroles ugr
       JOIN roles r ON ugr.RoleID = r.RoleID
       WHERE ugr.UserID = ?`,
        [userID]
      );

      const roles = (roleRows as Array<{ RoleName: string }>).map(
        (row) => row.RoleName
      );

      // ✅ 步驟 5: 將角色加入使用者資料
      return {
        ...users[0],
        Roles: roles, // 加入角色陣列
      };
    } catch (error) {
      console.error("驗證 Token 時發生錯誤:", error);
      return null;
    }
  }
  /**
   * 使用者登出（目前僅回傳成功訊息，實際的 Token 失效由前端處理）
   * 未來可以實作 Token 黑名單機制
   * @returns 登出結果
   */
  async logout(): Promise<{ success: boolean; message: string }> {
    try {
      // 目前僅回傳成功訊息
      // 實際的 Token 清除由前端處理（從 localStorage 或 cookies 移除）
      // 未來可以在這裡實作 Token 黑名單機制

      return {
        success: true,
        message: "登出成功",
      };
    } catch (error) {
      console.error("使用者登出時發生錯誤:", error);
      return {
        success: false,
        message: "登出失敗，請稍後再試",
      };
    }
  }

  /**
   * 刷新 JWT Token（延長有效期限）
   * @param oldToken 目前的 JWT Token
   * @returns 新的 Token 或錯誤訊息
   */
  async refreshToken(oldToken: string): Promise<LoginResponse> {
    try {
      // 步驟 1: 驗證舊 Token
      const user = await this.verifyTokenAndGetUser(oldToken);
      if (!user) {
        return {
          success: false,
          message: "Token 無效或已過期",
        };
      }

      // 步驟 2: 產生新的 Token
      const newToken = JWTUtil.generateToken({
        userID: user.userID,
        email: user.Email,
      });

      return {
        success: true,
        message: "Token 刷新成功",
        token: newToken,
        user: user,
      };
    } catch (error) {
      console.error("刷新 Token 時發生錯誤:", error);
      return {
        success: false,
        message: "Token 刷新失敗",
      };
    }
  }

  /**
   * 忘記密碼 - 產生重設 Token 並發送 Email
   * @param email 使用者 Email
   * @returns 操作結果
   */
  async forgotPassword(
    email: string
  ): Promise<{ success: boolean; message: string; resetToken?: string }> {
    try {
      // 步驟 1: 檢查使用者是否存在
      const [rows] = await this.pool.execute(
        'SELECT UserID, Email, FullName FROM Users WHERE Email = ? AND Status = "Active"',
        [email]
      );

      const users = rows as Array<{
        UserID: number;
        Email: string;
        FullName: string;
      }>;

      // 即使使用者不存在也回傳成功（安全考量，不透露帳號是否存在）
      if (users.length === 0) {
        return {
          success: true,
          message: "如果該 Email 存在，重設密碼連結已發送至您的信箱",
        };
      }

      const user = users[0];

      // 步驟 2: 產生重設密碼 Token 和過期時間（1小時後過期）
      const resetToken = CryptoUtil.generateSecureToken();
      const resetTokenExpiry = CryptoUtil.generateTokenExpiry(1); // 1小時後過期

      // 步驟 3: 將 Token 儲存到資料庫
      await this.pool.execute(
        "UPDATE Users SET ResetPasswordToken = ?, ResetPasswordTokenExpiry = ? WHERE UserID = ?",
        [resetToken, resetTokenExpiry, user.UserID]
      );

      console.log(
        `重設密碼 Token 已產生: ${resetToken} (使用者: ${user.FullName})`
      );

      // 步驟 4: 建立重設密碼的完整網址
      const baseUrl = process.env.FRONTEND_URL || "http://localhost:3000";
      const resetUrl = `${baseUrl}/reset-password?token=${resetToken}`;

      // 步驟 5: 發送重設密碼 Email
      console.log("準備發送重設密碼 Email 至:", user.Email);

      const emailResult = await this.emailService.sendPasswordResetEmail({
        to: user.Email,
        userName: user.FullName,
        resetToken: resetToken,
        resetUrl: resetUrl,
      });

      console.log("Email 發送結果:", emailResult);

      if (emailResult.success) {
        console.log(
          `重設密碼信件已發送至: ${user.Email} (使用者: ${user.FullName})`
        );

        return {
          success: true,
          message: "重設密碼連結已發送至您的信箱",
          // 開發階段回傳 Token，正式環境應移除
          ...(process.env.NODE_ENV === "development" && {
            resetToken: resetToken,
          }),
        };
      } else {
        console.error(`重設密碼信件發送失敗: ${emailResult.error}`);

        return {
          success: false,
          message: "發送重設密碼信件失敗，請稍後再試",
        };
      }
    } catch (error) {
      console.error("處理忘記密碼請求時發生錯誤:", error);
      return {
        success: false,
        message: "系統忙碌中，請稍後再試",
      };
    }
  }

  /**
   * 重設密碼 - 使用 Token 設定新密碼
   * @param token 重設密碼 Token
   * @param newPassword 新密碼
   * @returns 操作結果
   */
  async resetPassword(
    token: string,
    newPassword: string
  ): Promise<{ success: boolean; message: string }> {
    try {
      // 步驟 1: 查詢 Token 是否有效且未過期
      const [rows] = await this.pool.execute(
        `SELECT UserID, Email, FullName, ResetPasswordTokenExpiry 
         FROM Users 
         WHERE ResetPasswordToken = ? AND Status = "Active"`,
        [token]
      );

      const users = rows as Array<{
        UserID: number;
        Email: string;
        FullName: string;
        ResetPasswordTokenExpiry: Date;
      }>;

      if (users.length === 0) {
        return {
          success: false,
          message: "重設密碼連結無效或已過期",
        };
      }

      const user = users[0];

      // 步驟 2: 檢查 Token 是否已過期
      const now = new Date();
      if (user.ResetPasswordTokenExpiry < now) {
        return {
          success: false,
          message: "重設密碼連結已過期，請重新申請",
        };
      }

      // 步驟 3: 加密新密碼
      const passwordHash = await CryptoUtil.hashPassword(newPassword);

      // 步驟 4: 更新密碼並清除重設 Token
      await this.pool.execute(
        `UPDATE Users 
         SET PasswordHash = ?, ResetPasswordToken = NULL, ResetPasswordTokenExpiry = NULL 
         WHERE UserID = ?`,
        [passwordHash, user.UserID]
      );

      console.log(`使用者 ${user.FullName} 已成功重設密碼`);

      return {
        success: true,
        message: "密碼重設成功，請使用新密碼登入",
      };
    } catch (error) {
      console.error("重設密碼時發生錯誤:", error);
      return {
        success: false,
        message: "重設密碼失敗，請稍後再試",
      };
    }
  }

  /**
   * 修改密碼 - 需要驗證舊密碼
   * @param userID 使用者 ID
   * @param oldPassword 舊密碼
   * @param newPassword 新密碼
   * @returns 操作結果
   */
  async changePassword(
    userID: number,
    oldPassword: string,
    newPassword: string
  ): Promise<{ success: boolean; message: string }> {
    try {
      // 步驟 1: 查詢使用者目前的密碼雜湊
      const [rows] = await this.pool.execute(
        'SELECT PasswordHash, FullName FROM Users WHERE UserID = ? AND Status = "Active"',
        [userID]
      );

      const users = rows as Array<{ PasswordHash: string; FullName: string }>;

      if (users.length === 0) {
        return {
          success: false,
          message: "使用者不存在或帳號已停用",
        };
      }

      const user = users[0];

      // 步驟 2: 驗證舊密碼是否正確
      const isOldPasswordValid = await CryptoUtil.verifyPassword(
        oldPassword,
        user.PasswordHash
      );

      if (!isOldPasswordValid) {
        return {
          success: false,
          message: "目前密碼錯誤",
        };
      }

      // 步驟 3: 加密新密碼
      const newPasswordHash = await CryptoUtil.hashPassword(newPassword);

      // 步驟 4: 更新密碼
      await this.pool.execute(
        "UPDATE Users SET PasswordHash = ? WHERE UserID = ?",
        [newPasswordHash, userID]
      );

      console.log(`使用者 ${user.FullName} 已成功修改密碼`);

      return {
        success: true,
        message: "密碼修改成功",
      };
    } catch (error) {
      console.error("修改密碼時發生錯誤:", error);
      return {
        success: false,
        message: "修改密碼失敗，請稍後再試",
      };
    }
  }
}
