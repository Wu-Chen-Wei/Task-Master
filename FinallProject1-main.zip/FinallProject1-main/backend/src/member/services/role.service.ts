/**
 * 角色服務類別
 * 處理所有與角色相關的資料庫操作和業務邏輯
 */

import mysql from 'mysql2/promise';
import { Role, CreateRoleRequest, UpdateRoleRequest, RoleResponse } from '../types/role.types.js';

export class RoleService {
  constructor(private pool: mysql.Pool) {}

  /**
   * 取得所有角色列表
   * @returns 角色列表
   */
  async getAllRoles(): Promise<RoleResponse> {
    try {
      const [rows] = await this.pool.execute(
        'SELECT RoleID, RoleName, Description FROM Roles ORDER BY RoleID'
      );

      const roles = rows as Role[];

      return {
        success: true,
        message: '查詢角色列表成功',
        roles: roles
      };

    } catch (error) {
      console.error('查詢角色列表時發生錯誤:', error);
      return {
        success: false,
        message: '查詢角色列表失敗'
      };
    }
  }

  /**
   * 根據 RoleID 查詢角色
   * @param roleID 角色 ID
   * @returns 角色資料
   */
  async getRoleById(roleID: number): Promise<RoleResponse> {
    try {
      const [rows] = await this.pool.execute(
        'SELECT RoleID, RoleName, Description FROM Roles WHERE RoleID = ?',
        [roleID]
      );

      const roles = rows as Role[];

      if (roles.length === 0) {
        return {
          success: false,
          message: '找不到指定的角色'
        };
      }

      return {
        success: true,
        message: '查詢角色成功',
        role: roles[0]
      };

    } catch (error) {
      console.error('查詢角色時發生錯誤:', error);
      return {
        success: false,
        message: '查詢角色失敗'
      };
    }
  }

  /**
   * 檢查角色名稱是否已存在
   * @param roleName 角色名稱
   * @param excludeRoleID 排除的角色 ID（更新時使用）
   * @returns true 表示已存在
   */
  async checkRoleNameExists(roleName: string, excludeRoleID?: number): Promise<boolean> {
    try {
      let query = 'SELECT COUNT(*) as count FROM Roles WHERE RoleName = ?';
      const params: any[] = [roleName];

      if (excludeRoleID) {
        query += ' AND RoleID != ?';
        params.push(excludeRoleID);
      }

      const [rows] = await this.pool.execute(query, params);
      const result = rows as Array<{ count: number }>;
      return result[0].count > 0;

    } catch (error) {
      console.error('檢查角色名稱是否存在時發生錯誤:', error);
      throw new Error('檢查角色名稱失敗');
    }
  }

  /**
   * 建立新角色
   * @param roleData 角色資料
   * @returns 建立結果
   */
  async createRole(roleData: CreateRoleRequest): Promise<RoleResponse> {
    try {
      // 步驟 1: 檢查角色名稱是否已存在
      const nameExists = await this.checkRoleNameExists(roleData.roleName);
      if (nameExists) {
        return {
          success: false,
          message: '此角色名稱已存在，請使用其他名稱'
        };
      }

      // 步驟 2: 插入新角色
      const [result] = await this.pool.execute(
        'INSERT INTO Roles (RoleName, Description) VALUES (?, ?)',
        [roleData.roleName, roleData.description || null]
      );

      const insertResult = result as mysql.ResultSetHeader;
      const newRoleID = insertResult.insertId;

      // 步驟 3: 查詢新建立的角色資料
      const [roleRows] = await this.pool.execute(
        'SELECT RoleID, RoleName, Description FROM Roles WHERE RoleID = ?',
        [newRoleID]
      );

      const roles = roleRows as Role[];
      const newRole = roles[0];

      console.log(`角色 "${newRole.RoleName}" 建立成功 (ID: ${newRole.RoleID})`);

      return {
        success: true,
        message: '角色建立成功',
        role: newRole
      };

    } catch (error) {
      console.error('建立角色時發生錯誤:', error);
      return {
        success: false,
        message: '建立角色失敗，請稍後再試'
      };
    }
  }

  /**
   * 更新角色資料
   * @param roleID 角色 ID
   * @param updateData 更新的資料
   * @returns 更新結果
   */
  async updateRole(roleID: number, updateData: UpdateRoleRequest): Promise<RoleResponse> {
    try {
      // 步驟 1: 檢查角色是否存在
      const existingRole = await this.getRoleById(roleID);
      if (!existingRole.success) {
        return {
          success: false,
          message: '找不到指定的角色'
        };
      }

      // 步驟 2: 如果要更新角色名稱，檢查新名稱是否已被使用
      if (updateData.roleName) {
        const nameExists = await this.checkRoleNameExists(updateData.roleName, roleID);
        if (nameExists) {
          return {
            success: false,
            message: '此角色名稱已存在，請使用其他名稱'
          };
        }
      }

      // 步驟 3: 建立更新的 SQL 語句
      const updateFields: string[] = [];
      const updateValues: any[] = [];

      if (updateData.roleName !== undefined) {
        updateFields.push('RoleName = ?');
        updateValues.push(updateData.roleName);
      }

      if (updateData.description !== undefined) {
        updateFields.push('Description = ?');
        updateValues.push(updateData.description);
      }

      // 如果沒有任何更新內容
      if (updateFields.length === 0) {
        return {
          success: false,
          message: '沒有提供任何更新內容'
        };
      }

      // 步驟 4: 執行更新
      updateValues.push(roleID);
      await this.pool.execute(
        `UPDATE Roles SET ${updateFields.join(', ')} WHERE RoleID = ?`,
        updateValues
      );

      // 步驟 5: 查詢更新後的角色資料
      const updatedRole = await this.getRoleById(roleID);

      console.log(`角色 ID ${roleID} 更新成功`);

      return {
        success: true,
        message: '角色更新成功',
        role: updatedRole.role
      };

    } catch (error) {
      console.error('更新角色時發生錯誤:', error);
      return {
        success: false,
        message: '更新角色失敗，請稍後再試'
      };
    }
  }

  /**
   * 刪除角色
   * @param roleID 角色 ID
   * @returns 刪除結果
   */
  async deleteRole(roleID: number): Promise<RoleResponse> {
    try {
      // 步驟 1: 檢查角色是否存在
      const existingRole = await this.getRoleById(roleID);
      if (!existingRole.success) {
        return {
          success: false,
          message: '找不到指定的角色'
        };
      }

      // 步驟 2: 檢查是否有使用者正在使用此角色
      const [userRows] = await this.pool.execute(
        'SELECT COUNT(*) as count FROM UserGlobalRoles WHERE RoleID = ?',
        [roleID]
      );
      const userResult = userRows as Array<{ count: number }>;

      if (userResult[0].count > 0) {
        return {
          success: false,
          message: `此角色目前有 ${userResult[0].count} 位使用者正在使用，無法刪除`
        };
      }

      // 步驟 3: 檢查是否有專案成員正在使用此角色
      const [projectRows] = await this.pool.execute(
        'SELECT COUNT(*) as count FROM ProjectMembers WHERE RoleID = ?',
        [roleID]
      );
      const projectResult = projectRows as Array<{ count: number }>;

      if (projectResult[0].count > 0) {
        return {
          success: false,
          message: `此角色目前有 ${projectResult[0].count} 個專案成員正在使用，無法刪除`
        };
      }

      // 步驟 4: 刪除角色
      await this.pool.execute('DELETE FROM Roles WHERE RoleID = ?', [roleID]);

      console.log(`角色 "${existingRole.role?.RoleName}" (ID: ${roleID}) 已被刪除`);

      return {
        success: true,
        message: '角色刪除成功'
      };

    } catch (error) {
      console.error('刪除角色時發生錯誤:', error);
      return {
        success: false,
        message: '刪除角色失敗，請稍後再試'
      };
    }
  }
}