/**
 * 使用者業務邏輯服務類別
 * 處理所有與使用者相關的資料庫操作和業務邏輯
 * 支援 MySQL Connection Pool
 */

import mysql from "mysql2/promise";
import { CryptoUtil } from "../utils/crypto.js";
import { EmailService } from "./email.service.js";
import {
  CreateUserRequest,
  User,
  CreateUserResponse,
} from "../types/user.types.js";

export class UserService {
  private emailService: EmailService;

  constructor(private pool: mysql.Pool) {
    this.emailService = new EmailService();
  }

  /**
   * 檢查指定的 Email 是否已經存在於資料庫中
   * @param email 要檢查的 Email 地址
   * @returns true 表示 Email 已存在，false 表示可以使用
   */
  async checkEmailExists(email: string): Promise<boolean> {
    try {
      const [rows] = await this.pool.execute(
        "SELECT COUNT(*) as count FROM Users WHERE Email = ?",
        [email.toLowerCase()]
      );
      const result = rows as Array<{ count: number }>;
      return result[0].count > 0;
    } catch (error) {
      console.error("檢查 Email 是否存在時發生錯誤:", error);
      throw new Error("檢查 Email 失敗");
    }
  }

  /**
   * 建立新使用者帳號
   * @param userData 使用者註冊資料
   * @returns 建立結果（成功/失敗訊息）
   */
  async createUser(userData: CreateUserRequest): Promise<CreateUserResponse> {
    // 從 pool 取得連線來處理事務
    const connection = await this.pool.getConnection();

    try {
      // 開始資料庫事務（確保資料一致性）
      await connection.beginTransaction();

      // 步驟 1: 檢查 Email 是否已被註冊
      const emailExists = await this.checkEmailExists(userData.email);
      if (emailExists) {
        await connection.rollback();
        return {
          success: false,
          message: "此 Email 已被註冊，請使用其他 Email 地址",
        };
      }

      // 步驟 2: 加密使用者密碼
      const passwordHash = await CryptoUtil.hashPassword(userData.password);

      // 步驟 3: 產生 Email 驗證 Token 和過期時間
      const verificationToken = CryptoUtil.generateSecureToken();
      const verificationTokenExpiry = CryptoUtil.generateTokenExpiry(24); // 24小時後過期

      // ✅ 修改後
      const [result] = await connection.execute(
        `INSERT INTO Users 
       (Email, PasswordHash, FullName, Title, Provider, VerificationToken, VerificationTokenExpiry, NotificationEmail) 
       VALUES (?, ?, ?, ?, 'local', ?, ?, ?)`,
        [
          userData.email.toLowerCase(),
          passwordHash,
          userData.fullName,
          userData.title || null,
          verificationToken,
          verificationTokenExpiry,
          userData.notificationEmail || null
        ]
      );

      // 取得新建立的使用者 ID
      const insertResult = result as mysql.ResultSetHeader;
      const newUserID = insertResult.insertId;

      // 步驟 5: 查詢並回傳新建立的使用者資料（不包含敏感資訊）
      const [userRows] = await connection.execute(
        `SELECT UserID, Email, FullName, AvatarURL, Title, Status, 
                EmailVerified, CreatedAt, UpdatedAt 
         FROM Users WHERE UserID = ?`,
        [newUserID]
      );

      const users = userRows as User[];
      const newUser = users[0];

      // 提交事務
      await connection.commit();

      // 步驟 6: 發送帳號驗證 Email
      const baseUrl = process.env.FRONTEND_URL || "http://localhost:3000";
      const verificationUrl = `${baseUrl}/verify-email?token=${verificationToken}`;

      const emailResult = await this.emailService.sendVerificationEmail({
        to: userData.email.toLowerCase(),
        userName: userData.fullName,
        verificationToken: verificationToken,
        verificationUrl: verificationUrl,
      });

      if (emailResult.success) {
        console.log(
          `帳號驗證信件已發送至: ${userData.email} (使用者: ${userData.fullName})`
        );
      } else {
        console.error(`帳號驗證信件發送失敗: ${emailResult.error}`);
        // 註冊依然成功，只是信件發送失敗
      }

      return {
        success: true,
        message: "使用者註冊成功！請檢查您的 Email 進行帳號驗證。",
        user: newUser,
      };
    } catch (error) {
      // 發生錯誤時回滾事務
      await connection.rollback();
      console.error("建立使用者時發生錯誤:", error);

      return {
        success: false,
        message: "註冊失敗，請稍後再試",
      };
    } finally {
      // 一定要釋放連線回 pool
      connection.release();
    }
  }

  /**
   * 根據 UserID 查詢使用者資料
   * @param userID 使用者 ID
   * @returns 使用者資料（不包含密碼）
   */
  async getUserById(userID: number): Promise<User | null> {
    try {
      const [rows] = await this.pool.execute(
        `SELECT UserID, Email, FullName, AvatarURL, Title, Status, 
                EmailVerified, CreatedAt, UpdatedAt 
         FROM Users WHERE UserID = ?`,
        [userID]
      );

      const users = rows as User[];
      return users.length > 0 ? users[0] : null;
    } catch (error) {
      console.error("查詢使用者資料時發生錯誤:", error);
      throw new Error("查詢使用者失敗");
    }
  }

  /**
   * 驗證 Email
   * @param token 驗證 Token
   * @returns 驗證結果
   */
  async verifyEmail(token: string): Promise<{
    success: boolean;
    message: string;
    user?: any;
  }> {
    const connection = await this.pool.getConnection();

    try {
      console.log("🔵 Service: 開始驗證 Email Token");

      // 步驟 1: 查詢 Token
      const [rows] = await connection.execute(
        `SELECT UserID, Email, FullName, EmailVerified, VerificationTokenExpiry 
       FROM Users 
       WHERE VerificationToken = ?`,
        [token]
      );

      const users = rows as Array<{
        UserID: number;
        Email: string;
        FullName: string;
        EmailVerified: boolean;
        VerificationTokenExpiry: Date;
      }>;

      // ========== 情況 1：Token 不存在 ==========
      if (users.length === 0) {
        console.log("⚠️ Service: Token 不存在，檢查是否已驗證過");

        // ⭐⭐⭐ 嘗試從 Email 查詢（如果前端有傳 email 參數）
        // 或者：檢查最近是否有使用者驗證過（容錯機制）

        // 這裡我們無法確定是哪個使用者，所以回傳失敗
        return {
          success: false,
          message: "驗證連結無效或已過期",
        };
      }

      const user = users[0];

      // ========== 情況 2：已經驗證過了 ==========
      if (user.EmailVerified) {
        console.log("✅ Service: 使用者已經驗證過了", {
          userID: user.UserID,
          email: user.Email,
        });

        // ⭐ 查詢完整使用者資料
        const [userRows] = await connection.execute(
          `SELECT UserID, Email, FullName, Title, AvatarURL, EmailVerified, Status
         FROM Users WHERE UserID = ?`,
          [user.UserID]
        );

        const fullUsers = userRows as any[];
        const fullUser = fullUsers[0];

        // 查詢角色
        const [roleRows] = await connection.execute(
          `SELECT r.RoleName 
         FROM userglobalroles ugr
         JOIN roles r ON ugr.RoleID = r.RoleID
         WHERE ugr.UserID = ?`,
          [user.UserID]
        );

        const roles = (roleRows as any[]).map((row) => row.RoleName);

        // ⭐⭐⭐ 回傳成功（雖然是重複驗證，但對使用者友善）
        return {
          success: true,
          message: "您的 Email 已經驗證過了！",
          user: {
            userID: fullUser.UserID,
            Email: fullUser.Email,
            FullName: fullUser.FullName,
            Title: fullUser.Title,
            AvatarURL: fullUser.AvatarURL,
            EmailVerified: true,
            Status: fullUser.Status,
            Roles: roles,
          },
        };
      }

      // ========== 情況 3：Token 已過期 ==========
      const now = new Date();
      if (user.VerificationTokenExpiry < now) {
        console.log("❌ Service: Token 已過期");
        return {
          success: false,
          message: "驗證連結已過期，請重新發送驗證信",
        };
      }

      // ========== 情況 4：正常驗證流程 ==========
      // 更新為已驗證
      await connection.execute(
        `UPDATE Users 
       SET EmailVerified = TRUE, 
           VerificationToken = NULL, 
           VerificationTokenExpiry = NULL 
       WHERE UserID = ?`,
        [user.UserID]
      );

      // 查詢完整使用者資料
      const [userRows] = await connection.execute(
        `SELECT UserID, Email, FullName, Title, AvatarURL, EmailVerified, Status
       FROM Users WHERE UserID = ?`,
        [user.UserID]
      );

      const fullUsers = userRows as any[];
      const fullUser = fullUsers[0];

      // 查詢角色
      const [roleRows] = await connection.execute(
        `SELECT r.RoleName 
       FROM userglobalroles ugr
       JOIN roles r ON ugr.RoleID = r.RoleID
       WHERE ugr.UserID = ?`,
        [user.UserID]
      );

      const roles = (roleRows as any[]).map((row) => row.RoleName);

      console.log("✅ Service: Email 驗證成功", {
        userID: user.UserID,
        email: user.Email,
      });

      return {
        success: true,
        message: "Email 驗證成功！現在可以使用所有功能了",
        user: {
          userID: fullUser.UserID,
          Email: fullUser.Email,
          FullName: fullUser.FullName,
          Title: fullUser.Title,
          AvatarURL: fullUser.AvatarURL,
          EmailVerified: true,
          Status: fullUser.Status,
          Roles: roles,
        },
      };
    } catch (error) {
      console.error("❌ Service: 驗證 Email 錯誤:", error);
      throw error;
    } finally {
      connection.release();
    }
  }
  /**
   * 重新發送驗證信
   * @param email 使用者 Email
   * @returns 操作結果
   */
  async resendVerificationEmail(
    email: string
  ): Promise<{ success: boolean; message: string }> {
    const connection = await this.pool.getConnection();

    try {
      console.log("🔵 Service: 重新發送驗證信", { email });

      // 步驟 1: 查詢使用者
      const [rows] = await connection.execute(
        `SELECT UserID, Email, FullName, EmailVerified, Status 
       FROM Users 
       WHERE Email = ?`,
        [email]
      );

      const users = rows as Array<{
        UserID: number;
        Email: string;
        FullName: string;
        EmailVerified: boolean;
        Status: string;
      }>;

      if (users.length === 0) {
        return {
          success: false,
          message: "Email 不存在",
        };
      }

      const user = users[0];

      // 步驟 2: 檢查是否已驗證
      if (user.EmailVerified) {
        return {
          success: false,
          message: "Email 已經驗證過了",
        };
      }

      // 步驟 3: 檢查帳號狀態
      if (user.Status !== "Active") {
        return {
          success: false,
          message: "帳號已被停用或封存",
        };
      }

      // 步驟 4: 產生新的驗證 Token
      const { CryptoUtil } = await import("../utils/crypto.js");
      const verificationToken = CryptoUtil.generateSecureToken();
      const verificationTokenExpiry = CryptoUtil.generateTokenExpiry(24); // 24小時

      // ✅ 修改：EmailVerificationToken → VerificationToken
      await connection.execute(
        `UPDATE Users 
       SET VerificationToken = ?, 
           VerificationTokenExpiry = ? 
       WHERE UserID = ?`,
        [verificationToken, verificationTokenExpiry, user.UserID]
      );

      // 步驟 6: 發送驗證信
      const { EmailService } = await import("./email.service.js");
      const emailService = new EmailService();

      const baseUrl = process.env.FRONTEND_URL || "http://localhost:3000";
      const verificationUrl = `${baseUrl}/verify-email?token=${verificationToken}`;

      const emailResult = await emailService.sendVerificationEmail({
        to: user.Email,
        userName: user.FullName,
        verificationToken: verificationToken,
        verificationUrl: verificationUrl,
      });

      if (emailResult.success) {
        console.log("✅ Service: 驗證信已重新發送");
        return {
          success: true,
          message: "驗證信已重新發送至您的信箱",
        };
      } else {
        console.error("❌ Service: 發送驗證信失敗");
        return {
          success: false,
          message: "發送驗證信失敗，請稍後再試",
        };
      }
    } catch (error) {
      console.error("❌ Service: 重新發送驗證信錯誤:", error);
      throw error;
    } finally {
      connection.release();
    }
  }

  /**
   * 以下方法請加入到 UserService 類別中
   */

  /**
   * 管理員建立使用者（可指派角色）
   * @param userData 使用者資料
   * @param roleIDs 要指派的全域角色 ID 陣列
   * @returns 建立結果
   */
  async adminCreateUser(
    userData: CreateUserRequest,
    roleNames: string[] = []
  ): Promise<CreateUserResponse> {
    const connection = await this.pool.getConnection();

    try {
      await connection.beginTransaction();

      // 步驟 1: 檢查 Email 是否已被註冊
      const emailExists = await this.checkEmailExists(userData.email);
      if (emailExists) {
        await connection.rollback();
        return {
          success: false,
          message: "此 Email 已被註冊，請使用其他 Email 地址",
        };
      }

      // 步驟 2: 加密使用者密碼
      const passwordHash = await CryptoUtil.hashPassword(userData.password);

      // 步驟 3: 產生 Email 驗證 Token（管理員建立的帳號也需要驗證）
      const verificationToken = CryptoUtil.generateSecureToken();
      const verificationTokenExpiry = CryptoUtil.generateTokenExpiry(24);

      // 步驟 4: 將使用者資料插入資料庫
      const [result] = await connection.execute(
        `INSERT INTO Users 
   (Email, PasswordHash, FullName, Title, Provider, VerificationToken, VerificationTokenExpiry) 
   VALUES (?, ?, ?, ?, 'local', ?, ?)`,
        [
          userData.email.toLowerCase(),
          passwordHash,
          userData.fullName,
          userData.title || null,
          verificationToken,
          verificationTokenExpiry,
        ]
      );

      const insertResult = result as mysql.ResultSetHeader;
      const newUserID = insertResult.insertId;

      // 步驟 5: 指派全域角色
      if (roleNames.length > 0) {
        // 根據角色名稱查詢角色 ID
        const placeholders = roleNames.map(() => "?").join(",");
        const [roleRows] = await connection.execute(
          `SELECT RoleID, RoleName FROM Roles WHERE RoleName IN (${placeholders})`,
          roleNames
        );

        const validRoles = roleRows as Array<{
          RoleID: number;
          RoleName: string;
        }>;

        // 檢查是否所有角色都存在
        if (validRoles.length !== roleNames.length) {
          const foundRoleNames = validRoles.map((r) => r.RoleName);
          const notFoundRoles = roleNames.filter(
            (name) => !foundRoleNames.includes(name)
          );

          await connection.rollback();
          return {
            success: false,
            message: `以下角色不存在: ${notFoundRoles.join(", ")}`,
          };
        }

        // 插入使用者全域角色
        for (const role of validRoles) {
          await connection.execute(
            "INSERT INTO UserGlobalRoles (UserID, RoleID) VALUES (?, ?)",
            [newUserID, role.RoleID]
          );
        }

        console.log(
          `已為使用者 ${newUserID} 指派角色: ${roleNames.join(", ")}`
        );
      }

      // 步驟 6: 查詢新建立的使用者資料
      const [userRows] = await connection.execute(
        `SELECT UserID, Email, FullName, AvatarURL, Title, Status, 
            EmailVerified, CreatedAt, UpdatedAt 
     FROM Users WHERE UserID = ?`,
        [newUserID]
      );

      const users = userRows as User[];
      const newUser = users[0];

      await connection.commit();

      // 步驟 7: 發送帳號驗證 Email
      const baseUrl = process.env.FRONTEND_URL || "http://localhost:3000";
      const verificationUrl = `${baseUrl}/verify-email?token=${verificationToken}`;
      /*       const baseUrl = process.env.BACKEND_URL || "http://localhost:4000";
      const verificationUrl = `${baseUrl}/api/users/verify-email?token=${verificationToken}`; */

      const emailResult = await this.emailService.sendVerificationEmail({
        to: userData.email.toLowerCase(),
        userName: userData.fullName,
        verificationToken: verificationToken,
        verificationUrl: verificationUrl,
      });

      if (emailResult.success) {
        console.log(`管理員建立使用者成功，驗證信已發送至: ${userData.email}`);
      } else {
        console.error(`驗證信發送失敗: ${emailResult.error}`);
      }

      return {
        success: true,
        message: "使用者建立成功！驗證信已發送至使用者信箱。",
        user: newUser,
      };
    } catch (error) {
      await connection.rollback();
      console.error("管理員建立使用者時發生錯誤:", error);

      return {
        success: false,
        message: "建立使用者失敗，請稍後再試",
      };
    } finally {
      connection.release();
    }
  }

  /**
   * 更新使用者狀態（停用/啟用）
   * @param userID 使用者 ID
   * @param status 新狀態
   * @returns 更新結果
   */
  async updateUserStatus(userId: number, status: string): Promise<boolean> {
    const connection = await this.pool.getConnection();

    try {
      console.log("🔵 Service: 更新使用者狀態", { userId, status });

      const [result] = await connection.execute(
        `UPDATE \`users\` 
       SET Status = ?, UpdatedAt = NOW() 
       WHERE UserID = ?`,
        [status, userId]
      );

      const updateResult = result as any;

      console.log("🔵 Service: 更新結果", updateResult);

      // 檢查是否有更新到資料
      return updateResult.affectedRows > 0;
    } catch (error) {
      console.error("❌ Service: 更新使用者狀態錯誤:", error);
      throw error;
    } finally {
      connection.release();
    }
  }

  /**
   * 指派全域角色給使用者
   * @param userID 使用者 ID
   * @param roleIDs 角色 ID 陣列
   * @returns 操作結果
   */
  async assignGlobalRoles(
    userID: number,
    roleNames: string[]
  ): Promise<{ success: boolean; message: string }> {
    const connection = await this.pool.getConnection();

    try {
      await connection.beginTransaction();

      // 1️⃣ 檢查使用者是否存在
      const [userRows] = await connection.execute(
        "SELECT UserID FROM Users WHERE UserID = ?",
        [userID]
      );
      if ((userRows as any[]).length === 0) {
        await connection.rollback();
        return { success: false, message: "使用者不存在" };
      }

      // 2️⃣ 如果沒角色 → 清空角色
      if (roleNames.length === 0) {
        await connection.execute(
          "DELETE FROM UserGlobalRoles WHERE UserID = ?",
          [userID]
        );
        await connection.commit();
        return { success: true, message: "已移除所有角色" };
      }

      // 3️⃣ 查出有效角色
      const placeholders = roleNames.map(() => "?").join(",");
      const [roleRows] = await connection.execute(
        `SELECT RoleID, RoleName FROM Roles WHERE RoleName IN (${placeholders})`,
        roleNames
      );
      const validRoles = roleRows as Array<{
        RoleID: number;
        RoleName: string;
      }>;

      if (validRoles.length === 0) {
        await connection.rollback();
        return { success: false, message: "找不到任何有效角色" };
      }

      // 4️⃣ 先刪除舊的角色
      await connection.execute("DELETE FROM UserGlobalRoles WHERE UserID = ?", [
        userID,
      ]);

      // 5️⃣ 插入新角色（防止重複）
      for (const role of validRoles) {
        await connection.execute(
          "INSERT IGNORE INTO UserGlobalRoles (UserID, RoleID) VALUES (?, ?)",
          [userID, role.RoleID]
        );
      }

      await connection.commit();

      return {
        success: true,
        message: `角色指派成功：${validRoles
          .map((r) => r.RoleName)
          .join(", ")}`,
      };
    } catch (error) {
      await connection.rollback();
      console.error("❌ assignGlobalRoles 錯誤:", error);
      return { success: false, message: "角色指派失敗" };
    } finally {
      connection.release();
    }
  }

  /**
   * 更新使用者個人資料
   * @param userID 使用者 ID
   * @param profileData 要更新的資料
   * @returns 更新結果
   */
  /**
   * 更新使用者個人資料（含 NotificationEmail）
   * 優化版：更新後會立即 SELECT 一次確認資料是否正確更新
   */
  async updateProfile(
    userID: number,
    profileData: {
      FullName?: string;
      Title?: string | null;
      AvatarURL?: string | null;
      NotificationEmail?: string | null;
    }
  ): Promise<{ success: boolean; message: string; user?: any }> {
    const connection = await this.pool.getConnection();
    console.log("🔵 後端收到的 profileData:", profileData);

    try {
      await connection.beginTransaction();

      // === Step 1: 檢查使用者是否存在 ===
      const [userRows] = await connection.execute(
        "SELECT UserID, Status FROM Users WHERE UserID = ?",
        [userID]
      );

      if ((userRows as any[]).length === 0) {
        await connection.rollback();
        return { success: false, message: "使用者不存在" };
      }

      if ((userRows as any[])[0].Status !== "Active") {
        await connection.rollback();
        return { success: false, message: "帳號已被停用或封存" };
      }

      // === Step 2: 建立動態 UPDATE 語句 ===
      const updateFields: string[] = [];
      const updateValues: any[] = [];

      if (profileData.FullName !== undefined) {
        updateFields.push("FullName = ?");
        updateValues.push(profileData.FullName);
      }

      if (profileData.Title !== undefined) {
        updateFields.push("Title = ?");
        updateValues.push(profileData.Title);
      }

      if (profileData.AvatarURL !== undefined) {
        updateFields.push("AvatarURL = ?");
        updateValues.push(profileData.AvatarURL);
      }

      if (profileData.NotificationEmail !== undefined) {
        updateFields.push("NotificationEmail = ?");
        updateValues.push(profileData.NotificationEmail);
      }

      if (updateFields.length === 0) {
        await connection.rollback();
        return { success: false, message: "沒有提供任何要更新的欄位" };
      }

      // 常見問題：忘記更新 UpdatedAt
      updateFields.push("UpdatedAt = NOW()");

      // === Step 3: 執行 UPDATE ===
      updateValues.push(userID);

      const updateQuery = `UPDATE Users SET ${updateFields.join(
        ", "
      )} WHERE UserID = ?`;

      console.log("🔧 執行 UPDATE:", updateQuery, updateValues);

      await connection.execute(updateQuery, updateValues);

      // === ⭐ Step 4: 立即 SELECT 驗證資料是否更新 ===
      const [checkRows] = await connection.execute(
        `SELECT UserID, Email, FullName, AvatarURL, Title, Status, 
              EmailVerified, NotificationEmail 
       FROM Users WHERE UserID = ?`,
        [userID]
      );

      console.log("🔍 UPDATE 後立即查詢:", checkRows);

      const updatedUser = (checkRows as any[])[0];

      // === Step 5: 查詢角色 ===
      const [roleRows] = await connection.execute(
        `SELECT r.RoleName 
       FROM userglobalroles ugr
       JOIN roles r ON ugr.RoleID = r.RoleID
       WHERE ugr.UserID = ?`,
        [userID]
      );

      const roles = (roleRows as any[]).map((r) => r.RoleName);

      // === Step 6: Commit ===
      await connection.commit();

      return {
        success: true,
        message: "個人資料更新成功",
        user: {
          ...updatedUser,
          Roles: roles,
          EmailVerified: Boolean(updatedUser.EmailVerified),
        },
      };
    } catch (error) {
      await connection.rollback();
      console.error("❌ 更新個人資料錯誤:", error);
      throw error;
    } finally {
      connection.release();
    }
  }

  /**
   * 取得所有使用者列表（支援分頁和篩選）
   */
  async getAllUsers(options?: {
    page?: number;
    pageSize?: number;
    search?: string;
    status?: string;
  }): Promise<{
    users: any[];
    total: number;
    page: number;
    pageSize: number;
    totalPages: number;
  }> {
    const connection = await this.pool.getConnection();

    try {
      const page = parseInt(String(options?.page || 1));
      const pageSize = parseInt(String(options?.pageSize || 10));
      const search = String(options?.search || "").trim();
      const status = String(options?.status || "");
      const offset = (page - 1) * pageSize;

      console.log("🔵 Service: 分頁參數", {
        page,
        pageSize,
        offset,
        search,
        status,
      });

      // 建立查詢條件
      const conditions: string[] = ["1=1"];
      const params: any[] = [];

      // 搜尋條件
      if (search) {
        conditions.push("(u.FullName LIKE ? OR u.Email LIKE ?)");
        params.push(`%${search}%`, `%${search}%`);
        console.log("🔵 Service: 套用搜尋條件", search);
      }

      // 狀態篩選
      if (status) {
        conditions.push("u.Status = ?");
        params.push(status);
        console.log("🔵 Service: 套用狀態篩選", status);
      }

      const whereClause = conditions.join(" AND ");
      console.log("🔵 Service: WHERE 條件", whereClause);
      console.log("🔵 Service: 參數", params);

      // 1. 查詢總數
      const countSql = `
      SELECT COUNT(DISTINCT u.UserID) as total 
      FROM \`users\` u 
      WHERE ${whereClause}
    `;

      const [countResult] = await connection.execute(countSql, params);
      const total = (countResult as any[])[0].total;
      console.log("🔵 Service: 符合條件的總使用者數", total);

      // 2. 查詢分頁資料
      const dataSql = `
      SELECT 
        u.UserID,
        u.Email,
        u.FullName,
        u.Title,
        u.AvatarURL,
        u.Status,
        u.EmailVerified,
        u.Provider,
        u.CreatedAt,
        u.UpdatedAt,
        GROUP_CONCAT(DISTINCT r.RoleName) as Roles
      FROM \`users\` u
      LEFT JOIN \`userglobalroles\` ugr ON u.UserID = ugr.UserID
      LEFT JOIN \`roles\` r ON ugr.RoleID = r.RoleID
      WHERE ${whereClause}
      GROUP BY u.UserID, u.Email, u.FullName, u.Title, u.AvatarURL, 
               u.Status, u.EmailVerified, u.Provider, u.CreatedAt, u.UpdatedAt
      ORDER BY u.CreatedAt DESC
      LIMIT ${pageSize} OFFSET ${offset}
    `;

      const [rows] = await connection.execute(dataSql, params);
      const userRows = rows as any[];
      console.log("🔵 Service: 查詢完成，回傳", userRows.length, "筆資料");

      // 處理資料
      const users = userRows.map((user) => ({
        ...user,
        Roles: user.Roles ? user.Roles.split(",") : [],
        EmailVerified: Boolean(user.EmailVerified),
      }));

      const totalPages = Math.ceil(total / pageSize);

      console.log("✅ Service: 回傳結果", {
        total,
        page,
        pageSize,
        totalPages,
        returned: users.length,
      });

      return { users, total, page, pageSize, totalPages };
    } catch (error) {
      console.error("❌ Service: 查詢使用者列表錯誤:", error);
      throw error;
    } finally {
      connection.release();
    }
  }

  /**
   * 更新使用者資料
   * @param userId 使用者 ID
   * @param data 要更新的資料
   * @returns 是否更新成功
   */
  async updateUser(
    userId: number,
    data: {
      fullName?: string;
      title?: string;
      status?: string;
    }
  ): Promise<boolean> {
    const connection = await this.pool.getConnection();

    try {
      console.log("🔵 Service: 更新使用者資料", { userId, data });

      // 動態建立 UPDATE 語句
      const updates: string[] = [];
      const values: any[] = [];

      if (data.fullName !== undefined) {
        updates.push("FullName = ?");
        values.push(data.fullName);
      }

      if (data.title !== undefined) {
        updates.push("Title = ?");
        values.push(data.title);
      }

      if (data.status !== undefined) {
        updates.push("Status = ?");
        values.push(data.status);
      }

      // 總是更新 UpdatedAt
      updates.push("UpdatedAt = NOW()");

      // 如果沒有要更新的欄位
      if (updates.length === 1) {
        // 只有 UpdatedAt
        console.log("⚠️ Service: 沒有要更新的欄位");
        return false;
      }

      // 加入 userId
      values.push(userId);

      const sql = `UPDATE \`users\` SET ${updates.join(", ")} WHERE UserID = ?`;

      console.log("🔵 Service: 執行 SQL", { sql, values });

      const [result] = await connection.execute(sql, values);

      const updateResult = result as any;

      console.log("🔵 Service: 更新結果", updateResult);

      return updateResult.affectedRows > 0;
    } catch (error) {
      console.error("❌ Service: 更新使用者資料錯誤:", error);
      throw error;
    } finally {
      connection.release();
    }
  }
  /**
   * 審核使用者（管理員操作）
   * @param userId 使用者 ID
   * @param roleNames 要指派的角色名稱陣列
   * @returns 審核結果
   */
  async approveUser(
    userId: number,
    roleNames: string[] = []
  ): Promise<{
    success: boolean;
    message: string;
    user?: any;
  }> {
    const connection = await this.pool.getConnection();

    try {
      await connection.beginTransaction();

      console.log("🔵 Service: 開始審核使用者", { userId, roleNames });

      // 步驟 1: 檢查使用者是否存在
      const [userRows] = await connection.execute(
        `SELECT UserID, Email, FullName, Status, EmailVerified
       FROM Users WHERE UserID = ?`,
        [userId]
      );

      const users = userRows as Array<{
        UserID: number;
        Email: string;
        FullName: string;
        Status: string;
        EmailVerified: boolean;
      }>;

      if (users.length === 0) {
        await connection.rollback();
        return {
          success: false,
          message: "找不到指定的使用者",
        };
      }

      const user = users[0];

      // 步驟 2: 檢查 Email 是否已驗證
      if (!user.EmailVerified) {
        await connection.rollback();
        return {
          success: false,
          message: "使用者尚未驗證 Email，無法審核",
        };
      }

      // 步驟 3: 檢查使用者狀態
      if (user.Status === "Active") {
        await connection.rollback();
        return {
          success: false,
          message: "使用者已經是啟用狀態",
        };
      }

      // 步驟 4: 驗證角色是否存在
      if (roleNames.length === 0) {
        await connection.rollback();
        return {
          success: false,
          message: "請至少指派一個角色",
        };
      }

      const placeholders = roleNames.map(() => "?").join(",");
      const [roleRows] = await connection.execute(
        `SELECT RoleID, RoleName FROM Roles WHERE RoleName IN (${placeholders})`,
        roleNames
      );

      const validRoles = roleRows as Array<{
        RoleID: number;
        RoleName: string;
      }>;

      if (validRoles.length !== roleNames.length) {
        const foundRoleNames = validRoles.map((r) => r.RoleName);
        const notFoundRoles = roleNames.filter(
          (name) => !foundRoleNames.includes(name)
        );

        await connection.rollback();
        return {
          success: false,
          message: `以下角色不存在: ${notFoundRoles.join(", ")}`,
        };
      }

      // 步驟 5: 更新使用者狀態為 Active
      await connection.execute(
        `UPDATE Users SET Status = 'Active' WHERE UserID = ?`,
        [userId]
      );

      // 步驟 6: 指派角色
      for (const role of validRoles) {
        await connection.execute(
          "INSERT INTO UserGlobalRoles (UserID, RoleID) VALUES (?, ?)",
          [userId, role.RoleID]
        );
      }

      console.log(
        `✅ 使用者 ${
          user.FullName
        } (ID: ${userId}) 已審核通過，指派角色: ${roleNames.join(", ")}`
      );

      await connection.commit();

      // 步驟 7: 查詢完整使用者資料
      const [updatedUserRows] = await connection.execute(
        `SELECT UserID, Email, FullName, Title, AvatarURL, EmailVerified, Status
       FROM Users WHERE UserID = ?`,
        [userId]
      );

      const updatedUsers = updatedUserRows as any[];
      const updatedUser = updatedUsers[0];

      return {
        success: true,
        message: "使用者審核成功，帳號已啟用",
        user: {
          userID: updatedUser.UserID,
          Email: updatedUser.Email,
          FullName: updatedUser.FullName,
          Title: updatedUser.Title,
          AvatarURL: updatedUser.AvatarURL,
          EmailVerified: updatedUser.EmailVerified,
          Status: updatedUser.Status,
          Roles: roleNames,
        },
      };
    } catch (error) {
      await connection.rollback();
      console.error("❌ Service: 審核使用者時發生錯誤:", error);
      return {
        success: false,
        message: "審核使用者失敗",
      };
    } finally {
      connection.release();
    }
  }
}
