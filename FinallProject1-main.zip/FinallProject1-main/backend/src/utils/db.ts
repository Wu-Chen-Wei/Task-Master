// backend/src/utils/db.ts
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

// 讀取 .env
dotenv.config();

// 建立 MySQL 連線池
export const db = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  port: Number(process.env.DB_PORT) || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// ✅ 測試連線函式（健康檢查用）
export async function testDbConnection() {
  const [rows] = await db.query('SELECT 1 AS ok');
  return rows;
}

