import express from "express";
import dotenv from "dotenv";
import { mailer } from "../services/easytrack-mailer";
import { db } from "../services/db";


dotenv.config();
const app = express();
app.use(express.json());

// 測試API
app.get("/", (req, res) => {
  res.json({ message: "Send-email API is working" });
});

// ✅ 取得所有 notifications + projects 資料
app.get("/all", async (req, res) => {
  try {
    const [automationrulesRows] = await db.query("SELECT * FROM automationrules WHERE DeletedAt IS NULL");

    res.json({
      automationrules: automationrulesRows,
    });
  } catch (error: any) {
    console.error("❌ 取得資料失敗:", error);
    res.status(500).json({ error: "資料查詢失敗", detail: error.message });
  }
});

// 📁 routes/rule.ts (或你的 app.ts)
app.post("/create", async (req, res) => {
  try {
    const {
      ProjectID,
      MissionID,
      Name,
      Descriptions,
      TriggerDefinition,
      ActionDefinition,
      IsEnabled,
    } = req.body;

    const [result] = await db.query(
      `INSERT INTO automationrules (ProjectID, MissionID, Name, Descriptions, TriggerDefinition, ActionDefinition, IsEnabled)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [ProjectID, MissionID, Name, Descriptions, TriggerDefinition, ActionDefinition, IsEnabled]
    );

    res.json({
      success: true,
      message: "新規則建立成功",
      newRule: {
        RuleID: (result as any).insertId, // 加上 RuleID
        ProjectID,
        MissionID,
        Name,
        Descriptions,
        TriggerDefinition,
        ActionDefinition,
        IsEnabled,
      },
    });
  } catch (err: any) {
    console.error("❌ 建立規則失敗:", err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ✅ 切換規則啟用狀態
app.patch("/toggle/:id", async (req, res) => {
  const ruleId = req.params.id;
  try {
    // 查目前狀態
    const [rows] = await db.query<any[]>("SELECT IsEnabled FROM automationrules WHERE RuleID = ?", [ruleId]);
    if ((rows as any[]).length === 0) {
        return res.status(404).json({ error: "找不到這筆規則" });
        }

    const current = rows[0].IsEnabled;
    const newValue = current ? 0 : 1;

    await db.query("UPDATE automationrules SET IsEnabled = ? WHERE RuleID = ?", [newValue, ruleId]);

    res.json({ success: true, newStatus: newValue });
  } catch (error) {
  if (error instanceof Error) {
    console.error("❌ 更新啟用狀態失敗:", error.message);
    res.status(500).json({ error: "資料更新失敗", detail: error.message });
  } else {
    console.error("❌ 未知錯誤:", error);
    res.status(500).json({ error: "未知錯誤" });
  }
}
});

// ✅ 更新自動化規則
app.put("/update/:ruleId", async (req, res) => {
  try {
    const { ruleId } = req.params;
    const {
      Name,
      Descriptions,
      TriggerDefinition,
      ActionDefinition,
      IsEnabled,
    } = req.body;

    const [result] = await db.query(
      `UPDATE automationrules 
       SET Name = ?, Descriptions = ?, TriggerDefinition = ?, 
           ActionDefinition = ?, IsEnabled = ?, UpdatedAt = NOW()
       WHERE RuleID = ?`,
      [Name, Descriptions, TriggerDefinition, ActionDefinition, IsEnabled, ruleId]
    );

    if ((result as any).affectedRows === 0) {
      return res.status(404).json({ success: false, message: "找不到該規則" });
    }

    // ✅ 新增回傳 newRule，讓前端能更新畫面
    res.json({
      success: true,
      message: "更新成功",
      newRule: {
        RuleID: Number(ruleId),
        Name,
        Descriptions,
        TriggerDefinition,
        ActionDefinition,
        IsEnabled,
      },
    });
  } catch (error: any) {
    console.error("❌ 更新規則錯誤:", error);
    res.status(500).json({
      success: false,
      message: "伺服器錯誤",
      detail: error.message,
    });
  }
});




// ✅ 軟刪除通知（設定 DeletedAt 為當前時間）
app.put("/delete/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const [result] = await db.query(
      "UPDATE automationrules SET DeletedAt = NOW() WHERE RuleID = ?",
      [id]
    );

    if ((result as any).affectedRows > 0) {
      res.json({ success: true });
    } else {
      res.status(404).json({ success: false, message: "通知不存在" });
    }
  } catch (error: any) {
    console.error("❌ 刪除通知失敗:", error);
    res.status(500).json({ success: false, message: "伺服器錯誤" });
  }
});
export default app;
