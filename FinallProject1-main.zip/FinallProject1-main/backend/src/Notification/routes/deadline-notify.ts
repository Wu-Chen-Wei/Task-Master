import cron from "node-cron";
import { db } from "../services/db";
import { mailer } from "../services/easytrack-mailer";

// "*/1 * * * *" 表示 每分鐘執行一次。
async function loadCronSettings() {
  const [rows] = await db.query<any>(`SELECT * FROM notification_settings LIMIT 1`);
  return rows[0];
}

async function startDynamicCron() {
  

  const cronPattern = `*/1 * * * *`;

  cron.schedule(cronPattern, async () => {

    const settings = await loadCronSettings();

    console.log(`[CRON] Checking project EndDate reminders...${settings.CronIntervalMinutes} ${settings.NotifyBeforeMinutes}`);

    if (!settings.IsEnabled) {
      console.log("[CRON] Disabled. Skip.");
      return;
    }

    const [projects] = await db.query<any[]>(
      `
      SELECT p.*, u.NotificationEmail AS OwnerEmail
      FROM projects p
      LEFT JOIN users u ON p.OwnerUserID = u.UserID
      WHERE p.IsEndDateNotified = 0
      AND p.EndDate IS NOT NULL
      AND p.EndDate <= DATE_ADD(NOW(), INTERVAL ? MINUTE)
      `,
      [settings.NotifyBeforeMinutes]
    );

    for (const project of projects) {
      await mailer.sendMail({
        from: process.env.GMAIL_SYSTEM_USER,
        to: project.OwnerEmail,
        subject: `提醒：[${project.ProjectName}] 即將到期`,
        text: `您的專案「${project.ProjectName}」將於 ${project.EndDate} 到期。`
      });
       console.log(`${project.OwnerEmail}`);
      await db.query(
        `UPDATE projects SET IsEndDateNotified = 1 WHERE ProjectID = ?`,
        [project.ProjectID]
      );
    }

    console.log("[CRON] Done");
  });
}

startDynamicCron();
