import express from "express";
import dotenv from "dotenv";
import { mailer } from "../services/easytrack-mailer";
import { db } from "../services/db";


dotenv.config();
const app = express();
app.use(express.json());

app.get("/userEmailSearch/:userId", async (req, res) => {
  try {
    const userId = req.params.userId;

    const [rows] = await db.query<any>(
      "SELECT NotificationEmail FROM users WHERE UserID = ?",
      [userId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json({ email: rows[0].NotificationEmail });
  } catch (err) {
    console.error("Error fetching email:", err);
    res.status(500).json({ error: "Database error" });
  }
});

app.get("/notification-settings-get", async (req, res) => {
  const [rows] = await db.query<any>(`SELECT * FROM notification_settings LIMIT 1`);
  res.json(rows[0]);
});

app.put("/notification-settings-put", async (req, res) => {
  const { CronIntervalMinutes, NotifyBeforeMinutes, cronIsEnabled } = req.body;

  await db.query(
    `UPDATE notification_settings SET 
      CronIntervalMinutes = ?, 
      NotifyBeforeMinutes = ?, 
      IsEnabled = ?
     WHERE SettingID = 1`,
    [CronIntervalMinutes, NotifyBeforeMinutes, cronIsEnabled]
  );

  res.json({ success: true });
});

// PUT /api/set/notification-settings-toggle
app.put("/notification-settings-toggle", async (req, res) => {
  const { cronIsEnabled } = req.body;

  try {
    await db.query(
      "UPDATE notification_settings SET IsEnabled = ? WHERE SettingID = 1",
      [cronIsEnabled]
    );
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "更新失敗" });
  }
});

// PUT /api/users/:userId/email
app.put("/updateEmail/:userId", async (req, res) => {
  const userId = req.params.userId;
  const { email } = req.body;

  try {
    await db.query("UPDATE users SET NotificationEmail = ? WHERE UserID = ?", [email, userId]);
    res.status(200).json({ success: true, email });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "更新失敗" });
  }
});

export default app;