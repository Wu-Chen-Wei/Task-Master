import express from "express";
import dotenv from "dotenv";
import nodemailer from "nodemailer";
import mysql from "mysql2/promise";
import { mailer } from "../services/easytrack-mailer";
import { db } from "../services/db";

dotenv.config();
const app = express();
app.use(express.json());

// 測試API
app.get("/", (req, res) => {
    res.json({ message: "Send-email API is working" });
});

// 寄信API
app.post("/", async (req, res) => {
    try {
        const { userId, projectId, content } = req.body;

        if (!projectId || !content) {
            console.error("Send email failed: missing content", req.body);
            return res.status(400).json({ error: "Failed to send email", detail: "Missing content" });
        }

        // 1️⃣ 查 Project 信息
        const [projectRows] = await db.query(
            "SELECT * FROM projects WHERE ProjectID = ?",
            [projectId]
        );
        const project = (projectRows as any[])[0];

        if (!project) {
            return res.status(404).json({ error: "Project not found" });
        }

        // 2️⃣ 查 projectmembers --> 取得所有 UserID
        const [memberRows] = await db.query(
            "SELECT UserID FROM projectmembers WHERE ProjectID = ?",
            [projectId]
        );
        const memberList = memberRows as { UserID: number }[];

        if (memberList.length === 0) {
            return res.status(404).json({ error: "No members found for project" });
        }

        const userIds = memberList.map(m => m.UserID);

        // 3️⃣ 查 users 表，取得 email
        const [userRows] = await db.query(
            `SELECT UserID, FullName, Email, NotificationEmail FROM users WHERE UserID IN (${userIds.map(() => "?").join(",")})`,
            userIds
        );
        const users = userRows as { UserID: number; FullName: string; Email: string; NotificationEmail: string }[];

        if (users.length === 0) {
            return res.status(404).json({ error: "No user emails found" });
        }

        // 4️⃣ 逐一寄信
        for (const user of users) {

            const mailOptions = {
            from: `${process.env.GMAIL_SYSTEM_USER}`,
            to: user.NotificationEmail,
            subject: "EasyTrack 通知信件",
            text: `

            嗨 ${user.FullName}

            ${content}：「${project.Description}」

            `,
        };

        try {
                const info = await mailer.sendMail(mailOptions);
                console.log(`📧 Email sent to ${user.NotificationEmail}:`, info.response);
            } catch (emailErr) {
                console.error(`❌ Failed to send email to ${user.NotificationEmail}:`, emailErr);
            }
        }
        res.json({ success: true, message: "Email sent successfully!" });
    } catch (error: any) {
        console.error("❌ Send email failed:", error);
        res.status(500).json({ error: "Failed to send email", detail: error.message });
    }
});

export default app; // ✅ 一定要加這行
