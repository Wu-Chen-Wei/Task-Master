import express from "express";
import dotenv from "dotenv";
import { mailer } from "../services/easytrack-mailer";
import { db } from "../services/db";

dotenv.config();

const router = express.Router();

let clients: any[] = []; // SSE 連線列表


router.get("/testlog", (req, res) => {
  console.log("🔥 這是測試 log");
  res.json({ message: "OK" });
});

// ✅ 取得所有 notifications + projects 資料
router.get("/all", async (req, res) => {
  try {
    const [notificationsRows] = await db.query<any>("SELECT * FROM notifications WHERE DeletedAt IS NULL ORDER BY CreatedAt DESC");

    const [projectsRows] = await db.query("SELECT * FROM projects");
    const [countisreadRows] = await db.query("SELECT COUNT(*) AS unreadCount FROM notifications WHERE IsRead = 0") as any[];

    // 3️⃣ 取 projecthistory 的 ProjectID 和 ChangeType
    const [historyRows] = await db.query<any>(`
      SELECT ProjectID, ChangeType, ChangedAt
      FROM projecthistory
    `);

    const notificationsWithChangeType = notificationsRows.map((n: any) => {
  // 找出該通知所屬專案的所有歷史紀錄，且時間相等
  const relatedHistories = historyRows.filter(
    (h: any) =>
      h.ProjectID === n.ProjectID &&
      new Date(h.ChangedAt).getTime() === new Date(n.CreatedAt).getTime()
  );

  // 若完全沒有時間相等的紀錄，退而取最新一筆
  const latestHistory =
    relatedHistories.length > 0
      ? relatedHistories[0]
      : historyRows
          .filter((h: any) => h.ProjectID === n.ProjectID)
          .sort(
            (a: any, b: any) =>
              new Date(b.ChangedAt).getTime() - new Date(a.ChangedAt).getTime()
          )[0];

  return {
    ...n,
    ChangeType: latestHistory ? latestHistory.ChangeType : null,
  };
});

    
    

    res.json({
      notifications: notificationsWithChangeType,
      projects: projectsRows,
      unreadCount: countisreadRows[0]?.unreadCount || 0,
    });
  } catch (error: any) {
    console.error("❌ 取得資料失敗:", error);
    res.status(500).json({ error: "資料查詢失敗", detail: error.message });
  }
});

// GET /api/notifications/unread-count
router.get("/unread-count", async (req, res) => {
  try {
    const [rows] = await db.query<any[]>(
      "SELECT COUNT(*) AS unreadCount FROM notifications WHERE IsRead = 0 AND DeletedAt IS NULL"
    );
    res.json({ unreadCount: rows[0].unreadCount });
  } catch (error) {
    console.error("❌ 取得未讀數量失敗:", error);
    res.status(500).json({ message: "伺服器錯誤" });
  }
});

router.get("/stream", (req, res) => {
  res.set({
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
  });
  res.flushHeaders();
  clients.push(res);
  req.on("close", () => {
    clients = clients.filter((c) => c !== res);
  });
});



// // === SSE 連線端點 ===
// app.get("/stream-sidebar", (req, res) => {
//   res.setHeader("Content-Type", "text/event-stream");
//   res.setHeader("Cache-Control", "no-cache");
//   res.setHeader("Connection", "keep-alive");
//   res.flushHeaders();

//   clients.push(res);
//   console.log("🟢 新 SSE 連線，目前連線數:", clients.length);

//   req.on("close", () => {
//     clients = clients.filter((c) => c !== res);
//     console.log("🔴 SSE 連線中斷，目前剩餘:", clients.length);
//   });
// });

// === 推播工具函式 ===
function broadcast(event: string, data: any) {
  clients.forEach((client) => {
    client.write(`event: ${event}\n`);
    client.write(`data: ${JSON.stringify(data)}\n\n`);
  });
}

// ✅ 取得目前未讀數量
async function getUnreadCount() {
  const [rows] = await db.query<any[]>(
    "SELECT COUNT(*) AS unreadCount FROM notifications WHERE IsRead = 0 AND DeletedAt IS NULL"
  );
  return rows[0].unreadCount || 0;
}




// ✅ 後端新增通知後推送給所有 client
export async function broadcastNewNotification(notification: any) {
  

  console.log("📣 推播新通知給所有 SSE 客戶端:", notification);
  broadcast("newNotification", notification);

  const unreadCount = await getUnreadCount();
  broadcast("unreadCount", { unreadCount });
}


// app.get("/events", (req, res) => {
//   res.setHeader("Content-Type", "text/event-stream");
//   res.setHeader("Cache-Control", "no-cache");
//   res.setHeader("Connection", "keep-alive");
//   res.flushHeaders();

//   clients.push(res);

//   req.on("close", () => {
//     clients = clients.filter((c) => c !== res);
//   });
// });

// // SSE 取得未讀通知數
// app.get("/unread-count-stream", async (req, res) => {
//   // 設定 SSE 必要 header
//   res.setHeader("Content-Type", "text/event-stream");
//   res.setHeader("Cache-Control", "no-cache");
//   res.setHeader("Connection", "keep-alive");

//   const sendUnreadCount = async () => {
//     try {
//       const result = await db.query<any>("SELECT COUNT(*) AS count FROM notifications WHERE IsRead = 0");
//       const count = result[0]?.count || 0;
//       res.write(`data: ${JSON.stringify({ unreadCount: count })}\n\n`);
//     } catch (err) {
//       console.error("SSE unread count error:", err);
//     }
//   };

//   // 初次推送
//   sendUnreadCount();

//   // 設定 interval，每 5 秒更新一次（可改成資料庫觸發更佳）
//   const interval = setInterval(sendUnreadCount, 5000);

//   // 連線關閉時清理
//   req.on("close", () => {
//     clearInterval(interval);
//   });
// });



// ✅ 更新通知為已讀
router.put("/notifications/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await db.query("UPDATE notifications SET IsRead = 1 WHERE NotificationID = ?", [id]);

// 即時推播未讀數更新
    const unreadCount = await getUnreadCount();
    broadcast("unreadCount", { unreadCount });

    res.json({ success: true, message: "通知已標記為已讀" });
  } catch (err) {
    console.error("更新通知狀態失敗:", err);
    res.status(500).json({ success: false, message: "伺服器錯誤" });
  }
});

// ✅ 軟刪除通知（設定 DeletedAt 為當前時間）
router.put("/delete/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const [result] = await db.query(
      "UPDATE notifications SET DeletedAt = NOW() WHERE NotificationID = ?",
      [id]
    );

    if ((result as any).affectedRows > 0) {
      res.json({ success: true });
    } else {
      res.status(404).json({ success: false, message: "通知不存在" });
    }
  } catch (error: any) {
    console.error("❌ 刪除通知失敗:", error);
    res.status(500).json({ success: false, message: "伺服器錯誤" });
  }
});

export default router; // ✅ 匯出 router，不是 app
