import nodemailer from "nodemailer";

export const mailer = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: process.env.GMAIL_SYSTEM_USER,
        pass: process.env.GMAIL_SYSTEM_PASS, // 不是登入密碼，是 GMAIL 發給第三方的 APP 密碼
    },
});