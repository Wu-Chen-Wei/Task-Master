import express from "express";
import cors from "cors";
import morgan from "morgan";
import path from "path"; // 上傳圖片1102
import {fileURLToPath} from "url"; //上傳圖片1102
import {authenticateToken} from "./middleware/auth.middleware"; // 請根據實際路徑引入中介軟體
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 新增：引入使用者路由和認證路由
//============================================
import { pool } from "./config/db.js"; //固定連線資料庫字串
//============================================
// 劉敦桐_權限模組
import { member_createUserRoutes } from "./member/routes/user.routes";
import { member_createAuthRoutes } from "./member/routes/auth.routes";
import { member_createRoleRoutes } from "./member/routes/role.routes.js";
import { member_createProjectRoutes } from "./member/routes/project.routes.js"; // 這支路由是?? 給project用的? by 辛
// 劉敦桐_權限模組
//============================================

// =========================================================
// 專案模組 (Project Module) 導入
// =========================================================
import { ProjectModel } from "./project/models/project.model";
import { ProjectAttachmentModel } from "./project/models/project.attachment.model";
import { ProjectHistoryModel } from "./project/models/project.history.model";

import { ProjectCrudService } from "./project/services/project.crud.service";
import { PmTransferService } from "./project/services/pm.transfer.service";
import { RdlStampService } from "./project/services/rdl.stamp.service";
import { AttachmentService } from "./project/services/attachment.service";

import { createProjectRoutes } from "./project/routes/project.routes";
import { createAttachmentRoutes } from "./project/routes/attachment.routes";
// =========================================================
// 專案模組 (Project Module) 導入
// =========================================================

import Notification_sendEmail from "./Notification/routes/send-email.js";
import Notification_list from "./Notification/routes/list.js";
import Notification_rule from "./Notification/routes/rule.js";
import Notification_set from "./Notification/routes/set";
import "./Notification/routes/deadline-notify";
// =========================================================
// 📊 Dashboard 模組 (Dashboard Module) 導入
// =========================================================
import {Dashboard_createDashboardRoutes} from "./Dashboard/routes/dashboard.routes";
// =========================================================

// ⭐⭐⭐ Mission 模組導入（新增） ==================================
import createMissionRoutes from "./mission/routes/mission.routes.js"; // <— 新增：Mission 路由入口
// ===============================================================

const app = express();

// Middleware
app.use(
  cors({
    origin: [
      "http://localhost:5000",
      "http://localhost:5173",
      "http://127.0.0.1:5500",
      "http://localhost:5500",
      "http://localhost:8080", // 可能的其他開發端口
    ],
    credentials: true,
  })
);
app.use(morgan("dev"));
app.use(express.json());
// 🔍 測試 body parser 是否正常
// 🔍 全局測試：確認 body parser 是否運作
// app.use((req, res, next) => {
//   if (req.method === "PUT" || req.method === "POST") {
//     console.log("🔍 [Body Test]", req.method, req.path);
//     console.log("🔍 Content-Type:", req.headers["content-type"]);
//     console.log("🔍 req.body:", req.body);
//   }
//   next();
// });
app.use("/uploads", express.static(path.join(__dirname, "../uploads")));
// ✅ 加入全域請求 Log
// app.use((req, res, next) => {
//   console.log(`📍 收到請求: ${req.method} ${req.url}`);
//   next();
// });
// Routes
// 新的認證路由
console.log("✅ 正在註冊 /api/auth 路由");
const authRoutes = member_createAuthRoutes(pool);
app.use("/api/auth", authRoutes);
console.log("✅ /api/auth 路由註冊完成");

// 使用者管理路由
const userRoutes = member_createUserRoutes(pool);
app.use("/api/users", userRoutes);

// 在路由設定區域加入
const roleRoutes = member_createRoleRoutes(pool);
app.use("/api/roles", roleRoutes);

// 註冊路由
app.use("/api/projects", member_createProjectRoutes(pool));


// Mission 路由註冊
const missionRoutes = createMissionRoutes(pool);
app.use("/api/missions", missionRoutes);

// 使用 sendemail 中介軟體
app.use("/api/send-email", Notification_sendEmail);

app.use("/api/list", Notification_list);

app.use("/api/rule", Notification_rule);

app.use("/api/set", Notification_set);
// =========================================================
// 專案模組 (Project Module) 核心 DI 設定
// =========================================================

// 2.1 實例化 Models 層 (Layer 5: 數據持久化層)
// Models 層只依賴資料庫連線池 (pool) [5-7]。
const projectModel = new ProjectModel(pool);
const attachmentModel = new ProjectAttachmentModel(pool);
const historyModel = new ProjectHistoryModel(pool);

// 2.2 實例化 Services 層 (Layer 4: 核心業務邏輯與事務層)
// Services 層依賴 Models 和 pool。

// 實例化 ProjectCrudService (負責一般 CRUD, P3/P4 權限檢查) [8]
const projectCrudService = new ProjectCrudService(
  pool,
  projectModel,
  historyModel,
  attachmentModel // ⭐ 【新增】將 attachmentModel 傳遞給 ProjectCrudService
);

// 實例化 RdlStampService (負責 RDL 蓋章 C1-C3 聚合驗證) [9]
const rdlStampService = new RdlStampService(pool, projectModel, historyModel);

// 實例化 PmTransferService (負責 PM 轉讓 T1-T6 原子交易，需 AttachmentModel 支援 T4A) [10]
const pmTransferService = new PmTransferService(
  pool,
  projectModel,
  attachmentModel,
  historyModel
);

// 實例化 AttachmentService (負責附件刪除 P1/P6 權限檢查) [11]
const attachmentService = new AttachmentService(
  pool,
  projectModel,
  attachmentModel,
  historyModel
);
// =========================================================
// 專案模組 (Project Module) 核心 DI 設定
// =========================================================

// 健康檢查端點
app.get("/health", (req, res) => {
  res.json({
    status: "OK",
    timestamp: new Date().toISOString(),
    routes: {
      auth: "/api/auth",
      users: "/api/users",
      health: "/health",
      // ⭐ 新增：讓別人知道有 Mission API
      missions: "/api/missions",
    },
  });
});

// =========================================================
// 專案模組 (Project Module) 路由註冊
// =========================================================

// 3.1 專案核心路由註冊 (Project Routes)
// 依照 project.routes.ts 契約，需要 Model 和三個核心 Service [3]。
const projectRoutes = createProjectRoutes(
  pool,
  projectModel, // 用於初始化 P1 狀態鎖定中介軟體 [3]
  projectCrudService,
  pmTransferService,
  rdlStampService
);
app.use("/api/v1/projects", projectRoutes); // 掛載到 /api/v1/projects 基礎路徑

// 3.2 附件路由註冊 (Attachment Routes)
// 依照 attachment.routes.ts 契約，需要 AttachmentService [12]。
const attachmentRoutes = createAttachmentRoutes(pool, attachmentService);
app.use("/api/v1/attachments", attachmentRoutes); // 掛載到 /api/v1/attachments 基礎路徑
// 專案模組_測試用============================================
// const projectTestRoutes = createProjectTestRoutes(pool);
// app.use("/api/v1/projects/test", projectTestRoutes);
// =========================================================
// 專案模組 (Project Module) 路由註冊
// =========================================================

// =========================================================
// 📊 Dashboard 模組 (Dashboard Module) 路由註冊
// =========================================================

// Dashboard 路由註冊
// 提供 Kanban 看板、甘特圖、搜尋篩選、進度追蹤、標籤分析等功能
const dashboardRoutes = Dashboard_createDashboardRoutes(pool);
app.use("/api/dashboard", authenticateToken, dashboardRoutes); // ✅ 一起註冊

// 404 處理
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `找不到路徑: ${req.originalUrl}`,
  });
});

export default app;
