import dotenv from "dotenv";
import app from "./app.js";
import { testConnection } from "./config/db.js";
import os from "os";  // ✅ 新增 os 模組
/* import userRoutes from "./Notification/routes/userRoutes.js"; */

import nodemailer from "nodemailer";


// 使用 userRoutes 中介軟體
/* app.use("/api/users", userRoutes); */




dotenv.config();

const PORT = process.env.PORT || 3000;

const startServer = async () => {
  try {
    // 測試資料庫連線
    await testConnection();

    // 初始化角色系統

    app.listen(PORT, () => {
      // 找出本機 IP (只取 IPv4)
      const networkInterfaces = os.networkInterfaces();
      let localIP = "127.0.0.1";

      for (const key of Object.keys(networkInterfaces)) {
        const iface = networkInterfaces[key];
        if (!iface) continue;

        for (const alias of iface) {
          if (alias.family === "IPv4" && !alias.internal) {
            localIP = alias.address;
          }
        }
      }

      console.log(`✅ MySQL connected!`);
      console.log(`✅ 角色系統初始化完成`);
      console.log(`✅ 使用者管理功能已啟用`); // 新增這行
      console.log(`🚀 Server running on:`);
      console.log(`   Local:   http://localhost:${PORT}`);
      console.log(`   Network: http://${localIP}:${PORT}`);
      console.log(`📋 Mission API: http://localhost:${PORT}/api/missions`);
      console.log(``); // 新增
      console.log(`📋 可用的 API 端點:`); // 新增
      console.log(`   認證功能: http://localhost:${PORT}/api/auth`); // 新增
      console.log(`   使用者註冊: http://localhost:${PORT}/api/users/register`); // 新增
      console.log(
        `   檢查Email: http://localhost:${PORT}/api/users/check-email`
      ); // 新增
      console.log(`   健康檢查: http://localhost:${PORT}/health`); // 新增
      console.log(`📋 可用的 API 端點:`);
      console.log(`   認證功能: http://localhost:${PORT}/api/auth`);/* 
      console.log(`     - 登入: POST /login`); */
      console.log(`     - 忘記密碼: POST /forgot-password`);
      console.log(`     - 重設密碼: POST /reset-password`);
      console.log(`     - 修改密碼: POST /change-password`);
      console.log(`   使用者註冊: http://localhost:${PORT}/api/users/register`);
    });
  } catch (error) {
    console.error("❌ 服務器啟動失敗:", error);
    process.exit(1);
  }
};

startServer();
