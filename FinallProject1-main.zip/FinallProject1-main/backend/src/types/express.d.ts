// backend/src/types/express.d.ts
import { User, Mission } from '../utils/permissions';

declare global {
  namespace Express {
    interface Request {
      user?: User;
      mission?: Mission;
    }
  }
}

export {};