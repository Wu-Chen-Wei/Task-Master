// src/mission/index.ts
import missionRoutes from './routes/mission.routes.js';
export default missionRoutes;
