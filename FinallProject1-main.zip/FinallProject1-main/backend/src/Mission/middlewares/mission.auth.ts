import { Request, Response, NextFunction } from 'express';
import mysql from 'mysql2/promise';

// 檢查使用者角色的中介層
export const checkRole = (pool: mysql.Pool, allowedRoles: string[]) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.user) {
        res.status(401).json({ success: false, message: '請先登入' });
        return;
      }

      const [rows] = await pool.execute(
        `SELECT r.RoleName 
         FROM userglobalroles ugr
         JOIN roles r ON ugr.RoleID = r.RoleID
         WHERE ugr.UserID = ?`,
        [req.user.userID]
      );

      const userRoles = (rows as any[]).map(row => row.RoleName);
      const hasPermission = allowedRoles.some(role => userRoles.includes(role));

      if (!hasPermission) {
        res.status(403).json({ 
          success: false, 
          message: `需要以下角色之一: ${allowedRoles.join(', ')}` 
        });
        return;
      }

      next();
    } catch (error) {
      console.error('角色檢查錯誤:', error);
      res.status(500).json({ success: false, message: '伺服器錯誤' });
    }
  };
};

// 檢查是否為專案成員
export const checkProjectMember = (pool: mysql.Pool) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.user) {
        res.status(401).json({ success: false, message: '請先登入' });
        return;
      }

      const missionId = req.params.id || req.params.missionId;
      if (!missionId) {
        res.status(400).json({ success: false, message: '缺少任務ID' });
        return;
      }

      // 檢查使用者是否為 Admin
      const [adminRows] = await pool.execute(
        `SELECT r.RoleName 
         FROM userglobalroles ugr
         JOIN roles r ON ugr.RoleID = r.RoleID
         WHERE ugr.UserID = ? AND r.RoleName = 'Admin'`,
        [req.user.userID]
      );

      // 如果是 Admin，直接通過
      if ((adminRows as any[]).length > 0) {
        next();
        return;
      }

      // 查詢任務所屬專案，並檢查使用者是否為專案成員
      const [rows] = await pool.execute(
        `SELECT pm.UserID 
         FROM missions m
         JOIN projectmembers pm ON m.ProjectID = pm.ProjectID
         WHERE m.MissionID = ? AND pm.UserID = ?`,
        [missionId, req.user.userID]
      );

      if ((rows as any[]).length === 0) {
        res.status(403).json({ 
          success: false, 
          message: '您不是此任務所屬專案的成員' 
        });
        return;
      }

      next();
    } catch (error) {
      console.error('專案成員檢查錯誤:', error);
      res.status(500).json({ success: false, message: '伺服器錯誤' });
    }
  };
};