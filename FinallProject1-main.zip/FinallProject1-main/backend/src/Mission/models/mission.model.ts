// 📂 src/Mission/models/mission.model.ts

import { pool } from "../../config/db.js";
import { MissionInput } from "../types/mission.types.js";
import { RowDataPacket } from "mysql2"; // ✅ 引入型別

export const missionModel = {
  // ---------------------------------------
  // 1. 取得任務列表（搜尋 + 狀態 + 使用者過濾）
  // ---------------------------------------
  async getAll(search?: string, status?: string, userId?: number, userRoles?: string[]) {
    let sql = `
    SELECT
      MissionID AS id,
      ProjectID AS projectId,
      Title AS title,
      Description AS description,
      Status AS status,
      Priority AS priority,
      StartDate AS startDate,
      DueDate AS dueDate,
      AssigneeID AS assigneeId,
      ReporterID AS reporterId,
      CreatedAt AS createdAt,
      UpdatedAt AS updatedAt
    FROM missions
    WHERE 1=1
  `;

    const params: any[] = [];

    // 權限過濾：非 Admin 的使用者需要過濾
    if (userId && !userRoles?.includes('Admin')) {
      if (userRoles?.includes('QA')) {
        // QA 只能看到指派給自己的任務
        sql += ` AND AssigneeID = ?`;
        params.push(userId);
      } else if (userRoles?.includes('RDL') || userRoles?.includes('RD') || userRoles?.includes('PM')) {
        // RDL/RD/PM 只能看到自己參與的專案中的任務
        sql += ` AND ProjectID IN (
          SELECT ProjectID FROM projectmembers WHERE UserID = ?
        )`;
        params.push(userId);
      }
    }

    if (search) {
      sql += ` AND (Title LIKE ? OR Description LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`);
    }

    if (status && status !== "全部狀態") {
      sql += ` AND Status = ?`;
      params.push(status);
    }

    sql += ` ORDER BY MissionID DESC`;

    const [rows] = await pool.query<RowDataPacket[]>(sql, params);
    return rows;
  },

  // ---------------------------------------
  // 2. 取得單一 Mission
  // ---------------------------------------
  async getById(id: number) {
    // ✅ 加上型別標註
    const [rows] = await pool.query<RowDataPacket[]>(
      `
      SELECT
        MissionID AS id,
        ProjectID AS projectId,
        Title AS title,
        Description AS description,
        Status AS status,
        Priority AS priority,
        StartDate AS startDate,
        DueDate AS dueDate,
        AssigneeID AS assigneeId,
        ReporterID AS reporterId,
        QASignedByUserID AS qaSignedByUserId,
        QASignedAt AS qaSignedAt,
        CreatedAt AS createdAt,
        UpdatedAt AS updatedAt
      FROM missions
      WHERE MissionID = ?
      `,
      [id]
    );

    return rows[0] || null;
  },

  // ---------------------------------------
  // 3. 建立 Mission
  // ---------------------------------------
  async create(input: MissionInput) {
    const sql = `
      INSERT INTO missions (
        ProjectID,
        Title,
        Description,
        Status,
        Priority,
        StartDate,
        DueDate,
        AssigneeID,
        ReporterID
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const params = [
      input.projectId,
      input.title,
      input.description,
      input.status,
      input.priority,
      input.startDate,
      input.dueDate,
      input.assigneeId,
      input.reporterId,
    ];

    const [result]: any = await pool.query(sql, params);

    return {
      id: result.insertId,
      ...input,
    };
  },

  // ---------------------------------------
  // 4. 更新 Mission
  // ---------------------------------------
  async update(id: number, input: MissionInput, userId?: number) {
    const sql = `
      UPDATE missions
      SET
        Title = ?,
        Description = ?,
        Status = ?,
        Priority = ?,
        StartDate = ?,
        DueDate = ?,
        AssigneeID = ?
      WHERE MissionID = ?
    `;

    const params = [
      input.title,
      input.description,
      input.status,
      input.priority,
      input.startDate,
      input.dueDate,
      input.assigneeId,
      id,
    ];

    const [result]: any = await pool.query(sql, params);
    
    // 記錄歷史
    if (result.affectedRows > 0 && userId) {
      await this.addHistory(id, userId, 'Status', '', input.status);
    }
    
    return result.affectedRows > 0;
  },

  // ---------------------------------------
  // 5. 刪除 Mission
  // ---------------------------------------
  async delete(id: number) {
    const [result]: any = await pool.query(
      `DELETE FROM missions WHERE MissionID = ?`,
      [id]
    );
    return result.affectedRows > 0;
  },

  // ---------------------------------------
  // 6. 取得附件
  // ---------------------------------------
  async getAttachments(missionId: number) {
    // ✅ 加上型別標註
    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT 
        AttachmentID as id,
        MissionID as missionId,
        FileName as filename,
        FilePath as filepath,
        UploadedAt as uploadedAt
      FROM missionattachments 
      WHERE MissionID = ? AND DeletedAt IS NULL
      ORDER BY UploadedAt DESC`,
      [missionId]
    );
    return rows;
  },

  // ---------------------------------------
  // 7. 刪除附件
  // ---------------------------------------
  async deleteAttachment(fileId: number) {
    const [result]: any = await pool.query(
      `UPDATE missionattachments SET DeletedAt = NOW() WHERE AttachmentID = ?`,
      [fileId]
    );
    return result.affectedRows > 0;
  },

  // ---------------------------------------
  // 8. 取得附件資訊（✅ 重要：需要回傳 missionId）
  // ---------------------------------------
  async getAttachmentInfo(fileId: number) {
    // ✅ 加上型別標註
    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT 
        AttachmentID as id,
        MissionID as missionId,
        FileName as filename,
        FilePath as filepath,
        FileName as originalname
      FROM missionattachments 
      WHERE AttachmentID = ? AND DeletedAt IS NULL`,
      [fileId]
    );
    return rows[0] || null;
  },

  // ---------------------------------------
  // 9. 取得成員
  // ---------------------------------------
  async getMembers(missionId: number) {
    // ✅ 加上型別標註
    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT 
        u.UserID as userId,
        u.Name as name,
        u.Email as email,
        pm.Role as role
      FROM projectmembers pm
      JOIN users u ON pm.UserID = u.UserID
      JOIN missions m ON pm.ProjectID = m.ProjectID
      WHERE m.MissionID = ? AND pm.DeletedAt IS NULL`,
      [missionId]
    );
    return rows;
  },

  // ---------------------------------------
  // 10. 歷史紀錄
  // ---------------------------------------
  async getHistory(missionId: number) {
    // ✅ 加上型別標註
    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT 
        HistoryID as id,
        MissionID as missionId,
        UserID as userId,
        FieldChanged as fieldChanged,
        OldValue as oldValue,
        NewValue as newValue,
        ChangedAt as changedAt
      FROM missionhistory 
      WHERE MissionID = ? 
      ORDER BY ChangedAt DESC`,
      [missionId]
    );
    return rows;
  },

  // ---------------------------------------
  // 11. QA 簽核
  // ---------------------------------------
  async signMission(missionId: number, qaUserId: number) {
    console.log('🔍 signMission model 被呼叫:', { missionId, qaUserId });
    
    const sql = `
      UPDATE missions 
      SET 
        Status = 'Closed',
        QASignedByUserID = ?,
        QASignedAt = NOW()
      WHERE MissionID = ?
    `;
    
    console.log('🔍 執行 SQL:', sql);
    console.log('🔍 參數:', [qaUserId, missionId]);
    
    const [result]: any = await pool.query(sql, [qaUserId, missionId]);
    
    console.log('🔍 SQL 結果:', result);
    
    if (result.affectedRows > 0) {
      console.log('✅ 更新成功，新增歷史紀錄');
      await this.addHistory(missionId, qaUserId, 'Status', 'Testing', 'Closed');
    } else {
      console.log('❌ 沒有更新任何資料');
    }
    
    return result.affectedRows > 0;
  },

  // ---------------------------------------
  // 12. 指派給 QA
  // ---------------------------------------
  async assignToQA(missionId: number, qaUserId: number) {
    const sql = `
      UPDATE missions 
      SET 
        Status = 'Testing',
        AssigneeID = ?
      WHERE MissionID = ?
    `;
    
    const [result]: any = await pool.query(sql, [qaUserId, missionId]);
    
    if (result.affectedRows > 0) {
      await this.addHistory(missionId, qaUserId, 'AssigneeID', '', qaUserId.toString());
      await this.addHistory(missionId, qaUserId, 'Status', 'In Progress', 'Testing');
    }
    
    return result.affectedRows > 0;
  },

  // ---------------------------------------
  // 13. 新增歷史紀錄
  // ---------------------------------------
  async addHistory(missionId: number, userId: number, field: string, oldValue: string, newValue: string) {
    const sql = `
      INSERT INTO missionhistory (MissionID, UserID, FieldChanged, OldValue, NewValue)
      VALUES (?, ?, ?, ?, ?)
    `;
    
    await pool.query(sql, [missionId, userId, field, oldValue, newValue]);
  },
};