// 📂 檔案：backend/src/mission/controllers/mission.controller.ts

import { Request, Response } from "express";
import path from "path";
import { MissionService } from "../services/mission.crud.service";

// ------------------------
// 1. 取得任務列表（含搜尋、狀態）
// ------------------------
export const getMissions = async (req: Request, res: Response) => {
  try {
    const search = req.query.search as string;
    const status = req.query.status as string;
    
    // 取得使用者資訊
    const userId = (req as any).user?.userID;
    const userRoles = (req as any).user?.roles || [];

    const missions = await MissionService.getMissions(search, status, userId, userRoles);
    res.json({ success: true, data: missions });
  } catch (err) {
    console.error("❌ getMissions error:", err);
    res.status(500).json({ success: false });
  }
};

// ------------------------
// 2. 依 ID 取得單一任務
// ------------------------
export const getMissionById = async (req: Request, res: Response) => {
  try {
    const mission = await MissionService.getMissionById(req.params.id);

    if (!mission) {
      return res.status(404).json({ success: false, message: "Not found" });
    }

    res.json({ success: true, data: mission });
  } catch (err) {
    console.error("❌ getMissionById error:", err);
    res.status(500).json({ success: false });
  }
};

// ------------------------
// 3. 建立任務（⭐ 已整合 JWT + mapping）
// ------------------------
export const createMission = async (req: Request, res: Response) => {
  try {
    console.log("📌 createMission 收到資料：", req.body);

    // ⭐ 從 JWT 取得 ReporterID
    const reporterId = (req as any).user?.userID;
    if (!reporterId) {
      return res
        .status(401)
        .json({ success: false, message: "缺少 ReporterID" });
    }

    const input = {
      projectId: req.body.projectId,
      title: req.body.title,
      description: req.body.desc,
      status: req.body.status,
      priority: req.body.priority,
      startDate: req.body.start_date,
      dueDate: req.body.end_date,
      assigneeId: req.body.assigneeId,
      reporterId, // ⭐ 新增
    };

    const mission = await MissionService.createMission(input);

    res.json({ success: true, data: mission });
  } catch (err) {
    console.error("❌ createMission error:", err);
    res.status(500).json({ success: false });
  }
};
// ------------------------
// 4. 更新任務
// ------------------------
export const updateMission = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user?.userID;
    const ok = await MissionService.updateMission(req.params.id, req.body, userId);
    res.json({ success: ok });
  } catch (err) {
    console.error("❌ updateMission error:", err);
    res.status(500).json({ success: false });
  }
};

// ------------------------
// 5. 刪除任務
// ------------------------
export const deleteMission = async (req: Request, res: Response) => {
  try {
    const ok = await MissionService.deleteMission(req.params.id);
    res.json({ success: ok });
  } catch (err) {
    console.error("❌ deleteMission error:", err);
    res.status(500).json({ success: false });
  }
};

// ------------------------
// 6. 附件列表
// ------------------------
export const getAttachments = async (req: Request, res: Response) => {
  try {
    const files = await MissionService.getAttachments(req.params.missionId);
    res.json({ success: true, data: files });
  } catch (err) {
    console.error("❌ getAttachments error:", err);
    res.status(500).json({ success: false });
  }
};

// ------------------------
// 7. 刪除附件
// ------------------------
export const deleteAttachment = async (req: Request, res: Response) => {
  try {
    const ok = await MissionService.deleteAttachment(req.params.id);
    res.json({ success: ok });
  } catch (err) {
    console.error("❌ deleteAttachment error:", err);
    res.status(500).json({ success: false });
  }
};

// ------------------------
// 8. 附件下載（download）
// ------------------------
export const downloadAttachment = async (req: Request, res: Response) => {
  try {
    const fileId = req.params.id;
    const file = await MissionService.getAttachmentInfo(fileId);

    if (!file) {
      return res.status(404).json({
        success: false,
        message: "File not found",
      });
    }

    const filePath = path.join(__dirname, "../../../uploads", file.filename);
    res.download(filePath, file.originalname);
  } catch (err) {
    console.error("❌ downloadAttachment error:", err);
    res.status(500).json({
      success: false,
      message: "Download failed",
    });
  }
};

// ------------------------
// 9. 任務成員列表
// ------------------------
export const getMembers = async (req: Request, res: Response) => {
  try {
    const data = await MissionService.getMembers(req.params.missionId);
    res.json({ success: true, data });
  } catch (err) {
    console.error("❌ getMembers error:", err);
    res.status(500).json({ success: false });
  }
};

// ------------------------
// 10. 歷史紀錄
// ------------------------
export const getHistory = async (req: Request, res: Response) => {
  try {
    const data = await MissionService.getHistory(req.params.missionId);
    res.json({ success: true, data });
  } catch (err) {
    console.error("❌ getHistory error:", err);
    res.status(500).json({ success: false });
  }
};

// ------------------------
// 11. QA 簽核任務
// ------------------------
export const signMission = async (req: Request, res: Response) => {
  try {
    const missionId = req.params.id;
    const userId = (req as any).user?.userID;
    
    console.log('🔍 signMission 被呼叫:', { missionId, userId });
    
    if (!userId) {
      console.log('❌ 缺少使用者ID');
      return res.status(401).json({ success: false, message: "缺少使用者ID" });
    }

    const result = await MissionService.signMission(missionId, userId);
    console.log('✅ signMission 結果:', result);
    res.json({ success: true, data: result });
  } catch (err) {
    console.error("❌ signMission error:", err);
    res.status(500).json({ success: false, message: err.message });
  }
};

// ------------------------
// 12. 指派任務給 QA
// ------------------------
export const assignToQA = async (req: Request, res: Response) => {
  try {
    const missionId = req.params.id;
    const { qaUserId } = req.body;
    
    const result = await MissionService.assignToQA(missionId, qaUserId);
    res.json({ success: true, data: result });
  } catch (err) {
    console.error("❌ assignToQA error:", err);
    res.status(500).json({ success: false, message: err.message });
  }
};


