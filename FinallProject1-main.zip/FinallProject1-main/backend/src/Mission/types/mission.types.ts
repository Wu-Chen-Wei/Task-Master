// src/Mission/types/mission.types.ts

export interface Mission {
  id: number; // 主鍵，自動增加
  projectId: number; // 隸屬專案 ID（必填）
  title: string;
  description: string;
  status: string;
  priority: string;
  startDate: string; // ISO 日期字串
  dueDate: string; // ISO 日期字串
  assigneeId: number | null; // 指派人 (UserID)，可為 null
}

/**
 * ✔ 用於「建立任務」時的輸入資料
 * - 和 Mission 類似，但不需要 id
 * - 必須含 projectId 與 assigneeId
 */
export interface MissionInput {
  projectId: number;
  title: string;
  description: string;
  status: string;
  priority: string;
  startDate: string;
  dueDate: string;
  assigneeId: number | null;
  reporterId: number;  // ⭐ 必填，由 JWT 自動帶入
}

// ---- 其他附表 ----

export interface MissionAttachment {
  id: string;
  name: string;
  uploader: string;
  uploaded_at: string;
  mission_id: string;
}

export interface MissionMember {
  id: string;
  name: string;
  role: string;
  join_date: string;
  mission_id: string;
}

export interface MissionHistory {
  id: string;
  status: string;
  action: string;
  user: string;
  date: string;
  mission_id: string;
}
