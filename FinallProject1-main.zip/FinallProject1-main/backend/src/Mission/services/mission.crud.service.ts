import { missionModel } from "../models/mission.model.js";
import { MissionInput } from "../types/mission.types.js";

/**
 * MissionService
 * 負責所有 Mission 的商業邏輯
 */
export const MissionService = {
  // -------------------------------
  // CRUD
  // -------------------------------

  /** 取得任務列表（搜尋 + 狀態 + 使用者過濾） */
  getMissions(search?: string, status?: string, userId?: number, userRoles?: string[]) {
    return missionModel.getAll(search, status, userId, userRoles);
  },

  /** 依 ID 取得任務 */
  getMissionById(id: string) {
    return missionModel.getById(Number(id));
  },

  /** 建立任務 */
  createMission(input: MissionInput) {
    return missionModel.create(input);
  },

  /** 更新任務 */
  updateMission(id: string, input: MissionInput, userId?: number) {
    return missionModel.update(Number(id), input, userId);
  },

  /** 刪除任務 */
  deleteMission(id: string) {
    return missionModel.delete(Number(id));
  },

  // -------------------------------
  // 附件
  // -------------------------------

  /** 取得某任務的所有附件 */
  getAttachments(missionId: string) {
    return missionModel.getAttachments(Number(missionId));
  },

  /** 刪除單一附件 */
  deleteAttachment(fileId: string) {
    return missionModel.deleteAttachment(Number(fileId));
  },

  /** 查詢單一附件資訊（下載時用） */
  getAttachmentInfo(fileId: string) {
    return missionModel.getAttachmentInfo(Number(fileId));
  },

  // -------------------------------
  // 成員
  // -------------------------------

  /** 取得某任務的所有成員 */
  getMembers(missionId: string) {
    return missionModel.getMembers(Number(missionId));
  },

  // -------------------------------
  // 歷史紀錄
  // -------------------------------

  /** 取得某任務的歷史紀錄 */
  getHistory(missionId: string) {
    return missionModel.getHistory(Number(missionId));
  },

  /** QA 簽核任務 */
  async signMission(missionId: string, qaUserId: number) {
    const mission = await missionModel.getById(Number(missionId));
    if (!mission) {
      throw new Error('任務不存在');
    }
    
    // 允許 QA 在多種狀態下簽核
    const allowedStatuses = ['Testing', 'Reopened', 'In Progress'];
    if (!allowedStatuses.includes(mission.status)) {
      throw new Error(`任務狀態為 ${mission.status}，無法簽核`);
    }
    
    return missionModel.signMission(Number(missionId), qaUserId);
  },

  /** 指派任務給 QA */
  async assignToQA(missionId: string, qaUserId: number) {
    const mission = await missionModel.getById(Number(missionId));
    if (!mission) {
      throw new Error('任務不存在');
    }
    
    return missionModel.assignToQA(Number(missionId), qaUserId);
  },
};
