// src/Mission/routes/mission.routes.ts

import express from "express";
import {
  getMissions,
  getMissionById,
  createMission,
  updateMission,
  deleteMission,
  getAttachments,
  deleteAttachment,
  getMembers,
  getHistory,
  downloadAttachment,
  signMission,
  assignToQA,
} from "../controllers/mission.controller.js";
import { authenticate } from "../../member/middlewares/auth.middleware.js";
import { checkRole, checkProjectMember } from "../middlewares/mission.auth.js";
import mysql from "mysql2/promise";

// 需要從外部傳入 pool
export const createMissionRoutes = (pool: mysql.Pool) => {
const router = express.Router();

// 取得任務列表（需要登入）
router.get("/", authenticate, getMissions);

// 取得單一任務（需要是專案成員）
router.get("/:id", authenticate, checkProjectMember(pool), getMissionById);

// 建立任務（RDL 權限）
router.post("/", authenticate, checkRole(pool, ['RDL']), createMission);

// 更新任務（專案成員）
router.put("/:id", authenticate, checkProjectMember(pool), updateMission);

// 刪除任務（RDL 權限）
router.delete("/:id", authenticate, checkRole(pool, ['RDL']), deleteMission);

// QA 簽核（只有 QA 可以簽核）
router.post("/:id/sign", authenticate, checkRole(pool, ['QA']), signMission);

// 指派給 QA（RD 完成後指派）
router.post("/:id/assign-qa", authenticate, checkRole(pool, ['RD', 'RDL']), assignToQA);

// 附件相關
router.get("/:missionId/attachments", authenticate, checkProjectMember(pool), getAttachments);
router.get("/attachments/:id/download", authenticate, downloadAttachment);
router.delete("/attachments/:id", authenticate, deleteAttachment);

// 成員和歷史
router.get("/:missionId/members", authenticate, checkProjectMember(pool), getMembers);
router.get("/:missionId/history", authenticate, checkProjectMember(pool), getHistory);

return router;
};

export default createMissionRoutes;