// 程式檔案: backend/src/Dashboard/services/dashboard.service.ts
// 層次與職責: 業務邏輯層 (Services Layer)
// 核心職責: 實作 Dashboard 四大核心功能

import { Pool } from "mysql2/promise";
import { toDBId, toCoreId, CoreID } from "../types/core.types";
import {
  KanbanBoardData,
  KanbanColumn,
  KanbanCard,
  ProjectProgressStats,
  TagAnalysisResult,
  DateRangeQuery,
} from "../types/dashboard.types";
import { BusinessError, DASHBOARD_ERROR_CODES } from "../types/error.types";
import {
  MISSION_STATUS,
  DEFAULT_KANBAN_COLUMNS,
} from "../types/system.constants";

/**
 * DashboardService
 * 負責實作 Dashboard 模組的四大核心功能：
 * 1. Kanban 看板展示
 * 2. 甘特圖視覺化
 * 3. Mission 搜尋與篩選
 * 4. 進度追蹤圖表
 * 5. 熱門標籤與類型分析
 */
export class DashboardService {
  private db: Pool;

  constructor(db: Pool) {
    this.db = db;
  }

  // ================================================================
  // 功能 1: Kanban 看板展示
  // ================================================================

  /**
   * 取得專案的 Kanban 看板完整資料
   * @param projectId 專案 ID (CoreID 格式)
   * @param userId 使用者 ID (CoreID 格式)
   * @returns Kanban 看板資料，包含欄位和任務卡片
   */
  async getKanbanBoard(
    projectId: CoreID,
    userId: CoreID
  ): Promise<KanbanBoardData> {
    const dbProjectId = toDBId(projectId, "ProjectID");
    const dbUserId = toDBId(userId, "UserID");

    // 1. 取得專案資訊
    const [projectRows] = await this.db.query(
      `SELECT ProjectName FROM Projects WHERE ProjectID = ? AND DeletedAt IS NULL`,
      [dbProjectId]
    );

    if ((projectRows as any[]).length === 0) {
      throw new BusinessError(
        `專案不存在: ${projectId}`,
        DASHBOARD_ERROR_CODES.NOT_FOUND.PROJECT_NOT_FOUND.code,
        DASHBOARD_ERROR_CODES.NOT_FOUND.PROJECT_NOT_FOUND.name
      );
    }

    const projectName = (projectRows as any[])[0].ProjectName;

    // 2. 取得使用者的欄位排序偏好
    const [settingsRows] = await this.db.query(
      `SELECT ColumnOrder FROM KanbanSettings 
       WHERE UserID = ? AND ProjectID = ? AND DeletedAt IS NULL`,
      [dbUserId, dbProjectId]
    );

    let columnOrder: string[];
    if ((settingsRows as any[]).length > 0) {
      const columnOrderJson = (settingsRows as any[])[0].ColumnOrder;
      const parsed =
        typeof columnOrderJson === "string"
          ? JSON.parse(columnOrderJson)
          : columnOrderJson;

      // 處理格式
      if (Array.isArray(parsed)) {
        columnOrder = parsed;
      } else if (parsed.order) {
        // 如果 order 是陣列包陣列，取第一層
        columnOrder = Array.isArray(parsed.order[0])
          ? parsed.order[0]
          : parsed.order;
      } else {
        columnOrder = DEFAULT_KANBAN_COLUMNS;
      }
    } else {
      columnOrder = DEFAULT_KANBAN_COLUMNS;
    }

    // 3. 取得所有任務並按狀態分組（修復：FullName + DISTINCT TagName）
    const [missionRows] = await this.db.query(
      `SELECT 
        m.MissionID,
        m.Title,
        m.Description,
        m.Status,
        m.Priority,
        m.AssigneeID,
        u.FullName AS AssigneeName,
        m.CreatedAt,
        m.UpdatedAt,
        GROUP_CONCAT(DISTINCT t.TagName) AS Tags
      FROM Missions m
      LEFT JOIN Users u ON m.AssigneeID = u.UserID
      LEFT JOIN MissionTags mt ON m.MissionID = mt.MissionID
      LEFT JOIN Tags t ON mt.TagID = t.TagID
      WHERE m.ProjectID = ? AND m.DeletedAt IS NULL
      GROUP BY m.MissionID
      ORDER BY m.CreatedAt DESC`,
      [dbProjectId]
    );

    // 4. 將任務轉換為卡片格式並按欄位分組
    const missions = missionRows as any[];
    const columnMap = new Map<string, KanbanCard[]>();

    // 確保 columnOrder 是陣列
    if (!Array.isArray(columnOrder)) {
      console.error(
        "❌ columnOrder 不是陣列，型別:",
        typeof columnOrder,
        "值:",
        columnOrder
      );
      columnOrder = DEFAULT_KANBAN_COLUMNS;
    } else {
      console.log("✅ columnOrder 是陣列:", columnOrder);
    }
    // 初始化所有欄位
    columnOrder.forEach((status) => {
      columnMap.set(status, []);
    });

    // 分配任務到對應欄位
    missions.forEach((mission) => {
      const card: KanbanCard = {
        missionID: toCoreId(mission.MissionID, "MissionID"),
        title: mission.Title,
        description: mission.Description || undefined,
        priority: mission.Priority,
        assigneeID: mission.AssigneeID
          ? toCoreId(mission.AssigneeID, "AssigneeID")
          : undefined,
        assigneeName: mission.AssigneeName || undefined,
        tags: mission.Tags ? mission.Tags.split(",") : [],
        createdAt: mission.CreatedAt,
        updatedAt: mission.UpdatedAt || undefined,
      };

      const statusCards = columnMap.get(mission.Status);
      if (statusCards) {
        statusCards.push(card);
      } else {
        // 如果任務狀態不在欄位順序中，加到最後
        if (!columnMap.has(mission.Status)) {
          columnMap.set(mission.Status, []);
        }
        columnMap.get(mission.Status)!.push(card);
      }
    });

    // 5. 建立欄位陣列
    const columns: KanbanColumn[] = [];
    columnMap.forEach((cards, status) => {
      columns.push({
        status: status,
        displayName: this.getStatusDisplayName(status),
        cards: cards,
        count: cards.length,
      });
    });

    return {
      projectID: projectId,
      projectName: projectName,
      columns: columns,
    };
  }

  /**
   * 更新任務狀態（拖曳任務時呼叫）
   * @param missionId 任務 ID
   * @param newStatus 新的狀態
   * @param userId 操作的使用者 ID
   */
  async updateMissionStatus(
    missionId: CoreID,
    newStatus: string,
    userId: CoreID
  ): Promise<void> {
    const dbMissionId = toDBId(missionId, "MissionID");
    const dbUserId = toDBId(userId, "UserID");

    // 驗證狀態是否有效
    const validStatuses = Object.values(MISSION_STATUS) as string[];
    if (!validStatuses.includes(newStatus)) {
      throw new BusinessError(
        `無效的任務狀態: ${newStatus}`,
        DASHBOARD_ERROR_CODES.BAD_REQUEST.INVALID_MISSION_STATUS.code,
        DASHBOARD_ERROR_CODES.BAD_REQUEST.INVALID_MISSION_STATUS.name
      );
    }

    // 先查 OldValue（優化邏輯）
    const [oldRows] = await this.db.query(
      `SELECT Status FROM Missions WHERE MissionID = ? AND DeletedAt IS NULL`,
      [dbMissionId]
    );
    if ((oldRows as any[]).length === 0) {
      throw new BusinessError(
        `任務不存在或已被刪除: ${missionId}`,
        DASHBOARD_ERROR_CODES.NOT_FOUND.MISSION_NOT_FOUND.code,
        DASHBOARD_ERROR_CODES.NOT_FOUND.MISSION_NOT_FOUND.name
      );
    }
    const oldStatus = (oldRows as any[])[0].Status;

    // 更新任務狀態
    const [result] = await this.db.query(
      `UPDATE Missions 
       SET Status = ?, UpdatedAt = NOW() 
       WHERE MissionID = ? AND DeletedAt IS NULL`,
      [newStatus, dbMissionId]
    );

    if ((result as any).affectedRows === 0) {
      throw new BusinessError(
        `任務不存在或已被刪除: ${missionId}`,
        DASHBOARD_ERROR_CODES.NOT_FOUND.MISSION_NOT_FOUND.code,
        DASHBOARD_ERROR_CODES.NOT_FOUND.MISSION_NOT_FOUND.name
      );
    }

    // 記錄歷史（修復：FieldChanged；用查到的 oldStatus）
    await this.db.query(
      `INSERT INTO MissionHistory (MissionID, UserID, FieldChanged, OldValue, NewValue, ChangedAt)
       VALUES (?, ?, 'Status', ?, ?, NOW())`,
      [dbMissionId, dbUserId, oldStatus, newStatus]
    );
  }

  // ================================================================
  // 功能 2: 甘特圖視覺化
  // ================================================================

  /**
   * 取得專案甘特圖資料
   * @param projectId 專案 ID
   * @returns 甘特圖任務陣列
   */
  async getGanttChartData(projectId: CoreID) {
    const dbProjectId = toDBId(projectId, "ProjectID");

    const [rows] = await this.db.query(
      `SELECT 
        m.MissionID, 
        m.Title, 
        IFNULL(m.StartDate, CURDATE()) AS StartDate,
        IFNULL(m.DueDate, DATE_ADD(CURDATE(), INTERVAL 7 DAY)) AS DueDate,
        m.Status,
        m.Priority,
        m.AssigneeID,
        u.FullName AS AssigneeName,
        p.ProjectName,
        p.StartDate AS ProjectStartDate, 
        p.EndDate AS ProjectEndDate
      FROM Missions m
      JOIN Projects p ON p.ProjectID = m.ProjectID
      LEFT JOIN Users u ON m.AssigneeID = u.UserID
      WHERE m.ProjectID = ? AND m.DeletedAt IS NULL
      ORDER BY m.StartDate ASC, m.Priority DESC`,
      [dbProjectId]
    );

    const missions = rows as any[];

    return {
      projectID: projectId,
      projectName: missions[0]?.ProjectName || "",
      projectStartDate: missions[0]?.ProjectStartDate || null,
      projectEndDate: missions[0]?.ProjectEndDate || null,
      tasks: missions.map((m) => ({
        missionID: toCoreId(m.MissionID, "MissionID"),
        title: m.Title,
        startDate: m.StartDate,
        dueDate: m.DueDate,
        status: m.Status,
        priority: m.Priority,
        assigneeID: m.AssigneeID
          ? toCoreId(m.AssigneeID, "AssigneeID")
          : undefined,
        assigneeName: m.AssigneeName || undefined,
      })),
    };
  }

  // ================================================================
  // 功能 3: Mission 搜尋與篩選
  // ================================================================

  /**
   * 搜尋與篩選任務
   * @param filters 篩選條件
   * @returns 符合條件的任務列表
   */
  async searchMissions(filters: {
    projectId?: CoreID;
    assigneeId?: CoreID;
    status?: string;
    priority?: string;
    tags?: string[];
    keyword?: string;
    startDate?: string;
    endDate?: string;
  }) {
    let sql = `
      SELECT DISTINCT
        m.MissionID,
        m.ProjectID,
        m.Title,
        m.Description,
        m.Status,
        m.Priority,
        m.AssigneeID,
        u.FullName AS AssigneeName,
        m.StartDate,
        m.DueDate,
        m.CreatedAt,
        m.UpdatedAt,
        p.ProjectName,
        GROUP_CONCAT(DISTINCT t.TagName) AS Tags
      FROM Missions m
      LEFT JOIN Users u ON m.AssigneeID = u.UserID
      LEFT JOIN Projects p ON m.ProjectID = p.ProjectID
      LEFT JOIN MissionTags mt ON m.MissionID = mt.MissionID
      LEFT JOIN Tags t ON mt.TagID = t.TagID
      WHERE m.DeletedAt IS NULL
    `;

    const params: any[] = [];

    // 專案篩選
    if (filters.projectId) {
      sql += ` AND m.ProjectID = ?`;
      params.push(toDBId(filters.projectId, "ProjectID"));
    }

    // 指派人篩選
    if (filters.assigneeId) {
      sql += ` AND m.AssigneeID = ?`;
      params.push(toDBId(filters.assigneeId, "AssigneeID"));
    }

    // 狀態篩選
    if (filters.status) {
      sql += ` AND m.Status = ?`;
      params.push(filters.status);
    }

    // 優先度篩選
    if (filters.priority) {
      sql += ` AND m.Priority = ?`;
      params.push(filters.priority);
    }

    // 關鍵字搜尋（標題或描述）
    if (filters.keyword) {
      sql += ` AND (m.Title LIKE ? OR m.Description LIKE ?)`;
      const keyword = `%${filters.keyword}%`;
      params.push(keyword, keyword);
    }

    // 日期範圍篩選（假設用 CreatedAt；若 DueDate，改 m.DueDate）
    if (filters.startDate) {
      sql += ` AND m.CreatedAt >= ?`;
      params.push(filters.startDate);
    }

    if (filters.endDate) {
      sql += ` AND m.CreatedAt <= ?`;
      params.push(filters.endDate);
    }

    sql += ` GROUP BY m.MissionID ORDER BY m.CreatedAt DESC`;

    const [rows] = await this.db.query(sql, params);
    const missions = rows as any[];

    // 如果有標籤篩選，需要額外過濾（可優化為 SQL，但暫留 JS）
    let filteredMissions = missions;
    if (filters.tags && filters.tags.length > 0) {
      filteredMissions = missions.filter((mission) => {
        if (!mission.Tags) return false;
        const missionTags = mission.Tags.split(",");
        return filters.tags!.some((tag) => missionTags.includes(tag));
      });
    }

    return {
      total: filteredMissions.length,
      missions: filteredMissions.map((m) => ({
        missionID: toCoreId(m.MissionID, "MissionID"),
        projectID: toCoreId(m.ProjectID, "ProjectID"),
        projectName: m.ProjectName,
        title: m.Title,
        description: m.Description || undefined,
        status: m.Status,
        priority: m.Priority,
        assigneeID: m.AssigneeID
          ? toCoreId(m.AssigneeID, "AssigneeID")
          : undefined,
        assigneeName: m.AssigneeName || undefined,
        startDate: m.StartDate || undefined,
        dueDate: m.DueDate || undefined,
        tags: m.Tags ? m.Tags.split(",") : [],
        createdAt: m.CreatedAt,
        updatedAt: m.UpdatedAt || undefined,
      })),
    };
  }

  // ================================================================
  // 功能 4: 進度追蹤圖表
  // ================================================================

  /**
   * 取得專案進度統計（從 MetricsDaily 匯總表查詢）
   * @param projectId 專案 ID
   * @param dateRange 日期範圍（可選）
   * @returns 專案進度統計資料
   */
  async getProjectProgress(
    projectId: CoreID,
    dateRange?: DateRangeQuery
  ): Promise<ProjectProgressStats> {
    const dbProjectId = toDBId(projectId, "ProjectID");

    // 取得專案名稱
    const [projectRows] = await this.db.query(
      `SELECT ProjectName FROM Projects WHERE ProjectID = ? AND DeletedAt IS NULL`,
      [dbProjectId]
    );

    if ((projectRows as any[]).length === 0) {
      throw new BusinessError(
        `專案不存在: ${projectId}`,
        DASHBOARD_ERROR_CODES.NOT_FOUND.PROJECT_NOT_FOUND.code,
        DASHBOARD_ERROR_CODES.NOT_FOUND.PROJECT_NOT_FOUND.name
      );
    }

    const projectName = (projectRows as any[])[0].ProjectName;

    // 從 MetricsDaily 取得最新的統計資料
    let sql = `
      SELECT 
        OpenMissions,
        InProgressMissions,
        ResolvedMissions,
        ClosedMissions,
        Date
      FROM MetricsDaily
      WHERE ProjectID = ?
    `;

    const params: any[] = [dbProjectId];

    if (dateRange?.startDate) {
      sql += ` AND Date >= ?`;
      params.push(dateRange.startDate);
    }

    if (dateRange?.endDate) {
      sql += ` AND Date <= ?`;
      params.push(dateRange.endDate);
    }

    sql += ` ORDER BY Date DESC LIMIT 1`;

    const [metricsRows] = await this.db.query(sql, params);

    if ((metricsRows as any[]).length === 0) {
      throw new BusinessError(
        `查詢期間內無可用資料`,
        DASHBOARD_ERROR_CODES.NOT_FOUND.NO_DATA_AVAILABLE.code,
        DASHBOARD_ERROR_CODES.NOT_FOUND.NO_DATA_AVAILABLE.name
      );
    }

    const metrics = (metricsRows as any[])[0];
    const totalMissions =
      metrics.OpenMissions +
      metrics.InProgressMissions +
      metrics.ResolvedMissions +
      metrics.ClosedMissions;

    const completedMissions = metrics.ClosedMissions;
    const completionRate =
      totalMissions > 0
        ? Math.round((completedMissions / totalMissions) * 100 * 100) / 100
        : 0;

    return {
      projectID: projectId,
      projectName: projectName,
      totalMissions: totalMissions,
      completedMissions: completedMissions,
      completionRate: completionRate,
      openMissions: metrics.OpenMissions,
      inProgressMissions: metrics.InProgressMissions,
      resolvedMissions: metrics.ResolvedMissions,
      closedMissions: metrics.ClosedMissions,
    };
  }

  /**
   * 取得專案進度趨勢（時間序列資料）
   * @param projectId 專案 ID
   * @param dateRange 日期範圍
   * @returns 進度趨勢資料陣列
   */
  async getProgressTrend(projectId: CoreID, dateRange: DateRangeQuery) {
    const dbProjectId = toDBId(projectId, "ProjectID");

    const [rows] = await this.db.query(
      `SELECT 
        Date,
        OpenMissions,
        InProgressMissions,
        ResolvedMissions,
        ClosedMissions
      FROM MetricsDaily
      WHERE ProjectID = ? 
        AND Date >= ? 
        AND Date <= ?
      ORDER BY Date ASC`,
      [dbProjectId, dateRange.startDate, dateRange.endDate]
    );

    return (rows as any[]).map((row) => ({
      date: row.Date,
      openMissions: row.OpenMissions,
      inProgressMissions: row.InProgressMissions,
      resolvedMissions: row.ResolvedMissions,
      closedMissions: row.ClosedMissions,
      totalMissions:
        row.OpenMissions +
        row.InProgressMissions +
        row.ResolvedMissions +
        row.ClosedMissions,
    }));
  }

  // ================================================================
  // 功能 5: 熱門標籤與類型分析
  // ================================================================

  /**
   * 分析專案中的熱門標籤
   * @param projectId 專案 ID
   * @param dateRange 日期範圍（可選）
   * @returns 標籤分析結果
   */
  async analyzePopularTags(
    projectId: CoreID,
    dateRange?: DateRangeQuery
  ): Promise<TagAnalysisResult> {
    const dbProjectId = toDBId(projectId, "ProjectID");

    // 取得專案名稱
    const [projectRows] = await this.db.query(
      `SELECT ProjectName FROM Projects WHERE ProjectID = ? AND DeletedAt IS NULL`,
      [dbProjectId]
    );

    if ((projectRows as any[]).length === 0) {
      throw new BusinessError(
        `專案不存在: ${projectId}`,
        DASHBOARD_ERROR_CODES.NOT_FOUND.PROJECT_NOT_FOUND.code,
        DASHBOARD_ERROR_CODES.NOT_FOUND.PROJECT_NOT_FOUND.name
      );
    }

    const projectName = (projectRows as any[])[0].ProjectName;

    // 先查總任務數（修復：單獨查，避免重複計）
    let totalSql = `SELECT COUNT(DISTINCT m.MissionID) AS totalMissions FROM Missions m INNER JOIN MissionTags mt ON m.MissionID = mt.MissionID WHERE m.ProjectID = ? AND m.DeletedAt IS NULL`;
    const totalParams: any[] = [dbProjectId];
    if (dateRange?.startDate) {
      totalSql += ` AND m.CreatedAt >= ?`;
      totalParams.push(dateRange.startDate);
    }
    if (dateRange?.endDate) {
      totalSql += ` AND m.CreatedAt <= ?`;
      totalParams.push(dateRange.endDate);
    }
    const [totalRows] = await this.db.query(totalSql, totalParams);
    const totalMissions = (totalRows as any[])[0].totalMissions || 0;

    // 統計標籤使用次數
    let sql = `
      SELECT 
        t.TagName,
        COUNT(DISTINCT mt.MissionID) AS TagCount
      FROM Tags t
      INNER JOIN MissionTags mt ON t.TagID = mt.TagID
      INNER JOIN Missions m ON mt.MissionID = m.MissionID
      WHERE m.ProjectID = ? AND m.DeletedAt IS NULL
    `;

    const params: any[] = [dbProjectId];

    if (dateRange?.startDate) {
      sql += ` AND m.CreatedAt >= ?`;
      params.push(dateRange.startDate);
    }

    if (dateRange?.endDate) {
      sql += ` AND m.CreatedAt <= ?`;
      params.push(dateRange.endDate);
    }

    sql += ` GROUP BY t.TagID, t.TagName ORDER BY TagCount DESC`;

    const [tagRows] = await this.db.query(sql, params);
    const tags = tagRows as any[];

    return {
      projectID: projectId,
      projectName: projectName,
      totalMissions: totalMissions,
      tagStats: tags.map((tag) => ({
        tag: tag.TagName,
        count: tag.TagCount,
        percentage:
          totalMissions > 0
            ? Math.round((tag.TagCount / totalMissions) * 100 * 100) / 100
            : 0,
      })),
      dateRange: dateRange,
    };
  }

  /**
   * 分析任務類型分布（依優先度）
   * @param projectId 專案 ID
   * @returns 優先度分布統計
   */
  async analyzePriorityDistribution(projectId: CoreID) {
    const dbProjectId = toDBId(projectId, "ProjectID");

    const [rows] = await this.db.query(
      `SELECT 
        Priority,
        COUNT(*) AS Count
      FROM Missions
      WHERE ProjectID = ? AND DeletedAt IS NULL
      GROUP BY Priority
      ORDER BY 
        FIELD(Priority, 'Critical', 'High', 'Medium', 'Low')`,
      [dbProjectId]
    );

    const priorities = rows as any[];
    const total = priorities.reduce((sum, p) => sum + p.Count, 0);

    return {
      projectID: projectId,
      total: total,
      distribution: priorities.map((p) => ({
        priority: p.Priority,
        count: p.Count,
        percentage:
          total > 0 ? Math.round((p.Count / total) * 100 * 100) / 100 : 0,
      })),
    };
  }

  // ================================================================
  // 輔助方法
  // ================================================================

  /**
   * 取得狀態的顯示名稱（修復：移除 'Resolved'，改用 'Closed'）
   */
  private getStatusDisplayName(status: string): string {
    const displayNames: Record<string, string> = {
      Open: "待處理",
      "In Progress": "進行中",
      Testing: "測試中",
      Reopened: "重新開啟",
      Closed: "已關閉",
    };
    return displayNames[status] || status;
  }
  /**
 * 取得 Dashboard 總覽資料
 */
async getDashboardOverview(userId: string): Promise<any> {
  try {
    // 1. 系統總覽
    const [totalUsers] = await this.db.query<any[]>(
      'SELECT COUNT(*) as count FROM users'
    );
    
    const [totalProjects] = await this.db.query<any[]>(
      'SELECT COUNT(*) as count FROM projects '
    );
    
    const [totalMissions] = await this.db.query<any[]>(
      'SELECT COUNT(*) as count FROM missions'
    );
    
    const [inProgressMissions] = await this.db.query<any[]>(
      `SELECT COUNT(*) as count FROM missions 
       WHERE Status = 'In Progress' `
    );

    // 2. 我的任務摘要
    const [myMissions] = await this.db.query<any[]>(
      `SELECT 
        Status,
        COUNT(*) as count
       FROM missions 
       WHERE AssigneeID = ?
       GROUP BY Status`,
      [userId]
    );

    const myTaskSummary = {
      inProgress: myMissions.find(m => m.Status === 'In Progress')?.count || 0,
      testing: myMissions.find(m => m.Status === 'Testing')?.count || 0,
      total: myMissions.reduce((sum, m) => sum + m.count, 0),
    };

    // 3. 即將到期的任務（7天內到期）
    const [upcomingDeadlines] = await this.db.query<any[]>(
      `SELECT 
        m.MissionID as id,
        m.Title as title,
        m.DueDate as dueDate,
        m.Priority as priority,
        DATEDIFF(m.DueDate, NOW()) as daysLeft
       FROM missions m
       WHERE m.AssigneeID = ? 
         AND m.Status NOT IN ('Closed') 
         AND m.DueDate IS NOT NULL
         AND m.DueDate >= CURDATE()
         AND m.DueDate <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
       ORDER BY m.DueDate ASC
       LIMIT 5`,
      [userId]
    );

    // 4. 最近活動（從 missionhistory 取得）
    const [recentActivities] = await this.db.query<any[]>(
      `SELECT 
        h.HistoryID as id,
        h.FieldChanged as field,
        h.OldValue as oldValue,
        h.NewValue as newValue,
        h.ChangedAt as timestamp,
        m.Title as missionTitle,
        m.MissionID as missionId,
        u.FullName as userName
       FROM missionhistory h
       LEFT JOIN missions m ON h.MissionID = m.MissionID
       LEFT JOIN users u ON h.UserID = u.UserID
       WHERE m.ProjectID IN (
         SELECT ProjectID FROM projectmembers WHERE UserID = ?
       )
       ORDER BY h.ChangedAt DESC
       LIMIT 10`,
      [userId]
    );

    // 5. 所有專案列表
    const [projects] = await this.db.query<any[]>(
      `SELECT 
        p.ProjectID as id,
        p.ProjectName as name,
        COUNT(m.MissionID) as totalMissions
       FROM projects p
       LEFT JOIN missions m ON p.ProjectID = m.ProjectID 
       WHERE p.DeletedAt IS NULL
       GROUP BY p.ProjectID, p.ProjectName
       ORDER BY p.CreatedAt DESC`
    );

    // 組合資料
    return {
      overview: {
        totalUsers: totalUsers[0].count,
        totalProjects: totalProjects[0].count,
        totalMissions: totalMissions[0].count,
        inProgressMissions: inProgressMissions[0].count,
      },
      myTasks: myTaskSummary,
      upcomingDeadlines: upcomingDeadlines,
      recentActivities: recentActivities,
      projects: projects,
    };

  } catch (error) {
    console.error('❌ getDashboardOverview error:', error);
    throw error;
  }
}
  
}
