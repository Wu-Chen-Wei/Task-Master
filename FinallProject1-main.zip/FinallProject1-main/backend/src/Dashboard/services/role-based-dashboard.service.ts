// 程式檔案: backend/src/Dashboard/services/role-based-dashboard.service.ts
// 層次與職責: 業務邏輯層 (Services Layer)
// 核心職責: 根據使用者角色提供不同的 Dashboard 資料

import { Pool } from "mysql2/promise";
import { toDBId, toCoreId, CoreID } from "../types/core.types";
import { BusinessError, DASHBOARD_ERROR_CODES } from "../types/error.types";

/**
 * RoleBasedDashboardService
 * 根據使用者角色提供客製化的 Dashboard 資料
 */
export class RoleBasedDashboardService {
  private db: Pool;

  constructor(db: Pool) {
    this.db = db;
  }

  /**
   * 取得使用者的 Dashboard 資料（依角色顯示不同內容）
   * @param userId 使用者 ID
   * @param userRole 使用者角色
   * @returns 客製化的 Dashboard 資料
   */
  async getUserDashboard(userId: CoreID, userRole: string) {
    const dbUserId = toDBId(userId, "UserID");

    console.log("Getting dashboard data for user:", userId, "Role:", userRole);

    switch (userRole) {
      case "Admin":
        console.log("Fetching data for Admin");
        return await this.getAdminDashboard(dbUserId);

      case "AccountAdmin":
        console.log("Fetching data for AccountAdmin");
        return await this.getAccountAdminDashboard(dbUserId);

      case "PM":
        console.log("Fetching data for PM");
        return await this.getPMDashboard(dbUserId);

      case "RDL":
        console.log("Fetching data for RDL");
        return await this.getRDLDashboard(dbUserId);

      case "RD":
        console.log("Fetching data for RD");
        return await this.getRDDashboard(dbUserId);

      case "QA":
        console.log("Fetching data for QA");
        return await this.getQADashboard(dbUserId);

      default:
        console.log("Fetching data for default user");
        return await this.getDefaultDashboard(dbUserId);
    }
  }

  // ================================================================
  // Admin Dashboard - 系統管理員看全局資料
  // ================================================================
  private async getAdminDashboard(userId: number) {
    // 1. 系統整體統計
    const [systemStats] = await this.db.query(`
      SELECT 
        (SELECT COUNT(*) FROM Users) AS TotalUsers,
        (SELECT COUNT(*) FROM Projects WHERE DeletedAt IS NULL) AS TotalProjects,
        (SELECT COUNT(*) FROM Missions WHERE DeletedAt IS NULL) AS TotalMissions,
        (SELECT COUNT(*) FROM Missions WHERE Status = 'In Progress' AND DeletedAt IS NULL) AS InProgressMissions
    `);

    const stats = (systemStats as any[])[0];

    // 2. 所有專案列表
    const [allProjects] = await this.db.query(`
      SELECT 
        p.ProjectID as id,
        p.ProjectName as name,
        COUNT(DISTINCT m.MissionID) AS totalMissions
      FROM Projects p
      LEFT JOIN Missions m ON p.ProjectID = m.ProjectID AND m.DeletedAt IS NULL
      WHERE p.DeletedAt IS NULL
      GROUP BY p.ProjectID
      ORDER BY p.CreatedAt DESC
    `);

    // 3. 最近活動（所有專案）
    const [recentActivities] = await this.db.query(`
      SELECT 
        h.HistoryID as id,
        h.FieldChanged as field,
        h.NewValue as newValue,
        h.ChangedAt as timestamp,
        m.Title as missionTitle,
        m.MissionID as missionId,
        u.FullName as userName
      FROM missionhistory h
      LEFT JOIN missions m ON h.MissionID = m.MissionID
      LEFT JOIN users u ON h.UserID = u.UserID
      ORDER BY h.ChangedAt DESC
      LIMIT 10
    `);

    // ✅ 統一格式回傳
    return {
      role: "Admin", // ✅ 加上英文角色
      roleTitle: "系統管理員", // ✅ 加上中文標題
      overview: {
        totalUsers: stats.TotalUsers,
        totalProjects: stats.TotalProjects,
        totalMissions: stats.TotalMissions,
        inProgressMissions: stats.InProgressMissions,
      },
      myTasks: {
        inProgress: 0,
        testing: 0,
        total: 0,
      },
      upcomingDeadlines: [],
      recentActivities: recentActivities,
      projects: allProjects,
    };
  }

  // ================================================================
  // AccountAdmin Dashboard - 帳號管理員看使用者相關資料
  // ================================================================
  private async getAccountAdminDashboard(userId: number) {
    // 1. 系統統計（AccountAdmin 也能看系統概況）
    const [systemStats] = await this.db.query(`
      SELECT 
        (SELECT COUNT(*) FROM Users) AS TotalUsers,
        (SELECT COUNT(*) FROM Projects WHERE DeletedAt IS NULL) AS TotalProjects,
        (SELECT COUNT(*) FROM Missions WHERE DeletedAt IS NULL) AS TotalMissions,
        (SELECT COUNT(*) FROM Missions WHERE Status = 'In Progress' AND DeletedAt IS NULL) AS InProgressMissions
    `);

    const stats = (systemStats as any[])[0];

    // 2. 所有專案列表
    const [allProjects] = await this.db.query(`
      SELECT 
        p.ProjectID as id,
        p.ProjectName as name,
        COUNT(DISTINCT m.MissionID) AS totalMissions
      FROM Projects p
      LEFT JOIN Missions m ON p.ProjectID = m.ProjectID AND m.DeletedAt IS NULL
      WHERE p.DeletedAt IS NULL
      GROUP BY p.ProjectID
      ORDER BY p.CreatedAt DESC
    `);

    // 3. 最近活動
    const [recentActivities] = await this.db.query(`
      SELECT 
        h.HistoryID as id,
        h.FieldChanged as field,
        h.NewValue as newValue,
        h.ChangedAt as timestamp,
        m.Title as missionTitle,
        m.MissionID as missionId,
        u.FullName as userName
      FROM missionhistory h
      LEFT JOIN missions m ON h.MissionID = m.MissionID
      LEFT JOIN users u ON h.UserID = u.UserID
      ORDER BY h.ChangedAt DESC
      LIMIT 10
    `);

    // ✅ 統一格式回傳
    return {
      overview: {
        totalUsers: stats.TotalUsers,
        totalProjects: stats.TotalProjects,
        totalMissions: stats.TotalMissions,
        inProgressMissions: stats.InProgressMissions,
      },
      myTasks: {
        inProgress: 0,
        testing: 0,
        total: 0,
      },
      upcomingDeadlines: [],
      recentActivities: recentActivities,
      projects: allProjects,
    };
  }

  // ================================================================
  // PM Dashboard - 專案經理看負責的專案進度
  // ================================================================
  private async getPMDashboard(userId: number) {
    // 1. 我負責的專案統計
    const [projectStats] = await this.db.query(
      `SELECT 
        COUNT(DISTINCT p.ProjectID) AS TotalProjects,
        COUNT(DISTINCT m.MissionID) AS TotalMissions,
        COUNT(DISTINCT CASE WHEN m.Status = 'In Progress' THEN m.MissionID END) AS InProgressMissions
      FROM Projects p
      LEFT JOIN Missions m ON p.ProjectID = m.ProjectID AND m.DeletedAt IS NULL
      WHERE p.OwnerUserID = ? AND p.DeletedAt IS NULL`,
      [userId]
    );

    const stats = (projectStats as any[])[0];

    // 2. 我負責的專案列表
    const [myProjects] = await this.db.query(
      `SELECT 
        p.ProjectID as id,
        p.ProjectName as name,
        COUNT(DISTINCT m.MissionID) AS totalMissions
      FROM Projects p
      LEFT JOIN Missions m ON p.ProjectID = m.ProjectID AND m.DeletedAt IS NULL
      WHERE p.OwnerUserID = ? AND p.DeletedAt IS NULL
      GROUP BY p.ProjectID
      ORDER BY p.StartDate DESC`,
      [userId]
    );

    // 3. 我被指派的任務
    const [myTasks] = await this.db.query(
      `SELECT 
        Status,
        COUNT(*) as count
      FROM missions 
      WHERE AssigneeID = ?
      GROUP BY Status`,
      [userId]
    );

    const myTaskSummary = {
      inProgress:
        (myTasks as any[]).find((m: any) => m.Status === "In Progress")
          ?.count || 0,
      testing:
        (myTasks as any[]).find((m: any) => m.Status === "Testing")?.count || 0,
      total: (myTasks as any[]).reduce(
        (sum: number, m: any) => sum + m.count,
        0
      ),
    };

    // 4. 需要關注的任務（高優先度）
    const [urgentMissions] = await this.db.query(
      `SELECT 
        m.MissionID as id,
        m.Title as title,
        m.DueDate as dueDate,
        m.Priority as priority,
        DATEDIFF(m.DueDate, NOW()) as daysLeft
      FROM Missions m
      INNER JOIN Projects p ON m.ProjectID = p.ProjectID
      WHERE p.OwnerUserID = ?
        AND m.Priority IN ('High', 'Critical')
        AND m.Status NOT IN ('Closed')
        AND m.DueDate IS NOT NULL
        AND m.DueDate >= CURDATE()
        AND m.DeletedAt IS NULL
      ORDER BY m.DueDate ASC
      LIMIT 5`,
      [userId]
    );

    // 5. 最近活動
    const [recentActivities] = await this.db.query(
      `SELECT 
        h.HistoryID as id,
        h.FieldChanged as field,
        h.NewValue as newValue,
        h.ChangedAt as timestamp,
        m.Title as missionTitle,
        m.MissionID as missionId,
        u.FullName as userName
      FROM missionhistory h
      LEFT JOIN missions m ON h.MissionID = m.MissionID
      LEFT JOIN users u ON h.UserID = u.UserID
      LEFT JOIN projects p ON m.ProjectID = p.ProjectID
      WHERE p.OwnerUserID = ?
      ORDER BY h.ChangedAt DESC
      LIMIT 10`,
      [userId]
    );

    // ✅ 統一格式回傳
    return {
      role: "PM",
      roleTitle: "專案經理",
      overview: {
        totalUsers: 0,
        totalProjects: stats.TotalProjects,
        totalMissions: stats.TotalMissions,
        inProgressMissions: stats.InProgressMissions,
      },
      myTasks: myTaskSummary,
      upcomingDeadlines: urgentMissions,
      recentActivities: recentActivities,
      projects: myProjects,
    };
  }

  // ================================================================
  // RDL Dashboard - RD Leader 看團隊工作量和專案參與情況
  // ================================================================
  private async getRDLDashboard(userId: number) {
    // 1. 我參與的專案統計
    const [projectStats] = await this.db.query(
      `SELECT 
        COUNT(DISTINCT p.ProjectID) AS TotalProjects,
        COUNT(DISTINCT m.MissionID) AS TotalMissions,
        COUNT(DISTINCT CASE WHEN m.Status = 'In Progress' THEN m.MissionID END) AS InProgressMissions
      FROM ProjectMembers pm
      INNER JOIN Projects p ON pm.ProjectID = p.ProjectID
      LEFT JOIN Missions m ON p.ProjectID = m.ProjectID AND m.DeletedAt IS NULL
      WHERE pm.UserID = ? AND p.DeletedAt IS NULL`,
      [userId]
    );

    const stats = (projectStats as any[])[0];

    // 2. 我參與的專案列表
    const [myProjects] = await this.db.query(
      `SELECT 
        p.ProjectID as id,
        p.ProjectName as name,
        COUNT(DISTINCT m.MissionID) AS totalMissions
      FROM ProjectMembers pm
      INNER JOIN Projects p ON pm.ProjectID = p.ProjectID
      LEFT JOIN Missions m ON p.ProjectID = m.ProjectID AND m.DeletedAt IS NULL
      WHERE pm.UserID = ? AND p.DeletedAt IS NULL
      GROUP BY p.ProjectID
      ORDER BY p.CreatedAt DESC`,
      [userId]
    );

    // 3. 我的任務摘要
    const [myTasks] = await this.db.query(
      `SELECT 
        Status,
        COUNT(*) as count
      FROM missions 
      WHERE AssigneeID = ?
      GROUP BY Status`,
      [userId]
    );

    const myTaskSummary = {
      inProgress:
        (myTasks as any[]).find((m: any) => m.Status === "In Progress")
          ?.count || 0,
      testing:
        (myTasks as any[]).find((m: any) => m.Status === "Testing")?.count || 0,
      total: (myTasks as any[]).reduce(
        (sum: number, m: any) => sum + m.count,
        0
      ),
    };

    // 4. 即將到期的任務
    const [upcomingDeadlines] = await this.db.query(
      `SELECT 
        m.MissionID as id,
        m.Title as title,
        m.DueDate as dueDate,
        m.Priority as priority,
        DATEDIFF(m.DueDate, NOW()) as daysLeft
      FROM missions m
      WHERE m.AssigneeID = ? 
        AND m.Status NOT IN ('Closed') 
        AND m.DueDate IS NOT NULL
        AND m.DueDate >= CURDATE()
        AND m.DueDate <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
      ORDER BY m.DueDate ASC
      LIMIT 5`,
      [userId]
    );

    // 5. 最近活動
    const [recentActivities] = await this.db.query(
      `SELECT 
        h.HistoryID as id,
        h.FieldChanged as field,
        h.NewValue as newValue,
        h.ChangedAt as timestamp,
        m.Title as missionTitle,
        m.MissionID as missionId,
        u.FullName as userName
      FROM missionhistory h
      LEFT JOIN missions m ON h.MissionID = m.MissionID
      LEFT JOIN users u ON h.UserID = u.UserID
      WHERE m.ProjectID IN (
        SELECT ProjectID FROM projectmembers WHERE UserID = ?
      )
      ORDER BY h.ChangedAt DESC
      LIMIT 10`,
      [userId]
    );

    // ✅ 統一格式回傳
    return {
      role: "RDL",
      roleTitle: "RD Leader",
      overview: {
        totalUsers: 0,
        totalProjects: stats.TotalProjects,
        totalMissions: stats.TotalMissions,
        inProgressMissions: stats.InProgressMissions,
      },
      myTasks: myTaskSummary,
      upcomingDeadlines: upcomingDeadlines,
      recentActivities: recentActivities,
      projects: myProjects,
    };
  }

  // ================================================================
  // RD Dashboard - 開發人員看自己被指派的任務和專案
  // ================================================================
  private async getRDDashboard(userId: number) {
    // 1. 我參與的專案統計
    const [projectStats] = await this.db.query(
      `SELECT 
        COUNT(DISTINCT p.ProjectID) AS TotalProjects,
        COUNT(DISTINCT CASE WHEN m.AssigneeID = ? THEN m.MissionID END) AS TotalMissions,
        COUNT(DISTINCT CASE WHEN m.AssigneeID = ? AND m.Status = 'In Progress' THEN m.MissionID END) AS InProgressMissions
      FROM ProjectMembers pm
      INNER JOIN Projects p ON pm.ProjectID = p.ProjectID
      LEFT JOIN Missions m ON p.ProjectID = m.ProjectID AND m.DeletedAt IS NULL
      WHERE pm.UserID = ? AND p.DeletedAt IS NULL`,
      [userId, userId, userId]
    );

    const stats = (projectStats as any[])[0];

    // 2. 我參與的專案列表
    const [myProjects] = await this.db.query(
      `SELECT 
        p.ProjectID as id,
        p.ProjectName as name,
        COUNT(DISTINCT CASE WHEN m.AssigneeID = ? THEN m.MissionID END) AS totalMissions
      FROM ProjectMembers pm
      INNER JOIN Projects p ON pm.ProjectID = p.ProjectID
      LEFT JOIN Missions m ON p.ProjectID = m.ProjectID AND m.DeletedAt IS NULL
      WHERE pm.UserID = ? AND p.DeletedAt IS NULL
      GROUP BY p.ProjectID
      ORDER BY p.CreatedAt DESC`,
      [userId, userId]
    );

    // 3. 我的任務摘要
    const [myTasks] = await this.db.query(
      `SELECT 
        Status,
        COUNT(*) as count
      FROM missions 
      WHERE AssigneeID = ?
      GROUP BY Status`,
      [userId]
    );

    const myTaskSummary = {
      inProgress:
        (myTasks as any[]).find((m: any) => m.Status === "In Progress")
          ?.count || 0,
      testing:
        (myTasks as any[]).find((m: any) => m.Status === "Testing")?.count || 0,
      total: (myTasks as any[]).reduce(
        (sum: number, m: any) => sum + m.count,
        0
      ),
    };

    // 4. 即將到期的任務
    const [upcomingDeadlines] = await this.db.query(
      `SELECT 
        m.MissionID as id,
        m.Title as title,
        m.DueDate as dueDate,
        m.Priority as priority,
        DATEDIFF(m.DueDate, NOW()) as daysLeft
      FROM missions m
      WHERE m.AssigneeID = ? 
        AND m.Status NOT IN ('Closed') 
        AND m.DueDate IS NOT NULL
        AND m.DueDate >= CURDATE()
        AND m.DueDate <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
      ORDER BY m.DueDate ASC
      LIMIT 5`,
      [userId]
    );

    // 5. 最近活動
    const [recentActivities] = await this.db.query(
      `SELECT 
        h.HistoryID as id,
        h.FieldChanged as field,
        h.NewValue as newValue,
        h.ChangedAt as timestamp,
        m.Title as missionTitle,
        m.MissionID as missionId,
        u.FullName as userName
      FROM missionhistory h
      LEFT JOIN missions m ON h.MissionID = m.MissionID
      LEFT JOIN users u ON h.UserID = u.UserID
      WHERE m.ProjectID IN (
        SELECT ProjectID FROM projectmembers WHERE UserID = ?
      )
      ORDER BY h.ChangedAt DESC
      LIMIT 10`,
      [userId]
    );

    // ✅ 統一格式回傳
    return {
      role: "RD",
      roleTitle: "開發人員",
      overview: {
        totalUsers: 0,
        totalProjects: stats.TotalProjects,
        totalMissions: stats.TotalMissions,
        inProgressMissions: stats.InProgressMissions,
      },
      myTasks: myTaskSummary,
      upcomingDeadlines: upcomingDeadlines,
      recentActivities: recentActivities,
      projects: myProjects,
    };
  }

  // ================================================================
  // QA Dashboard - QA 看需要測試的任務和測試中的任務
  // ================================================================
  private async getQADashboard(userId: number) {
    // 1. 我參與的專案統計
    const [projectStats] = await this.db.query(
      `SELECT 
        COUNT(DISTINCT p.ProjectID) AS TotalProjects,
        COUNT(DISTINCT m.MissionID) AS TotalMissions,
        COUNT(DISTINCT CASE WHEN m.Status = 'Testing' THEN m.MissionID END) AS InProgressMissions
      FROM ProjectMembers pm
      INNER JOIN Projects p ON pm.ProjectID = p.ProjectID
      LEFT JOIN Missions m ON p.ProjectID = m.ProjectID AND m.DeletedAt IS NULL
      WHERE pm.UserID = ? AND p.DeletedAt IS NULL`,
      [userId]
    );

    const stats = (projectStats as any[])[0];

    // 2. 我參與的專案列表
    const [myProjects] = await this.db.query(
      `SELECT 
        p.ProjectID as id,
        p.ProjectName as name,
        COUNT(DISTINCT CASE WHEN m.Status = 'Testing' THEN m.MissionID END) AS totalMissions
      FROM ProjectMembers pm
      INNER JOIN Projects p ON pm.ProjectID = p.ProjectID
      LEFT JOIN Missions m ON p.ProjectID = m.ProjectID AND m.DeletedAt IS NULL
      WHERE pm.UserID = ? AND p.DeletedAt IS NULL
      GROUP BY p.ProjectID
      ORDER BY p.CreatedAt DESC`,
      [userId]
    );

    // 3. 待測試任務摘要
    const [myTasks] = await this.db.query(
      `SELECT 
        COUNT(*) as testing
      FROM missions m
      INNER JOIN projects p ON m.ProjectID = p.ProjectID
      INNER JOIN projectmembers pm ON p.ProjectID = pm.ProjectID
      WHERE pm.UserID = ? AND m.Status = 'Testing'`,
      [userId]
    );

    const myTaskSummary = {
      inProgress: 0,
      testing: (myTasks as any[])[0]?.testing || 0,
      total: (myTasks as any[])[0]?.testing || 0,
    };

    // 4. 即將到期的測試任務
    const [upcomingDeadlines] = await this.db.query(
      `SELECT 
        m.MissionID as id,
        m.Title as title,
        m.DueDate as dueDate,
        m.Priority as priority,
        DATEDIFF(m.DueDate, NOW()) as daysLeft
      FROM missions m
      INNER JOIN projects p ON m.ProjectID = p.ProjectID
      INNER JOIN projectmembers pm ON p.ProjectID = pm.ProjectID
      WHERE pm.UserID = ?
        AND m.Status = 'Testing'
        AND m.DueDate IS NOT NULL
        AND m.DueDate >= CURDATE()
        AND m.DueDate <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
      ORDER BY m.DueDate ASC
      LIMIT 5`,
      [userId]
    );

    // 5. 最近活動
    const [recentActivities] = await this.db.query(
      `SELECT 
        h.HistoryID as id,
        h.FieldChanged as field,
        h.NewValue as newValue,
        h.ChangedAt as timestamp,
        m.Title as missionTitle,
        m.MissionID as missionId,
        u.FullName as userName
      FROM missionhistory h
      LEFT JOIN missions m ON h.MissionID = m.MissionID
      LEFT JOIN users u ON h.UserID = u.UserID
      WHERE m.ProjectID IN (
        SELECT ProjectID FROM projectmembers WHERE UserID = ?
      )
      ORDER BY h.ChangedAt DESC
      LIMIT 10`,
      [userId]
    );

    // ✅ 統一格式回傳
    return {
      role: "QA",
      roleTitle: "QA 測試人員",
      overview: {
        totalUsers: 0,
        totalProjects: stats.TotalProjects,
        totalMissions: stats.TotalMissions,
        inProgressMissions: stats.InProgressMissions,
      },
      myTasks: myTaskSummary,
      upcomingDeadlines: upcomingDeadlines,
      recentActivities: recentActivities,
      projects: myProjects,
    };
  }

  // ================================================================
  // Default Dashboard - 一般使用者或未知角色
  // ================================================================
  private async getDefaultDashboard(userId: number) {
    // 1. 基本統計
    const [stats] = await this.db.query(
      `SELECT 
        COUNT(*) AS TotalMissions,
        COUNT(CASE WHEN Status = 'In Progress' THEN 1 END) AS InProgressMissions
      FROM missions
      WHERE AssigneeID = ?`,
      [userId]
    );

    const taskStats = (stats as any[])[0];

    // 2. 我的任務摘要
    const [myTasks] = await this.db.query(
      `SELECT 
        Status,
        COUNT(*) as count
      FROM missions 
      WHERE AssigneeID = ?
      GROUP BY Status`,
      [userId]
    );

    const myTaskSummary = {
      inProgress:
        (myTasks as any[]).find((m: any) => m.Status === "In Progress")
          ?.count || 0,
      testing:
        (myTasks as any[]).find((m: any) => m.Status === "Testing")?.count || 0,
      total: (myTasks as any[]).reduce(
        (sum: number, m: any) => sum + m.count,
        0
      ),
    };

    // 3. 即將到期
    const [upcomingDeadlines] = await this.db.query(
      `SELECT 
        m.MissionID as id,
        m.Title as title,
        m.DueDate as dueDate,
        m.Priority as priority,
        DATEDIFF(m.DueDate, NOW()) as daysLeft
      FROM missions m
      WHERE m.AssigneeID = ? 
        AND m.Status NOT IN ('Closed') 
        AND m.DueDate IS NOT NULL
        AND m.DueDate >= CURDATE()
        AND m.DueDate <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
      ORDER BY m.DueDate ASC
      LIMIT 5`,
      [userId]
    );

    // 4. 專案列表（我參與的）
    const [projects] = await this.db.query(
      `SELECT DISTINCT
        p.ProjectID as id,
        p.ProjectName as name,
        COUNT(DISTINCT CASE WHEN m.AssigneeID = ? THEN m.MissionID END) AS totalMissions
      FROM missions m
      INNER JOIN projects p ON m.ProjectID = p.ProjectID
      WHERE m.AssigneeID = ?
      GROUP BY p.ProjectID
      ORDER BY p.CreatedAt DESC`,
      [userId, userId]
    );

    // 5. 最近活動
    const [recentActivities] = await this.db.query(
      `SELECT 
        h.HistoryID as id,
        h.FieldChanged as field,
        h.NewValue as newValue,
        h.ChangedAt as timestamp,
        m.Title as missionTitle,
        m.MissionID as missionId,
        u.FullName as userName
      FROM missionhistory h
      LEFT JOIN missions m ON h.MissionID = m.MissionID
      LEFT JOIN users u ON h.UserID = u.UserID
      WHERE m.AssigneeID = ?
      ORDER BY h.ChangedAt DESC
      LIMIT 10`,
      [userId]
    );

    // ✅ 統一格式回傳
    return {
      overview: {
        totalUsers: 0,
        totalProjects: 0,
        totalMissions: taskStats.TotalMissions,
        inProgressMissions: taskStats.InProgressMissions,
      },
      myTasks: myTaskSummary,
      upcomingDeadlines: upcomingDeadlines,
      recentActivities: recentActivities,
      projects: projects,
    };
  }
}
