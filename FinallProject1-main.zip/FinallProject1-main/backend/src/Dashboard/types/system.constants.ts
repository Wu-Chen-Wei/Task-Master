// 程式檔案：backend/src/Dashboard/types/system.constants.ts
// 層次與職責：系統定義與數據契約層（Types Layer）
// 核心職責：定義 Dashboard 模組中所有 ENUM 和常數值

/**
 * Mission 狀態常數（對應 Missions.Status）
 * 用於 Kanban 看板的欄位分類
 */
export const MISSION_STATUS = {
  /** 已指派，等待開始 */
  OPEN: "Open",
  
  /** 正在開發中 */
  IN_PROGRESS: "In Progress",
  
  /** 開發完成，等待 QA 驗證 */
  TESTING: "Testing",
  
  /** QA 驗證失敗，退回修改 */
  REOPENED: "Reopened",
  
  /** QA 驗證成功 */
  RESOLVED: "Resolved",
  
  /** 已關閉 */
  CLOSED: "Closed",
} as const;

/**
 * Mission 優先度常數（對應 Missions.Priority）
 */
export const MISSION_PRIORITY = {
  /** 低優先度 */
  LOW: "Low",
  
  /** 中優先度 */
  MEDIUM: "Medium",
  
  /** 高優先度 */
  HIGH: "High",
  
  /** 緊急 */
  CRITICAL: "Critical",
} as const;

/**
 * 報表類型常數
 */
export const REPORT_TYPES = {
  /** 週報 */
  WEEKLY: "weekly",
  
  /** 月報 */
  MONTHLY: "monthly",
  
  /** 進度追蹤報表 */
  PROGRESS: "progress",
  
  /** Bug 統計報表 */
  BUG_STATS: "bug_stats",
  
  /** 平均修復時間報表 (MTTR) */
  MTTR: "mttr",
  
  /** 工作量分布報表 */
  WORKLOAD: "workload",
  
  /** 標籤分析報表 */
  TAG_ANALYSIS: "tag_analysis",
  
  /** 自訂報表 */
  CUSTOM: "custom",
} as const;

/**
 * 報表匯出格式常數
 */
export const EXPORT_FORMATS = {
  /** CSV 格式 */
  CSV: "csv",
  
  /** PDF 格式 */
  PDF: "pdf",
  
  /** Excel 格式 */
  EXCEL: "excel",
} as const;

/**
 * 角色 ID 常數（與 member 模組共用）
 */
export const ROLE_IDS = {
  /** Admin - 系統管理員 */
  ADMIN: 1,
  
  /** AccountAdmin - 帳號管理員 */
  ACCOUNT_ADMIN: 2,
  
  /** PM - 專案經理 */
  PM: 3,
  
  /** RDL - 研發主管 */
  RDL: 4,
  
  /** RD - 研發工程師 */
  RD: 5,
  
  /** QA - 品質保證 */
  QA: 6,
} as const;

/**
 * Kanban 預設欄位順序
 */
export const DEFAULT_KANBAN_COLUMNS: string[] = [
  MISSION_STATUS.OPEN,
  MISSION_STATUS.IN_PROGRESS,
  MISSION_STATUS.TESTING,
  MISSION_STATUS.CLOSED,
  MISSION_STATUS.REOPENED

];

/**
 * 時間範圍預設值（天）
 */
export const DEFAULT_TIME_RANGES = {
  /** 最近 7 天 */
  WEEK: 7,
  
  /** 最近 30 天 */
  MONTH: 30,
  
  /** 最近 90 天 */
  QUARTER: 90,
  
  /** 最近 365 天 */
  YEAR: 365,
} as const;

/**
 * 分頁預設值
 */
export const PAGINATION_DEFAULTS = {
  /** 預設頁碼 */
  PAGE: 1,
  
  /** 預設每頁筆數 */
  LIMIT: 20,
  
  /** 最大每頁筆數 */
  MAX_LIMIT: 100,
} as const;

/**
 * 工作量警告閾值
 */
export const WORKLOAD_THRESHOLDS = {
  /** 輕度負載（任務數） */
  LIGHT: 3,
  
  /** 中度負載（任務數） */
  MODERATE: 5,
  
  /** 重度負載（任務數） */
  HEAVY: 8,
  
  /** 超載（任務數） */
  OVERLOADED: 10,
} as const;

/**
 * 指標更新頻率（分鐘）
 */
export const METRICS_UPDATE_INTERVAL = {
  /** 即時更新（適用於看板） */
  REALTIME: 1,
  
  /** 每小時更新 */
  HOURLY: 60,
  
  /** 每日更新 */
  DAILY: 1440,
} as const;

/**
 * 顏色代碼（用於前端圖表）
 */
export const CHART_COLORS = {
  /** 成功/完成 - 綠色 */
  SUCCESS: "#10b981",
  
  /** 進行中 - 藍色 */
  IN_PROGRESS: "#3b82f6",
  
  /** 警告 - 黃色 */
  WARNING: "#f59e0b",
  
  /** 錯誤/Bug - 紅色 */
  ERROR: "#ef4444",
  
  /** 待處理 - 灰色 */
  PENDING: "#6b7280",
  
  /** 已解決 - 靛藍色 */
  RESOLVED: "#6366f1",
} as const;

/**
 * 權限檢查用的資源類型
 */
export const RESOURCE_TYPES = {
  /** Kanban 看板 */
  KANBAN: "kanban",
  
  /** 報表 */
  REPORT: "report",
  
  /** 指標 */
  METRICS: "metrics",
  
  /** 工作量 */
  WORKLOAD: "workload",
} as const;

/**
 * 快取時間（秒）
 */
export const CACHE_TTL = {
  /** Kanban 資料快取時間 */
  KANBAN: 60,
  
  /** 報表快取時間 */
  REPORT: 300,
  
  /** 指標快取時間 */
  METRICS: 180,
  
  /** 工作量快取時間 */
  WORKLOAD: 120,
} as const;






























