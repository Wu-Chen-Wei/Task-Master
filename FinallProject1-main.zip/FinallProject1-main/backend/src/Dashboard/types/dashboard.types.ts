// 程式檔案:backend/src/Dashboard/types/dashboard.types.ts
// 層次與職責:系統定義與數據契約層(Types Layer)
// 核心職責:定義 Dashboard 模組中所有型別和介面

import { CoreID } from "../types/core.types";

// ================================================================
// 資料庫表格型別定義
// ================================================================

/**
 * KanbanSettings 資料表(資料庫格式)
 */
export interface KanbanSettingsDBRow {
  SettingsID: number;
  UserID: number;
  ProjectID: number;
  ColumnOrder: string; // JSON 陣列
  CustomColumns: string | null; // JSON 物件
  CreatedAt: string;
  UpdatedAt: string | null;
  DeletedAt: string | null;
}

/**
 * KanbanSettings 物件(JSON 傳輸格式)
 */
export interface KanbanSettingsObject {
  settingsID: CoreID;
  userID: CoreID;
  projectID: CoreID;
  columnOrder: string[];
  customColumns?: Record<string, any>;
  createdAt: string;
  updatedAt?: string;
}

/**
 * MetricsDaily 資料表(資料庫格式)
 */
export interface MetricsDailyDBRow {
  MetricsID: number;
  ProjectID: number;
  Date: string;
  OpenMissions: number;
  InProgressMissions: number;
  ResolvedMissions: number;
  ClosedMissions: number;
  BugCount: number;
  AvgResolveTimeHours: number;
}

/**
 * MetricsDaily 物件(JSON 傳輸格式)
 */
export interface MetricsDailyObject {
  metricsID: CoreID;
  projectID: CoreID;
  date: string;
  openMissions: number;
  inProgressMissions: number;
  resolvedMissions: number;
  closedMissions: number;
  bugCount: number;
  avgResolveTimeHours: number;
}

/**
 * UserWorkload 資料表(資料庫格式)
 */
export interface UserWorkloadDBRow {
  WorkloadID: number;             // 主鍵
  UserID: number;                 // 使用者 ID
  ProjectID: number;              // 專案 ID
  OpenMissionCount: number;       // 開啟任務數量
  InProgressMissionCount: number; // 進行中任務數量
  UpdatedAt: string;              // 最後更新時間 (自動更新)
}

/**
 * UserWorkload 物件(JSON 傳輸格式)
 */
export interface UserWorkloadObject {
  workloadID: CoreID;
  userID: CoreID;
  date: string;
  activeTasks: number;
  completedTasks: number;
  totalStoryPoints: number;
}

/**
 * Reports 資料表(資料庫格式)
 */
export interface ReportsDBRow {
  ReportID: number; // 主鍵
  ProjectID: number; // 專案 ID
  GeneratedByUserID: number; // 產生報表的使用者
  ReportType: string; // 報表類型 (e.g. weekly, mttr, workload)
  Data: string; // JSON 格式的報表資料
  GeneratedAt: string; // 生成時間 (DATETIME)
  DeletedAt: string | null; // 軟刪除時
}

/**
 * Reports 物件(JSON 傳輸格式)
 */
export interface ReportsObject {
  reportID: CoreID;
  projectID: CoreID;
  reportType: string;
  reportName: string;
  startDate: string;
  endDate: string;
  generatedBy: CoreID;
  reportData: string; // JSON 字串
  createdAt: string;
}

// ================================================================
// Kanban 相關型別
// ================================================================

/**
 * Kanban Mission 資料(從 Missions 表查詢)
 */
export interface KanbanMission {
  MissionID: number;
  ProjectID: number;
  Title: string;
  Description: string | null;
  Status: string;
  Priority: string;
  AssigneeID: number | null;
  AssigneeName: string | null;
  Tags: string; // JSON 陣列字串
  StoryPoints: number | null;
  CreatedAt: string;
  UpdatedAt: string | null;
}

/**
 * Kanban 卡片(傳給前端的格式)
 */
export interface KanbanCard {
  missionID: CoreID;
  title: string;
  description?: string;
  priority: string;
  assigneeID?: CoreID;
  assigneeName?: string;
  tags: string[];
  storyPoints?: number;
  createdAt: string;
  updatedAt?: string;
}

/**
 * Kanban 欄位
 */
export interface KanbanColumn {
  status: string;
  displayName: string;
  cards: KanbanCard[];
  count: number;
}

/**
 * Kanban 看板完整資料
 */
export interface KanbanBoardData {
  projectID: CoreID;
  projectName: string;
  columns: KanbanColumn[];
  settings?: KanbanSettingsObject;
}

// ================================================================
// 請求參數型別
// ================================================================

/**
 * 日期範圍查詢參數
 */
export interface DateRangeQuery {
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
}

/**
 * 更新 Kanban 設定的請求
 */
export interface UpdateKanbanSettingsRequest {
  columnOrder?: string[];
  customColumns?: Record<string, any>;
}

/**
 * 更新 Mission 狀態的請求
 */
export interface UpdateMissionStatusRequest {
  status: string;
}

/**
 * 自訂報表參數
 */
export interface CustomReportParams {
  projectId: CoreID;
  startDate: string;
  endDate: string;
  reportName?: string;
  metrics?: string[];
}

// ================================================================
// 統計分析型別
// ================================================================

/**
 * 專案進度統計
 */
export interface ProjectProgressStats {
  projectID: CoreID;
  projectName: string;
  totalMissions: number;
  completedMissions: number;
  completionRate: number;
  openMissions: number;
  inProgressMissions: number;
  resolvedMissions: number;
  closedMissions: number;
}

/**
 * Bug 統計
 */
export interface BugStats {
  projectID: CoreID;
  projectName: string;
  totalBugs: number;
  openBugs: number;
  resolvedBugs: number;
  avgResolveTimeHours: number;
}

/**
 * 工作量分布
 */
export interface WorkloadDistribution {
  projectID: CoreID;
  projectName: string;
  totalMembers: number;
  totalActiveTasks: number;
  totalCompletedTasks: number;
  avgTasksPerMember: number;
  distribution: {
    light: number;
    moderate: number;
    heavy: number;
    overloaded: number;
  };
  memberWorkloads: Array<{
    userID: CoreID;
    username: string;
    email: string;
    activeTasks: number;
    completedTasks: number;
    totalStoryPoints: number;
    workloadLevel: "light" | "moderate" | "heavy" | "overloaded";
  }>;
}

/**
 * 團隊工作量統計
 */
export interface TeamWorkloadStats {
  totalMembers: number;
  totalActiveTasks: number;
  totalCompletedTasks: number;
  totalStoryPoints: number;
  avgTasksPerMember: number;
  distribution: {
    light: number;
    moderate: number;
    heavy: number;
    overloaded: number;
  };
  memberWorkloads: Array<{
    userID: CoreID;
    username: string;
    email: string;
    activeProjects: number;
    activeTasks: number;
    completedTasks: number;
    totalStoryPoints: number;
    workloadLevel: "light" | "moderate" | "heavy" | "overloaded";
  }>;
}

/**
 * 標籤分析結果
 */
export interface TagAnalysisResult {
  projectID: CoreID;
  projectName: string;
  totalMissions: number;
  tagStats: Array<{
    tag: string;
    count: number;
    percentage: number;
  }>;
  dateRange?: {
    startDate: string;
    endDate: string;
  };
}

/**
 * MTTR 報表
 */
export interface MTTRReport {
  projectID: CoreID;
  projectName: string;
  totalResolved: number;
  avgResolveTimeHours: number;
  medianResolveTimeHours: number;
  minResolveTimeHours: number;
  maxResolveTimeHours: number;
  dateRange?: {
    startDate: string;
    endDate: string;
  };
}

// ================================================================
// Model 層介面(資料操作)
// ================================================================

/**
 * KanbanSettings 建立參數
 */
export interface KanbanSettingsCreateInput {
  UserID: number;
  ProjectID: number;
  ColumnOrder: string;
  CustomColumns?: string | null;
}

/**
 * KanbanSettings 更新參數
 */
export interface KanbanSettingsUpdateInput {
  ColumnOrder?: string;
  CustomColumns?: string;
}

/**
 * MetricsDaily 建立參數
 */
export interface MetricsDailyCreateInput {
  ProjectID: number;
  Date: string;
  OpenMissions: number;
  InProgressMissions: number;
  ResolvedMissions: number;
  ClosedMissions: number;
  BugCount: number;
  AvgResolveTimeHours: number;
}

/**
 * MetricsDaily 更新參數
 */
export interface MetricsDailyUpdateInput {
  OpenMissions?: number;
  InProgressMissions?: number;
  ResolvedMissions?: number;
  ClosedMissions?: number;
  BugCount?: number;
  AvgResolveTimeHours?: number;
}

/**
 * UserWorkload 建立參數
 */
export interface UserWorkloadCreateInput {
  UserID: number;
  Date: string;
  ActiveTasks: number;
  CompletedTasks: number;
  TotalStoryPoints: number;
}

/**
 * UserWorkload 更新參數
 */
export interface UserWorkloadUpdateInput {
  ActiveTasks?: number;
  CompletedTasks?: number;
  TotalStoryPoints?: number;
}

/**
 * Reports 建立參數
 */
export interface ReportsCreateInput {
  ProjectID: number;       // 專案 ID
  GeneratedBy: number;     // ✅ 建立報表的使用者 ID
  ReportType: string;      // 報表類型（如 'weekly'、'mttr'）
  StartDate: string;       // 起始日期
  EndDate: string;         // 結束日期
  ReportName?: string;     // 可選的報表名稱
  ReportData: string;      // ✅ JSON 格式的報表內容
}

/**
 * Reports 更新參數
 */
export interface ReportsUpdateInput {
  ReportName?: string;
  ReportData?: string;
}
