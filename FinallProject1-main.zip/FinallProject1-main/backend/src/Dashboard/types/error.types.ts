// 程式檔案: backend/src/Dashboard/types/error.types.ts
// 層次與職責: 系統定義與數據契約層 (Types Layer)
// 核心職責: 定義 Dashboard 模組中所有標準化錯誤碼

export const DASHBOARD_ERROR_CODES = {
  /** 403 Forbidden 錯誤碼 */
  FORBIDDEN: {
    code: 40301,
    name: "PERMISSION_DENIED",
    description: "權限不足：用戶無權查看或操作此資源",
  },

  /** 400 Bad Request 錯誤碼 */
  BAD_REQUEST: {
    /** 數據驗證失敗 */
    VALIDATION_FAILED: {
      code: 40001,
      name: "VALIDATION_FAILED",
      description: "數據驗證失敗：Request Body 格式錯誤或缺少必填欄位",
    },
    /** 日期範圍無效 */
    INVALID_DATE_RANGE: {
      code: 40002,
      name: "INVALID_DATE_RANGE",
      description: "日期範圍無效：開始日期不能晚於結束日期",
    },
    /** 不支援的報表類型 */
    UNSUPPORTED_REPORT_TYPE: {
      code: 40003,
      name: "UNSUPPORTED_REPORT_TYPE",
      description: "不支援的報表類型",
    },
    /** 不支援的匯出格式 */
    UNSUPPORTED_EXPORT_FORMAT: {
      code: 40004,
      name: "UNSUPPORTED_EXPORT_FORMAT",
      description: "不支援的匯出格式：僅支援 CSV 和 PDF",
    },
    /** 無效的 Mission 狀態 */
    INVALID_MISSION_STATUS: {
      code: 40005,
      name: "INVALID_MISSION_STATUS",
      description: "無效的 Mission 狀態",
    },
    /** ✅ 新增：無效的 Project ID */
    INVALID_PROJECT_ID: {
      code: 40006,
      name: "INVALID_PROJECT_ID",
      description: "缺少或無效的 ProjectID",
    },
  },

  /** 404 Not Found 錯誤碼 */
  NOT_FOUND: {
    /** Kanban 設定未找到 */
    KANBAN_SETTINGS_NOT_FOUND: {
      code: 40401,
      name: "KANBAN_SETTINGS_NOT_FOUND",
      description: "找不到指定的 Kanban 設定",
    },
    /** 報表未找到 */
    REPORT_NOT_FOUND: {
      code: 40402,
      name: "REPORT_NOT_FOUND",
      description: "找不到指定的報表",
    },
    /** 專案未找到 */
    PROJECT_NOT_FOUND: {
      code: 40403,
      name: "PROJECT_NOT_FOUND",
      description: "找不到指定的專案",
    },
    /** Mission 未找到 */
    MISSION_NOT_FOUND: {
      code: 40404,
      name: "MISSION_NOT_FOUND",
      description: "找不到指定的 Mission",
    },
    /** 無資料 */
    NO_DATA_AVAILABLE: {
      code: 40405,
      name: "NO_DATA_AVAILABLE",
      description: "查詢期間內無可用資料",
    },
    /** ✅ 新增：一般資料未找到 */
    DATA_NOT_FOUND: {
      code: 40406,
      name: "DATA_NOT_FOUND",
      description: "查無對應的資料",
    },
  },

  /** 409 Conflict 錯誤碼 */
  CONFLICT: {
    /** Kanban 設定已存在 */
    KANBAN_SETTINGS_EXISTS: {
      code: 40901,
      name: "KANBAN_SETTINGS_EXISTS",
      description: "該使用者在此專案已有 Kanban 設定",
    },
  },

  /** 500 Internal Error 錯誤碼 */
  INTERNAL_ERROR: {
    /** 報表生成失敗 */
    REPORT_GENERATION_FAILED: {
      code: 50001,
      name: "REPORT_GENERATION_FAILED",
      description: "報表生成失敗：系統內部錯誤",
    },
    /** 指標計算失敗 */
    METRICS_CALCULATION_FAILED: {
      code: 50002,
      name: "METRICS_CALCULATION_FAILED",
      description: "指標計算失敗：系統內部錯誤",
    },
    /** 匯出失敗 */
    EXPORT_FAILED: {
      code: 50003,
      name: "EXPORT_FAILED",
      description: "報表匯出失敗：系統內部錯誤",
    },
    /** 資料庫操作失敗 */
    DATABASE_ERROR: {
      code: 50004,
      name: "DATABASE_ERROR",
      description: "資料庫操作失敗：系統內部錯誤",
    },
  },
} as const;

/**
 * BusinessError 類別
 * -------------------------------------------------
 * 用於在業務邏輯層（Services 層）中拋出統一的業務錯誤。
 * Controllers 層可捕捉此錯誤並回傳對應的 HTTP 狀態碼與錯誤訊息。
 */
export class BusinessError extends Error {
  /** 錯誤代碼（對應 DASHBOARD_ERROR_CODES 的 code） */
  public code: number;

  /** 錯誤名稱（對應 DASHBOARD_ERROR_CODES 的 name） */
  public name: string;

  /**
   * 建構子
   * @param message 錯誤訊息（給開發者或回傳給前端）
   * @param code 錯誤代碼
   * @param name 錯誤名稱
   */
  constructor(message: string, code: number, name: string) {
    super(message);
    this.code = code;
    this.name = name;
    Object.setPrototypeOf(this, BusinessError.prototype);
  }
}
