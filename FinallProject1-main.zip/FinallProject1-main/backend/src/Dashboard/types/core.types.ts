// 程式檔案: backend/src/types/core.types.ts
// 層次與職責: 核心型別定義層
// 核心職責: 定義全專案共用的核心型別和 ID 轉換函數

/**
 * CoreID 型別
 * 用於 JSON API 傳輸的 ID 格式 (字串)
 * 範例: "P_123", "U_456", "M_789"
 */
export type CoreID = string;

/**
 * ID 前綴對應表
 */
export const ID_PREFIXES = {
  User: "U",
  UserID: "U",
  AssigneeID: "U",
  CreatedBy: "U",
  UpdatedBy: "U",
  GeneratedBy: "U",
  CurrentUserID: "U",

  Project: "P",
  ProjectID: "P",

  Mission: "M",
  MissionID: "M",

  Role: "R",
  RoleID: "R",

  Notification: "N",
  NotificationID: "N",

  Metrics: "ME",
  MetricsID: "ME",
  Kanban: "K",
  KanbanID: "K",
  SettingsID: "KS",
  Workload: "W",
  WorkloadID: "W",
  Report: "RP",
  ReportID: "RP",

  Member: "MB",
  MemberID: "MB",
} as const;

/**
 * ✅ 將資料庫 ID (number) 轉換為 CoreID (string)
 */
export function toCoreId(
  dbId: number,
  idType: keyof typeof ID_PREFIXES
): CoreID {
  const prefix = ID_PREFIXES[idType];
  if (!prefix) throw new Error(`Unknown ID type: ${idType}`);
  return `${prefix}_${dbId}`;
}

/**
 * ✅ 改進版：允許傳入 "1" 或 "P_1"
 * 會自動判斷格式並轉換為正確的數字 ID
 */
export function toDBId(
  coreId: CoreID,
  idType: keyof typeof ID_PREFIXES
): number {
  const expectedPrefix = ID_PREFIXES[idType];
  if (!expectedPrefix) throw new Error(`Unknown ID type: ${idType}`);

  // 若是純數字，直接轉換
  if (/^\d+$/.test(coreId)) {
    return parseInt(coreId, 10);
  }

  // 若是 PREFIX_NUMBER 格式
  const parts = coreId.split("_");
  if (parts.length !== 2) {
    throw new Error(
      `Invalid CoreID format: ${coreId}. Expected format: PREFIX_NUMBER`
    );
  }

  const [prefix, idStr] = parts;
  if (prefix !== expectedPrefix) {
    throw new Error(
      `CoreID prefix mismatch: expected ${expectedPrefix}, got ${prefix} for ${idType}`
    );
  }

  const dbId = parseInt(idStr, 10);
  if (isNaN(dbId) || dbId <= 0) {
    throw new Error(`Invalid ID number in CoreID: ${coreId}`);
  }

  return dbId;
}

/**
 * 批次轉換
 */
export function toCoreIdArray(
  dbIds: number[],
  idType: keyof typeof ID_PREFIXES
): CoreID[] {
  return dbIds.map((id) => toCoreId(id, idType));
}

export function toDBIdArray(
  coreIds: CoreID[],
  idType: keyof typeof ID_PREFIXES
): number[] {
  return coreIds.map((id) => toDBId(id, idType));
}

/**
 * 驗證 CoreID 格式是否有效
 */
export function isValidCoreId(
  coreId: string,
  idType?: keyof typeof ID_PREFIXES
): boolean {
  if (/^\d+$/.test(coreId)) return true; // ✅ 新增：允許純數字
  const parts = coreId.split("_");
  if (parts.length !== 2) return false;

  const [prefix, idStr] = parts;
  if (idType && prefix !== ID_PREFIXES[idType]) return false;
  const dbId = parseInt(idStr, 10);
  return !isNaN(dbId) && dbId > 0;
}

/**
 * 從 CoreID 提取前綴
 */
export function extractPrefix(coreId: CoreID): string {
  if (/^\d+$/.test(coreId)) return ""; // 純數字沒有前綴
  const parts = coreId.split("_");
  if (parts.length !== 2)
    throw new Error(`Invalid CoreID format: ${coreId}`);
  return parts[0];
}

/**
 * 從 CoreID 提取數字 ID
 */
export function extractNumericId(coreId: CoreID): number {
  if (/^\d+$/.test(coreId)) return parseInt(coreId, 10); // ✅ 支援純數字
  const parts = coreId.split("_");
  if (parts.length !== 2)
    throw new Error(`Invalid CoreID format: ${coreId}`);

  const dbId = parseInt(parts[1], 10);
  if (isNaN(dbId) || dbId <= 0)
    throw new Error(`Invalid ID number in CoreID: ${coreId}`);

  return dbId;
}
