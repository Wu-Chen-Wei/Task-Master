// 檔案位置: backend/src/Dashboard/routes/dashboard.routes.ts
// 層次與職責: API 路由層 (Routes Layer)
// 核心職責: 定義 Dashboard 模組的 API 端點，並支援 JWT 驗證與角色權限控制

import { Router, Request, Response } from "express";
import { DashboardService } from "../services/dashboard.service";
import { RoleBasedDashboardService } from "../services/role-based-dashboard.service";
import mysql from "mysql2/promise";
import { BusinessError } from "../types/error.types";

/**
 * DashboardRoutesService
 * 負責處理 Dashboard 模組的所有 API 路由，並將請求委派給對應的 Service。
 */
export class DashboardRoutesService {
  private router: Router; // Express Router 實例，用於綁定路由
  private dashboardService: DashboardService; // 一般 Dashboard 業務邏輯
  private roleBasedDashboardService: RoleBasedDashboardService; // 基於角色的 Dashboard 業務邏輯
  private SYSTEM_USER_ID = "1"; // 系統預設使用者 ID（可能用於特殊情境）

  /**
   * 建構子
   * @param pool MySQL 連線池，用於資料庫操作
   * 初始化 Router 與 Service，並註冊所有路由
   */
  constructor(pool: mysql.Pool) {
    this.router = Router();
    this.dashboardService = new DashboardService(pool);
    this.roleBasedDashboardService = new RoleBasedDashboardService(pool);
    this.initializeRoutes(); // 註冊路由
  }

  /**
   * 初始化所有 Dashboard 相關路由
   * - /home: 基於角色的 Dashboard 首頁
   * - /projects/:projectId/kanban: Kanban 看板
   * - /missions/:missionId/status: 更新任務狀態
   * - /projects/:projectId/gantt: 甘特圖資料
   * - /missions/search: 任務搜尋與篩選
   * - /projects/:projectId/progress: 專案進度
   * - /projects/:projectId/progress/trend: 進度趨勢
   * - /projects/:projectId/tags/analysis: 標籤分析
   * - /projects/:projectId/priority/analysis: 優先級分佈
   * - /dashboard/:projectId: 取得指定專案 Dashboard
   */
  private initializeRoutes(): void {
    // ✨ 新增：基於角色的 Dashboard 首頁
    this.router.get("/home", this.getRoleBasedDashboard.bind(this));
    // ✅ 新增：取得完整 Dashboard 資料（包含我的任務、即將到期、最近活動）
    this.router.get("/overview", this.getDashboardOverview.bind(this));

    // 功能 1: Kanban 看板展示
    this.router.get(
      "/projects/:projectId/kanban",
      this.getKanbanBoard.bind(this)
    );
    this.router.put(
      "/missions/:missionId/status",
      this.updateMissionStatus.bind(this)
    );

    // 功能 2: 甘特圖視覺化
    this.router.get(
      "/projects/:projectId/gantt",
      this.getGanttChartData.bind(this)
    );

    // 功能 3: Mission 搜尋與篩選
    this.router.get("/missions/search", this.searchMissions.bind(this));

    // 功能 4: 進度追蹤圖表
    this.router.get(
      "/projects/:projectId/progress",
      this.getProjectProgress.bind(this)
    );
    this.router.get(
      "/projects/:projectId/progress/trend",
      this.getProgressTrend.bind(this)
    );

    // 功能 5: 熱門標籤與類型分析
    this.router.get(
      "/projects/:projectId/tags/analysis",
      this.analyzePopularTags.bind(this)
    );
    this.router.get(
      "/projects/:projectId/priority/analysis",
      this.analyzePriorityDistribution.bind(this)
    );

    // 新增：取得指定專案 Dashboard
    this.router.get("/dashboard/:projectId", this.getDashboardById.bind(this));
  }

  /**
   * 取得 Router 實例
   */
  public getRouter(): Router {
    return this.router;
  }

  /**
   * 🔐 從 JWT 或 Header 取得使用者 ID
   * @throws Error 當 JWT 中沒有 userID 時拋出錯誤
   */
  private getUserId(req: Request): string {
    if ((req as any).user && (req as any).user.userID) {
      return (req as any).user.userID.toString();
    }
    throw new Error("使用者 ID 並不存在，請確保認證正確。");
  }

  /**
   * 🔐 從 JWT 或 Header 取得使用者角色
   * @returns string 使用者角色，若不存在則回傳預設 "User"
   */
  private getUserRole(req: Request): string {
    const roles = (req as any).user?.roles;
    if (roles && roles.length > 0) {
      return roles[0]; // 假設第一個角色為主要角色
    }
    return "User"; // 預設角色
  }

  // ================================================================
  // ✨ 新功能：基於角色的 Dashboard 首頁
  // ================================================================

  /**
   * 🏠 基於角色的 Dashboard 首頁
   * GET /api/dashboard/home
   * 根據角色返回不同的 Dashboard 資料：
   * - Admin: 系統全局統計
   * - AccountAdmin: 使用者管理統計
   * - PM: 專案進度
   * - RDL: 團隊工作量 + 我的任務
   * - RD: 我被指派的任務
   * - QA: 待測試任務
   */
  private async getRoleBasedDashboard(
    req: Request,
    res: Response
  ): Promise<void> {
    try {
      const userId = this.getUserId(req);
      const userRole = this.getUserRole(req);
      const data = await this.roleBasedDashboardService.getUserDashboard(
        userId,
        userRole
      );
      res.json({ success: true, data });
    } catch (error: any) {
      console.error("[DashboardRoute] getRoleBasedDashboard error:", error);
      this.handleError(res, error);
    }
  }
  // ================================================================
  // ✨ 新功能：Dashboard 總覽（我的任務、即將到期、最近活動）
  // ================================================================

  /**
   * 📊 取得 Dashboard 總覽資料
   * GET /api/dashboard/overview
   * 包含：
   * - 系統總覽統計
   * - 我的任務摘要
   * - 即將到期提醒
   * - 最近活動
   * - 所有專案列表
   */
  // ✅ 新的
  private async getDashboardOverview(
    req: Request,
    res: Response
  ): Promise<void> {
    try {
      const userId = this.getUserId(req);
      const userRole = this.getUserRole(req); // ✅ 取得角色

      // ✅ 呼叫基於角色的服務
      const data = await this.roleBasedDashboardService.getUserDashboard(
        userId,
        userRole
      );

      res.json({ success: true, data });
    } catch (error: any) {
      console.error("[DashboardRoute] getDashboardOverview error:", error);
      this.handleError(res, error);
    }
  }

  // ================================================================
  // 功能 1: Kanban 看板展示
  // ================================================================

  /**
   * Kanban 看板資料
   * GET /projects/:projectId/kanban
   */
  private async getKanbanBoard(req: Request, res: Response): Promise<void> {
    try {
      const { projectId } = req.params;
      const userId = this.getUserId(req);
      const data = await this.dashboardService.getKanbanBoard(
        projectId,
        userId
      );
      res.json({ success: true, data });
    } catch (error: any) {
      console.error("[DashboardRoute] getKanbanBoard error:", error);
      this.handleError(res, error);
    }
  }

  /**
   * 更新任務狀態
   * PUT /missions/:missionId/status
   * @body status 任務狀態 (必填)
   */
  private async updateMissionStatus(
    req: Request,
    res: Response
  ): Promise<void> {
    try {
      const { missionId } = req.params;
      const { status } = req.body;
      const userId = this.getUserId(req);

      if (!status) {
        res.status(400).json({
          success: false,
          error: {
            code: 40001,
            name: "VALIDATION_FAILED",
            message: "缺少必填欄位: status",
          },
        });
        return;
      }

      await this.dashboardService.updateMissionStatus(
        missionId,
        status,
        userId
      );
      res.json({ success: true, message: "任務狀態更新成功" });
    } catch (error: any) {
      console.error("[DashboardRoute] updateMissionStatus error:", error);
      this.handleError(res, error);
    }
  }

  // ================================================================
  // 功能 2: 甘特圖視覺化
  // ================================================================

  /**
   * 甘特圖資料
   * GET /projects/:projectId/gantt
   */
  private async getGanttChartData(req: Request, res: Response): Promise<void> {
    try {
      const { projectId } = req.params;
      const data = await this.dashboardService.getGanttChartData(projectId);
      res.json({ success: true, data });
    } catch (error: any) {
      console.error("[DashboardRoute] getGanttChartData error:", error);
      this.handleError(res, error);
    }
  }

  // ================================================================
  // 功能 3: Mission 搜尋與篩選
  // ================================================================

  /**
   * 搜尋與篩選任務
   * GET /missions/search
   * 支援條件: projectId, assigneeId, status, priority, tags, keyword, startDate, endDate
   */
  private async searchMissions(req: Request, res: Response): Promise<void> {
    try {
      const {
        projectId,
        assigneeId,
        status,
        priority,
        tags,
        keyword,
        startDate,
        endDate,
      } = req.query;
      const filters: any = {};
      if (projectId) filters.projectId = projectId.toString();
      if (assigneeId) filters.assigneeId = assigneeId.toString();
      if (status) filters.status = status.toString();
      if (priority) filters.priority = priority.toString();
      if (tags) filters.tags = tags.toString().split(",");
      if (keyword) filters.keyword = keyword.toString();
      if (startDate) filters.startDate = startDate.toString();
      if (endDate) filters.endDate = endDate.toString();

      const data = await this.dashboardService.searchMissions(filters);
      res.json({ success: true, data });
    } catch (error: any) {
      console.error("[DashboardRoute] searchMissions error:", error);
      this.handleError(res, error);
    }
  }

  // ================================================================
  // 功能 4: 進度追蹤圖表
  // ================================================================

  /**
   * 專案進度資料
   * GET /projects/:projectId/progress
   */
  private async getProjectProgress(req: Request, res: Response): Promise<void> {
    try {
      const { projectId } = req.params;
      const { startDate, endDate } = req.query;
      const dateRange =
        startDate && endDate
          ? { startDate: startDate.toString(), endDate: endDate.toString() }
          : undefined;
      const data = await this.dashboardService.getProjectProgress(
        projectId,
        dateRange
      );
      res.json({ success: true, data });
    } catch (error: any) {
      console.error("[DashboardRoute] getProjectProgress error:", error);
      this.handleError(res, error);
    }
  }

  /**
   * 進度趨勢資料
   * GET /projects/:projectId/progress/trend
   * @query startDate, endDate (必填)
   */
  private async getProgressTrend(req: Request, res: Response): Promise<void> {
    try {
      const { projectId } = req.params;
      const { startDate, endDate } = req.query;
      if (!startDate || !endDate) {
        res.status(400).json({
          success: false,
          error: {
            code: 40001,
            name: "VALIDATION_FAILED",
            message: "缺少必填參數: startDate 和 endDate",
          },
        });
        return;
      }
      const data = await this.dashboardService.getProgressTrend(projectId, {
        startDate: startDate.toString(),
        endDate: endDate.toString(),
      });
      res.json({ success: true, data });
    } catch (error: any) {
      console.error("[DashboardRoute] getProgressTrend error:", error);
      this.handleError(res, error);
    }
  }

  // ================================================================
  // 功能 5: 熱門標籤與類型分析
  // ================================================================

  /**
   * 熱門標籤分析
   * GET /projects/:projectId/tags/analysis
   */
  private async analyzePopularTags(req: Request, res: Response): Promise<void> {
    try {
      const { projectId } = req.params;
      const { startDate, endDate } = req.query;
      const dateRange =
        startDate && endDate
          ? { startDate: startDate.toString(), endDate: endDate.toString() }
          : undefined;
      const data = await this.dashboardService.analyzePopularTags(
        projectId,
        dateRange
      );
      res.json({ success: true, data });
    } catch (error: any) {
      console.error("[DashboardRoute] analyzePopularTags error:", error);
      this.handleError(res, error);
    }
  }

  /**
   * 優先級分佈分析
   * GET /projects/:projectId/priority/analysis
   */
  private async analyzePriorityDistribution(
    req: Request,
    res: Response
  ): Promise<void> {
    try {
      const { projectId } = req.params;
      const data = await this.dashboardService.analyzePriorityDistribution(
        projectId
      );
      res.json({ success: true, data });
    } catch (error: any) {
      console.error(
        "[DashboardRoute] analyzePriorityDistribution error:",
        error
      );
      this.handleError(res, error);
    }
  }

  /**
   * 取得指定專案 Dashboard
   * GET /dashboard/:projectId
   */
  private async getDashboardById(req: Request, res: Response): Promise<void> {
    try {
      const { projectId } = req.params;
      const userId = this.getUserId(req);
      const userRole = this.getUserRole(req);
      const data = await this.roleBasedDashboardService.getUserDashboard(
        userId,
        userRole
      );
      res.json({ success: true, data });
    } catch (error: any) {
      console.error("[DashboardRoute] getDashboardById error:", error);
      this.handleError(res, error);
    }
  }

  // ================================================================
  // 錯誤處理
  // ================================================================

  /**
   * 錯誤處理
   * @param error BusinessError 或一般錯誤
   * 根據錯誤類型返回對應的 HTTP 狀態碼與錯誤訊息
   */
  private handleError(res: Response, error: any): void {
    if (error instanceof BusinessError) {
      res.status(this.getHttpStatusFromErrorCode(error.code)).json({
        success: false,
        error: { code: error.code, name: error.name, message: error.message },
      });
    } else {
      res.status(500).json({
        success: false,
        error: { code: 50004, name: "DATABASE_ERROR", message: "系統內部錯誤" },
      });
    }
  }

  /**
   * 根據錯誤碼取得 HTTP 狀態碼
   * @param errorCode 業務錯誤碼
   * @returns number HTTP 狀態碼
   */
  private getHttpStatusFromErrorCode(errorCode: number): number {
    const firstDigit = Math.floor(errorCode / 10000);
    switch (firstDigit) {
      case 4:
        if (errorCode >= 40000 && errorCode < 40100) return 400;
        if (errorCode >= 40300 && errorCode < 40400) return 403;
        if (errorCode >= 40400 && errorCode < 40500) return 404;
        if (errorCode >= 40900 && errorCode < 41000) return 409;
        return 400;
      case 5:
        return 500;
      default:
        return 500;
    }
  }
}

/**
 * 工廠函數：建立 Dashboard 路由
 * @param pool MySQL 連線池
 * @returns Router 綁定所有 Dashboard API 的 Router
 */
export const Dashboard_createDashboardRoutes = (pool: mysql.Pool): Router => {
  const routesService = new DashboardRoutesService(pool);
  return routesService.getRouter();
};
