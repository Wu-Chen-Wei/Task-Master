// 📂 檔案：backend/src/middleware/auth.middleware.ts

import { Request, Response, NextFunction } from "express";
import { JWTUtil } from "../member/utils/jwt"; // ✅ 根據實際檔案位置調整路徑
import { JWTPayload } from "../member/types/auth.types"; // ✅ 根據實際檔案位置調整路徑

/**
 * 🔐 JWT 驗證中介層
 * 功能：
 * 1. 從 Header 中提取 Token
 * 2. 驗證 Token 合法性與有效性
 * 3. 將解出的使用者資訊掛載到 req.user
 */
export const authenticateToken = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers["authorization"];
  console.log("Authorization Header:", authHeader);  // 打印 Header
  const token = JWTUtil.extractTokenFromHeader(authHeader);
  console.log("Extracted Token:", token);  // 打印提取的 Token

  if (!token) {
  console.log("No token found in authorization header");  // Token 不存在
    return res
      .status(401)
      .json({ success: false, message: "缺少授權 Token，請重新登入" });
  }

  const payload = JWTUtil.verifyToken(token);
  console.log("JWT Payload:", payload);  // 打印 Token 解碼後的 payload

  if (!payload) {
    console.log("Invalid or expired JWT token");  // 無效或過期的 Token
    return res
      .status(403)
      .json({ success: false, message: "無效或過期的 Token" });
  }
  

  // Attach the user payload to the request object
  console.log("Attaching user to request:", payload);  // 附加 user 資料到 req
  (req as any).user = payload as JWTPayload; 


  console.log("JWT Authentication passed, proceeding to next middleware/route");
    next();  // 確保流轉到下一個中介軟體或路由處理
};
