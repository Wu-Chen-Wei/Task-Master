// backend/src/middleware/checkProjectMember.ts
import { Request, Response, NextFunction } from 'express';
import { pool } from '../config/db';

/**
 * 檢查使用者是否為專案成員
 * Admin 可以看所有專案
 */
export const checkProjectMember = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ success: false, message: '未登入' });
    }

    const userId = (user as any).userID;

    // ✅ 檢查是否為 Admin
    const [adminCheck] = await pool.query<any[]>(
      `SELECT COUNT(*) as isAdmin 
       FROM userglobalroles ugr
       JOIN roles r ON ugr.RoleID = r.RoleID
       WHERE ugr.UserID = ? AND r.RoleName = 'Admin'`,
      [userId]
    );

    // ✅ 如果是 Admin，直接通過
    if (adminCheck[0].isAdmin > 0) {
      console.log('✅ Admin 使用者，跳過專案成員檢查');
      return next();
    }

    // ✅ 非 Admin，檢查是否為專案成員
    const missionId = req.params.id || req.params.missionId;

    // 查詢任務屬於哪個專案
    const [missions] = await pool.query<any[]>(
      'SELECT ProjectID FROM missions WHERE MissionID = ?',
      [missionId]
    );

    if (missions.length === 0) {
      return res.status(404).json({ success: false, message: '任務不存在' });
    }

    const projectId = missions[0].ProjectID;

    // 檢查使用者是否為該專案成員
    const [members] = await pool.query<any[]>(
      'SELECT * FROM projectmembers WHERE ProjectID = ? AND UserID = ?',
      [projectId, userId]
    );

    if (members.length === 0) {
      return res.status(403).json({ 
        success: false, 
        message: '您不是此專案成員' 
      });
    }

    next();
  } catch (error) {
    console.error('❌ 檢查專案成員錯誤:', error);
    res.status(500).json({ success: false, message: '權限檢查失敗' });
  }
};