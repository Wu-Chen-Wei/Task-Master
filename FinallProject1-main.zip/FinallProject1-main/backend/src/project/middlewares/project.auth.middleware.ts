// 程式檔案：backend/src/project/middlewares/project.auth.middleware.ts

// 層次與職責：流程控制與前置處理層（Middleware Layer）[3]。

// 核心職責是實施 P1 專案狀態鎖定契約，在請求到達 Controller/Service 之前，檢查專案是否處於不可變 (Immutable) 狀態 [2, 3]。

// 核心契約與依賴：

// 1. P1 狀態鎖定契約：如果專案狀態為 Completed (50) 或 Archived (60)，則必須拋出 40901 錯誤碼 [4]。

// 2. ID 資料類型轉換契約：必須呼叫 toDBId 將 CoreID (string) 轉為 DB ID (number) [6]。

// ===============程式碼本體=================
import {Request, Response, NextFunction} from "express";
import * as mysql from "mysql2/promise";

import {ProjectModel} from "../models/project.model";
import {CoreID, ProjectDBRow} from "../types/project.types";
import {PROJECT_ERROR_CODES} from "../types/error.types";
import {PROJECT_STATE_IDS} from "../types/system.constants";
import {toDBId} from "../utils/id.converter";

/**
 * 標準化的業務錯誤類別 (Business Error)。
 * 包含標準錯誤碼 (code) 和名稱 (name)，用於回傳給 Controller 層 [7, 8]。
 */
class BusinessError extends Error {
  public code: number;
  public name: string;

  constructor(message: string, code: number, name: string) {
    super(message);
    this.code = code;
    this.name = name;
  }
}

/**
 * 實作 P1 專案狀態鎖定檢查的中介軟體工廠 [2, 3]。
 * 如果專案狀態為 Completed (50) 或 Archived (60)，則拒絕修改請求 [4]。
 * @param projectModel ProjectModel 實例
 * @returns Express 中介軟體函數
 */
export const projectAuthMiddleware = (projectModel: ProjectModel) => {
  return async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      // 假設 ProjectID 從路由參數中取得 (例如 /api/v1/projects/:projectId)
      const projectId = req.params.projectId as CoreID;
      if (!projectId) {
        // 如果沒有 ProjectID，則跳過此檢查（例如用於 POST /projects 建立請求）
        return next();
      }

      // 1. 執行 ID 轉換契約 [6]
      const dbProjectId = toDBId(projectId, "ProjectID");

      // 2. 取得專案數據，用於狀態檢查
      const projectDbRow: ProjectDBRow | null = await projectModel.findByID(
        dbProjectId
      );

      if (!projectDbRow) {
        // 如果找不到專案，應該讓 Controller/Service 處理 40401 錯誤 [4, 9]
        return next();
      }

      const stateId = projectDbRow.CurrentStateID;

      // 3. P1 狀態鎖定檢查 [3, 10]
      const immutableStates: number[] = [
        PROJECT_STATE_IDS.COMPLETED, // 50 [11, 12]
        PROJECT_STATE_IDS.ARCHIVED, // 60 [11, 12]
      ];

      if (immutableStates.includes(stateId)) {
        // 檢查失敗，拋出 40901 PROJECT_STATE_IMMUTABLE 錯誤 [4]
        const immutableError =
          PROJECT_ERROR_CODES.CONFLICT.PROJECT_STATE_IMMUTABLE;

        throw new BusinessError(
          `P1 狀態鎖定檢查失敗：專案狀態為 ${stateId}，禁止修改。`,
          immutableError.code,
          immutableError.name
        );
      }

      // 檢查通過，繼續執行下一個中介軟體或控制器
      next();
    } catch (error) {
      // 處理 BusinessError 或其他錯誤
      if (error instanceof BusinessError) {
        res
          .status(error.code >= 400 && error.code < 500 ? error.code : 400)
          .json({
            code: error.code,
            message: error.message,
          });
      } else {
        console.error("projectAuthMiddleware 發生內部錯誤:", error);
        res.status(500).json({
          code: 50000,
          message: "伺服器內部錯誤，無法執行狀態檢查",
        });
      }
    }
  };
};
