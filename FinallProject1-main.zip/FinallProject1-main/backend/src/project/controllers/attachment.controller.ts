// backend/src/project/controllers/attachment.controller.ts

import path from "path";
import fs from "fs"; // ⭐ 新增 fs 模組，用於檢查檔案是否存在
import {Request, Response} from "express";
import {
  AttachmentService,
  AttachmentCreationRequest,
} from "../services/attachment.service";
import {PROJECT_ERROR_CODES} from "../types/error.types";
import {ROLE_IDS} from "../types/system.constants";
import {CoreID} from "../types/project.types";

class BusinessError extends Error {
  public code: number;
  public name: string;
  constructor(message: string, code: number, name: string) {
    super(message);
    this.code = code;
    this.name = name;
  }
}

interface ServiceError extends Error {
  code?: number;
}

export class AttachmentController {
  constructor(private attachmentService: AttachmentService) {}

  private getPrimaryRoleIDFromNames(roles: string[]): number {
    const roleMap: {[key: string]: number} = {
      Admin: ROLE_IDS.ADMIN,
      PM: ROLE_IDS.PM,
      RDL: ROLE_IDS.RDL,
      RD: ROLE_IDS.RD,
      QA: ROLE_IDS.QA,
    };

    let highestRoleID = 0;
    for (const roleName of roles) {
      if (
        (roleMap[roleName] && roleMap[roleName] < highestRoleID) ||
        highestRoleID === 0
      ) {
        highestRoleID = roleMap[roleName];
      }
    }

    const forbiddenError = PROJECT_ERROR_CODES.FORBIDDEN;

    if (highestRoleID === 0) {
      throw new BusinessError(
        `無法解析使用者主要角色，權限不足。`,
        forbiddenError.code,
        forbiddenError.name
      );
    }

    return highestRoleID;
  }

  private handleServiceError(res: Response, error: ServiceError): void {
    const errorCode = error.code || 500;
    const errorMessage = error.message;
    let httpStatus: number;

    if (errorCode >= 40000 && errorCode < 50000) {
      httpStatus = Math.floor(errorCode / 100);
    } else if (errorCode >= 50000) {
      httpStatus = 500;
    } else {
      httpStatus = error.code || 500;
    }

    // 防止 Header 已經發送後再次發送
    if (!res.headersSent) {
      res.status(httpStatus).json({
        code: errorCode,
        message: errorMessage,
        name: (error as BusinessError).name || "SERVICE_ERROR",
      });
    }
  }

  createAttachment = async (req: Request, res: Response): Promise<void> => {
    try {
      const files = (req as any).files as Express.Multer.File[];
      const projectId = req.body.projectId as CoreID;
      const validationError = PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED;

      if (!projectId || !files || files.length === 0) {
        throw new BusinessError(
          `附件建立失敗：缺少 ProjectID 或檔案資訊。`,
          validationError.code,
          validationError.name
        );
      }

      const currentUserId = req.user!.userID.toString() as CoreID;
      const currentUserRole = this.getPrimaryRoleIDFromNames(req.user!.roles);

      const newAttachments = [];
      for (const file of files) {
        // ⭐ 這裡保留原本的解碼邏輯，因為這是從 Multer (binary) 讀進來的
        let originalFileName = Buffer.from(
          file.originalname,
          "latin1"
        ).toString("utf-8");

        const webAccessiblePath = `/uploads/${file.filename}`;
        const payload: AttachmentCreationRequest = {
          projectId: projectId,
          fileName: originalFileName,
          filePath: webAccessiblePath,
        };

        const newAttachmentDbRow =
          await this.attachmentService.createAttachment(
            payload,
            currentUserId,
            currentUserRole
          );

        newAttachments.push(newAttachmentDbRow);
      }

      res.status(201).json({
        success: true,
        data: newAttachments,
      });
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };

  softDeleteAttachment = async (req: Request, res: Response): Promise<void> => {
    try {
      const attachmentId = req.params.attachmentId as CoreID;

      if (!attachmentId) {
        const validationError =
          PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED;
        throw new BusinessError(
          `[ID Conversion Error] AttachmentID 必須是 string 類型。收到: ${attachmentId}`,
          validationError.code,
          validationError.name
        );
      }

      const currentUserId = req.user!.userID.toString() as CoreID;
      const currentUserRole = this.getPrimaryRoleIDFromNames(req.user!.roles);

      const success = await this.attachmentService.softDeleteAttachment(
        attachmentId,
        currentUserId,
        currentUserRole
      );

      if (success) {
        res.status(204).send();
      } else {
        const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND;
        throw new BusinessError(
          `刪除附件失敗：找不到指定的附件 ID: ${attachmentId}。`,
          notFoundError.code,
          notFoundError.name
        );
      }
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };

  // =========================================================
  // ⭐ 修正重點：下載附件方法
  // =========================================================
  downloadAttachment = async (req: Request, res: Response): Promise<void> => {
    try {
      const attachmentId = req.params.attachmentId as CoreID;
      const currentUserId = req.user!.userID.toString() as CoreID;
      const currentUserRole = this.getPrimaryRoleIDFromNames(req.user!.roles);

      const attachment = await this.attachmentService.getAttachmentById(
        attachmentId,
        currentUserId,
        currentUserRole
      );

      if (!attachment) {
        const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND;
        throw new BusinessError(
          notFoundError.description,
          notFoundError.code,
          notFoundError.name
        );
      }

      // ⭐ 修正 1: 更安全的路徑計算
      // 不要使用 replace，改用 path.basename 取出檔名，再組合成絕對路徑
      // 這樣無論 DB 存的是 "/uploads/file.txt" 還是 "uploads\file.txt" 都能正常運作
      const fileNameOnDisk = path.basename(attachment.filePath);
      const absoluteFilePath = path.join(
        process.cwd(),
        "uploads",
        fileNameOnDisk
      );

      // ⭐ 修正 2: 檢查檔案是否存在
      if (!fs.existsSync(absoluteFilePath)) {
        console.error(
          `[Download Error] File missing on disk: ${absoluteFilePath}`
        );
        throw new BusinessError(
          "伺服器上找不到實體檔案",
          404,
          "FILE_NOT_FOUND"
        );
      }

      // ⭐ 修正 3: 移除錯誤的二次解碼
      // DB 中的 attachment.fileName 已經是 UTF-8 (在 createAttachment 時轉過了)
      // 如果這裡再轉一次 Buffer.from(..., 'latin1')，中文就會變成亂碼或導致 Header 報錯
      const originalFileName = attachment.fileName;

      // URL 編碼用於 filename*=UTF-8''...
      const encodedFileName = encodeURIComponent(originalFileName);

      // 設定 Headers
      res.setHeader("Content-Type", "application/octet-stream");
      // 使用標準的 RFC 5987 格式，支援中文檔名
      res.setHeader(
        "Content-Disposition",
        `attachment; filename*=UTF-8''${encodedFileName}`
      );

      // 發送檔案
      res.sendFile(absoluteFilePath, (err) => {
        if (err) {
          console.error(`[Download Error] SendFile failed:`, err);
          // 只有當 Header 還沒送出時才回傳錯誤 JSON
          if (!res.headersSent) {
            this.handleServiceError(
              res,
              new Error("檔案讀取或傳輸失敗") as ServiceError
            );
          }
        }
      });
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };
}
