// 程式檔案：backend/src/project/controllers/project.controller.ts
// 層次與職責：請求協調與處理層（Controller Layer）。
// 核心職責是實作「功能分離」邏輯，根據 Request Body 內容，決定將請求路由到不同的服務 (CRUD, PM Transfer, RDL Stamp)。
// 核心契約：必須捕捉 Services 層拋出的 BusinessError (例如 40001, 40301, 40901, 50001) 並回傳適當的 HTTP 狀態碼。

import {Request, Response, NextFunction} from "express";
import {ProjectCrudService} from "../services/project.crud.service";
import {PmTransferService} from "../services/pm.transfer.service";
import {RdlStampService} from "../services/rdl.stamp.service";
import {PROJECT_ERROR_CODES} from "../types/error.types";
import {ROLE_IDS} from "../types/system.constants";
import {
  CoreID,
  ProjectObject,
  ProjectUpdateRequest,
  RdlStampRequest,
  PmTransferRequest,
  MemberActionRequest,
} from "../types/project.types";

/**
 * 標準化的業務錯誤類別 (Business Error)。
 */
class BusinessError extends Error {
  public code: number;
  public name: string;
  constructor(message: string, code: number, name: string) {
    super(message);
    this.code = code;
    this.name = name;
  }
}

/**
 * 標準化的業務錯誤介面，用於捕捉 Service 層拋出的錯誤。
 */
interface ServiceError extends Error {
  code?: number;
}

/**
 * ProjectController 負責接收和協調專案模組的所有 HTTP 請求。
 */
export class ProjectController {
  // 使用參數屬性來宣告和初始化服務實例，解決屬性缺失問題
  constructor(
    private crudService: ProjectCrudService,
    private pmTransferService: PmTransferService,
    private rdlStampService: RdlStampService
  ) {
    // 依賴注入契約：確保服務實例被儲存。
  }

  /**
   * 輔助方法：將角色名稱陣列 (string[]) 轉換為服務層所需的單一數字 RoleID (number)。
   */
  private getPrimaryRoleIDFromNames(roles: string[]): number {
    if (roles.includes("Admin")) return ROLE_IDS.ADMIN;
    if (roles.includes("PM")) return ROLE_IDS.PM;
    if (roles.includes("RDL")) return ROLE_IDS.RDL;
    if (roles.includes("RD")) return ROLE_IDS.RD;
    if (roles.includes("QA")) return ROLE_IDS.QA;
    return 0; // Default to no role
  }

  /**
   * 統一處理 Services 層拋出的錯誤，並回傳適當的 HTTP 狀態碼。
   */
  private handleServiceError(res: Response, error: ServiceError): void {
    const errorCode = error.code || 50000;
    const errorMessage = error.message || "伺服器內部錯誤。";
    const errorName = (error as BusinessError).name || "INTERNAL_SERVER_ERROR";

    let httpStatus: number;

    if (errorCode === 40401) {
      httpStatus = 404;
    } else if (errorCode >= 40000 && errorCode < 50000) {
      httpStatus = Math.floor(errorCode / 100);
    } else if (errorCode >= 50000) {
      httpStatus = 500;
    } else {
      httpStatus = 500;
    }

    // 統一回傳錯誤
    res.status(httpStatus).json({
      code: errorCode,
      message: errorMessage,
      name: errorName,
    });
  }

  // ===================================================================
  // GET /api/v1/projects 及其擴展 (數據獲取)
  // ===================================================================

  /**
   * 處理 GET /api/v1/projects/assignable 請求 (API 擴展 1)。
   * 獲取所有可指派的使用者清單。
   */
  getAssignableUsers = async (req: Request, res: Response): Promise<void> => {
    try {
      const users = await this.crudService.getAssignableUsersList();
      res.status(200).json({success: true, data: users});
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };

  /**
   * 處理 GET /api/v1/projects/:projectId/members 請求 (API 擴展 2)。
   * 獲取專案的完整成員清單 (用於詳情頁 Tab 4)。
   */
  getProjectMembersList = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    try {
      const projectId = req.params.projectId as CoreID;
      // 呼叫 crudService.getProjectMembersList
      const members = await this.crudService.getProjectMembersList(projectId);
      res.status(200).json({success: true, data: members});
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };

  /**
   * 處理 GET /api/v1/projects/:projectId/history 請求 (API 擴展 4)。
   * 獲取專案的所有歷史變動紀錄 (用於詳情頁 Tab 5)。
   */
  getProjectHistoryList = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    try {
      const projectId = req.params.projectId as CoreID;
      // 呼叫 crudService.getProjectHistoryList
      const history = await this.crudService.getProjectHistoryList(projectId);
      res.status(200).json({success: true, data: history});
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };

  /**
   * 處理 GET /api/v1/projects (標準專案列表) 請求。
   */
  getProjectsList = async (req: Request, res: Response): Promise<void> => {
    try {
      const {
        status,
        search,
        page,
        limit,
        sortBy,
        sortOrder,
        tagId,
        assignedToUserId,
      } = req.query;
      const currentUserId = req.user!.userID.toString() as CoreID;
      const currentUserRole = this.getPrimaryRoleIDFromNames(req.user!.roles);

      const filters = {
        status,
        search,
        page,
        limit,
        sortBy,
        sortOrder,
        tagId,
        assignedToUserId,
      } as any;

      // 實施 Assigned Read
      const result = await this.crudService.getProjectsList(
        filters,
        currentUserRole,
        currentUserId,
        false
      );

      res
        .status(200)
        .json({success: true, data: result.data, meta: result.meta});
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };

  /**
   * 處理 GET /api/v1/projects/all (PM/Admin 專門獲取全部專案) 請求。
   */
  getAllProjectsList = async (req: Request, res: Response): Promise<void> => {
    try {
      const {
        status,
        search,
        page,
        limit,
        sortBy,
        sortOrder,
        tagId,
        assignedToUserId,
      } = req.query;
      const currentUserId = req.user!.userID.toString() as CoreID;
      const currentUserRole = this.getPrimaryRoleIDFromNames(req.user!.roles);

      const filters = {
        status,
        search,
        page,
        limit,
        sortBy,
        sortOrder,
        tagId,
        assignedToUserId,
      } as any;

      // 強制忽略 Assigned Read，獲取所有專案
      const result = await this.crudService.getProjectsList(
        filters,
        currentUserRole,
        currentUserId,
        true
      );

      res
        .status(200)
        .json({success: true, data: result.data, meta: result.meta});
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };

  /**
   * 處理 GET /api/v1/projects/{projectID} (讀取單一專案) 請求。
   * 傳遞使用者上下文 (ID/Role) 以觸發 30 -> 40 自動流轉 (GET Side Effect)。
   */
  getProjectById = async (req: Request, res: Response): Promise<void> => {
    try {
      const projectId = req.params.projectId as CoreID;

      // 1. 獲取使用者 ID 和主要角色
      const currentUserId = req.user!.userID.toString() as CoreID;
      const currentUserRole = this.getPrimaryRoleIDFromNames(req.user!.roles);

      // 2. 傳遞使用者資訊給 Service 層
      const project = await this.crudService.getProjectById(
        projectId,
        currentUserId,
        currentUserRole
      );

      res.status(200).json({success: true, data: project});
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };

  // ===================================================================
  // POST/PATCH/DELETE 及其擴展
  // ===================================================================

  /**
   * 處理 POST /api/v1/projects (建立新專案) 請求。
   */
  createProject = async (req: Request, res: Response): Promise<void> => {
    try {
      const currentUserId = req.user!.userID.toString() as CoreID;

      const newProject = await this.crudService.createProject(
        req.body,
        currentUserId
      );

      // 建立成功回傳 201 Created
      res.status(201).json({success: true, data: newProject});
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };

  /**
   * 處理 PATCH /api/v1/projects/{projectID} (更新專案) 請求。
   * 遵循功能分離契約：負責將請求路由到 CRUD, PM Transfer 或 RDL Stamp 服務。
   */
  updateProject = async (req: Request, res: Response): Promise<void> => {
    try {
      const projectId = req.params.projectId as CoreID;
      const payload = req.body;
      const currentUserId = req.user!.userID.toString() as CoreID;
      const currentUserRole = this.getPrimaryRoleIDFromNames(req.user!.roles);

      let updatedProject: ProjectObject;

      // 1. 功能分離：檢查是否為 RDL 蓋章
      if (
        "rdlApproved" in payload &&
        (payload as RdlStampRequest).rdlApproved === true
      ) {
        const rdlStampPayload = payload as RdlStampRequest;
        // rdlStampService.stampProject 回傳 ProjectDBRow
        const dbRow = await this.rdlStampService.stampProject(
          projectId,
          rdlStampPayload,
          currentUserId,
          currentUserRole
        );
        // 修正點：使用 crudService 的 mapToProjectObject 轉換 DBRow 為 DTO
        updatedProject = this.crudService.mapToProjectObject(dbRow);
      }
      // 2. 功能分離：檢查是否為 PM 轉讓
      else if (
        "ownerUserID" in payload &&
        typeof payload.ownerUserID === "string"
      ) {
        const pmTransferPayload = payload as PmTransferRequest;
        // pmTransferService.transferProject 回傳 ProjectObject
        updatedProject = await this.pmTransferService.transferProject(
          projectId,
          pmTransferPayload,
          currentUserId,
          currentUserRole
        );
      }
      // 3. 功能分離：檢查是否為手動狀態轉換 (10 -> 20 或 20 -> 30)
      else if (
        "targetStateId" in payload &&
        typeof payload.targetStateId === "number"
      ) {
        const targetStateId = payload.targetStateId as number;
        // crudService.transitionProjectState 回傳 ProjectObject
        updatedProject = await this.crudService.transitionProjectState(
          projectId,
          currentUserId,
          currentUserRole,
          targetStateId
        );
      }
      // 4. 執行一般欄位更新 (CRUD)
      else {
        // crudService.updateProject 回傳 ProjectObject
        updatedProject = await this.crudService.updateProject(
          projectId,
          payload as ProjectUpdateRequest,
          currentUserId,
          currentUserRole
        );
      }

      res.status(200).json({success: true, data: updatedProject});
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };

  /**
   * 處理 POST /api/v1/projects/:projectId/members (新增或更新專案成員) 請求。
   */
  addProjectMember = async (req: Request, res: Response): Promise<void> => {
    try {
      const projectId = req.params.projectId as CoreID;
      const payload: MemberActionRequest = req.body;
      const currentUserId = req.user!.userID.toString() as CoreID;
      const currentUserRole = this.getPrimaryRoleIDFromNames(req.user!.roles);

      await this.crudService.addProjectMember(
        projectId,
        payload,
        currentUserId,
        currentUserRole
      );

      res.status(200).json({success: true, message: "專案成員新增/更新成功。"});
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };

  /**
   * 處理 DELETE /api/v1/projects/:projectId/members/:userId (移除專案成員) 請求。
   */
  removeProjectMember = async (req: Request, res: Response): Promise<void> => {
    try {
      const projectId = req.params.projectId as CoreID;
      // 從 URL 參數中讀取要移除的 userId (CoreID / string)
      const userIdToRemove = req.params.userId as CoreID;

      if (!userIdToRemove) {
        const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND;
        throw new BusinessError(
          `刪除失敗：缺少成員 ID 參數。`,
          notFoundError.code,
          notFoundError.name
        );
      }

      // 修正點：構造 MemberActionRequest Payload，解決類型不匹配
      const payload: MemberActionRequest = {userId: userIdToRemove};

      const currentUserId = req.user!.userID.toString() as CoreID;
      const currentUserRole = this.getPrimaryRoleIDFromNames(req.user!.roles);

      const success = await this.crudService.removeProjectMember(
        projectId,
        payload, // 傳遞構造好的 Payload
        currentUserId,
        currentUserRole
      );

      if (success) {
        res.status(204).send(); // 成功刪除回傳 204 No Content
      } else {
        const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND;
        throw new BusinessError(
          `找不到專案成員 ID: ${userIdToRemove}。`,
          notFoundError.code,
          notFoundError.name
        );
      }
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };

  /**
   * 處理 50 -> 60 PM 歸檔的受控例外流轉 (PATCH /archive 路由)。
   */
  archiveProject = async (req: Request, res: Response): Promise<void> => {
    try {
      const projectId = req.params.projectId as CoreID;
      const currentUserId = req.user!.userID.toString() as CoreID;
      const currentUserRole = this.getPrimaryRoleIDFromNames(req.user!.roles);

      // crudService 實作狀態 50 -> 60 的例外流轉邏輯和 P3 權限檢查
      const updatedProject = await this.crudService.archiveProject(
        projectId,
        currentUserId,
        currentUserRole
      );

      res.status(200).json({success: true, data: updatedProject});
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };

  /**
   * 處理 DELETE /api/v1/projects/{projectID} (專案軟刪除) 請求。
   */
  softDeleteProject = async (req: Request, res: Response): Promise<void> => {
    try {
      const projectId = req.params.projectId as CoreID;
      const currentUserId = req.user!.userID.toString() as CoreID;
      const currentUserRole = this.getPrimaryRoleIDFromNames(req.user!.roles);

      const success = await this.crudService.softDeleteProject(
        projectId,
        currentUserId,
        currentUserRole
      );

      if (success) {
        res.status(204).send(); // 刪除成功，回傳 204 No Content
      } else {
        const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND;
        throw new BusinessError(
          notFoundError.description,
          notFoundError.code,
          notFoundError.name
        );
      }
    } catch (error) {
      this.handleServiceError(res, error as ServiceError);
    }
  };
}
