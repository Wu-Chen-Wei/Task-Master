// 程式檔案：backend/src/project/services/rdl.stamp.service.ts
// 層次與職責：核心業務邏輯與事務層（Services Layer）。
// 核心職責：實作 RDL 蓋章 (RDL Stamp) 的 C1-C3 聚合查詢驗證，並更新 Projects 表。
// 核心契約與依賴：
// 1. C1 狀態檢查：Project.CurrentStateID 必須為 40 (ReadyForClosure)。
// 2. C2 角色檢查：當前使用者 Role 必須是 RDL (ID=4) 且為專案成員。
// 3. C3 任務審計聚合：必須驗證專案下的所有 Missions 都已通過 QA 擔保。
// 4. 原子更新契約：C1-C3 通過後，必須將 Projects.CurrentStateID 從 40 **原子性地** 轉換到 50 (Completed)，並更新 RDLApprovedByUserID/At。
// 5. 歷史記錄契約：必須寫入 RDL_STAMP 和 STATE_TRANSITION 兩種類型的歷史記錄。
// 6. 錯誤碼契約：C1/C3 失敗拋出 40002 RDL_STAMP_FAILED；C2 失敗拋出 40301 PERMISSION_DENIED。

// ===============程式碼本體=================

import * as mysql from "mysql2/promise";
import {ProjectModel} from "../models/project.model";
import {ProjectHistoryModel} from "../models/project.history.model";
import {ProjectDBRow, RdlStampRequest, CoreID} from "../types/project.types";
import {
  ROLE_IDS,
  PROJECT_STATE_IDS,
  MISSION_STATUS,
  HISTORY_CHANGE_TYPES,
} from "../types/system.constants";
import {PROJECT_ERROR_CODES} from "../types/error.types";
import {toDBId} from "../utils/id.converter";
import { db } from "../../Notification/services/db";

/**
 * 標準化的業務錯誤類別 (Business Error)。
 * 包含標準錯誤碼 (code) 和名稱 (name)，用於回傳給 Controller 層。
 */
class BusinessError extends Error {
  public code: number;
  public name: string;
  constructor(message: string, code: number, name: string) {
    super(message);
    this.code = code;
    this.name = name;
  }
}

/**
 * RdlStampService 專門負責 RDL 蓋章 (RDL Stamp) 的業務邏輯驗證。
 * 必須實施 C1-C3 聚合查詢驗證契約。
 */
export class RdlStampService {
  private pool: mysql.Pool;
  private projectModel: ProjectModel;
  private historyModel: ProjectHistoryModel;

  constructor(
    pool: mysql.Pool,
    projectModel: ProjectModel,
    historyModel: ProjectHistoryModel
  ) {
    this.pool = pool;
    this.projectModel = projectModel;
    this.historyModel = historyModel;
  }

  /**
   * 執行 RDL 蓋章流程。
   * 必須依序通過 C1 (狀態)、C2 (角色與指派)、C3 (任務審計聚合) 檢查。
   *
   * @param projectId 專案的 CoreID (string)
   * @param payload 請求體 (RdlStampRequest)
   * @param currentUserId 當前操作者 CoreID (string)
   * @param currentUserRole 當前操作者 RoleID (number)
   * @returns 更新後的 ProjectDBRow
   * @throws {BusinessError} 40401 (PROJECT_NOT_FOUND), 40301 (PERMISSION_DENIED), 40002 (RDL_STAMP_FAILED)
   */
  public async stampProject(
    projectId: CoreID,
    payload: RdlStampRequest,
    currentUserId: CoreID,
    currentUserRole: number
  ): Promise<ProjectDBRow> {
    // 1. 執行 ID 轉換契約：CoreID (string) -> DB INT (number)
    const dbProjectId = toDBId(projectId, "ProjectID");
    const dbCurrentUserId = toDBId(currentUserId, "RDLApprovedByUserID");

    // 2. 取得舊數據，用於驗證
    const projectDbRow = await this.projectModel.findByID(dbProjectId);
    const stampFailedError = PROJECT_ERROR_CODES.BAD_REQUEST.RDL_STAMP_FAILED; // 40002
    const forbiddenError = PROJECT_ERROR_CODES.FORBIDDEN; // 40301

    if (!projectDbRow) {
      const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND; // 40401
      throw new BusinessError(
        notFoundError.description,
        notFoundError.code,
        notFoundError.name
      );
    }

    // C1 檢查：專案狀態檢查 (State Check)
    const READY_FOR_CLOSURE = PROJECT_STATE_IDS.READY_FOR_CLOSURE; // 40
    if (projectDbRow.CurrentStateID !== READY_FOR_CLOSURE) {
      throw new BusinessError(
        `C1 檢查失敗：專案狀態必須為 ReadyForClosure (${READY_FOR_CLOSURE})。`,
        stampFailedError.code,
        stampFailedError.name
      );
    }

    // C2 檢查：角色與指派檢查 (Role and Assignment Check)
    const RDL_ROLE_ID = ROLE_IDS.RDL;
    if (currentUserRole !== RDL_ROLE_ID) {
      throw new BusinessError(
        `C2 檢查失敗：只有 RDL (Role ID: ${RDL_ROLE_ID}) 有權執行蓋章操作。`,
        forbiddenError.code,
        forbiddenError.name
      );
    }

    // C2 嚴格指派檢查：確認 RDL 是 ProjectMembers 表中的成員
    const [memberRows] = await this.pool.query(
      `SELECT COUNT(*) as count FROM ProjectMembers WHERE ProjectID = ? AND UserID = ? AND RoleID = ?`,
      [dbProjectId, dbCurrentUserId, RDL_ROLE_ID]
    );

    const memberCount = (memberRows as Array<{count: number}>)[0].count;
    if (memberCount === 0) {
      throw new BusinessError(
        `C2 檢查失敗：用戶 ${currentUserId} 未被指派為專案 ${projectId} 的 RDL 成員。`,
        forbiddenError.code,
        forbiddenError.name
      );
    }

    // C3 檢查：任務審計聚合驗證 (Mission Audit Aggregation Check)
    const MISSION_CLOSED_STATUS = MISSION_STATUS.CLOSED; // 'Closed'
    const c3Sql = `
      SELECT
        COUNT(MissionID) AS count
      FROM
        Missions
      WHERE
        ProjectID = ?
      AND DeletedAt IS NULL
      AND (
        Status != ?
        OR QASignedByUserID IS NULL
      );
    `;

    const [results] = await this.pool.query(c3Sql, [
      dbProjectId,
      MISSION_CLOSED_STATUS,
    ]);

    const unAuditedMissionCount = (results as Array<{count: number}>)[0].count;
    if (unAuditedMissionCount > 0) {
      // C3 驗證失敗，拋出 RDL_STAMP_FAILED
      throw new BusinessError(
        `C3 檢查失敗：尚有 ${unAuditedMissionCount} 筆任務未通過 QA 審計或未結案。`,
        stampFailedError.code,
        stampFailedError.name
      );
    }

    // 3. 驗證成功：執行 Projects 表更新 (原子更新)
    const now = new Date().toISOString().slice(0, 19).replace("T", " ");
    const oldStateId = projectDbRow.CurrentStateID; // 應為 40
    const NEW_STATE_ID = PROJECT_STATE_IDS.COMPLETED; // 轉換到 50

    type ProjectUpdatePayload = Partial<
      Omit<ProjectDBRow, "ProjectID" | "CreatedAt" | "UpdatedAt" | "DeletedAt">
    >;

    const updateFields: ProjectUpdatePayload = {
      RDLApprovedByUserID: dbCurrentUserId,
      RDLApprovedAt: now,
      // ⭐ 核心修正：將狀態從 40 轉換到 50
      CurrentStateID: NEW_STATE_ID,
    };

    const updateSuccess = await this.projectModel.update(
      dbProjectId,
      updateFields
    );

    if (!updateSuccess) {
      // 內部錯誤，可能因 DB 連線或鎖定問題
      throw new BusinessError(
        "RDL 蓋章失敗：資料庫更新操作未成功。",
        500,
        "INTERNAL_DB_ERROR"
      );
    }

    // ---------------- 查使用者姓名 ----------------
        const [userRows] = await db.execute<any[]>(
          "SELECT ProjectName FROM projects WHERE ProjectID = ? LIMIT 1",
          [dbProjectId]
        );
    
        const projectName = userRows.length > 0 ? userRows[0].ProjectName : "未知使用者";

        // ---------------- 查使用者姓名 ----------------
        const [userRows1] = await db.execute<any[]>(
          "SELECT FullName FROM users WHERE UserID = ? LIMIT 1",
          [currentUserId]
        );

        const currentUserName = userRows1.length > 0 ? userRows1[0].FullName : "未知使用者";

    // 4. 記錄歷史：RDL_STAMP (RDL 蓋章資訊)
    const RDL_STAMP_TYPE = HISTORY_CHANGE_TYPES.RDL_STAMP;
    await this.historyModel.recordChange({
      ProjectID: dbProjectId,
      ChangedByUserID: dbCurrentUserId,
      ChangeType: RDL_STAMP_TYPE,
      Detail: `RDL ${currentUserId} 對專案執行最終蓋章確認。`,
      OldValue: null,
      NewValue: JSON.stringify({
        RDLApprovedByUserID: dbCurrentUserId,
        RDLApprovedAt: updateFields.RDLApprovedAt,
      }),
    },
    // --------------------------通知模組-------------------------------
      {
        UserID: 1,
        ProjectID: dbProjectId,
        MissionID: null,
        Content: `RDL ${currentUserName} 對專案[${projectName}]執行最終蓋章確認。`,
        IsRead: 0,
      },
      "RDL_stamp"
      // ----------------------------------------------------------------
    );

    // ⭐ 新增歷史記錄：STATE_TRANSITION (狀態 40 -> 50 變更)
    const STATE_TRANSITION_TYPE = HISTORY_CHANGE_TYPES.STATE_TRANSITION;
    await this.historyModel.recordChange({
      ProjectID: dbProjectId,
      ChangedByUserID: dbCurrentUserId,
      ChangeType: STATE_TRANSITION_TYPE,
      Detail: `RDL蓋章，狀態從 ${oldStateId} 轉換到 ${NEW_STATE_ID} (Completed)。`,
      OldValue: String(oldStateId),
      NewValue: String(NEW_STATE_ID),
    },
    // --------------------------通知模組-------------------------------
    {
      UserID: 1,
      ProjectID: dbProjectId,
      MissionID: null,
      Content: `RDL ${currentUserName} 對專案[${projectName}]執行最終蓋章確認。`,
      IsRead: 0,
    },
    "RDL_stamp"
    // ----------------------------------------------------------------
  );

    // 5. 返回更新後的 ProjectDBRow
    const updatedProject = await this.projectModel.findByID(dbProjectId);
    if (!updatedProject) {
      const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND;
      throw new BusinessError(
        notFoundError.description,
        notFoundError.code,
        notFoundError.name
      );
    }

    return updatedProject;
  }
}
