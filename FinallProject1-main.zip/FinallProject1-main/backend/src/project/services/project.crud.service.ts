// 程式檔案：backend/src/project/services/project.crud.service.ts
// 層次與職責：核心業務邏輯與事務層（Services Layer）[22]。
// 核心職責是處理 Projects 表的一般 CRUD 業務邏輯，實施權限檢查，並對讀取到的數據進行組裝 [22]。
// 此外，由於 ProjectMembers 表缺乏 Models Layer，此 Service 負責所有 ProjectMembers 的 Raw SQL 寫入 [22]。
// 核心契約與依賴：
// 1. 狀態流轉契約：實作 10->20->30 的手動流轉，和 30->40 的自動流轉 (GET Side Effect) [23, 24]。
// 2. RDL 權限檢查 (C2 變體)：20->30 必須驗證 RDL 角色 [25]。
// 3. 縱深防禦契約：POST 建立專案時，必須檢查 ownerUserID 等角色有效性 (40001) [22]。
// 4. 歷史記錄契約：所有狀態流轉必須寫入 ProjectHistory，ChangeType 為 STATE_TRANSITION [22]。
// 5. P3/P6 權限檢查契約：驗證使用者是否有權編輯專案或管理成員 (Admin 或 PM Owner / Admin/PM/RDL) [26, 27]。
// ===============程式碼本體=================

import * as mysql from "mysql2/promise";
import {
  ProjectModel,
  ProjectListFilters as ModelProjectListFilters,
} from "../models/project.model";
import {
  ProjectHistoryModel,
  ProjectHistoryDBRow,
} from "../models/project.history.model"; // 引入 ProjectHistoryDBRow
import {
  ProjectDBRow,
  ProjectObject,
  ProjectUpdateRequest,
  CoreID,
  MemberActionRequest,
  AssignableUserObject, // ⭐ 新增導入
  ProjectMemberObject, // ⭐ 新增導入
  ProjectHistoryObject, // ⭐ 新增導入
  AttachmentObject, // 【新增導入】
  MissionSummary, // 【新增導入】
} from "../types/project.types";
import {
  PROJECT_STATE_IDS,
  HISTORY_CHANGE_TYPES,
  ROLE_IDS,
  MISSION_STATUS,
} from "../types/system.constants";
import {PROJECT_ERROR_CODES} from "../types/error.types";
import {toDBId, toCoreId} from "../utils/id.converter";
import {log} from "console"; // 假設 log 是為了調試目的 [28]
import {db} from "../../Notification/services/db"; // 假設 db 是 Notification 模組的依賴
import {
  ProjectAttachmentModel,
  AttachmentDBRow,
} from "../models/project.attachment.model"; // 【新增】引入 Attachment Model [5, 6]

/**
 * 標準化的業務錯誤類別 (Business Error)。
 * 包含標準錯誤碼 (code) 和名稱 (name)，用於回傳給 Controller 層 [10]。
 */
class BusinessError extends Error {
  constructor(message: string, public code: number, public name: string) {
    super(message);
    this.code = code;
    this.name = name;
  }
}

/**
 * 專案列表篩選條件 [1]。
 */
export interface ProjectListFilters {
  status?: number;
  search?: string;
  assignedToUserId?: number; // 原始欄位，Service Layer 內部設定

  // ⭐ 新增：分頁與排序 (Pagination & Sorting)
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: "ASC" | "DESC";

  // ⭐ 新增：標籤篩選 (Tag Filter)
  tagId?: number; // Projects.ProjectTagID
}

/**
 * 專案建立請求 Payload 介面 [1]。
 */
interface ProjectCreationRequest extends ProjectObject {
  rdlUserId: CoreID;
  rdUserIds: CoreID[];
  qaUserIds: CoreID[];
}

// ----------------------------------------------------------------
// 核心 Service 類別 [10]
// ----------------------------------------------------------------

export interface PaginationMeta {
  totalProjects: number;
  totalPages: number;
  currentPage: number;
}

/**
 * ProjectCrudService 負責專案的一般 CRUD 操作和狀態流轉邏輯 [1]。
 */
export class ProjectCrudService {
  private pool: mysql.Pool;
  private projectModel: ProjectModel;
  private historyModel: ProjectHistoryModel;
  private attachmentModel: ProjectAttachmentModel; // 【修正/新增】在建構子中注入並儲存

  constructor(
    pool: mysql.Pool,
    projectModel: ProjectModel,
    historyModel: ProjectHistoryModel,
    attachmentModel: ProjectAttachmentModel // 【修正/新增】在建構子中注入並儲存
  ) {
    this.pool = pool;
    this.projectModel = projectModel;
    this.historyModel = historyModel;
    this.attachmentModel = attachmentModel; // 【修正】儲存實例
  }

  /**
   * 輔助方法：將資料庫 ProjectDBRow 轉換為 ProjectObject。
   * 遵循 ID 資料類型轉換契約 [11]。
   */
  public mapToProjectObject(dbRow: ProjectDBRow): ProjectObject {
    return {
      projectID: toCoreId(dbRow.ProjectID),
      projectName: dbRow.ProjectName,
      description: dbRow.Description,
      ownerUserID: toCoreId(dbRow.OwnerUserID),
      ownerName: dbRow.OwnerName,
      startDate: dbRow.StartDate,
      endDate: dbRow.EndDate,
      currentStateID: dbRow.CurrentStateID,
      rdlApprovedByUserID: dbRow.RDLApprovedByUserID
        ? toCoreId(dbRow.RDLApprovedByUserID)
        : null,
      rdlApprovedByName: dbRow.RDLApprovedByName,
      rdlApprovedAt: dbRow.RDLApprovedAt,
      projectTagID: dbRow.ProjectTagID,
      deletedAt: dbRow.DeletedAt,
    } as ProjectObject;
  }

  /**
   * P3 權限檢查：驗證使用者是否有權編輯專案 (Admin 或 PM Owner) [11]。
   * @throws {BusinessError} 40301 PERMISSION_DENIED [12]。
   */
  private checkP3Permission(
    projectDbRow: ProjectDBRow,
    currentUserId: CoreID,
    currentUserRole: number
  ): void {
    const currentDbId = toDBId(currentUserId, "CurrentUserID");
    const forbiddenError = PROJECT_ERROR_CODES.FORBIDDEN; // 40301 [11]

    if (currentUserRole === ROLE_IDS.ADMIN) {
      // Admin 豁免 [12]
      return;
    }

    if (
      currentUserRole === ROLE_IDS.PM &&
      projectDbRow.OwnerUserID === currentDbId
    ) {
      return; // PM Owner 允許 [12]
    }

    throw new BusinessError(
      `P3 檢查失敗：用戶無權修改此專案。${forbiddenError.description}`,
      forbiddenError.code,
      forbiddenError.name
    );
  }

  /**
   * 【新增輔助方法】查詢專案中當前 RDL 的總人數
   * @param dbProjectId 資料庫 Project ID
   * @returns 當前 RDL 的數量 (number)
   */
  // 檢查rdl人數，避免rdl為空
  private async getRdlCount(dbProjectId: number): Promise<number> {
    const RDL_ROLE_ID = ROLE_IDS.RDL;
    const [rows] = await this.pool.query(
      `SELECT COUNT(*) as count FROM ProjectMembers WHERE ProjectID = ? AND RoleID = ?`,
      [dbProjectId, RDL_ROLE_ID]
    );
    return (rows as Array<{count: number}>)[0]?.count || 0;
  }

  // =========================================================
  // ⭐ 狀態流轉核心方法 (Workflow Transition Methods) [6]
  // =========================================================

  /**
   * 輔助方法：執行單一狀態轉換並記錄歷史。
   * 遵循歷史記錄契約：ChangeType 必須是 STATE_TRANSITION [7]。
   * @param projectDbRow 專案數據
   * @param newStateId 新的狀態 ID
   * @param currentUserId 當前操作者 CoreID
   * @param connection 可選的資料庫連線 (用於原子交易，此處未使用，但保持相容性)
   */
  private async transitionStateAndRecord(
    projectDbRow: ProjectDBRow,
    newStateId: number,
    currentUserId: CoreID,
    connection?: mysql.Connection
  ): Promise<ProjectDBRow | null> {
    const oldStateId = projectDbRow.CurrentStateID;
    const dbProjectId = projectDbRow.ProjectID;
    const changedByDbId = toDBId(currentUserId, "ChangedByUserID");

    // 1. 執行 Projects 表更新
    const updateSuccess = await this.projectModel.update(
      dbProjectId,
      {CurrentStateID: newStateId},
      connection
    );

    // ---------------- 查使用者姓名 ----------------
    const [userRows] = await db.execute<any[]>(
      "SELECT ProjectName FROM projects WHERE ProjectID = ? LIMIT 1",
      [dbProjectId]
    );

    const projectName =
      userRows.length > 0 ? userRows[0].ProjectName : "未知使用者";

    if (updateSuccess) {
      // 2. 記錄歷史：STATE_TRANSITION
      await this.historyModel.recordChange(
        {
          ProjectID: dbProjectId,
          ChangedByUserID: changedByDbId,
          ChangeType: HISTORY_CHANGE_TYPES.STATE_TRANSITION,
          Detail: `專案狀態從 ${oldStateId} 轉換到 ${newStateId}。`,
          OldValue: String(oldStateId),
          NewValue: String(newStateId),
        },
        // --------------------------通知模組-------------------------------
        {
          UserID: 1,
          ProjectID: dbProjectId,
          MissionID: null,
          Content: `[${projectName}]專案狀態從 ${oldStateId} 轉換到 ${newStateId}。`,
          IsRead: 0,
        },
        "project_status_changed",
        // ----------------------------------------------------------------
        connection
      );

      // 3. 重新讀取並返回更新後的數據
      return this.projectModel.findByID(dbProjectId);
    }
    return null;
  }

  /**
   * 實作手動狀態轉換 (10 -> 20 -> 30) 邏輯 [7, 8]。
   * @param projectId 專案 ID
   * @param currentUserId 當前使用者 ID
   * @param currentUserRole 當前使用者角色
   * @param targetStateId 目標狀態 ID (20 或 30)
   * @returns 更新後的 ProjectObject
   * @throws {BusinessError} 40301 (PERMISSION_DENIED), 40001 (VALIDATION_FAILED)
   */
  public async transitionProjectState(
    projectId: CoreID,
    currentUserId: CoreID,
    currentUserRole: number,
    targetStateId: number
  ): Promise<ProjectObject> {
    const dbProjectId = toDBId(projectId, "ProjectID");
    const oldProjectDbRow = await this.projectModel.findByID(dbProjectId);
    const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND; // 40401
    const forbiddenError = PROJECT_ERROR_CODES.FORBIDDEN; // 40301
    const validationError = PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED; // 40001

    if (!oldProjectDbRow) {
      throw new BusinessError(
        notFoundError.description,
        notFoundError.code,
        notFoundError.name
      );
    }

    const currentState = oldProjectDbRow.CurrentStateID;
    let isPermissionGranted = false;

    // 10 -> 20 (PM 啟動) 檢查 [7]
    if (targetStateId === PROJECT_STATE_IDS.PendingReview) {
      if (currentState !== PROJECT_STATE_IDS.UNSTARTED) {
        throw new BusinessError(
          `狀態轉換失敗：專案必須是 UNSTARTED (${PROJECT_STATE_IDS.UNSTARTED}) 才能轉換到 PendingReview (20)。`,
          validationError.code,
          validationError.name
        );
      }
      // 檢查 PM 權限 (P3 檢查)
      this.checkP3Permission(oldProjectDbRow, currentUserId, currentUserRole);
      isPermissionGranted = true;
    }
    // 20 -> 30 (RDL 啟動) 檢查 [7]
    else if (targetStateId === PROJECT_STATE_IDS.Active) {
      if (currentState !== PROJECT_STATE_IDS.PendingReview) {
        throw new BusinessError(
          `狀態轉換失敗：專案必須是 PendingReview (${PROJECT_STATE_IDS.PendingReview}) 才能轉換到 Active (30)。`,
          validationError.code,
          validationError.name
        );
      }

      // ⭐ C2 變體檢查：必須是 RDL (ID: 4) 角色 [7, 8]
      const RDL_ROLE_ID = ROLE_IDS.RDL;
      if (currentUserRole !== RDL_ROLE_ID) {
        throw new BusinessError(
          `C2 檢查失敗：只有 RDL (Role ID: ${RDL_ROLE_ID}) 有權執行 ${currentState} -> ${targetStateId} 的狀態轉換。`,
          forbiddenError.code,
          forbiddenError.name
        );
      }
      isPermissionGranted = true;
    } else {
      throw new BusinessError(
        `狀態轉換失敗：不支援從 ${currentState} 手動轉換到目標狀態 ${targetStateId}。`,
        validationError.code,
        validationError.name
      );
    }

    // 執行狀態轉換 (若通過權限檢查)
    if (isPermissionGranted) {
      const updatedProject = await this.transitionStateAndRecord(
        oldProjectDbRow,
        targetStateId,
        currentUserId
      );
      if (!updatedProject) {
        throw new Error("狀態更新失敗。");
      }
      return this.mapToProjectObject(updatedProject);
    }

    throw new BusinessError(
      `狀態轉換失敗：流程或權限錯誤。`,
      forbiddenError.code,
      forbiddenError.name
    );
  }

  /**
   * 實作 PM 歸檔的受控例外流轉 (50 -> 60) [13, 14]。
   * 此操作規避了 P1 鎖定，只允許 PM 執行 [13]。
   * @param projectId 專案 ID
   * @param currentUserId 當前使用者 ID
   * @param currentUserRole 當前使用者角色
   * @returns 更新後的 ProjectObject
   */
  public async archiveProject(
    projectId: CoreID,
    currentUserId: CoreID,
    currentUserRole: number
  ): Promise<ProjectObject> {
    const dbProjectId = toDBId(projectId, "ProjectID");
    const oldProjectDbRow = await this.projectModel.findByID(dbProjectId);
    const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND; // 40401

    if (!oldProjectDbRow) {
      throw new BusinessError(
        notFoundError.description,
        notFoundError.code,
        notFoundError.name
      );
    }

    // 檢查：狀態必須是 Completed (50) 才能歸檔 [14]
    if (oldProjectDbRow.CurrentStateID !== PROJECT_STATE_IDS.COMPLETED) {
      const validationError = PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED; // 40001
      throw new BusinessError(
        `歸檔失敗：專案狀態必須是 Completed (${PROJECT_STATE_IDS.COMPLETED}) 才能歸檔。`,
        validationError.code,
        validationError.name
      );
    }

    // 執行 P3 檢查 (Admin 豁免，PM Owner 允許) [11]
    this.checkP3Permission(oldProjectDbRow, currentUserId, currentUserRole);

    // 執行狀態流轉 50 -> 60 (ARCHIVED) [13]
    const updatedProject = await this.transitionStateAndRecord(
      oldProjectDbRow,
      PROJECT_STATE_IDS.ARCHIVED,
      currentUserId
    );

    if (!updatedProject) {
      throw new Error("歸檔狀態更新失敗。");
    }
    return this.mapToProjectObject(updatedProject);
  }

  /**
   * C3 聚合檢查的核心 SQL 邏輯，用於驗證 Mission 審計狀態 [15]。
   * 此邏輯用於實作 30 -> 40 的自動流轉 [16]。
   * @param dbProjectId 資料庫 Project ID
   * @returns 未審計 Mission 的數量 (number)
   */
  private async checkC3MissionAggregation(
    dbProjectId: number
  ): Promise<number> {
    // C3 核心 SQL 驗證：查詢是否存在任何「未 Closed」或「未 QASigned」的 Mission [15]。
    const MISSION_CLOSED_STATUS = MISSION_STATUS.CLOSED; // 'Closed' [6]
    const c3Sql = `
            SELECT
                COUNT(MissionID) AS count
            FROM
                Missions
            WHERE
                ProjectID = ?
                AND DeletedAt IS NULL
                AND (
                    Status != ?
                    OR QASignedByUserID IS NULL
                )
        `;

    const [results] = await this.pool.query(c3Sql, [
      dbProjectId,
      MISSION_CLOSED_STATUS,
    ]);

    // 處理查詢結果，確保類型安全 [17]
    const unAuditedMissionCount =
      (results as Array<{count: number}>)[0]?.count || 0;
    if (unAuditedMissionCount > 0) {
      return 0;
    } else {
      return unAuditedMissionCount;
    }
  }

  /**
   * 【新增】從 Missions 表中獲取任務摘要列表。
   * 遵循數據過濾契約 [8] 與 Missions 摘要結構契約 [9]。
   * @param dbProjectId 資料庫 Project ID (number)
   * @returns MissionSummary Object 陣列
   */
  private async getMissionSummariesByProjectId(
    dbProjectId: number
  ): Promise<MissionSummary[]> {
    // Missions 表的欄位包含 MissionID, Title, Status, DueDate, QASignedByUserID 等 [8, 9]
    const sql = `
        SELECT
            MissionID, Title, Description, Status, AssigneeID, DueDate, QASignedByUserID
        FROM 
            Missions
        WHERE
            ProjectID = ? AND DeletedAt IS NULL
    `;
    const [rows] = await this.pool.query<mysql.RowDataPacket[]>(sql, [
      dbProjectId,
    ]);

    // 將 DB Row (number ID) 轉換為 MissionSummary DTO (CoreID string) [9, 10]
    return rows.map((row) => ({
      missionID: toCoreId(row.MissionID), // CoreID 轉換 [10]
      title: row.Title,
      description: row.Description,
      status: row.Status,
      assigneeID: row.AssigneeID ? toCoreId(row.AssigneeID) : null,
      dueDate: row.DueDate,
      qaSignedByUserID: row.QASignedByUserID
        ? toCoreId(row.QASignedByUserID)
        : null, // CoreID 轉換
    })) as MissionSummary[];
  }

  /**
   * 檢查專案是否「完全驗收完畢」。
   * * 必須同時滿足 3 個條件：
   * 1. 至少要有一件任務 (total_missions > 0)
   * 2. 沒有未完成的任務 (Status != 'Closed' OR QASignedByUserID IS NULL)
   * 3. 沒有未指派的任務 (AssigneeUserID IS NULL)
   * * @param dbProjectId 專案 ID
   * @returns {Promise<boolean>} - true (表示 3 條件全滿足), false (任一條件不滿足)
   */
  private async validateProjectCompletion(
    dbProjectId: number
  ): Promise<boolean> {
    const MISSION_CLOSED_STATUS = MISSION_STATUS.CLOSED; // 'Closed'

    // 這個 SQL 會計算 2 個數字：
    // 1. total_missions: 總共有幾件 (未刪除) 任務。
    // 2. bad_missions_count: 有幾件任務是「有問題的」。
    //
    // 「有問題」 (Bad) 的定義 = 未完成 (條件2) 或 未指派 (條件3)
    // (Status != ? OR QASignedByUserID IS NULL OR AssigneeUserID IS NULL)
    //
    const validationSql = `
        SELECT
            -- 計算總任務數 (用於條件 1)
            COUNT(MissionID) AS total_missions,


            -- 計算「有問題」的任務數 (用於條件 2 & 3)
            COUNT(
                CASE
                    WHEN (Status != ? OR QASignedByUserID IS NULL OR AssigneeID IS NULL) THEN 1
                    ELSE NULL
                END
            ) AS bad_missions_count
        FROM
            Missions
        WHERE
            ProjectID = ?
            AND DeletedAt IS NULL
    ;
    `;

    const [results] = await this.pool.query(validationSql, [
      MISSION_CLOSED_STATUS,
      dbProjectId,
    ]);

    // 安全地取得查詢結果 (即使查詢為空)
    const counts = (
      results as Array<{
        total_missions: number;
        bad_missions_count: number;
      }>
    )[0] || {total_missions: 0, bad_missions_count: 0};

    const totalMissions = counts.total_missions;
    const badMissionsCount = counts.bad_missions_count;

    // --- 執行您的 3 個邏輯判斷 ---

    // 條件 1: 「至少有一個被完成」
    // 這隱含了「總任務數必須大於 0」。
    // (如果總數為 0，就不可能 "至少有一個被完成")
    const atLeastOneMissionExists = totalMissions > 0;

    // 條件 2 & 3: 「沒有未完成」 且 「沒有未指派」
    // 這代表我們算出來的「有問題的任務數」必須等於 0。
    const noBadMissions = badMissionsCount === 0;

    // 必須 3 個條件同時成立，才回傳 true
    //
    // 範例 1: total=5, bad=0  => (true && true)  => 回傳 true (成功)
    // 範例 2: total=5, bad=1  => (true && false) => 回傳 false (失敗，有未完成)
    // 範例 3: total=0, bad=0  => (false && true) => 回傳 false (失敗，專案為空)

    // --- 在這裡加入偵錯 Log ---
    // log(
    //   `[Debug Project ${dbProjectId}] totalMissions: ${totalMissions}, badMissionsCount: ${badMissionsCount}`
    // );
    // log(
    //   `[Debug Project ${dbProjectId}] atLeastOneMissionExists: ${atLeastOneMissionExists}, noBadMissions: ${noBadMissions}`
    // );
    // log(
    //   `[Debug Project ${dbProjectId}] Returning: ${
    //     atLeastOneMissionExists && noBadMissions
    //   }`
    // );
    // --- Log 結束 ---
    return atLeastOneMissionExists && noBadMissions;
  }

  /**
   * 實作自動流轉契約 (30 -> 40) 的核心邏輯 (GET Side Effect) [7, 8]。
   * @param dbProjectDbRow 專案數據列
   * @param currentUserId 當前操作者 CoreID
   * @returns 更新後的 ProjectDBRow
   */
  private async checkAndAutoTransitionToReadyForClosure(
    dbProjectDbRow: ProjectDBRow,
    currentUserId: CoreID
  ): Promise<ProjectDBRow> {
    // 狀態條件：只在 Active (30) 狀態下執行檢查 [8]
    if (dbProjectDbRow.CurrentStateID !== PROJECT_STATE_IDS.Active) {
      return dbProjectDbRow;
    }

    const dbProjectId = dbProjectDbRow.ProjectID;

    // 執行 C3 聚合檢查變體 [16] checkC3MissionAggregation 更新為 validateProjectCompletion
    const isComplete: boolean = await this.validateProjectCompletion(
      dbProjectId
    );

    // 流轉條件：如果未審計任務數量為 0，則觸發 30 -> 40 [16]
    if (isComplete) {
      const READY_FOR_CLOSURE = PROJECT_STATE_IDS.READY_FOR_CLOSURE; // 40
      // log(`[Auto-Transition] Project ${toCoreId(dbProjectId)} (30) -> (40)`);

      const updatedProject = await this.transitionStateAndRecord(
        dbProjectDbRow,
        READY_FOR_CLOSURE,
        currentUserId
      );

      if (updatedProject) {
        return updatedProject;
      }
    }

    return dbProjectDbRow;
  }

  // =========================================================
  // ⭐ 新增：數據獲取擴展 API (Data Retrieval Extensions)
  // =========================================================

  /**
   * ⭐ 擴展 1: 獲取所有可指派的使用者清單 (Admin, PM, RDL, RD, QA)。
   * 由於專案模組集中實作，此處執行跨表查詢。
   */
  public async getAssignableUsersList(): Promise<AssignableUserObject[]> {
    // 專案相關角色 ID: Admin (1), PM (3), RDL (4), RD (5), QA (6) [35]
    const ASSIGNABLE_ROLES = [
      ROLE_IDS.ADMIN,
      ROLE_IDS.PM,
      ROLE_IDS.RDL,
      ROLE_IDS.RD,
      ROLE_IDS.QA,
    ];

    const sql = `
            SELECT
                u.UserID, u.FullName, u.Title,ugr.RoleID
            FROM Users u
            JOIN UserGlobalRoles ugr ON u.UserID = ugr.UserID
            WHERE u.Status = 'Active' AND ugr.RoleID IN (?)
            GROUP BY u.UserID, u.FullName, ugr.RoleID
            ORDER BY u.FullName
        `;

    const [rows] = await this.pool.query(sql, [ASSIGNABLE_ROLES]);
    const dbRows = rows as Array<{
      UserID: number;
      FullName: string;
      Title: string;
      RoleID: number;
    }>;

    // 遵循 ID 類型轉換契約
    return dbRows.map((row) => ({
      userID: toCoreId(row.UserID),
      fullName: row.FullName,
      title: row.Title,
      roleID: toCoreId(row.RoleID),
    }));
  }

  /**
   * ⭐ 擴展 2: 獲取專案的完整成員清單 (Tab 4)。
   */
  public async getProjectMembersList(
    projectId: CoreID
  ): Promise<ProjectMemberObject[]> {
    const dbProjectId = toDBId(projectId, "ProjectID");
    const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND; // 40401

    if (!(await this.projectModel.findByID(dbProjectId))) {
      throw new BusinessError(
        notFoundError.description,
        notFoundError.code,
        notFoundError.name
      );
    }

    const sql = `
            SELECT
                pm.UserID, pm.RoleID, pm.JoinedAt, u.FullName, r.RoleName
            FROM ProjectMembers pm
            JOIN Users u ON pm.UserID = u.UserID
            JOIN Roles r ON pm.RoleID = r.RoleID
            WHERE pm.ProjectID = ?
            ORDER BY pm.RoleID ASC, pm.JoinedAt ASC
        `;

    const [rows] = await this.pool.query(sql, [dbProjectId]);
    const dbRows = rows as Array<{
      UserID: number;
      RoleID: number;
      JoinedAt: string;
      FullName: string;
      RoleName: string;
    }>;

    return dbRows.map((row) => ({
      userID: toCoreId(row.UserID),
      fullName: row.FullName,
      roleID: row.RoleID,
      roleName: row.RoleName,
      joinedAt: row.JoinedAt,
    }));
  }

  /**
   * ⭐ 擴展 4: 獲取專案的歷史記錄清單 (Tab 5)。
   */
  public async getProjectHistoryList(
    projectId: CoreID
  ): Promise<ProjectHistoryObject[]> {
    const dbProjectId = toDBId(projectId, "ProjectID");
    const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND; // 40401

    if (!(await this.projectModel.findByID(dbProjectId))) {
      throw new BusinessError(
        notFoundError.description,
        notFoundError.code,
        notFoundError.name
      );
    }

    // 使用 JOIN Users 獲取 ChangedByUserID 對應的 FullName
    const historySql = `
            SELECT
                ph.*, u.FullName
            FROM ProjectHistory ph
            JOIN Users u ON ph.ChangedByUserID = u.UserID
            WHERE ph.ProjectID = ?
            ORDER BY ph.ChangedAt DESC
        `;

    const [historyRows] = await this.pool.query(historySql, [dbProjectId]);
    // 假設 FullName 欄位存在於 Users 表中
    const dbHistoryRows = historyRows as (ProjectHistoryDBRow & {
      FullName: string;
    })[];

    return dbHistoryRows.map((row) => ({
      historyID: toCoreId(row.HistoryID),
      changedByUserID: toCoreId(row.ChangedByUserID),
      changedByUserName: row.FullName,
      changeType: row.ChangeType,
      detail: row.Detail,
      oldValue: row.OldValue,
      newValue: row.NewValue,
      changedAt: row.ChangedAt,
    }));
  }

  // =========================================================
  // CRUD 實現 (已補齊所有縱深防禦和歷史記錄邏輯)
  // =========================================================

  /**
   * 讀取專案列表。
   * 實施 Assigned Read 契約 [9]。
   * ⭐ 契約變更：現在回傳數據和分頁元數據 { data, meta }。
   */
  public async getProjectsList(
    filters: ProjectListFilters,
    currentUserRole: number,
    currentUserId: CoreID,
    ignoreAssignedRead: boolean = false
  ): Promise<{data: ProjectObject[]; meta: PaginationMeta}> {
    const currentDbId = toDBId(currentUserId, "CurrentUserID");
    let modelFilters: ModelProjectListFilters = {...filters};

    // ⭐ 修正點：確保 page 和 limit 被明確解析為數字
    if (modelFilters.page) {
      modelFilters.page = Number(modelFilters.page);
    }
    if (modelFilters.limit) {
      modelFilters.limit = Number(modelFilters.limit);
    }

    // 3. 預設排序和分頁參數 [3]
    modelFilters.sortBy = filters.sortBy || "EndDate";
    modelFilters.sortOrder = filters.sortOrder || "ASC";
    // 這裡的 modelFilters.limit 和 modelFilters.page 現在是數字或 undefined
    modelFilters.limit = modelFilters.limit || 12; // 每頁 12 筆
    modelFilters.page = modelFilters.page || 1; // 預設第 1 頁

    // 1. 實施 Assigned Read 契約 / 處理「我的檔案」篩選
    // ⭐ 修正邏輯：只要不是來自 /all 路由 (ignoreAssignedRead = false)，
    // 且 filter 中沒有明確的 assignedToUserId，則強制 Assigned Read。
    if (!ignoreAssignedRead) {
      // 如果 filters 中沒有 assignedToUserId（例如點擊 MINE/URGENT，或只是普通用戶讀取）
      if (modelFilters.assignedToUserId === undefined) {
        modelFilters.assignedToUserId = currentDbId;
      }
    }
    // 如果 ignoreAssignedRead 為 true (來自 /projects/all 路由)，
    // 則 modelFilters.assignedToUserId 保持 undefined，Service 將

    // 2. 快速篩選邏輯：處理「優先處理」 (tagId 5) 篩選 [11]
    if (filters.tagId !== undefined) {
      modelFilters.assignedToUserId = currentDbId;
    }

    // ⭐ 新增：第一步，執行總數查詢
    const totalProjects = await this.projectModel.countAllByFilter(
      modelFilters
    ); // 呼叫 Models Layer 新增的方法

    const totalPages = Math.ceil(totalProjects / modelFilters.limit);
    // 確保當前頁碼在有效範圍內
    const currentPage =
      modelFilters.page > totalPages && totalPages > 0
        ? totalPages
        : modelFilters.page;
    modelFilters.page = currentPage;

    // ⭐ 第二步，執行分頁數據查詢
    const dbResults = await this.projectModel.findAllByFilter(
      modelFilters as ModelProjectListFilters
    );

    // 3. 組裝分頁元數據
    const meta: PaginationMeta = {
      totalProjects: totalProjects,
      totalPages: totalPages,
      currentPage: currentPage,
    };

    return {
      data: dbResults.map(this.mapToProjectObject.bind(this)), // 傳回專案數據
      meta: meta, // 傳回元數據
    };
  }

  /**
   * 建立新專案 (POST /api/v1/projects) [19]。
   * 必須實施縱深防禦檢查 (40001) [9] 和 ProjectMembers 寫入邏輯 [9]。
   */
  public async createProject(
    projectData: ProjectCreationRequest,
    currentUserId: CoreID
  ): Promise<ProjectObject> {
    const validationError = PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED; // 40001 [20]

    // 1.1 必填欄位驗證 (rdlUserId) [21]
    if (!projectData.rdlUserId) {
      throw new BusinessError(
        `RDLUserID 是必填欄位。`,
        validationError.code,
        validationError.name
      );
    }

    // 修正邏輯：如果 projectData.ownerUserID 遺失 (undefined)，則使用 currentUserId [21]
    const finalOwnerUserID = projectData.ownerUserID || currentUserId;

    // 1.2 執行 ID 轉換契約 [22]
    const dbOwnerUserID = toDBId(finalOwnerUserID, "OwnerUserID");
    const dbRdlId = toDBId(projectData.rdlUserId, "RDLUserID");
    const dbRdIds = (projectData.rdUserIds ?? []).map((id) =>
      toDBId(id, "RDUserID")
    );
    const dbQaIds = (projectData.qaUserIds ?? []).map((id) =>
      toDBId(id, "qaUserID")
    );
    const changedByDbId = toDBId(currentUserId, "ChangedByUserID");

    // 1.3 縱深防禦檢查：驗證 OwnerUserID 必須是 PM/Admin 角色 [23]
    const [roleRows] = await this.pool.execute(
      `SELECT COUNT(*) as count FROM UserGlobalRoles
            WHERE UserID = ? AND RoleID IN (?, ?)`,
      [dbOwnerUserID, ROLE_IDS.PM, ROLE_IDS.ADMIN]
    );
    const isOwnerAuthorized =
      (roleRows as Array<{count: number}>)[0]?.count > 0;

    if (!isOwnerAuthorized) {
      throw new BusinessError(
        `專案擁有者 ID (${projectData.ownerUserID}) 必須具備 PM (${ROLE_IDS.PM}) 或 Admin (${ROLE_IDS.ADMIN}) 角色才能建立專案。`,
        validationError.code,
        validationError.name
      );
    }

    // 1.3.2 縱深防禦檢查：驗證 RdlId 必須是 RDL/Admin 角色 [24]
    const [rows] = await this.pool.execute(
      `SELECT COUNT(*) as count FROM UserGlobalRoles
            WHERE UserID = ? AND RoleID IN (?, ?) `,
      [dbRdlId, ROLE_IDS.RDL, ROLE_IDS.ADMIN]
    );
    const isRdlAuthorized = (rows as Array<{count: number}>)[0]?.count > 0;

    if (!isRdlAuthorized) {
      throw new BusinessError(
        `專案RDL負責人 ID (${projectData.rdlUserId}) 必須具備 RDL (${ROLE_IDS.RDL}) 或 Admin (${ROLE_IDS.ADMIN})角色才能建立專案。`,
        validationError.code,
        validationError.name
      );
    }

    // 1.3.3 縱深防禦檢查：驗證所有 RD ID 是否為 RD/Admin 角色 [25]
    for (const dbRdId of dbRdIds) {
      const [rdRoleRows] = await this.pool.execute(
        `SELECT COUNT(*) as count FROM UserGlobalRoles
                WHERE UserID = ? AND RoleID IN (?, ?)`,
        [dbRdId, ROLE_IDS.RD, ROLE_IDS.ADMIN]
      );
      const isRdAuthorized =
        (rdRoleRows as Array<{count: number}>)[0]?.count > 0;
      if (!isRdAuthorized) {
        throw new BusinessError(
          `專案 RD ID (${toCoreId(dbRdId)}) 必須具備 RD (${
            ROLE_IDS.RD
          }) 或 Admin (${ROLE_IDS.ADMIN}) 角色才能加入專案。`,
          validationError.code,
          validationError.name
        );
      }
    }

    // 1.3.4 縱深防禦檢查：驗證所有 QA ID 是否為 QA/Admin 角色 [26]
    for (const dbQaId of dbQaIds) {
      const [qaRoleRows] = await this.pool.execute(
        `SELECT COUNT(*) as count FROM UserGlobalRoles
                WHERE UserID = ? AND RoleID IN (?, ?)`,
        [dbQaId, ROLE_IDS.QA, ROLE_IDS.ADMIN]
      );
      const isQaAuthorized =
        (qaRoleRows as Array<{count: number}>)[0]?.count > 0;
      if (!isQaAuthorized) {
        throw new BusinessError(
          `專案 QA ID (${toCoreId(dbQaId)}) 必須具備 QA (${
            ROLE_IDS.QA
          }) 或 Admin (${ROLE_IDS.ADMIN}) 角色才能加入專案。`,
          validationError.code,
          validationError.name
        );
      }
    }

    // 2. 準備 Projects 表數據 [27]
    const projectDBPayload: Omit<
      ProjectDBRow,
      "ProjectID" | "CreatedAt" | "UpdatedAt" | "DeletedAt"
    > = {
      ProjectName: projectData.projectName,
      Description: projectData.description,
      OwnerUserID: dbOwnerUserID,
      StartDate: projectData.startDate,
      EndDate: projectData.endDate,
      CurrentStateID: PROJECT_STATE_IDS.UNSTARTED, // 初始狀態 10 [27]
      RDLApprovedByUserID: null,
      RDLApprovedAt: null,
      ProjectTagID: projectData.projectTagID || null,
    };

    const newProject = await this.projectModel.create(projectDBPayload); // 呼叫 Model 建立 [28]

    if (!newProject) {
      throw new BusinessError(
        "專案建立失敗：資料庫操作未回傳新紀錄。",
        500,
        "INTERNAL_DB_ERROR"
      );
    }

    // 3. 實作 ProjectMembers 初始化寫入 (使用 Raw SQL) [28]
    const dbProjectId = newProject.ProjectID;
    const membersToInsert: [number, number, number][] = [];

    // 3.1 寫入 PM (RoleID: 3) [28]
    membersToInsert.push([dbProjectId, dbOwnerUserID, ROLE_IDS.PM]);

    // 3.2 寫入 RDL (RoleID: 4) [29]
    membersToInsert.push([dbProjectId, dbRdlId, ROLE_IDS.RDL]);

    // 3.3 寫入 RD 列表 (RoleID: 5) [29]
    for (const rdId of dbRdIds) {
      // 排除 PM 和 RDL，避免重複插入 [29]
      if (rdId !== dbOwnerUserID && rdId !== dbRdlId) {
        membersToInsert.push([dbProjectId, rdId, ROLE_IDS.RD]);
      }
    }
    // 3.4 寫入 QA 列表 (RoleID: 6) (補齊 QA 成員寫入邏輯)
    for (const qaId of dbQaIds) {
      // 排除 PM 和 RDL，避免重複插入
      if (qaId !== dbOwnerUserID && qaId !== dbRdlId) {
        membersToInsert.push([dbProjectId, qaId, ROLE_IDS.QA]);
      }
    }

    if (membersToInsert.length > 0) {
      const placeholders = membersToInsert.map(() => "(?, ?, ?)").join(",");
      const flatValues = membersToInsert.flatMap((m) => m);
      const memberInsertSql = `
                INSERT INTO ProjectMembers (ProjectID, UserID, RoleID)
                VALUES ${placeholders}
                ON DUPLICATE KEY UPDATE RoleID = VALUES(RoleID);
            `;
      await this.pool.query(memberInsertSql, flatValues);
    }

    // ---------------- 查使用者姓名 ----------------
    const [userRows] = await db.execute<any[]>(
      "SELECT FullName FROM users WHERE UserID = ? LIMIT 1",
      [currentUserId]
    );

    const [userRows1] = await db.execute<any[]>(
      "SELECT UserID FROM projectmembers WHERE ProjectID = ? AND RoleID = 4",
      [dbProjectId]
    );

    const [userRows2] = await db.execute<any[]>(
      "SELECT FullName FROM users WHERE UserID = ? LIMIT 1",
      [userRows1[0].UserID]
    );

    const currentUserName =
      userRows.length > 0 ? userRows[0].FullName : "未知使用者";

    const targetUserName =
      userRows2.length > 0 ? userRows2[0].FullName : "未知使用者";

    const [userRows3] = await db.execute<any[]>(
          "SELECT ProjectName FROM projects WHERE ProjectID = ? LIMIT 1",
          [dbProjectId]
        );
    
    const projectName = userRows3.length > 0 ? userRows3[0].ProjectName : "未知使用者";

    // 4. 記錄歷史：PROJECT_CREATED [30]
    await this.historyModel.recordChange(
      {
      ProjectID: dbProjectId,
      ChangedByUserID: changedByDbId,
      ChangeType: HISTORY_CHANGE_TYPES.PROJECT_CREATED,
      Detail: `${currentUserName}已建立專案，並交由 ${targetUserName} 負責。`,
      OldValue: null,
      NewValue: null,
    },
    // --------------------------通知模組-------------------------------
    {
      UserID: userRows1[0].UserID,
      ProjectID: dbProjectId,
      MissionID: null,
      Content: `${currentUserName} 已建立 [${projectName}] 專案，並交由 ${targetUserName} 負責。`,
      IsRead: 0,
    },
    // ----------------------------------------------------------------
    "project_created"
  );
  

    return this.mapToProjectObject(newProject);
  }

  /**
   * 讀取單一專案 (GET /api/v1/projects/{projectID}) [19]。
   * 實作 Assigned Read 契約 [31] 和 自動流轉契約 (30 -> 40 的 GET Side Effect) [8]。
   */

  public async getProjectById(
    projectId: CoreID,
    currentUserId: CoreID,
    currentUserRole: number
  ): Promise<ProjectObject> {
    const dbProjectId = toDBId(projectId, "ProjectID");
    const dbCurrentUserId = toDBId(currentUserId, "CurrentUserID");

    let dbResult = await this.projectModel.findByID(dbProjectId);

    if (!dbResult) {
      const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND;
      throw new BusinessError(
        notFoundError.description,
        notFoundError.code,
        notFoundError.name
      );
    }

    // 實施 30 -> 40 自動流轉 (GET Side Effect)
    dbResult = await this.checkAndAutoTransitionToReadyForClosure(
      dbResult,
      currentUserId
    );

    // 獨立查詢關聯數據 (Aggregation)
    const attachmentDbRows: AttachmentDBRow[] =
      await this.attachmentModel.findByProjectID(dbProjectId);

    const missionSummaries: MissionSummary[] =
      await this.getMissionSummariesByProjectId(dbProjectId);

    // Assigned Read 契約檢查
    const isAdminOrPM =
      currentUserRole === ROLE_IDS.ADMIN || currentUserRole === ROLE_IDS.PM;

    if (!isAdminOrPM) {
      // 檢查是否為專案成員
      const [memberRows] = await this.pool.query(
        `SELECT COUNT(*) as count FROM ProjectMembers WHERE ProjectID = ? AND UserID = ?`,
        [dbProjectId, dbCurrentUserId]
      );

      const memberCount = (memberRows as Array<{count: number}>)[0]?.count || 0;

      if (memberCount === 0) {
        const forbiddenError = PROJECT_ERROR_CODES.FORBIDDEN;
        throw new BusinessError(
          `權限不足：非專案 PM 或 Admin，且非專案成員，無權讀取此專案。`,
          forbiddenError.code,
          forbiddenError.name
        );
      }
    }

    // 最終 DTO 組裝與返回
    const projectObject = {
      // 核心欄位轉換
      projectID: toCoreId(dbResult.ProjectID),
      projectName: dbResult.ProjectName,
      description: dbResult.Description,
      ownerUserID: toCoreId(dbResult.OwnerUserID),
      ownerName: dbResult.OwnerName,
      startDate: dbResult.StartDate,
      endDate: dbResult.EndDate,
      currentStateID: dbResult.CurrentStateID,
      rdlApprovedByUserID: dbResult.RDLApprovedByUserID
        ? toCoreId(dbResult.RDLApprovedByUserID)
        : null,
      rdlApprovedByName: dbResult.RDLApprovedByName,
      rdlApprovedAt: dbResult.RDLApprovedAt,
      projectTagID: dbResult.ProjectTagID,
      deletedAt: dbResult.DeletedAt,

      // 關聯數據聚合 - Attachments (執行 ID 轉換)
      attachments: attachmentDbRows.map((row) => ({
        attachmentID: toCoreId(row.AttachmentID),
        projectID: toCoreId(row.ProjectID),
        fileName: row.FileName,
        filePath: row.FilePath,
        uploadedByUserID: toCoreId(row.UploadedByUserID),
        uploadedAt: row.UploadedAt,
      })) as AttachmentObject[],

      // 關聯數據聚合 - Mission Summary
      missionSummary: missionSummaries,
    } as ProjectObject;

    return projectObject;
  }
  /**
   * 處理一般欄位更新 (PATCH /api/v1/projects/{projectID}) [19]。
   * 此方法處理 Name, Description, StartDate, EndDate, ProjectTagID 的變更 [34]。
   * 服務層將負責 P3 權限檢查和歷史記錄寫入 [35]。
   */
  public async updateProject(
    projectId: CoreID,
    payload: ProjectUpdateRequest,
    currentUserId: CoreID,
    currentUserRole: number
  ): Promise<ProjectObject> {
    const dbProjectId = toDBId(projectId, "ProjectID");
    const oldProjectDbRow = await this.projectModel.findByID(dbProjectId);

    if (!oldProjectDbRow) {
      const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND; // 40401
      throw new BusinessError(
        notFoundError.description,
        notFoundError.code,
        notFoundError.name
      );
    }

    // P3 權限檢查 (Admin 或 PM Owner) [35]
    this.checkP3Permission(oldProjectDbRow, currentUserId, currentUserRole);

    const updateFields: Partial<
      Omit<ProjectDBRow, "ProjectID" | "CreatedAt" | "UpdatedAt">
    > = {};

    const historyRecords = [];
    const notificationData = [];
    const changedByDbId = toDBId(currentUserId, "ChangedByUserID");

    // 歷史記錄類型映射 [34]
    const historyTypeMap: Record<
      "projectName" | "description" | "startDate" | "endDate" | "projectTagID",
      keyof typeof HISTORY_CHANGE_TYPES
    > = {
      projectName: HISTORY_CHANGE_TYPES.PROJECT_NAME_UPDATE,
      description: HISTORY_CHANGE_TYPES.DESCRIPTION_UPDATE,
      startDate: HISTORY_CHANGE_TYPES.DATE_UPDATE,
      endDate: HISTORY_CHANGE_TYPES.DATE_UPDATE,
      projectTagID: HISTORY_CHANGE_TYPES.PROJECT_TAG_UPDATE,
    };

    for (const key in payload) {
      if (!payload.hasOwnProperty(key)) continue;
      const updateKey = key as keyof ProjectUpdateRequest;

      // 忽略特殊欄位，這些欄位由專屬的 Service 處理 [34]
      if (
        updateKey === "ownerUserID" ||
        updateKey === "rdlApprovedAt" || // 用於 Controller 的功能分離 [36]
        updateKey === "rdlApprovedByUserID" ||
        updateKey === "currentStateID"
      ) {
        continue;
      }

      if (!(updateKey in historyTypeMap)) {
        continue;
      }

      const dbKey = (updateKey.charAt(0).toUpperCase() +
        updateKey.slice(1)) as keyof ProjectDBRow;
      const newValue = payload[updateKey];

      // 處理 ProjectTagID 的特殊驗證和歷史記錄 [37]
      if (updateKey === "projectTagID") {
        if (newValue !== null && typeof newValue !== "number") {
          const validationError =
            PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED; // 40001
          throw new BusinessError(
            `ProjectTagID 驗證失敗：必須是數字或 null。`,
            validationError.code,
            validationError.name
          );
        }
        const oldValue: number | null = oldProjectDbRow.ProjectTagID;
        if (oldValue !== newValue) {
          updateFields.ProjectTagID = newValue as any;
          historyRecords.push({
            ProjectID: dbProjectId,
            ChangedByUserID: changedByDbId,
            ChangeType: HISTORY_CHANGE_TYPES.PROJECT_TAG_UPDATE,
            Detail: `變更 ProjectTagID。`,
            OldValue: String(oldValue),
            NewValue: String(newValue),
          });
        }
        continue;
      }

      // 處理其他一般欄位 (Name, Description, Dates) [38]
      if (updateKey in historyTypeMap) {
        const oldValue: string | null = oldProjectDbRow[
          dbKey as keyof ProjectDBRow
        ] as string | null;
        if (String(oldValue) === String(newValue)) continue;

        updateFields[dbKey as keyof ProjectDBRow] = newValue as any;

        historyRecords.push({
          ProjectID: dbProjectId,
          ChangedByUserID: changedByDbId,
          ChangeType: historyTypeMap[updateKey as keyof typeof historyTypeMap],
          Detail: `變更 ${updateKey}。`,
          OldValue: String(oldValue),
          NewValue: String(newValue),
        });
      }
    }

    // ---------------- 查使用者姓名 ----------------
    const [userRows] = await db.execute<any[]>(
      "SELECT FullName FROM users WHERE UserID = ? LIMIT 1",
      [currentUserId]
    );

    const currentUserName =
      userRows.length > 0 ? userRows[0].FullName : "未知使用者";

    const [userRows1] = await db.execute<any[]>(
      "SELECT ProjectName FROM projects WHERE ProjectID = ? LIMIT 1",
      [dbProjectId]
    );

    const projectName =
      userRows1.length > 0 ? userRows1[0].ProjectName : "未知使用者";

    if (Object.keys(updateFields).length > 0) {
      // ⭐ 修正點：檢查 projectModel.update 的回傳值 (Affected Rows > 0)
      const updateResult = await this.projectModel.update(
        dbProjectId,
        updateFields
      );
      await this.projectModel.update(dbProjectId, updateFields);

      let hasSentNotification = false;

      for (const record of historyRecords) {
        let notificationData = null;

        // 🔸 只讓第一筆變更觸發通知（避免同一次 update 產生多筆）
        if (!hasSentNotification) {
          notificationData = {
            UserID: 1, // 可改成實際使用者
            ProjectID: record.ProjectID,
            MissionID: null,
            Content: `${currentUserName}已將[${projectName}]專案已更新`, // 可加上提示文字
            Link: null,
            IsRead: 0,
          };
          hasSentNotification = true; // ✅ 標記已發送
        }

        // 同時傳入 history 與 notification
        await this.historyModel.recordChange(record, notificationData,"project_changed");
      }
    } else {
      // 如果沒有實際變更，直接返回舊數據 [39]
      return this.mapToProjectObject(oldProjectDbRow);
    }
    if (payload.rdlUserId) {
      const newRdlCoreId = payload.rdlUserId;
      const dbNewRdlId = toDBId(newRdlCoreId, "NewRDLUserID");
      const RDL_ROLE = ROLE_IDS.RDL;

      // 查詢當前 ProjectMembers 表中的 RDL ID (如果 Projects.RDLApprovedByUserID 為 NULL)
      const [oldRdlRows] = await this.pool.query(
        `SELECT UserID FROM ProjectMembers WHERE ProjectID = ? AND RoleID = ?`,
        [dbProjectId, RDL_ROLE]
      );
      const oldRdlId = (oldRdlRows as Array<{UserID: number}>)?.UserID;

      if (dbNewRdlId !== oldRdlId) {
        // 執行原子操作 A：移除舊 RDL (如果存在)
        if (oldRdlId) {
          // 使用 DELETE 移除舊 RDL 成員記錄
          const deleteSql = `DELETE FROM ProjectMembers WHERE ProjectID = ? AND UserID = ? AND RoleID = ?`;
          await this.pool.query(deleteSql, [dbProjectId, oldRdlId, RDL_ROLE]);

          // 應當為此移除操作寫入 PROJECT_PROJECTMEMBERS_UPDATE 歷史記錄
        }

        // 執行原子操作 B：新增/更新新 RDL
        const insertSql = `
                INSERT INTO ProjectMembers (ProjectID, UserID, RoleID)
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE RoleID = VALUES(RoleID);
            `;
        await this.pool.query(insertSql, [dbProjectId, dbNewRdlId, RDL_ROLE]);

        // 應當為此新增操作寫入 PROJECT_PROJECTMEMBERS_UPDATE 歷史記錄
      }
    }
    const updatedProject = await this.projectModel.findByID(dbProjectId);
    // 確保 updatedProject 存在 (如果更新成功但讀取失敗，則拋出錯誤)
    if (!updatedProject) {
      throw new Error("更新成功後，讀取專案數據失敗。");
    }
    return this.mapToProjectObject(updatedProject);
  }

  /**
   * 執行專案的軟刪除 (DELETE /api/v1/projects/{projectID}) [19]。
   * 必須實施 P3 權限檢查和 PROJECT_DELETED 歷史記錄寫入 [39]。
   */
  public async softDeleteProject(
    projectId: CoreID,
    currentUserId: CoreID,
    currentUserRole: number
  ): Promise<boolean> {
    const dbProjectId = toDBId(projectId, "ProjectID");
    const oldProjectDbRow = await this.projectModel.findByID(dbProjectId);

    if (!oldProjectDbRow) {
      const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND; // 40401
      throw new BusinessError(
        notFoundError.description,
        notFoundError.code,
        notFoundError.name
      );
    }

    // P3 權限檢查 [39]
    this.checkP3Permission(oldProjectDbRow, currentUserId, currentUserRole);

    // 執行軟刪除 [40]
    const success = await this.projectModel.softDelete(dbProjectId);

    // ---------------- 查使用者姓名 ----------------
    const [userRows] = await db.execute<any[]>(
      "SELECT FullName FROM users WHERE UserID = ? LIMIT 1",
      [currentUserId]
    );

    const currentUserName =
      userRows.length > 0 ? userRows[0].FullName : "未知使用者";

    const [userRows1] = await db.execute<any[]>(
      "SELECT ProjectName FROM projects WHERE ProjectID = ? LIMIT 1",
      [dbProjectId]
    );

    const projectName =
      userRows1.length > 0 ? userRows1[0].ProjectName : "未知使用者";

    if (success) {
      // 寫入 PROJECT_DELETED 歷史記錄 [41]
      const changedByDbId = toDBId(currentUserId, "ChangedByUserID");
      await this.historyModel.recordChange({
        ProjectID: dbProjectId,
        ChangedByUserID: changedByDbId,
        ChangeType: HISTORY_CHANGE_TYPES.PROJECT_DELETED,
        Detail: `專案執行軟刪除。`,
        OldValue: null,
        NewValue: null,
      },
    // --------------------------通知模組-------------------------------
    {
      UserID: 1,
      ProjectID: dbProjectId,
      MissionID: null,
      Content: `${currentUserName} 已刪除 [${projectName}] 專案。`,
      IsRead: 0,
      CreateAt: null,
      DeleteAt: null,
    },
    "project_changed",
    // ----------------------------------------------------------------
    );
    }

    return success;
  }

  /**
   * 檢查 P6 附件刪除/新增權限：驗證使用者是否有權管理成員 (PM 或 RDL) [41]。
   * 此邏輯用於 addProjectMember 和 removeProjectMember [4]。
   * @throws {BusinessError} 40301 PERMISSION_DENIED [2]。
   */
  private async checkP6Permission(
    projectDbRow: ProjectDBRow,
    currentUserId: CoreID,
    currentUserRole: number
  ): Promise<void> {
    const currentDbId = toDBId(currentUserId, "CurrentUserID");
    const forbiddenError = PROJECT_ERROR_CODES.FORBIDDEN; // 40301 [41]

    // P2/P6 檢查：Admin 豁免 [41]
    if (currentUserRole === ROLE_IDS.ADMIN) {
      return;
    }

    // P6 檢查：PM (ID: 3) 且為專案 Owner [42]
    if (
      currentUserRole === ROLE_IDS.PM &&
      projectDbRow.OwnerUserID === currentDbId
    ) {
      return;
    }

    // P6 檢查：RDL (ID: 4) 且為專案成員 [42]
    if (currentUserRole === ROLE_IDS.RDL) {
      const [memberRows] = await this.pool.query(
        `SELECT COUNT(*) as count FROM ProjectMembers WHERE ProjectID = ? AND UserID = ? AND RoleID = ?`,
        [projectDbRow.ProjectID, currentDbId, ROLE_IDS.RDL]
      );

      const memberCount = (memberRows as Array<{count: number}>)[0]?.count || 0;

      if (memberCount > 0) {
        return;
      }
    }

    throw new BusinessError(
      `權限不足：只有 Admin、專案 PM 或 RDL 有權管理成員。`,
      forbiddenError.code,
      forbiddenError.name
    );
  }

  /**
   * 新增或更新專案成員 (非 PM/RDL 轉讓) [2]。
   * @throws {BusinessError} 40301 PERMISSION_DENIED (如果嘗試變更 PM 角色) [43]。
   */
  public async addProjectMember(
    projectId: CoreID,
    payload: MemberActionRequest,
    currentUserId: CoreID,
    currentUserRole: number
  ): Promise<boolean> {
    const dbProjectId = toDBId(projectId, "ProjectID");
    const dbNewMemberId = toDBId(payload.userId, "NewMemberUserID");
    const changedByDbId = toDBId(currentUserId, "ChangedByUserID");
    const forbiddenError = PROJECT_ERROR_CODES.FORBIDDEN; // 40301

    // 1. 執行 P6 權限檢查 (誰有權新增成員)
    const oldProjectDbRow = await this.projectModel.findByID(dbProjectId);
    if (!oldProjectDbRow) {
      const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND; // 40401
      throw new BusinessError(
        notFoundError.description,
        notFoundError.code,
        notFoundError.name
      );
    }
    await this.checkP6Permission(
      oldProjectDbRow,
      currentUserId,
      currentUserRole
    );

    const newRoleId = payload.roleId || ROLE_IDS.RD;

    // 2. 避免透過此接口變更 PM 角色 [43]
    if (newRoleId === ROLE_IDS.PM) {
      throw new BusinessError(
        `禁止：PM 角色變更必須透過專門的 PM 轉讓 (T1-T6) 接口。`,
        forbiddenError.code,
        forbiddenError.name
      );
    }

    // ⭐  pre 3. 新增縱深防禦檢查：驗證被指派者必須具備對應的全域角色或 Admin

    // 檢查該使用者是否具備被指派角色 (newRoleId) 或 Admin 角色
    const [globalRoleRows] = await this.pool.execute(
      `SELECT COUNT(*) as count FROM UserGlobalRoles
    WHERE UserID = ? AND RoleID IN (?, ?)`,
      [dbNewMemberId, newRoleId, ROLE_IDS.ADMIN]
    );

    const isGloballyAuthorized =
      (globalRoleRows as Array<{count: number}>)[0]?.count > 0;
    if (!isGloballyAuthorized) {
      // 取得角色名稱以提供詳細錯誤資訊
      const roleName =
        Object.keys(ROLE_IDS).find(
          (key) => ROLE_IDS[key as keyof typeof ROLE_IDS] === newRoleId
        ) || "指定角色";
      const validationError = PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED; // 40001
      throw new BusinessError(
        `【縱深防禦失敗】使用者 ID (${payload.userId}) 必須具備 ${roleName} (Role ID: ${newRoleId}) 或 Admin (Role ID: ${ROLE_IDS.ADMIN}) 全域角色，才能被指派此專案角色。`,
        validationError.code,
        validationError.name // 40001 VALIDATION_FAILED
      );
    }

    // 3. 縱深防禦檢查：禁止將唯一的 RDL 降級為其他角色
    const [currentRoleRows] = await this.pool.query(
      `SELECT RoleID FROM ProjectMembers WHERE ProjectID = ? AND UserID = ?`,
      [dbProjectId, dbNewMemberId]
    );

    const isExistingMemberRDL =
      (currentRoleRows as Array<{RoleID: number}>).length > 0 &&
      (currentRoleRows as Array<{RoleID: number}>)[0].RoleID === ROLE_IDS.RDL;

    // 判斷是否為「將現有 RDL 降級為非 RDL 角色」的操作
    if (isExistingMemberRDL && newRoleId !== ROLE_IDS.RDL) {
      const currentRdlCount = await this.getRdlCount(dbProjectId);

      // 如果目前只有 1 個 RDL，且我們嘗試將其角色變更 (降級)，則禁止
      if (currentRdlCount <= 1) {
        const validationError =
          PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED; // 40001
        throw new BusinessError(
          `禁止：此專案中必須至少保留一位 RDL 角色成員，無法將最後一位 RDL 降級為其他角色 (${newRoleId})。`,
          validationError.code,
          validationError.name // 40001 VALIDATION_FAILED
        );
      }
    }

    // 4. 執行 ProjectMembers 寫入
    const sql = `
            INSERT INTO ProjectMembers (ProjectID, UserID, RoleID)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE RoleID = VALUES(RoleID);
        `;
    const values = [dbProjectId, dbNewMemberId, newRoleId];

    await this.pool.query(sql, values);

    // ---------------- 查使用者資訊 ----------------
    const [userRows] = await db.execute<any[]>(
      "SELECT FullName FROM users WHERE UserID = ? LIMIT 1",
      [currentUserId]
    );

    const currentUserName =
      userRows.length > 0 ? userRows[0].FullName : "未知使用者";

    const [userRows1] = await db.execute<any[]>(
      "SELECT ProjectName FROM projects WHERE ProjectID = ? LIMIT 1",
      [dbProjectId]
    );

    const projectName =
      userRows1.length > 0 ? userRows1[0].ProjectName : "未知使用者";

    const [userRows2] = await db.execute<any[]>(
      "SELECT FullName FROM users WHERE UserID = ? LIMIT 1",
      [toCoreId(dbNewMemberId)]
    );

    const memberUserName =
      userRows2.length > 0 ? userRows2[0].FullName : "未知使用者";

    const [userRows3] = await db.execute<any[]>(
      "SELECT RoleName FROM roles WHERE RoleID = ? LIMIT 1",
      [toCoreId(dbNewMemberId)]
    );

    const RoleName =
      userRows3.length > 0 ? userRows3[0].RoleName : "未知使用者";

    // 5. 記錄歷史：PROJECT_PROJECTMEMBERS_UPDATE [3]
    await this.historyModel.recordChange({
      ProjectID: dbProjectId,
      ChangedByUserID: changedByDbId,
      ChangeType: HISTORY_CHANGE_TYPES.PROJECT_PROJECTMEMBERS_UPDATE,
      Detail: `新增或更新成員 ${toCoreId(dbNewMemberId)}，角色: ${newRoleId}。`,
      OldValue: null,
      NewValue: String(newRoleId),
    },
    // --------------------------通知模組-------------------------------
    {
      UserID: 1,
      ProjectID: dbProjectId,
      MissionID: null,
      Content: `${currentUserName} 已新增或更新成員 ${memberUserName}至 [${projectName}] 專案，角色: ${RoleName}。`,
      IsRead: 0,
      CreateAt: null,
      DeleteAt: null,
    },
    "project_members_change"
    // ----------------------------------------------------------------
  );

    return true;
  }

  /**
   * 移除專案成員 [14]。
   * @throws {BusinessError} 40301 PERMISSION_DENIED (如果嘗試移除 PM) [9]。
   * ⭐ 已新增：40001 VALIDATION_FAILED (如果嘗試移除唯一的 RDL)。
   *   * ⭐ 修改：移除專案成員 (API 擴展 3)。
   * 強化檢查：1. 只有 PM/RDL/Admin 可用。2. PM 不可刪。3. 唯一的 RDL 不可刪 [36]。
   */
  public async removeProjectMember(
    projectId: CoreID,
    payload: MemberActionRequest, // 包含要移除的 userId (CoreID)
    currentUserId: CoreID,
    currentUserRole: number
  ): Promise<boolean> {
    const dbProjectId = toDBId(projectId, "ProjectID");
    const dbMemberIdToRemove = toDBId(payload.userId, "MemberUserID");
    const changedByDbId = toDBId(currentUserId, "ChangedByUserID");
    const forbiddenError = PROJECT_ERROR_CODES.FORBIDDEN; // 40301 [37]
    const validationError = PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED; // 40001 [37]
    const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND; // 40401

    // 1. 取得專案數據並執行 P6 權限檢查 [37]
    const oldProjectDbRow = await this.projectModel.findByID(dbProjectId);

    if (!oldProjectDbRow) {
      throw new BusinessError(
        notFoundError.description,
        notFoundError.code,
        notFoundError.name
      );
    }

    // P6 權限檢查 (Admin/PM/RDL 才能操作) [37]
    await this.checkP6Permission(
      oldProjectDbRow as ProjectDBRow,
      currentUserId,
      currentUserRole
    );

    // 2. 禁止移除 PM (Owner) [38]
    if (dbMemberIdToRemove === (oldProjectDbRow as ProjectDBRow).OwnerUserID) {
      throw new BusinessError(
        `禁止：無法移除專案 PM，請執行 PM 轉讓流程。`,
        forbiddenError.code,
        forbiddenError.name
      );
    }

    // ⭐ 3. 新增縱深防禦檢查：禁止移除專案中唯一的 RDL [38]

    // 3.1 查詢被移除成員的角色
    const [memberRows] = await this.pool.query(
      `SELECT RoleID FROM ProjectMembers WHERE ProjectID = ? AND UserID = ?`,
      [dbProjectId, dbMemberIdToRemove]
    );

    const memberInfo = memberRows as Array<{RoleID: number}>;
    if (memberInfo.length === 0) {
      return false; // 成員不存在
    }

    const memberRole = memberInfo[0].RoleID; // 取得目標成員的角色 ID

    if (memberRole === ROLE_IDS.RDL) {
      const currentRdlCount = await this.getRdlCount(dbProjectId);
      // 如果當前 RDL 只有 1 人 (即被移除者是唯一的 RDL)，則禁止移除
      if (currentRdlCount <= 1) {
        throw new BusinessError(
          `【RDL 契約失敗】此專案中必須至少保留一位 RDL 角色成員。無法移除最後一位 RDL。`,
          validationError.code,
          validationError.name
        );
      }
    }
    // End of 唯一的 RDL 檢查

    // 4. 執行 DELETE 移除成員 [39]
    const sql = `
            DELETE FROM ProjectMembers
            WHERE ProjectID = ? AND UserID = ?
        `;
    const [result] = await this.pool.query(sql, [
      dbProjectId,
      dbMemberIdToRemove,
    ]);
    const success = (result as mysql.ResultSetHeader).affectedRows > 0;

    // ---------------- 查使用者資訊 ----------------
    const [userRows] = await db.execute<any[]>(
      "SELECT FullName FROM users WHERE UserID = ? LIMIT 1",
      [currentUserId]
    );

    const currentUserName =
      userRows.length > 0 ? userRows[0].FullName : "未知使用者";

    const [userRows1] = await db.execute<any[]>(
      "SELECT ProjectName FROM projects WHERE ProjectID = ? LIMIT 1",
      [dbProjectId]
    );

    const projectName =
      userRows1.length > 0 ? userRows1[0].ProjectName : "未知使用者";

    const [userRows2] = await db.execute<any[]>(
      "SELECT FullName FROM users WHERE UserID = ? LIMIT 1",
      [toCoreId(dbMemberIdToRemove)]
    );

    const memberUserName =
      userRows2.length > 0 ? userRows2[0].FullName : "未知使用者";

    if (success) {
      // 5. 記錄歷史：PROJECT_PROJECTMEMBERS_UPDATE [10]
      await this.historyModel.recordChange({
        ProjectID: dbProjectId,
        ChangedByUserID: changedByDbId,
        ChangeType: HISTORY_CHANGE_TYPES.PROJECT_PROJECTMEMBERS_UPDATE,
        Detail: `從專案中移除了成員 ${toCoreId(dbMemberIdToRemove)}。`,
        OldValue: String(dbMemberIdToRemove),
        NewValue: null,
      },
    // --------------------------通知模組-------------------------------
    {
      UserID: 1,
      ProjectID: dbProjectId,
      MissionID: null,
      Content: `${currentUserName} 從 [${projectName}] 專案中移除了成員 ${memberUserName}。`,
      IsRead: 0,
    },
    "project_members_change"
    // ----------------------------------------------------------------
    );
    }

    return success;
  }
}
