// 程式檔案：backend/src/project/services/attachment.service.ts

// 層次與職責：核心業務邏輯與事務層（Services Layer）[1]。
// 核心職責：處理專案附件的建立與軟刪除業務邏輯，實施 P1 狀態鎖定和 P6 權限檢查 [1]。
// 核心契約：
// P6 附件刪除/新增權限檢查 (PM=3 或 RDL=4 且為專案成員) [1, 5]。
// P1 狀態鎖定依賴：需檢查專案是否為 Completed (50) 或 Archived (60) [1, 2]。
// 歷史記錄契約：操作成功後必須寫入 ProjectHistory 紀錄，ChangeType 為 ATTACHMENT_UPDATE [1, 6-8]。

// ===============程式碼本體=================

import * as mysql from "mysql2/promise";
import {ProjectModel} from "../models/project.model";
import {
  ProjectAttachmentModel,
  AttachmentDBRow,
} from "../models/project.attachment.model";
import {ProjectHistoryModel} from "../models/project.history.model";
import {CoreID, ProjectDBRow, AttachmentObject} from "../types/project.types";
import {
  ROLE_IDS,
  PROJECT_STATE_IDS,
  HISTORY_CHANGE_TYPES,
} from "../types/system.constants";
import {PROJECT_ERROR_CODES} from "../types/error.types";
import {toDBId, toCoreId} from "../utils/id.converter";
import {db} from "../../Notification/services/db";

/**
 * 標準化的業務錯誤類別 (Business Error) [9]。
 * 包含標準錯誤碼 (code) 和名稱 (name)，用於回傳給 Controller 層 [9]。
 */
class BusinessError extends Error {
  public code: number;
  public name: string;
  constructor(message: string, code: number, name: string) {
    super(message);
    this.code = code;
    this.name = name;
  }
}

/**
 * 附件建立請求 Payload (檔案 metadata) [9]。
 */
export interface AttachmentCreationRequest {
  projectId: CoreID;
  fileName: string;
  filePath: string;
}

/**
 * AttachmentService 專門處理附件相關的業務邏輯 [9]。
 */
export class AttachmentService {
  private pool: mysql.Pool;
  private projectModel: ProjectModel;
  private attachmentModel: ProjectAttachmentModel;
  private historyModel: ProjectHistoryModel;

  constructor(
    pool: mysql.Pool,
    projectModel: ProjectModel,
    attachmentModel: ProjectAttachmentModel,
    historyModel: ProjectHistoryModel
  ) {
    this.pool = pool;
    this.projectModel = projectModel;
    this.attachmentModel = attachmentModel;
    this.historyModel = historyModel;
  }

  /**
   * 檢查 P6 附件刪除/新增權限：驗證使用者是否有權操作附件 (PM 或 RDL) [5]。
   * 權限條件：必須是 Admin (ID: 1)，或者是指派給該專案的 PM (ID: 3) 或 RDL (ID: 4) [5]。
   * @throws {BusinessError} 40301 PERMISSION_DENIED [5]。
   */
  private async checkP6AttachmentPermission(
    projectDbRow: ProjectDBRow,
    currentUserId: CoreID,
    currentUserRole: number
  ): Promise<void> {
    const currentDbId = toDBId(currentUserId, "CurrentUserID");
    const forbiddenError = PROJECT_ERROR_CODES.FORBIDDEN; // 40301 [5, 10]

    // P2 檢查：Admin 豁免 [5]
    if (currentUserRole === ROLE_IDS.ADMIN) {
      return;
    }

    // P6 檢查：PM (ID: 3)
    if (currentUserRole === ROLE_IDS.PM) {
      // 檢查是否為專案的 PM (OwnerUserID) [11]
      if (projectDbRow.OwnerUserID === currentDbId) {
        return;
      }
    }

    // P6 檢查：RDL (ID: 4)
    if (currentUserRole === ROLE_IDS.RDL) {
      // 查詢 ProjectMembers 表以確認 RDL 身份 [11]
      const [memberRows] = await this.pool.query(
        `SELECT COUNT(*) as count FROM ProjectMembers WHERE ProjectID = ? AND UserID = ? AND RoleID = ?`,
        [projectDbRow.ProjectID, currentDbId, ROLE_IDS.RDL]
      );

      // 存取查詢結果 [12]
      const memberCount = (memberRows as Array<{count: number}>)[0]?.count || 0;

      if (memberCount > 0) {
        return;
      }
    }

    throw new BusinessError(
      `權限不足：只有 Admin、專案 PM 或 RDL 有權操作附件。`,
      forbiddenError.code,
      forbiddenError.name
    );
  }

  /**
   * 檢查 P1 狀態鎖定：Completed (50)/Archived (60) 狀態禁止修改 [1, 12]。
   * @throws {BusinessError} 40901 PROJECT_STATE_IMMUTABLE [2, 4]。
   */
  private checkP1StateLock(projectDbRow: ProjectDBRow): void {
    const stateId = projectDbRow.CurrentStateID; // 類型: number [2]

    const immutableStates: number[] = [
      PROJECT_STATE_IDS.COMPLETED, // 50 [2, 13]
      PROJECT_STATE_IDS.ARCHIVED, // 60 [2, 13]
    ];

    if (immutableStates.includes(stateId)) {
      const immutableError =
        PROJECT_ERROR_CODES.CONFLICT.PROJECT_STATE_IMMUTABLE; // 40901 [2, 4]

      throw new BusinessError(
        `P1 檢查失敗：專案狀態為 ${stateId} (Completed/Archived)，禁止操作附件。`,
        immutableError.code,
        immutableError.name
      );
    }
  }

  /**
   * 執行專案附件的軟刪除流程 [14]。
   * 必須依序通過 P1 (狀態鎖定) 和 P6 (權限檢查) [14]。
   */
  public async softDeleteAttachment(
    attachmentId: CoreID,
    currentUserId: CoreID,
    currentUserRole: number
  ): Promise<boolean> {
    const dbAttachmentId = toDBId(attachmentId, "AttachmentID");
    const changedByDbId = toDBId(currentUserId, "ChangedByUserID");
    const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND; // 40401 [14]

    // 1. 取得附件數據 [14]
    const attachmentDbRow: AttachmentDBRow | null =
      await this.attachmentModel.findByID(dbAttachmentId);

    if (!attachmentDbRow) {
      throw new BusinessError(
        `找不到指定的附件 ID: ${attachmentId}。`,
        notFoundError.code,
        notFoundError.name
      );
    }

    const dbProjectId = attachmentDbRow.ProjectID;

    // 2. 取得專案數據，用於狀態和成員權限檢查 [15]
    const projectDbRow = await this.projectModel.findByID(dbProjectId);

    if (!projectDbRow) {
      // 如果專案被軟刪除或找不到，這裡會拋出 40401，符合 contract [15]
      throw new BusinessError(
        `找不到附件所屬的專案 ID: ${dbProjectId}。`,
        notFoundError.code,
        notFoundError.name
      );
    }

    // ⭐ 3. P1 檢查：專案狀態鎖定 (Completed/Archived) [1, 16]
    this.checkP1StateLock(projectDbRow);

    // 4. P6 檢查：附件刪除權限 (PM/RDL 且為專案成員) [1, 16]
    await this.checkP6AttachmentPermission(
      projectDbRow,
      currentUserId,
      currentUserRole
    );

    // 5. 執行附件軟刪除 [16]
    const success = await this.attachmentModel.softDelete(dbAttachmentId);

    // ---------------- 查使用者資訊 ----------------
    const [userRows] = await db.execute<any[]>(
      "SELECT FullName FROM users WHERE UserID = ? LIMIT 1",
      [currentUserId]
    );

    const currentUserName =
      userRows.length > 0 ? userRows[0].FullName : "未知使用者";

    const [userRows1] = await db.execute<any[]>(
      "SELECT ProjectName FROM projects WHERE ProjectID = ? LIMIT 1",
      [dbProjectId]
    );

    const projectName =
      userRows1.length > 0 ? userRows1[0].ProjectName : "未知使用者";

    if (success) {
      // 6. 記錄歷史：ATTACHMENT_UPDATE [8, 16]
      await this.historyModel.recordChange({
        ProjectID: dbProjectId,
        ChangedByUserID: changedByDbId,
        ChangeType: HISTORY_CHANGE_TYPES.ATTACHMENT_UPDATE, // 追蹤附件變動 [6, 8]
        Detail: `附件 ${attachmentId} (${attachmentDbRow.FileName}) 被軟刪除。`,
        OldValue: JSON.stringify({
          attachmentId: attachmentId,
          fileName: attachmentDbRow.FileName,
        }),
        NewValue: null,
      },
      // --------------------------通知模組-------------------------------
      {
        UserID: 1,
        ProjectID: dbProjectId,
        MissionID: null,
        Content: `[${projectName}] 專案中的附件 (${attachmentDbRow.FileName}) 已被 ${currentUserName} 刪除。`,
        IsRead: 0,
      },
      "project_changed"
      // ----------------------------------------------------------------

    );
    }

    return success;
  }

  /**
   * 執行專案附件的建立流程 (檔案 metadata 寫入) [6]。
   * 必須通過 P1 (狀態鎖定) 和 P6 (權限檢查) [1, 17]。
   */
  public async createAttachment(
    payload: AttachmentCreationRequest,
    currentUserId: CoreID,
    currentUserRole: number
  ): Promise<AttachmentDBRow> {
    // 1. 執行 ID 轉換契約 [18]
    const dbProjectId = toDBId(payload.projectId, "ProjectID");
    const changedByDbId = toDBId(currentUserId, "UploadedByUserID");
    const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND; // 40401 [18]

    // 2. 取得專案數據，用於權限檢查 [18]
    const projectDbRow = await this.projectModel.findByID(dbProjectId);

    if (!projectDbRow) {
      throw new BusinessError(
        `找不到附件所屬的專案 ID: ${payload.projectId}。`,
        notFoundError.code,
        notFoundError.name
      );
    }

    // ⭐ 3. P1 檢查：必須在 P6 檢查前執行 P1 狀態鎖定檢查 [1, 17]
    this.checkP1StateLock(projectDbRow);

    // 4. P6 檢查：附件新增權限 (PM/RDL 且為專案成員) [1, 17]
    await this.checkP6AttachmentPermission(
      projectDbRow,
      currentUserId,
      currentUserRole
    );

    // 5. 準備 ProjectAttachments 表數據 [17]
    const attachmentDBPayload: Omit<
      AttachmentDBRow,
      "AttachmentID" | "UploadedAt" | "DeletedAt"
    > = {
      ProjectID: dbProjectId,
      FileName: payload.fileName,
      FilePath: payload.filePath,
      UploadedByUserID: changedByDbId,
    };

    // 6. 執行附件 metadata 建立 [7]
    const newAttachment = await this.attachmentModel.create(
      attachmentDBPayload
    );

    if (!newAttachment) {
      throw new BusinessError(
        "附件建立失敗：資料庫操作未回傳新紀錄。",
        500,
        "INTERNAL_DB_ERROR"
      );
    }

    // ---------------- 查使用者資訊 ----------------
    const [userRows] = await db.execute<any[]>(
      "SELECT FullName FROM users WHERE UserID = ? LIMIT 1",
      [currentUserId]
    );

    const currentUserName =
      userRows.length > 0 ? userRows[0].FullName : "未知使用者";

    const [userRows1] = await db.execute<any[]>(
      "SELECT ProjectName FROM projects WHERE ProjectID = ? LIMIT 1",
      [dbProjectId]
    );

    const projectName =
      userRows1.length > 0 ? userRows1[0].ProjectName : "未知使用者";

    // 7. 記錄歷史：ATTACHMENT_UPDATE (附件新增類型) [7, 8]
    await this.historyModel.recordChange(
      {
        ProjectID: dbProjectId,
        ChangedByUserID: changedByDbId,
        ChangeType: HISTORY_CHANGE_TYPES.ATTACHMENT_UPDATE,
        Detail: `附件 ${newAttachment.FileName} 新增成功。`,
        OldValue: null,
        NewValue: JSON.stringify({
          attachmentId: toCoreId(newAttachment.AttachmentID),
          fileName: newAttachment.FileName,
          filePath: newAttachment.FilePath,
        }),
      },
      // --------------------------通知模組-------------------------------
      {
        UserID: 1,
        ProjectID: dbProjectId,
        MissionID: null,
        Content: `${currentUserName} 已於 [${projectName}] 新增附件 ${newAttachment.FileName} 。`,
        IsRead: 0,
      },
      "project_changed"
      // ----------------------------------------------------------------
    );

    return newAttachment;
  }

  // 由於我們只關注 P1/P6 檢查，此服務中不包含其他輔助方法。

  /**
   * 根據附件 ID 讀取附件紀錄。
   * 雖然下載權限寬鬆 (任何人可下載 [10])，但仍應檢查附件存在性。
   * @param attachmentId 附件的核心 ID (CoreID string)
   * @returns AttachmentObject | null
   */
  public async getAttachmentById(
    attachmentId: CoreID,
    // 雖然下載通常開放，但為了架構一致性，保留權限檢查參數
    currentUserId: CoreID,
    currentUserRole: number
  ): Promise<AttachmentObject | null> {
    // 1. 執行 ID 轉換契約：CoreID (string) -> DB INT (number) [3, 4]
    const dbAttachmentId = toDBId(attachmentId, "AttachmentID");

    // 2. 讀取附件數據，遵守數據過濾契約 (DeletedAt IS NULL) [6, 11]
    const attachmentDbRow: AttachmentDBRow | null =
      await this.attachmentModel.findByID(dbAttachmentId);

    if (!attachmentDbRow) {
      // 找不到附件，返回 null
      return null;
    }

    // 3. 執行 DTO 轉換契約：將 DB Row 轉換為 ProjectObject DTO [8]
    const attachmentObject: AttachmentObject = {
      attachmentID: toCoreId(attachmentDbRow.AttachmentID), // ID 轉換為 string [9]
      projectID: toCoreId(attachmentDbRow.ProjectID), // ID 轉換為 string [9]
      fileName: attachmentDbRow.FileName,
      filePath: attachmentDbRow.FilePath,
      uploadedByUserID: toCoreId(attachmentDbRow.UploadedByUserID), // ID 轉換為 string [9]
      uploadedAt: attachmentDbRow.UploadedAt,
    };

    return attachmentObject;
  }
}
