// 程式檔案：backend/src/project/services/pm.transfer.service.ts

// 層次與職責：核心業務邏輯與事務層（Services Layer）[1, 2]。
// 核心職責是實作專案的 PM 轉讓功能，確保 T1-T6 事務具備原子性 (Atomicity) [2-4]。
// 核心契約與依賴：
// 1. T1-T6 原子交易契約：轉讓流程必須在單一資料庫事務中執行，失敗時執行 Transaction Rollback [3, 4]。
// 2. T4A 附件轉讓契約：必須呼叫 project.attachment.model.ts 執行附件擁有者轉讓 [2-5]。
// 3. 歷史記錄契約 (T3)：轉讓成功後，必須寫入 ProjectHistory 紀錄，ChangeType 必須為 PM_TRANSFER [1, 6]。
// 4. 錯誤碼契約：如果事務失敗，拋出 50001 PM_TRANSFER_FAILED 錯誤碼 [7, 8]。
// 5. ID 資料類型轉換契約：呼叫 toDBId 將 CoreID (string) 轉為 DB ID (number) [2, 4, 9]。

// ===============程式碼本體=================

import * as mysql from "mysql2/promise";
import {ProjectModel} from "../models/project.model";
import {ProjectAttachmentModel} from "../models/project.attachment.model";
import {ProjectHistoryModel} from "../models/project.history.model";
import {
  CoreID,
  PmTransferRequest,
  ProjectDBRow,
  ProjectObject,
} from "../types/project.types";
import {HISTORY_CHANGE_TYPES, ROLE_IDS} from "../types/system.constants";
import {PROJECT_ERROR_CODES} from "../types/error.types";
import {toDBId, toCoreId} from "../utils/id.converter";
import {db} from "../../Notification/services/db";
import {string} from "zod";

/**
 * 標準化的業務錯誤類別 (Business Error)。
 * 包含標準錯誤碼 (code) 和名稱 (name)，用於回傳給 Controller 層 [7]。
 */
class BusinessError extends Error {
  public code: number;
  public name: string;

  constructor(message: string, code: number, name: string) {
    super(message);
    this.code = code;
    this.name = name;
  }
}

/**
 * PmTransferService 負責 PM 轉讓的 T1-T6 原子交易流程 [2]。
 */
export class PmTransferService {
  private pool: mysql.Pool;
  private projectModel: ProjectModel;
  private attachmentModel: ProjectAttachmentModel;
  private historyModel: ProjectHistoryModel;

  constructor(
    pool: mysql.Pool,
    projectModel: ProjectModel,
    attachmentModel: ProjectAttachmentModel,
    historyModel: ProjectHistoryModel
  ) {
    this.pool = pool;
    this.projectModel = projectModel;
    this.attachmentModel = attachmentModel;
    this.historyModel = historyModel;
  }

  /**
   * 輔助方法：將資料庫 ProjectDBRow 轉換為 ProjectObject。
   * 遵循 ID 資料類型轉換契約 [10, 11]。
   */
  private mapToProjectObject(dbRow: ProjectDBRow): ProjectObject {
    return {
      projectID: toCoreId(dbRow.ProjectID),
      projectName: dbRow.ProjectName,
      description: dbRow.Description,
      ownerUserID: toCoreId(dbRow.OwnerUserID),
      ownerName: dbRow.OwnerName,
      startDate: dbRow.StartDate,
      endDate: dbRow.EndDate,
      currentStateID: dbRow.CurrentStateID, // ProjectObject 必需屬性 [12]
      rdlApprovedByUserID: dbRow.RDLApprovedByUserID
        ? toCoreId(dbRow.RDLApprovedByUserID)
        : null,
      rdlApprovedByName: dbRow.RDLApprovedByName,
      rdlApprovedAt: dbRow.RDLApprovedAt, // ProjectObject 必需屬性 [13]
      projectTagID: dbRow.ProjectTagID,
      deletedAt: dbRow.DeletedAt,
    } as ProjectObject;
  }

  private checkP3Permission(
    projectDbRow: ProjectDBRow,
    currentUserId: CoreID,
    currentUserRole: number
  ): void {
    const currentDbId = toDBId(currentUserId, "CurrentUserID"); // 遵循 ID 轉換契約 [14]

    // P2/P3 檢查: Admin 豁免 [15]
    if (currentUserRole === ROLE_IDS.ADMIN) {
      return;
    }

    // P3 檢查: PM 擁有者 [15]
    if (
      currentUserRole === ROLE_IDS.PM &&
      projectDbRow.OwnerUserID === currentDbId
    ) {
      return;
    }

    // P3 檢查失敗
    const forbiddenError = PROJECT_ERROR_CODES.FORBIDDEN; // 40301 [16]
    throw new BusinessError(
      `權限不足：用戶無權修改此專案。${forbiddenError.description}`,
      forbiddenError.code,
      forbiddenError.name
    );
  }

  /**
   * 執行 PM 轉讓原子交易流程 (T1-T6) [3]。
   * @throws {BusinessError} 40401 (PROJECT_NOT_FOUND), 40301 (PERMISSION_DENIED), 50001 (PM_TRANSFER_FAILED) [3, 16-18]
   */
  public async transferProject(
    projectId: CoreID,
    payload: PmTransferRequest,
    currentUserId: CoreID,
    currentUserRole: number
  ): Promise<ProjectObject> {
    // 1. 執行 ID 轉換契約：CoreID (string) -> DB INT (number) [19]
    const dbProjectId = toDBId(projectId, "ProjectID");
    const dbCurrentUserId = toDBId(currentUserId, "ChangedByUserID");
    const newPmCoreId = payload.ownerUserID;
    const dbNewPmId = toDBId(newPmCoreId, "NewOwnerUserID");

    // 2. T1：前置檢查 (驗證專案存在性、取得舊 PM ID) [19]
    const oldProjectDbRow = await this.projectModel.findByID(dbProjectId);
    const notFoundError = PROJECT_ERROR_CODES.NOT_FOUND; // 40401 [18]

    // ⭐ 結構修正點 1: 專案存在性檢查 (40401)
    if (!oldProjectDbRow) {
      throw new BusinessError(
        notFoundError.description,
        notFoundError.code,
        notFoundError.name
      ); // 40401
    }

    // P3檢查 (Admin 或 舊 PM 擁有者) [15]
    this.checkP3Permission(oldProjectDbRow, currentUserId, currentUserRole);
    const dbOldPmId = oldProjectDbRow.OwnerUserID;

    // T1: 檢查是否嘗試轉讓給自己 (核心修正點)
    if (dbOldPmId === dbNewPmId) {
      // ⭐ 修正：轉讓給自己是無效操作，應拋出 40001 VALIDATION_FAILED 錯誤
      const validationError = PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED; // 40001 [2]
      throw new BusinessError(
        `PM 轉讓失敗：新的專案經理 ID (${newPmCoreId}) 不得與當前的專案經理 ID (${toCoreId(
          dbOldPmId
        )}) 相同。`,
        validationError.code,
        validationError.name
      );
    }

    // T1.1 檢查：新 PM 是否存在且活躍
    const [rows] = await this.pool.execute(
      `SELECT UserID FROM Users WHERE UserID = ? AND Status = 'Active'`,
      [dbNewPmId]
    );
    const activeUsers = rows as mysql.RowDataPacket[];

    if (activeUsers.length === 0) {
      // 拋出 40001 VALIDATION_FAILED 錯誤 [20]
      const validationError = PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED;
      throw new BusinessError(
        `新專案經理 ID (${newPmCoreId}) 無效或非活躍用戶。`,
        validationError.code,
        validationError.name
      ); // 40001
    }

    // ⭐ T1.2 縱深防禦檢查：驗證 New PM 必須是 PM/Admin 角色
    const [roleRows] = await this.pool.execute(
      `SELECT COUNT(*) as count FROM UserGlobalRoles
     WHERE UserID = ? AND RoleID IN (?, ?)`,
      [dbNewPmId, ROLE_IDS.PM, ROLE_IDS.ADMIN] // 角色 ID 3 (PM) 和 1 (Admin) [1]
    );

    const isNewPmAuthorized =
      (roleRows as Array<{count: number}>)[0]?.count > 0;

    if (!isNewPmAuthorized) {
      const validationError = PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED; // 40001 [7]
      throw new BusinessError(
        `PM 轉讓失敗：新的專案經理 ID (${newPmCoreId}) 必須具備 PM 或 Admin 全域角色。`,
        validationError.code,
        validationError.name
      ); // 40001
    }

    // 3. 啟動事務 (Transaction) [21]
    const connection = await this.pool.getConnection();
    const transferFailedError =
      PROJECT_ERROR_CODES.INTERNAL_ERROR.PM_TRANSFER_FAILED; // 50001 [18]

    try {
      await connection.beginTransaction();

      // T2: 鎖定資源 (SELECT FOR UPDATE) - 防止競態條件 [5, 22]
      await connection.query(
        `SELECT * FROM Projects WHERE ProjectID = ? FOR UPDATE`,
        [dbProjectId]
      );

      // T4A：附件轉讓 - 遵循 T4A 附件轉讓契約 [5, 22]
      await this.attachmentModel.transferAttachments(
        dbProjectId,
        dbOldPmId,
        dbNewPmId,
        connection // 傳遞專用連線
      );

      // T4：核心數據更新 - 更新 Projects 表中的 OwnerUserID [5, 22]
      const updateSuccess = await this.projectModel.update(
        dbProjectId,
        {OwnerUserID: dbNewPmId},
        connection // 傳遞專用連線
      );

      if (!updateSuccess) {
        throw new Error("Projects 表 OwnerUserID 更新失敗。");
      }

      // ---------------- 查使用者姓名 ----------------
      const [userRows] = await db.execute<any[]>(
        "SELECT FullName FROM users WHERE UserID = ? LIMIT 1",
        [toCoreId(dbOldPmId)]
      );

      const [userRows1] = await db.execute<any[]>(
        "SELECT FullName FROM users WHERE UserID = ? LIMIT 1",
        [newPmCoreId]
      );

      const currentUserName =
        userRows.length > 0 ? userRows[0].FullName : "未知使用者";

      const targetUserName =
        userRows1.length > 0 ? userRows1[0].FullName : "未知使用者";

      // T3：歷史記錄寫入 - 記錄 PM_TRANSFER [6, 22]
      await this.historyModel.recordChange(
        {
          ProjectID: dbProjectId,
          ChangedByUserID: dbCurrentUserId,
          ChangeType: HISTORY_CHANGE_TYPES.PM_TRANSFER, // 必須是 PM_TRANSFER [23]
          Detail: `專案經理轉讓操作：由 ${toCoreId(
            dbOldPmId
          )} 轉讓給 ${newPmCoreId}。`,
          OldValue: String(dbOldPmId),
          NewValue: String(dbNewPmId),
        },
        // --------------------------通知模組-------------------------------
        {
          UserID: 1,
          ProjectID: dbProjectId,
          MissionID: null,
          Content: `專案經理轉讓操作：由 ${currentUserName} 轉讓給 ${targetUserName}。`,
          IsRead: 0,
        },
        "project_owner_change",
        // ----------------------------------------------------------------
        connection
      ); // ⭐ 修正點 3: 將 connection 傳遞給 recordChange

      // T5: ProjectMembers 同步 - 更新 ProjectMembers 表 [22, 24]
      // 實作 ProjectMembers 同步：確保新的 PM 獲得 PM 角色，舊的 PM 角色被降級。

      // T5-A：確保新 PM 擁有 PM 角色 (RoleID: 3)
      const T5_A_SQL = `
                INSERT INTO ProjectMembers (ProjectID, UserID, RoleID)
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE RoleID = VALUES(RoleID);
            `;
      const T5_A_VALUES = [dbProjectId, dbNewPmId, ROLE_IDS.PM];
      await connection.query(T5_A_SQL, T5_A_VALUES);

      // ⭐ T5-B 修正：移除舊 PM 的 ProjectMembers 記錄 (而不是降級為 RDL)
      const T5_B_SQL = `
                DELETE FROM ProjectMembers
                WHERE ProjectID = ? AND UserID = ?;
            `;
      const T5_B_VALUES = [dbProjectId, dbOldPmId];
      await connection.query(T5_B_SQL, T5_B_VALUES);

      // T6：提交事務 [22, 25]
      await connection.commit();
      connection.release();

      // 4. 重新讀取更新後的數據並轉換為 JSON 傳輸結構 [25]
      const updatedProject = await this.projectModel.findByID(dbProjectId);
      if (!updatedProject) {
        throw new Error("轉讓成功後無法找到專案記錄。");
      }

      return this.mapToProjectObject(updatedProject);
    } catch (error) {
      // 如果 T1-T6 中任何一步失敗，執行回滾 [8, 22]
      await connection.rollback();
      connection.release();
      console.error("PM 轉讓原子交易失敗，已執行回滾:", error);

      // 拋出 50001 PM_TRANSFER_FAILED 錯誤 [18]
      throw new BusinessError(
        transferFailedError.description,
        transferFailedError.code,
        transferFailedError.name
      );
    }
  }
}
