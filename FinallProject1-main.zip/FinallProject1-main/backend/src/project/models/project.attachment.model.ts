// 程式檔案：backend/src/project/models/project.attachment.model.ts [4]
// 層次與職責：專案模組的數據交互與持久化層（Models Layer）[4]。
// 核心職責是負責 ProjectAttachments 資料表的操作，特別是為 T4A 附件轉讓提供數據存取介面 [2, 4]。
// 核心契約與依賴：
// 1. T4A 附件轉讓契約：必須提供方法執行 UPDATE ProjectAttachments SET UploadedByUserID (參考 3.2 T4A 流程 [5])。
// 2. 軟刪除策略 (Soft Delete Strategy)：必須支持附件的軟刪除 (UPDATE DeletedAt = NOW()) (參考 3.3 刪除策略 [6])。
// 3. 數據過濾契約：所有讀取操作必須自動過濾 DeletedAt IS NOT NULL 的記錄 (參考 數據處理契約 [3, 7])。
// 4. 類型安全契約：依賴 AttachmentDBRow 介面規範，確保所有 ID 在模型層中被視為 number (INT) 類型 [8]。
// 5. DB 依據：ProjectAttachments.UploadedByUserID 外鍵為 ON DELETE RESTRICT (總資料庫 [9, 10])，使得 T4A 轉讓邏輯成為強制要求。
// JSDoc 規範：必須用於所有公開方法，且需註明對契約的遵循情況 [3]。
// ===============程式碼本體=================
import * as mysql from "mysql2/promise";
import {CoreID} from "../types/project.types";
// ----------------------------------------------------------------
// 1. 資料庫內部結構定義 (DB Row Interface)
// ----------------------------------------------------------------
/**
 * AttachmentDBRow：ProjectAttachments 表在資料庫中的實際列結構。
 * ⚠️ ID 欄位必須是 number (INT)，以符合資料庫類型契約 [8]。
 */
export interface AttachmentDBRow extends mysql.RowDataPacket {
  AttachmentID: number;
  ProjectID: number;
  FileName: string;
  FilePath: string;
  UploadedByUserID: number; // T4A 轉讓的目標欄位，DB 中為 INT [5]
  UploadedAt: string;
  DeletedAt: string | null; // 軟刪除欄位 [11]
}
// ----------------------------------------------------------------
// 2. ProjectAttachmentModel 類別
// ----------------------------------------------------------------
/**
 * ProjectAttachmentModel 負責 ProjectAttachments 表的 CRUD 操作。
 * 必須實施 T4A 附件轉讓介面和軟刪除策略 [2]。
 */
export class ProjectAttachmentModel {
  private pool: mysql.Pool;
  /**
   * @param pool 資料庫連線池物件
   */
  constructor(pool: mysql.Pool) {
    this.pool = pool;
  }
  // ----------------------------------------------------------------
  // 讀取方法 (必須實施數據過濾契約)
  // ----------------------------------------------------------------
  /**
   * 根據 AttachmentID 查詢單一附件。
   * 必須遵守數據過濾契約 [3]，自動排除已軟刪除的記錄。
   * @param attachmentId 資料庫中的 AttachmentID (number 類型)
   * @returns AttachmentDBRow | null
   */
  public async findByID(attachmentId: number): Promise<AttachmentDBRow | null> {
    // 實施數據過濾契約: WHERE DeletedAt IS NULL [3]
    const sql = `
SELECT * FROM ProjectAttachments
WHERE AttachmentID = ? AND DeletedAt IS NULL
`;
    const [rows] = await this.pool.query(sql, [attachmentId]);
    const attachments = rows as AttachmentDBRow[];
    return attachments.length > 0 ? attachments[0] : null;
  }
  /**
   * 【新增】根據 ProjectID 獲取所有未軟刪除的附件列表。
   * 遵循數據過濾契約：DeletedAt IS NULL [5]。
   * @param projectId 資料庫中的 ProjectID (number 類型)
   * @returns ProjectAttachments 紀錄陣列
   */
  public async findByProjectID(projectId: number): Promise<AttachmentDBRow[]> {
    const sql = `
        SELECT 
            AttachmentID, ProjectID, FileName, FilePath, UploadedByUserID, UploadedAt
        FROM 
            ProjectAttachments
        WHERE 
            ProjectID = ? AND DeletedAt IS NULL 
    `;
    // ⚠️ 數據過濾契約：WHERE DeletedAt IS NULL
    const [rows] = await this.pool.query<AttachmentDBRow[]>(sql, [projectId]);
    return rows;
  }

  // ----------------------------------------------------------------
  // 建立方法 (必須實施 DB 寫入契約)
  // ----------------------------------------------------------------

  /**
   * 建立一個新的專案附件記錄。
   *
   * @param attachmentData 附件的核心資料 (ProjectID, FileName, FilePath, UploadedByUserID)
   * @returns AttachmentDBRow | null
   */
  public async create(
    attachmentData: Omit<
      AttachmentDBRow,
      "AttachmentID" | "UploadedAt" | "DeletedAt"
    >
  ): Promise<AttachmentDBRow | null> {
    const sql = `
        INSERT INTO ProjectAttachments (
            ProjectID, FileName, FilePath, UploadedByUserID
        ) VALUES (?, ?, ?, ?)
    `;

    const values = [
      attachmentData.ProjectID,
      attachmentData.FileName,
      attachmentData.FilePath,
      attachmentData.UploadedByUserID,
    ];

    try {
      const [result] = await this.pool.query(sql, values);
      const insertId = (result as mysql.ResultSetHeader).insertId;

      if (insertId) {
        // 模擬讀取剛剛建立的記錄 (需使用 findByID 來遵循數據過濾契約)
        return this.findByID(insertId);
      }
      return null;
    } catch (error) {
      console.error("Error creating attachment:", error);
      throw error;
    }
  }

  // ----------------------------------------------------------------
  // T4A 附件轉讓方法 (核心職責)
  // ----------------------------------------------------------------
  /**
   * 執行 T4A 附件轉讓 (T4A Attachment Transfer)。
   * 遵循 T4A 附件轉讓契約 [5]：這是 PM 轉讓原子交易 (T1-T6) 中，
   * 解除 UploadedByUserID 的 ON DELETE RESTRICT 約束的關鍵一步 [5, 12]。
   *
   * @param projectId 資料庫中的 ProjectID (number 類型)
   * @param oldPmId 舊 PM 的 UserID (number 類型)
   * @param newPmId 新 PM 的 UserID (number 類型)
   * @returns boolean 是否成功更新至少一筆記錄
   */
  public async transferAttachments(
    projectId: number,
    oldPmId: number,
    newPmId: number,
    connection?: mysql.Connection
  ): Promise<boolean> {
    // // ⭐ T4A 失敗注入點：強制拋出錯誤
    // throw new Error("T4A Simulated Transfer Failure - Must Rollback");
    // 轉讓邏輯：只更新未軟刪除 (DeletedAt IS NULL) 且屬於該專案的附件 [5]
    const sql = `
UPDATE ProjectAttachments
SET UploadedByUserID = ?
WHERE ProjectID = ? AND UploadedByUserID = ? AND DeletedAt IS NULL
`;
    const values = [newPmId, projectId, oldPmId];
    try {
      const executor = connection || this.pool;
      const [result] = await executor.query(sql, values);
      return (result as mysql.ResultSetHeader).affectedRows > 0;
    } catch (error) {
      console.error("Error executing T4A attachment transfer:", error);
      throw error;
    }
  }
  // ----------------------------------------------------------------
  // 附件軟刪除方法 (Soft Delete)
  // ----------------------------------------------------------------
  /**
   * 執行附件的軟刪除 (Soft Delete)。
   * 遵循軟刪除策略，更新 DeletedAt 欄位 [6, 11]。
   *
   * @param attachmentId 資料庫中的 AttachmentID (number 類型)
   * @returns boolean 是否成功執行軟刪除
   */
  public async softDelete(attachmentId: number): Promise<boolean> {
    // 軟刪除實作：執行 UPDATE DeletedAt = NOW() [6]
    const sql = `
UPDATE ProjectAttachments
SET DeletedAt = NOW()
WHERE AttachmentID = ? AND DeletedAt IS NULL
`;
    try {
      const [result] = await this.pool.query(sql, [attachmentId]);
      // 上層 service 成功後需寫入 ProjectHistory 紀錄 (ChangeType 為 ATTACHMENT_UPDATE) [7]
      return (result as mysql.ResultSetHeader).affectedRows > 0;
    } catch (error) {
      console.error("Error executing attachment soft delete:", error);
      throw error;
    }
  }
}
