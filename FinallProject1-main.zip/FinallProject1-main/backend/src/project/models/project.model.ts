// 程式檔案：backend/src/project/models/project.model.ts
// 層次與職責：專案模組的數據交互與持久化層（Models Layer）[1]。
// 核心職責是負責 Projects 資料表的基本 CRUD (建立、讀取、更新、刪除) 操作 [1]。
// 核心契約與依賴：
// 1. 數據過濾契約 (Data Filtering Contract)：所有讀取操作必須自動過濾 DeletedAt IS NOT NULL 的記錄 [1]。
// 2. 軟刪除策略 (Soft Delete Strategy)：處理 DELETE 請求時，必須執行軟刪除 (UPDATE DeletedAt = NOW()) [1]。
// 3. 類型安全契約：依賴 ProjectDBRow 介面，確保 ProjectID 和 OwnerUserID 在模型層中被視為 number (INT) 類型 [1]。
// 4. 原子交易支援契約：update 方法必須支援接收可選的 connection 參數，以確保 T1-T6 事務的原子性 [1]。
// 5. 列表查詢擴展契約：findAllByFilter 必須支援 assignedToUserId 篩選、分頁、排序和標籤過濾 [2]。
// ===============程式碼本體=================

import * as mysql from "mysql2/promise";

import {ProjectDBRow} from "../types/project.types"; // 依賴 ProjectDBRow 介面 [2]

/**
 * 專案列表查詢擴展過濾條件 [2]。
 * Service Layer 用於實施權限和傳遞 Models Layer 擴展查詢所需的參數。
 */
export interface ProjectListFilters {
  status?: number; // 狀態 ID 篩選 [2]
  search?: string; // 搜尋關鍵字 [2]
  assignedToUserId?: number; // DB INT 類型，用於實施 "Assigned Read" 契約 [2]
  // 分頁與排序 (Pagination & Sorting)
  page?: number; // Service 層傳入的頁碼 [3]
  limit?: number; // 每頁記錄數 [3]
  offset?: number; // 偏移量 (Model 層計算或 Service 層計算) [5]
  sortBy?: string; // 排序欄位 [3]
  sortOrder?: "ASC" | "DESC"; // 排序順序 [3]
  // 標籤篩選 (Tag Filter)
  tagId?: number; // Projects.ProjectTagID [3]
}

/**
 * ProjectModel 負責 Projects 表的 CRUD 操作 [3]。
 */
export class ProjectModel {
  private pool: mysql.Pool;

  constructor(pool: mysql.Pool) {
    this.pool = pool;
  }

  /**
   * 建立一個新的專案 [3]。
   */
  public async create(
    projectData: Omit<
      ProjectDBRow,
      | "ProjectID"
      | "OwnerName"
      | "RDLApprovedByName"
      | "CreatedAt"
      | "UpdatedAt"
      | "DeletedAt"
    >
  ): Promise<ProjectDBRow | null> {
    const sql = `
      INSERT INTO Projects (
        ProjectName, Description, OwnerUserID, StartDate, EndDate, CurrentStateID,
        RDLApprovedByUserID, RDLApprovedAt, ProjectTagID
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const values = [
      projectData.ProjectName,
      projectData.Description,
      projectData.OwnerUserID,
      projectData.StartDate,
      projectData.EndDate,
      projectData.CurrentStateID,
      projectData.RDLApprovedByUserID,
      projectData.RDLApprovedAt,
      projectData.ProjectTagID,
    ];

    try {
      const [result] = await this.pool.query(sql, values);
      const insertId = (result as mysql.ResultSetHeader).insertId;
      if (insertId) {
        // 模擬讀取剛剛建立的記錄 (需使用 findByID 來遵循數據過濾契約)
        return this.findByID(insertId);
      }
      return null;
    } catch (error) {
      console.error("Error creating project:", error);
      throw error;
    }
  }

  /**
   * 根據 ProjectID 查詢單一專案 [4]。
   * 必須遵守數據過濾契約，自動排除已軟刪除的記錄 [4]。
   */
  public async findByID(projectId: number): Promise<ProjectDBRow | null> {
    // 實施數據過濾契約: WHERE DeletedAt IS NULL [4]
    const sql = `
          SELECT
          p.*,
          pm_user.FullName AS OwnerName,
          
          COALESCE(
              rdl_user.FullName,
              (SELECT u.FullName FROM Users u 
               JOIN ProjectMembers pm ON u.UserID = pm.UserID 
               WHERE pm.ProjectID = p.ProjectID AND pm.RoleID = 4
               ORDER BY pm.JoinedAt LIMIT 1)
          ) AS RDLApprovedByName 
      FROM Projects p
      JOIN Users pm_user ON p.OwnerUserID = pm_user.UserID
      LEFT JOIN Users rdl_user ON p.RDLApprovedByUserID = rdl_user.UserID
      WHERE
          p.ProjectID = ?
          AND p.DeletedAt IS NULL
    `;
    const [rows] = await this.pool.query(sql, [projectId]);

    const projects = rows as ProjectDBRow[];

    return projects.length > 0 ? projects[0] : null; // [4]
  }

  /**
   * 查詢專案列表，支援篩選和搜尋 [5]。
   * 實施 Assigned Read 契約、數據過濾契約、分頁、排序和多欄位模糊搜尋 [5]。
   */
  public async findAllByFilter(
    filters: ProjectListFilters
  ): Promise<ProjectDBRow[]> {
    // ⭐ 處理分頁和排序參數 [5]
    const limit = filters.limit || 12;
    const page = filters.page || 1;
    const offset =
      filters.offset !== undefined ? filters.offset : (page - 1) * limit; // 允許 Service 層直接傳遞 offset [5]
    const sortBy = filters.sortBy || "EndDate";
    const sortOrder = filters.sortOrder || "ASC";
    const isAssignedRead = filters.assignedToUserId !== undefined; // [5]

    let sql = `
      SELECT
          p.*,
          pm_user.FullName AS OwnerName,
          
          /* ⭐ 關鍵修正：RDL 姓名回退機制 */
          COALESCE(
              rdl_user.FullName, /* 選項 1: 蓋章 RDL (如果 RDLApprovedByUserID 有值) */
              (SELECT u.FullName FROM Users u 
               JOIN ProjectMembers pm ON u.UserID = pm.UserID 
               WHERE pm.ProjectID = p.ProjectID AND pm.RoleID = 4 /* RDL Role ID = 4 [15] */
               ORDER BY pm.JoinedAt LIMIT 1) /* 選項 2: 被指派的 RDL 成員 (如果 RDLApprovedByUserID 為 NULL) */
          ) AS RDLApprovedByName 
      FROM Projects p
    `;

    // ⭐ 聯結 ProjectsMembers (Assigned Read 契約) [6]
    if (isAssignedRead) {
      sql += ` JOIN ProjectMembers pm ON p.ProjectID = pm.ProjectID`;
    }

    // ⭐ 聯結 Users 表以支援 PM 姓名搜尋 [6]
    sql += ` JOIN Users pm_user ON p.OwnerUserID = pm_user.UserID`;

    // ⭐ 聯結 Users 表以支援 RDL 姓名搜尋 (RDLApprovedByUserID 可為 NULL，使用 LEFT JOIN) [6]
    sql += ` LEFT JOIN Users rdl_user ON p.RDLApprovedByUserID = rdl_user.UserID`;

    // 基礎 WHERE 條件：數據過濾契約 (DeletedAt IS NULL) [7]
    sql += ` WHERE p.DeletedAt IS NULL`; // [7]

    const values: (string | number)[] = [];

    // 1. Assigned Read 過濾 [7]
    if (isAssignedRead) {
      sql += ` AND pm.UserID = ?`; // [7]
      values.push(filters.assignedToUserId as number);
    }

    // 2. 狀態篩選 (Status Filter) [7]
    if (filters.status !== undefined) {
      sql += ` AND p.CurrentStateID = ?`; // [7]
      values.push(filters.status);
    }

    // 3. 標籤篩選 (Tag Filter) [8]
    if (filters.tagId !== undefined) {
      sql += ` AND p.ProjectTagID = ?`; // [8]
      values.push(filters.tagId);
    }

    // 4. 搜尋關鍵字 (Search Filter) [8]
    if (filters.search) {
      const searchPattern = `%${filters.search}%`;
      sql += ` AND (
        p.ProjectName LIKE ?
        OR p.Description LIKE ?
        OR pm_user.FullName LIKE ?         /* 搜尋 PM 姓名 */
        OR rdl_user.FullName LIKE ?        /* 搜尋 RDL 姓名 */
      )`;
      // 注意：這裡只對 rdl_user.FullName 進行搜尋，無法涵蓋 RDL 成員回退機制中的姓名。
      values.push(searchPattern, searchPattern, searchPattern, searchPattern); // [8]
    }

    // 避免 JOIN ProjectMembers 帶來的重複記錄
    // 如果 isAssignedRead 為 true，必須使用 GROUP BY [9]
    if (isAssignedRead) {
      sql += ` GROUP BY p.ProjectID`;
    }

    // 排序和分頁 [5]
    sql += ` ORDER BY ${sortBy} ${sortOrder}`;
    sql += ` LIMIT ? OFFSET ?`;
    values.push(limit, offset);

    try {
      const [rows] = await this.pool.query(sql, values);
      return rows as ProjectDBRow[];
    } catch (error) {
      console.error("Error executing findAllByFilter:", error);
      throw error; // [9]
    }
  }

  /**
   * ⭐ 查詢符合篩選條件的專案總數 [9]。
   * 遵循數據過濾契約 [9]，與 findAllByFilter 使用相同的 WHERE/JOIN 邏輯，但不使用 LIMIT/OFFSET/ORDER BY [9]。
   */
  public async countAllByFilter(filters: ProjectListFilters): Promise<number> {
    const isAssignedRead = filters.assignedToUserId !== undefined; // [9]
    const values: (string | number)[] = []; // [9]

    // 1. 基礎 SQL 結構：只 SELECT COUNT(*)
    // 使用 COUNT(DISTINCT p.ProjectID) 避免 JOIN ProjectMembers 時重複計算 [9]
    let sql = `
      SELECT COUNT(DISTINCT p.ProjectID) as total
      FROM Projects p
    `; // [9, 10]

    // ⭐ 複製 findAllByFilter 的 JOINs 邏輯 [10]
    if (isAssignedRead) {
      sql += ` JOIN ProjectMembers pm ON p.ProjectID = pm.ProjectID`;
    }
    sql += ` JOIN Users pm_user ON p.OwnerUserID = pm_user.UserID`;
    sql += ` LEFT JOIN Users rdl_user ON p.RDLApprovedByUserID = rdl_user.UserID`;

    // 基礎 WHERE 條件：數據過濾契約 (DeletedAt IS NULL) [10]
    sql += ` WHERE p.DeletedAt IS NULL`;

    // ⭐ 複製 findAllByFilter 的 WHERE 條件邏輯 [10, 11]
    // 1. Assigned Read 過濾
    if (isAssignedRead) {
      sql += ` AND pm.UserID = ?`; // [11]
      values.push(filters.assignedToUserId as number); // [11]
    }

    // 2. 狀態篩選 (Status Filter)
    if (filters.status !== undefined) {
      sql += ` AND p.CurrentStateID = ?`; // [11]
      values.push(filters.status); // [11]
    }

    // 3. 標籤篩選 (Tag Filter)
    if (filters.tagId !== undefined) {
      sql += ` AND p.ProjectTagID = ?`; // [11]
      values.push(filters.tagId); // [11]
    }

    // 4. 搜尋關鍵字 (Search Filter)
    if (filters.search) {
      const searchPattern = `%${filters.search}%`; // [11]
      sql += ` AND (
        p.ProjectName LIKE ?
        OR p.Description LIKE ?
        OR pm_user.FullName LIKE ?
        OR rdl_user.FullName LIKE ?
      )`; // [11]
      values.push(searchPattern, searchPattern, searchPattern, searchPattern); // [11]
    }

    const [rows] = await this.pool.query(sql, values);
    const result = rows as Array<{total: number}>;
    return result ? result[0].total : 0;
  }

  /**
   * 更新專案的一般欄位 [12]。
   * 實施原子交易支援契約：支援接收可選的 connection 參數 [12]。
   */
  public async update(
    projectId: number,
    updateFields: Partial<
      Omit<ProjectDBRow, "ProjectID" | "CreatedAt" | "UpdatedAt" | "DeletedAt"> // 修正：加上 DeletedAt [12]
    >,
    connection?: mysql.Connection // 原子交易支援契約 [12]
  ): Promise<boolean> {
    const fields = Object.keys(updateFields)
      .map((key) => `${key} = ?`)
      .join(", ");
    const values = Object.values(updateFields);

    if (values.length === 0) {
      return false; // [13]
    }

    const sql = `UPDATE Projects SET ${fields} WHERE ProjectID = ?`; // [13]

    // 實施原子交易支援契約：使用傳入的 connection，如果沒有則使用 pool [13]
    const executor = connection || this.pool;
    const [result] = await executor.query(sql, [...values, projectId]);
    return (result as mysql.ResultSetHeader).affectedRows > 0; // [13]
  }

  /**
   * 執行專案的軟刪除 (Soft Delete) [13]。
   * 實施軟刪除策略，上層 service 成功後需寫入 ProjectHistory 紀錄 (ChangeType 為 PROJECT_DELETED) [13]。
   */
  public async softDelete(projectId: number): Promise<boolean> {
    // 軟刪除實作：執行 UPDATE DeletedAt = NOW() [14]
    const sql = `
      UPDATE Projects
      SET DeletedAt = NOW()
      WHERE ProjectID = ? AND DeletedAt IS NULL
    `; // [14]

    try {
      const [result] = await this.pool.query(sql, [projectId]);
      return (result as mysql.ResultSetHeader).affectedRows > 0; // [14]
    } catch (error) {
      console.error("Error executing soft delete:", error); // [14]
      throw error; // [14]
    }
  }
}
