// 程式檔案：backend/src/project/models/project.history.model.ts [2]
// 層次與職責：專案模組的數據交互與持久化層（Models Layer）[1]。
// 核心職責是專門處理 ProjectHistory 表的 INSERT 邏輯，記錄所有專案變動 [1, 2]。

// 核心契約與依賴：
// 1. 歷史記錄類型契約：必須支援所有 9 種必須追蹤的變動類型 (HISTORY_CHANGE_TYPES) [1, 3]。
// 2. DB 契約依據：ProjectHistory.ChangedByUserID 設為 INT NOT NULL 和 ON DELETE RESTRICT [6, 7]。
// 3. 類型安全契約：所有 ID 欄位必須是 number (INT) 類型 [7, 8]。

// JSDoc 規範：必須用於所有公開方法，且需註明對契約的遵循情況 [9]。
// ===============程式碼本體=================

import * as mysql from "mysql2/promise";
import {HISTORY_CHANGE_TYPES} from "../types/system.constants";
[3, 4];

import axios from "axios";
import {broadcastNewNotification} from "../../Notification/routes/list"; // ⭐ 新增 SSE 廣播匯入

// ----------------------------------------------------------------
// 1. 資料庫內部結構定義 (DB Row Interface)
// ----------------------------------------------------------------

/**
 * ProjectHistoryDBRow：ProjectHistory 表在資料庫中的實際列結構。
 */
export interface ProjectHistoryDBRow extends mysql.RowDataPacket {
  HistoryID: number;
  ProjectID: number;
  ChangedByUserID: number; // DB 中為 INT NOT NULL [7]
  ChangeType: keyof typeof HISTORY_CHANGE_TYPES; // 變更類型 ENUM [3]
  Detail: string | null;
  OldValue: string | null;
  NewValue: string | null;
  ChangedAt: string;
}

export interface NotificationDBRow extends mysql.RowDataPacket {
  NotificationID: number;
  UserID: number;
  ProjectID: number | null;
  MissionID: number | null;
  Content: string;
  Link?: string | null;
  IsRead: number;
  CreatedAt: string | null;
  DeletedAt: string | null;
}

// ----------------------------------------------------------------
// 2. ProjectHistoryModel 類別
// ----------------------------------------------------------------

/**
 * ProjectHistoryModel 負責專案歷史記錄的寫入操作。
 * 該模型只提供 INSERT 方法，專門服務於 Services Layer 的審計追蹤需求。
 */
export class ProjectHistoryModel {
  private pool: mysql.Pool;

  /**
   * @param pool 資料庫連線池物件
   */
  constructor(pool: mysql.Pool) {
    this.pool = pool;
  }

  // ----------------------------------------------------------------
  // 核心寫入方法 (Core INSERT Method)
  // ----------------------------------------------------------------

  /**
   * 記錄專案變更歷史。
   * 遵循歷史記錄類型契約，必須支援 HISTORY_CHANGE_TYPES 中定義的 9 種變動類型 [3, 5]。
   *
   * @param historyData 歷史記錄數據 (ProjectID, ChangedByUserID, ChangeType 等)
   * @returns boolean 寫入是否成功
   */
  public async recordChange(
    historyData: Omit<ProjectHistoryDBRow, "HistoryID" | "ChangedAt"> | null,
    // --------------------------通知模組-------------------------------
    notificationData: Omit<NotificationDBRow,"NotificationID" | "CreatedAt" | "DeletedAt"> | null,
    triggerName?: string,  // ✅ 新增 triggerName 參數，預設值
    // ----------------------------------------------------------------
    connection?: mysql.Connection // ⭐ 修正點 1: 接受可選連線
  ): Promise<boolean> {
    const sql = `
            INSERT INTO ProjectHistory (
                ProjectID, ChangedByUserID, ChangeType, Detail, OldValue, NewValue
            ) VALUES (?, ?, ?, ?, ?, ?)
        `;

    // 確保 ChangeType 是有效的契約類型 [3, 5]
    if (!(historyData?.ChangeType in HISTORY_CHANGE_TYPES)) {
      // 由於這是 Models Layer，通常會拋出底層錯誤，由 Services Layer 處理錯誤碼 [1]
      throw new Error(`Invalid ChangeType: ${historyData?.ChangeType}`);
    }

    const values = [
      historyData?.ProjectID,
      historyData?.ChangedByUserID, // ChangedByUserID 是 INT 且 NOT NULL [7]
      historyData?.ChangeType,
      historyData?.Detail,
      historyData?.OldValue,
      historyData?.NewValue,
    ];

    try {
      // ⭐ 修正點 2: 使用傳入的 connection，如果沒有則使用 pool
      const executor = connection || this.pool;
      const [result] = await executor.query(sql, values);

      console.log("🚀 NotificationData 傳入內容:", notificationData);

      // --------------------------通知模組-------------------------------
      //若有通知資料，則寫入 Notifications

      let shouldSendNotification = false;
      let shouldSendEmail = false;
      let finalRecipientUserId = null;

      const [rulesRows] = await executor.query(`
          SELECT TriggerDefinition, ActionDefinition
          FROM automationrules
          WHERE IsEnabled = 1 AND DeletedAt IS NULL;
        `);


      for (const rule of rulesRows as { TriggerDefinition: string, ActionDefinition: string }[]) {

      const trigger = typeof rule.TriggerDefinition === "string"
      ? JSON.parse(rule.TriggerDefinition)
      : rule.TriggerDefinition;

    const action = typeof rule.ActionDefinition === "string"
      ? JSON.parse(rule.ActionDefinition)
      : rule.ActionDefinition;

      // 🎯 只處理 trigger = project_changed 的規則
      if (trigger.trigger === triggerName) {

        

        // ✔ send_notification
        if (action.action === "send_notification") {

          console.log("send_notification:",action.action);
          shouldSendNotification = true;
          finalRecipientUserId = action.recipient_user_id ?? notificationData?.UserID;
        }

        // ✔ send_email
        if (action.action === "send_email") {

          console.log("send_email:",action.action);
          shouldSendEmail = true;
          finalRecipientUserId = action.recipient_user_id ?? notificationData?.UserID;
        }
      }
    }

    console.log("send_notification:",shouldSendNotification);
    console.log("shouldSendEmail:",shouldSendEmail);

    if (shouldSendNotification || shouldSendEmail) {

      if (notificationData && shouldSendNotification) {
        const sqlNotification = `
          INSERT INTO Notifications (
            UserID, ProjectID, MissionID, Content, Link, IsRead, CreatedAt
          ) VALUES (?, ?, ?, ?, ?, ?, NOW())
        `;
        const notificationValues = [
          notificationData.UserID,
          notificationData.ProjectID,
          notificationData.MissionID,
          notificationData.Content,
          notificationData.Link ?? null,
          notificationData.IsRead ?? 0,
        ];

        // ✅ 1. 寫入 Notifications 資料表
        const [resultNotification] = await executor.query(sqlNotification, notificationValues);

        console.log("✅ 寫入 Notifications 成功，內容為:", notificationValues);

        // ✅ 2. 推播給所有前端
        const newNotification = {
          NotificationID: (resultNotification as mysql.ResultSetHeader).insertId,
          UserID: notificationData.UserID,
          ProjectID: notificationData.ProjectID,
          MissionID: notificationData.MissionID,
          Content: notificationData.Content,
          Link: notificationData.Link ?? null,
          IsRead: notificationData.IsRead ?? 0,
          CreatedAt: new Date().toISOString(),
        };

        // 呼叫 SSE 推播
        await broadcastNewNotification(newNotification);
      }


      // 3️⃣ 通知寫入後，呼叫寄信 API
        if (shouldSendEmail) {

          try {
          axios.post("http://localhost:4000/api/send-email", {
            userId: notificationData?.UserID,
            projectId: notificationData?.ProjectID,
            content: notificationData?.Content || "系統通知：有最新變更",
          });
          console.log("✅ Email notification sent successfully");
        } catch (emailErr) {
          console.error("⚠️ Failed to send email notification:", emailErr);
        }

        }

    }

      
    // ----------------------------------------------------------------


      return (result as mysql.ResultSetHeader).affectedRows === 1;
    } catch (error) {
      console.error("Error recording project history:", error);
      // 當 ChangedByUserID 違反 ON DELETE RESTRICT 約束時，這裡會拋出 DB 錯誤 [6, 7]
      throw error;
    }
  }
  // ----------------------------------------------------------------
  // ⭐ 新增：讀取方法 (API 擴展 4 依賴)
  // ----------------------------------------------------------------

  /**
   * ⭐ 新增：根據 ProjectID 查詢專案的所有歷史記錄。
   *
   * @param projectId 資料庫中的 ProjectID (number 類型)
   * @returns ProjectHistoryDBRow[]
   */
  public async findByProjectId(
    projectId: number
  ): Promise<ProjectHistoryDBRow[]> {
    const sql = `
SELECT * FROM ProjectHistory
WHERE ProjectID = ?
ORDER BY ChangedAt DESC
`;
    const [rows] = await this.pool.query(sql, [projectId]);
    return rows as ProjectHistoryDBRow[];
  }
}
