// 程式檔案：backend/src/project/types/project.types.ts
// 層次與職責：系統定義與數據契約層（Types Layer）。
// 核心職責是定義專案模組中所有核心數據傳輸結構 (DTOs)、資料庫列結構，以及 ID 類型契約 [1, 2]。
// 核心契約與依賴：
// 1. ID 資料類型轉換契約 (ID Conversion Contract)：JSON 傳輸中所有核心 ID (ProjectID, UserID) 必須是 string (CoreID) 類型 [1]。
// 2. 資料庫類型契約 (DB Type Contract)：資料庫內部結構 ProjectDBRow 的 ID 欄位 (例如 ProjectID, OwnerUserID) 必須是 number (INT) 類型 [1]。
// 3. JSON 結構綱要：必須遵循 1.3 專案與任務 JSON 結構綱要 [1]。
// JSDoc 規範：必須用於所有匯出 (export) 的介面和類型 [1, 3]。
// ===============程式碼本體=================
import * as mysql from "mysql2/promise";
import {HISTORY_CHANGE_TYPES} from "./system.constants"; // 假設此處已引入 HISTORY_CHANGE_TYPES

/**
 * 通用核心 ID 類型 (例如 ProjectID, UserID, AttachmentID)。
 * 根據 ID 資料類型轉換契約，在 JSON 傳輸中必須是 string 類型 [4]。
 */
export type CoreID = string;

// ----------------------------------------------------------------
// 1. Mission 摘要結構 (MissionSummary Object)
// ----------------------------------------------------------------

/**
 * Missions 摘要結構，用於在 Project Object 中提供唯讀的任務資訊 [4]。
 */
export interface MissionSummary {
  missionID: CoreID; // 任務唯一識別碼 (string) [4]
  title: string;
  description: string;
  /** Missions.Status 欄位的 ENUM 值 [5] */
  status: "Open" | "In Progress" | "Testing" | "Reopened" | "Closed";
  assigneeID: CoreID | null; // 任務指派人 ID (string) [5]
  qaSignedByUserID: CoreID | null; // QA 蓋章者 ID (string) [5]
  dueDate: string; // 預計到期日期 (YYYY-MM-DD 格式) [5]
}

// ----------------------------------------------------------------
// 2. 附件結構 (Attachment Object)
// ----------------------------------------------------------------

/**
 * 附件 JSON 結構 [6]。
 * UploadedByUserID 是 T4A 轉讓流程的目標欄位 [6]。
 */
export interface AttachmentObject {
  attachmentID: CoreID; // 附件唯一識別碼 (string) [6]
  projectID: CoreID; // 所屬專案 ID (string) [6]
  fileName: string;
  filePath: string;
  uploadedByUserID: CoreID; // 上傳者 ID (string) [6]
  uploadedAt: string; // 時間戳記格式 [6]
}

// ----------------------------------------------------------------
// 3. 專案核心結構 (Project Object - JSON 傳輸結構)
// ----------------------------------------------------------------

/**
 * 專案核心表 JSON 結構，用於前後端數據傳輸 (DTO) [7]。
 * ID 欄位皆為 CoreID (string) 類型。
 */
export interface ProjectObject {
  projectID?: CoreID; // 專案 ID (string) [7]
  projectName: string;
  description: string;
  ownerUserID: CoreID; // PM ID (OwnerUserID)，必須是 string 類型 [7]
  ownerName: string; // ⭐ 來自 ProjectDBRow 擴展 [7]
  startDate: string; // YYYY-MM-DD 格式 [7]
  endDate: string; // YYYY-MM-DD 格式 [7]
  currentStateID: number; // 當前專案狀態 ID (number) [7]
  rdlApprovedByUserID: CoreID | null; // RDL 蓋章者 ID (string) [7]
  rdlApprovedByName: string; // ⭐ 來自 ProjectDBRow 擴展 [8]
  rdlApprovedAt: string | null;
  projectTagID: number | null; // 專案標籤 ID (number) [8]
  deletedAt?: string | null; // 軟刪除時間戳記 [8]
  // 關聯數據
  attachments?: AttachmentObject[]; // 附件列表 [8]
  missionSummary?: MissionSummary[]; // 任務摘要列表 (唯讀) [8]
}

// ----------------------------------------------------------------
// 4. 特殊操作 Request Payload 介面
// ----------------------------------------------------------------

/**
 * PM 轉讓 (PM Transfer) 請求體介面 [9]。
 */
export interface PmTransferRequest {
  ownerUserID: CoreID; // 新的 PM ID (string) [9]
}

/**
 * RDL 蓋章 (RDL Stamp) 請求體介面 [9]。
 */
export interface RdlStampRequest {
  rdlApproved: boolean; // 固定為 true [9]
}

/**
 * 一般欄位更新 (General Update) 請求體介面 [9]。
 */
export type ProjectUpdateRequest = Partial<ProjectObject>;

/**
 * ⭐ 新增：專案成員動作請求介面 (Service/Controller Payload)。
 * 用於新增或移除成員 [10]。
 */
export interface MemberActionRequest {
  userId: CoreID;
  roleId?: number; // 角色 ID (number)
}

// ----------------------------------------------------------------
// ⭐ 新增：數據獲取 DTOs (Data Retrieval DTOs)
// ----------------------------------------------------------------

/**
 * ⭐ 新增：可指派使用者 DTO，用於新增專案或成員選單 (API 擴展 1)。
 */
export interface AssignableUserObject {
  userID: CoreID;
  fullName: string;
  title: string;
}

/**
 * ⭐ 新增：專案成員 DTO，用於專案詳情頁面 (Tab 4) (API 擴展 2)。
 */
export interface ProjectMemberObject {
  userID: CoreID;
  fullName: string;
  roleID: number;
  roleName: string; // 角色名稱，例如 PM, RDL, RD
  joinedAt: string; // 加入時間 (Timestamp)
}

/**
 * ⭐ 新增：專案歷史記錄 DTO，用於專案詳情頁面 (Tab 5) (API 擴展 4)。
 */
export interface ProjectHistoryObject {
  historyID: CoreID;
  changedByUserID: CoreID;
  changedByUserName: string;
  changeType: keyof typeof HISTORY_CHANGE_TYPES;
  detail: string | null;
  oldValue: string | null;
  newValue: string | null;
  changedAt: string;
}

// ----------------------------------------------------------------
// 5. 資料庫內部結構定義 (DB Row Interface)
// ----------------------------------------------------------------

/**
 * ProjectDBRow：Projects 表在資料庫中的實際列結構 [11]。
 * ⚠️ 這裡的 ProjectID 和 UserID 必須是 number (INT)，因為它們是 DB 類型 [11]。
 */
export interface ProjectDBRow extends mysql.RowDataPacket {
  ProjectID: number; // DB 儲存為 INT [11]
  ProjectName: string;
  Description: string;
  OwnerUserID: number; // DB 儲存為 INT [11]
  OwnerName: string; // ⭐ JOIN 得到的欄位 [11]
  StartDate: string;
  EndDate: string;
  CurrentStateID: number;
  RDLApprovedByUserID: number | null; // DB 儲存為 INT 或 NULL [12]
  RDLApprovedByName: string; // ⭐ JOIN 得到的欄位 [12]
  RDLApprovedAt: string | null;
  ProjectTagID: number | null;
  DeletedAt: string | null; // 軟刪除欄位 [12]
  CreatedAt: string;
  UpdatedAt: string;
}
