// 程式檔案：backend/src/project/types/error.types.ts

// 層次與職責：系統定義與數據契約層（Types Layer）。
// 核心職責是定義專案模組中所有必須遵循的標準化核心錯誤碼規範 (Error Code Specification)。

// 核心契約與依賴：
// 1. 核心錯誤碼規範 (Error Code Contract)：必須實施 1.4 專案 API 接口文件中定義的所有核心錯誤代碼。
// 2. 架構鎖定依賴：必須包含 P1 檢查所需的 40901，C3 檢查所需的 40002，以及 T1-T6 交易所需的 50001。

// JSDoc 規範：必須用於所有匯出 (export) 的類型和常數。

// ===============程式碼本體=================

/**
 * 標準化錯誤回傳結構 (JSON Response Body)
 */
export interface ErrorResponse {
  /** 錯誤代碼 (例如 40301, 50001) */
  code: number;
  /** 錯誤描述 */
  message: string;
}

/**
 * 專案模組所有核心錯誤碼定義 (Error Code Constants)
 * 用於 services 層和 controllers 層回傳精確的業務邏輯失敗訊息。
 */
export const PROJECT_ERROR_CODES = {
  /** 403 Forbidden 錯誤碼 */
  FORBIDDEN: {
    code: 40301,
    name: "PERMISSION_DENIED",
    description:
      "權限不足：用戶無權執行此操作或修改此欄位。這用於 P3/P6 權限檢查失敗。",
  },

  /** 400 Bad Request 錯誤碼 */
  BAD_REQUEST: {
    /** 數據驗證失敗 */
    VALIDATION_FAILED: {
      code: 40001,
      name: "VALIDATION_FAILED",
      description: "數據驗證失敗：Request Body 格式錯誤或缺少必填欄位。",
    },
    /** RDL 蓋章前置檢查失敗 */
    RDL_STAMP_FAILED: {
      code: 40002,
      name: "RDL_STAMP_FAILED",
      description:
        "蓋章前置檢查失敗：尚有未通過 QA 審計的任務。此為 3.1 C3 聚合檢查失敗。",
    },
  },

  /** 404 Not Found 錯誤碼 */
  NOT_FOUND: {
    code: 40401,
    name: "PROJECT_NOT_FOUND",
    description: "找不到指定的專案。",
  },

  /** 409 Conflict 錯誤碼 (資源衝突/狀態鎖定) */
  CONFLICT: {
    /** 專案狀態鎖定不可變 */
    PROJECT_STATE_IMMUTABLE: {
      code: 40901,
      name: "PROJECT_STATE_IMMUTABLE",
      description:
        "專案狀態為 Completed/Archived，禁止任何修改。此為 P1 狀態鎖定檢查。",
    },
  },

  /** 500 Internal Error 錯誤碼 (原子交易失敗) */
  INTERNAL_ERROR: {
    /** PM 轉讓原子交易失敗 */
    PM_TRANSFER_FAILED: {
      code: 50001,
      name: "PM_TRANSFER_FAILED",
      description:
        "PM 轉讓失敗：原子操作未完成，數據已回滾。此為 3.2 T1-T6 交易失敗。",
    },
  },
} as const;
