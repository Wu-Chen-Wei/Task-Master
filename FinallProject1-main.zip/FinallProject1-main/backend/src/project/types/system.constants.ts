// 程式檔案：backend/src/project/types/system.constants.ts
// 層次與職責：系統定義與數據契約層 (Types Layer)。
// 核心職責：定義專案模組中所有 ENUM/FK 的數值常數，作為所有業務邏輯判斷的基礎契約。
// 核心契約與依賴：
// 1. 角色 ID 契約：定義 PM, RDL, QA 等角色的數值 ID，用於服務層的 P3/P6 權限檢查。
// 2. 專案狀態 ID 契約：定義專案流程狀態 ID，特別用於 project.auth.middleware.ts 的 P1 狀態鎖定檢查。
// 3. 歷史記錄類型契約：定義 11 種必須追蹤的變動類型，用於 Services Layer 寫入 ProjectHistory。

// ===============程式碼本體=================

/**
 * 角色 ID 數值常數 (Roles.RoleID)
 * 已同步 Member Module 資料庫的實際 RoleID [1]。
 */
export const ROLE_IDS = {
  /** 系統最高管理員 (System Administrator)，ID: 1。用於 P2 檢查 Admin 豁免權 [1-3]。 */
  ADMIN: 1,

  /** 專案經理 (Project Manager)，ID: 3 [1]。用於 P3 專案所有權檢查 [4] 及 PM 轉讓 (T1-T6) 流程 [1, 5]。 */
  PM: 3,

  /** 研發主管 (R&D Leader)，ID: 4 [1]。用於 RDL 蓋章 (C1-C3 檢查) [6] 及 P6 附件管理權限 [3]。 */
  RDL: 4,

  /** 研發工程師 (R&D)，ID: 5 [1]。主要在 Mission 層級操作，專案層級為唯讀 [7]。 */
  RD: 5,

  /** 品質擔保 (Quality Assurance)，ID: 6 [1]。主要在 Mission 層級執行 QA 驗證/蓋章 [8]。 */
  QA: 6,
} as const;

/**
 * 專案工作流程狀態 ID 數值常數 (Projects.CurrentStateID) [9]。
 * 這些狀態是專案生命週期流轉的依據，並用於 P1 狀態鎖定檢查 [1]。
 */
export const PROJECT_STATE_IDS = {
  /** 專案已建立，建立狀態初始為 10 (未開始) [9]。PM 確定資訊無誤後，按下確認按鈕進入 20 交給 RDL 分析。 */
  UNSTARTED: 10,

  /** 專案分析中狀態，ID: 20 [9]。RDL 分析完並建立 Missions 後，按下按鈕進入 30 (Active)。 */
  PendingReview: 20,

  /** 專案開發中狀態，ID: 30 (Active) [9]。RD 開發階段。所有 Missions 通過 QA 驗證後，系統自動或手動流轉進入 40 (ReadyForClosure)。 */
  Active: 30,

  /** 專案審查狀態，ID: 40 (ReadyForClosure) [9]。這是 RDL 蓋章 (C1 檢查) 的必要前置狀態 [10]。 */
  READY_FOR_CLOSURE: 40,

  /** 專案已結案狀態，ID: 50 (Completed) [9]。處於此狀態時，必須在 Middleware/Service 層實施 P1 狀態鎖定 (40901) [11-13]。 */
  COMPLETED: 50,

  /** 專案歷史歸檔狀態，ID: 60 (Archived) [9]。處於此狀態時，必須實施 P1 狀態鎖定 (40901) [11-13]。 */
  ARCHIVED: 60,
} as const;

/**
 * 任務工作流程狀態 ENUM (Missions.Status) [9]。
 * 用於 RDL 蓋章的 C3 任務審計聚合驗證 [14]。
 */
export const MISSION_STATUS = {
  /** 任務已指派，等待開始 (Open) [9]。 */
  OPEN: "Open",

  /** 任務正在開發中 (In Progress) [8]。 */
  IN_PROGRESS: "In Progress",

  /** 開發完成，提交 QA 驗證 (Testing) [8]。 */
  TESTING: "Testing",

  /** QA 驗證失敗，退回 RD 修改 (Reopened) [8]。 */
  REOPENED: "Reopened",

  /** QA 驗證成功並蓋章擔保 (Closed) [8]。 Missions.Status 必須是 'Closed' 才能通過 C3 檢查 [14]。 */
  CLOSED: "Closed",
} as const;

/**
 * 專案歷史記錄變更類型 ENUM (ProjectHistory.ChangeType) [8]。
 * 總共有 11 種必須追蹤的變動類型，由 Services 層寫入 ProjectHistoryModel [8, 15]。
 */
export const HISTORY_CHANGE_TYPES = {
  /** 專案初次建立 (POST) [16]。由 ProjectCrudService 觸發 [17]。 */
  PROJECT_CREATED: "PROJECT_CREATED",

  /** 專案軟刪除 (DELETE) [16]。由 ProjectCrudService 觸發 [18]。 */
  PROJECT_DELETED: "PROJECT_DELETED",

  /** 專案名稱 Projects.ProjectName 變更 [16]。 */
  PROJECT_NAME_UPDATE: "PROJECT_NAME_UPDATE",

  /** 專案描述 Projects.Description 變更 [16]。 */
  DESCRIPTION_UPDATE: "DESCRIPTION_UPDATE",

  /** 專案時程 Projects.StartDate/EndDate 變更 [16]。*/
  DATE_UPDATE: "DATE_UPDATE",

  /** 專案狀態 Projects.CurrentStateID 變更 [16]。用於記錄 UNSTARTED -> PendingReview -> Active 等流程流轉。 */
  STATE_TRANSITION: "STATE_TRANSITION",

  /** RDL 執行蓋章 (Projects.RDLApprovedByUserID/At 變更) [16]。由 RdlStampService 成功後觸發 [19]。 */
  RDL_STAMP: "RDL_STAMP",

  /** PM 轉讓 (Projects.OwnerUserID 變更) [20]。由 PmTransferService 執行 T3 歷史記錄寫入 [21]。 */
  PM_TRANSFER: "PM_TRANSFER",

  /** 附件新增/刪除 [20]。由 AttachmentService 觸發 [22, 23]。 */
  ATTACHMENT_UPDATE: "ATTACHMENT_UPDATE",

  /** 專案標籤 Projects.ProjectTagID 變更 [20, 24]。 */
  PROJECT_TAG_UPDATE: "PROJECT_TAG_UPDATE",

  /** 專案成員變更 (不包含 PM 轉讓，特指 RD/QA 的新增/移除) [20, 24]。 */
  PROJECT_PROJECTMEMBERS_UPDATE: "PROJECT_PROJECTMEMBERS_UPDATE",
} as const;
