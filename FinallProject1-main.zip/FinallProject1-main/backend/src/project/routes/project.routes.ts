// 程式檔案：backend/src/project/routes/project.routes.ts
// 層次與職責：請求進入與路由層（Routes Layer）。
// 核心職責是定義核心專案 API 路徑 /api/v1/projects 的 CRUD 操作，並將請求綁定到 ProjectController 的方法。

import {Router} from "express";
import {ProjectModel} from "../models/project.model";
import {ProjectCrudService} from "../services/project.crud.service";
import {PmTransferService} from "../services/pm.transfer.service";
import {RdlStampService} from "../services/rdl.stamp.service";
import {ProjectController} from "../controllers/project.controller";
import * as mysql from "mysql2/promise";
import {authenticate} from "../../member/middlewares/auth.middleware";
import {projectAuthMiddleware} from "../middlewares/project.auth.middleware";
import {ROLE_IDS} from "../types/system.constants"; // 引入角色常數

/**
 * 建立專案路由的工廠函數。
 */
export const createProjectRoutes = (
  pool: mysql.Pool,
  projectModel: ProjectModel,
  projectCrudService: ProjectCrudService,
  pmTransferService: PmTransferService,
  rdlStampService: RdlStampService
): Router => {
  const router = Router();

  const projectController = new ProjectController(
    projectCrudService,
    pmTransferService,
    rdlStampService
  );

  // 初始化 P1 狀態鎖定中介軟體
  const p1AuthMiddleware = projectAuthMiddleware(projectModel);

  // =========================================================
  // 專案核心 CRUD 路由 (路由優先級修正區)
  // =========================================================

  // 1. 擴展 1: GET /api/v1/projects/assignable (特定路徑優先)
  router.get("/assignable", authenticate, projectController.getAssignableUsers);

  // 2. 處理 GET /api/v1/projects/all (PM/Admin 專用，特定路徑優先)
  router.get("/all", authenticate, projectController.getAllProjectsList);

  // 3. 處理 GET /api/v1/projects (列表查詢，無參數)。
  router.get("/", authenticate, projectController.getProjectsList);

  // 4. 處理 POST /api/v1/projects 請求 (建立專案)。
  router.post("/", authenticate, projectController.createProject);

  // =========================================================
  // 專案詳情頁擴展 API (皆包含 :projectId 參數)
  // =========================================================

  // 5. 擴展 2：GET /api/v1/projects/:projectId/members (獲取成員列表)
  router.get(
    "/:projectId/members",
    authenticate,
    projectController.getProjectMembersList
  );

  // 6. 擴展 4：GET /api/v1/projects/:projectId/history (獲取歷史記錄)
  router.get(
    "/:projectId/history",
    authenticate,
    projectController.getProjectHistoryList
  );

  // 7. 核心 GET /api/v1/projects/:projectId 請求 (通用參數路由，必須在所有特定路由之後)
  router.get("/:projectId", authenticate, projectController.getProjectById);

  // 8. POST /api/v1/projects/:projectId/members (新增或更新專案成員)
  router.post(
    "/:projectId/members",
    authenticate,
    p1AuthMiddleware, // P1 狀態鎖定檢查
    projectController.addProjectMember
  );

  // 9. DELETE /api/v1/projects/:projectId/members/:userId (移除專案成員)
  router.delete(
    "/:projectId/members/:userId",
    authenticate,
    p1AuthMiddleware, // P1 狀態鎖定檢查
    projectController.removeProjectMember
  );

  // 10. PATCH /api/v1/projects/:projectId (更新、RDL 蓋章、PM 轉讓)
  router.patch(
    "/:projectId",
    authenticate,
    p1AuthMiddleware, // P1 狀態鎖定檢查 (40901)
    projectController.updateProject
  );

  // 11. DELETE /api/v1/projects/:projectId (專案軟刪除)
  router.delete(
    "/:projectId",
    authenticate,
    p1AuthMiddleware, // P1 狀態鎖定檢查 (40901)
    projectController.softDeleteProject
  );

  // 12. PM 歸檔 (PATCH /api/v1/projects/:projectId/archive)
  router.patch(
    "/:projectId/archive",
    authenticate,
    // 此處不需要 p1AuthMiddleware，因為它是受控例外流轉 (50->60)
    projectController.archiveProject
  );

  return router;
};
