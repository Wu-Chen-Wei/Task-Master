// 程式檔案：backend/src/project/routes/attachment.routes.ts
// 層次與職責：請求進入與路由層（Routes Layer）。
// 核心職責是定義附件模組的 API 路徑 /api/v1/attachments 的 POST (建立) 和 DELETE (刪除) 操作。

import {Router} from "express";
import * as mysql from "mysql2/promise";
import {AttachmentService} from "../services/attachment.service";
import {AttachmentController} from "../controllers/attachment.controller";
import {authenticate} from "../../member/middlewares/auth.middleware";
import {projectAuthMiddleware} from "../middlewares/project.auth.middleware";
import {projectUpload} from "../../config/multer.config"; // 引入檔案上傳中介軟體

/**
 * 建立附件路由的工廠函數。
 *
 * @param pool 資料庫連線池
 * @param attachmentService AttachmentService 實例
 * @returns 設定好的 Express Router
 */
export const createAttachmentRoutes = (
  pool: mysql.Pool,
  attachmentService: AttachmentService
): Router => {
  const router = Router();

  // 初始化 AttachmentController
  const attachmentController = new AttachmentController(attachmentService);

  // 附件刪除需要 ProjectModel 來檢查 P1 鎖定，因此我們需要一個特殊的 P1 中介軟體
  // 假設我們在 app.ts 傳遞了 ProjectModel 給 createAttachmentRoutes，但為了簡潔，
  // 這裡只依賴於 attachmentService 內部會執行 P1 檢查。
  // 實際的 P1 鎖定檢查應該由 AttachmentService 內部呼叫 project.model.ts 進行。

  // =========================================================
  // 附件 CRUD 路由 (API 擴展 5)
  // =========================================================

  /**
   * POST /api/v1/attachments (新增附件，支援多檔案上傳)
   * 核心契約：必須先通過 authenticate，然後 projectUpload 處理檔案。
   */
  router.post(
    "/",
    authenticate, // 步驟 1: 身份認證
    projectUpload.array("files", 10), // 步驟 2: Multer 處理檔案，最多 10 個，欄位名稱為 "files"
    attachmentController.createAttachment // 步驟 3: Controller 處理 metadata 和業務邏輯
  );

  /**
   * DELETE /api/v1/attachments/:attachmentID (刪除附件)
   * 核心契約：由 AttachmentService 執行 P1 狀態鎖定和 P6 權限檢查。
   */
  router.delete(
    "/:attachmentId",
    authenticate, // 步驟 1: 身份認證
    // 此處不掛載 projectAuthMiddleware，P1 鎖定檢查責任由 AttachmentService 承擔 [7]。
    attachmentController.softDeleteAttachment
  );

  // ⭐ 新增下載 API 契約：GET /api/v1/attachments/:attachmentId/download
  // 此端點將由 Controller 手動發送檔案，解決中文亂碼和強制下載問題。
  router.get(
    "/:attachmentId/download", // 使用 /download 擴展路徑以避免與其他 ID 查詢衝突
    authenticate,
    attachmentController.downloadAttachment // 新增的方法
  );

  return router;
};
