// 程式檔案：backend/src/project/utils/id.converter.ts

// 層次與職責：通用工具層（Utils Layer）。[9]
// 核心職責是實施 ID 資料類型轉換契約，提供類型安全的 ID 轉換功能。[9]
// 核心契約與依賴：
// 1. ID 資料類型轉換契約：將 JSON 傳輸的 CoreID (string) 轉換為資料庫所需的 number (INT) 類型。[9]
// 2. 類型安全契約：依賴 project.types.ts 中定義的 CoreID 類型。[9]
// 3. 驗證契約：轉換函式必須驗證結果是一個有效的正整數。[9]

import {CoreID} from "../types/project.types";
import {PROJECT_ERROR_CODES} from "../types/error.types"; // 引入錯誤碼定義 [7, 8]

/**
 * 標準化的業務錯誤類別 (Business Error)。
 * 包含標準錯誤碼 (code) 和名稱 (name)，用於回傳給 Controller 層 [5, 6]。
 * 必須在這裡定義以供 toDBId 拋出標準化錯誤。
 */
class BusinessError extends Error {
  public code: number;
  public name: string;

  constructor(message: string, code: number, name: string) {
    super(message);
    this.code = code;
    this.name = name;
  }
}

/**
 * 將 JSON 傳輸中的 CoreID (string) 轉換為資料庫所需的 ProjectID 或 UserID (number/INT) 類型。[3]
 * 此轉換是所有 services 層呼叫 models 層之前必須執行的步驟。[3]
 *
 * @param coreId 待轉換的 CoreID 字符串。[3]
 * @param idName ID 的名稱，用於錯誤提示 (例如 'ProjectID' 或 'OwnerUserID')
 * @returns 資料庫的 INT 類型 ID (number)。[3]
 * @throws {BusinessError} 40001 VALIDATION_FAILED 如果轉換結果不是有效的正整數。[2, 4]
 */
export function toDBId(coreId: CoreID, idName: string = "ID"): number {
  const validationError = PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED; // 40001 [2]

  if (typeof coreId !== "string") {
    // 這是一種型別檢查，確保輸入符合 CoreID 契約
    throw new BusinessError(
      `[ID Conversion Error] ${idName} 必須是 string 類型。收到: ${typeof coreId}`,
      validationError.code,
      validationError.name
    );
  }

  const dbId = parseInt(coreId, 10);

  // 實施驗證契約：確保結果是有效的正整數 [4]。
  if (isNaN(dbId) || dbId <= 0) {
    // 必須拋出 40001 VALIDATION_FAILED 錯誤
    throw new BusinessError(
      `[ID Conversion Error] Invalid ${idName}: '${coreId}'. ID 必須轉換為有效的正整數。`,
      validationError.code,
      validationError.name
    );
  }

  return dbId;
}

/**
 * 輔助函式：將資料庫的 INT 類型 ID 轉換回 JSON 傳輸所需的 CoreID (string) 類型。[1]
 * 用於從 model 層返回數據到 controller 層時。[1]
 * @param dbId 資料庫的 INT 類型 ID (number)。[1]
 * @returns CoreID 字符串。[1]
 */
export function toCoreId(dbId: number): CoreID {
  const validationError = PROJECT_ERROR_CODES.BAD_REQUEST.VALIDATION_FAILED;

  if (typeof dbId !== "number" || dbId <= 0) {
    // 確保輸入是有效的 number 類型
    throw new BusinessError(
      `[ID Conversion Error] DB ID 必須是有效的正整數。收到: ${dbId}`,
      validationError.code,
      validationError.name
    );
  }

  // 簡單地將 number 轉換為 string，遵循 CoreID 契約
  return String(dbId);
}
