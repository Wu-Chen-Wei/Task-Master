// 程式檔案：backend/src/config/multer.config.ts
import multer from "multer";
import path from "path";
import fs from "fs";
import {Request} from "express";

// ============================================================
// 📁 1️⃣ 使用者頭像上傳設定（avatarUpload）
// ============================================================
const avatarStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(process.cwd(), "uploads", "avatars");
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, {recursive: true});
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const userId = (req as any).user?.userID || "unknown";
    const timestamp = Date.now();
    const ext = path.extname(file.originalname);
    cb(null, `user-${userId}-${timestamp}${ext}`);
  },
});

// ✅ 匯出使用者頭像上傳設定
export const avatarUpload = multer({
  storage: avatarStorage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB
  },
});

// ============================================================
// 📂 2️⃣ 專案檔案上傳設定（projectUpload）
// ============================================================

const projectStorage = multer.diskStorage({
  destination: (req, files, cb) => {
    // 路徑：process.cwd()/uploads
    const uploadPath = path.join(process.cwd(), "uploads");

    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, {recursive: true});
    }
    cb(null, uploadPath);
  },

  filename: (req, files, cb) => {
    const timestamp = Date.now();

    // ⭐ 關鍵修正：強制將 Multer 讀取的原始檔名解碼為 UTF-8
    // 這解決了 Multer 在處理中文 multipart/form-data 時的亂碼問題
    const decodedOriginalname = Buffer.from(
      files.originalname,
      "latin1"
    ).toString("utf-8");

    // 使用解碼後的檔名進行處理
    const ext = path.extname(decodedOriginalname);
    const baseName = path.basename(decodedOriginalname, ext);

    // 磁碟儲存名稱：[原始檔名 (已解碼)]-[時間戳].[副檔名]
    cb(null, `${baseName}-${timestamp}${ext}`);
  },
});

// ✅ 匯出專案檔案上傳設定（允許多檔案、不限制格式）
export const projectUpload = multer({
  storage: projectStorage,
  fileFilter: (
    req: Request,
    files: Express.Multer.File,
    cb: multer.FileFilterCallback
  ) => {
    cb(null, true); // 不限制檔案格式
  },
  limits: {
    fileSize: 50 * 1024 * 1024, // 限制單檔 50MB
  },
});

// ============================================================
// 📘 使用說明
// ============================================================

//
// ▶ 上傳頭像：
// router.post("/avatar", avatarUpload.single("avatar"), controllerFunction);
//
// ▶ 上傳專案檔案（多檔案）：
// router.post("/project/upload", projectUpload.array("files", 10), controllerFunction);
//
// 路徑範例：
// - 頭像：uploads/avatars/
// - 專案：uploads/ (與 app.ts 的 express.static 設置一致)
//
// ============================================================
