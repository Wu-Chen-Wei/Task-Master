import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config(); // 載入 .env

// 建立 MySQL Pool（推薦比單一連線穩定）
export const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// 測試連線用的函式
export const testConnection = async () => {
  try {
    const connection = await pool.getConnection();
    console.log("✅ MySQL connected!");
    connection.release();
  } catch (error) {
    console.error("❌ MySQL connection failed:", error);
    process.exit(1); // 失敗就直接停掉程式
  }
};
