
// Next.js 指令，表示此檔案在前端執行（Client Component）。

import { createContext, useContext, useEffect, useState, ReactNode } from "react";
// 引入 React 所需的函式與型別：
// - createContext：建立 Context
// - useContext：使用 Context
// - useEffect：處理副作用（如載入資料）
// - useState：管理狀態
// - ReactNode：表示 React 元件的子元素型別

// 定義使用者資料的型別
interface UserData {
  userID: number;           // 使用者 ID
  Email: string;            // 使用者 Email
  FullName: string;         // 使用者全名
  Title?: string;           // 職稱（可選）
  Roles?: string[];         // 角色清單（可選）
  EmailVerified?: boolean;  // Email 是否驗證（可選）
  AvatarURL?: string;       // 頭像 URL（可選）
}

// 定義 Auth Context 的型別
interface AuthContextType {
  user: UserData | null;                // 當前使用者資料，未登入則為 null
  isLoggedIn: boolean;                  // 是否已登入
  isLoading: boolean;                   // 是否正在載入使用者資料
  setUser: (user: UserData | null) => void; // 更新使用者資料的方法
}

// 建立 Context，初始值為 undefined，避免未包在 Provider 時直接使用
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// 提供 Auth Context 的 Provider 元件
export function AuthProvider({ children }: { children: ReactNode }) {
  // 使用 useState 管理使用者資料與載入狀態
  const [user, setUser] = useState<UserData | null>(null); // 預設未登入
  const [isLoading, setIsLoading] = useState(true);        // 預設載入中

  useEffect(() => {
    // 定義載入使用者資料的函式
    const loadUser = () => {
      setIsLoading(true); // 開始載入

      // 從 localStorage 取得 token 與使用者資料
      const token = localStorage.getItem("token");
      const userStr = localStorage.getItem("user");

      // 如果沒有 token 或 user 資料，表示未登入
      if (!token || !userStr) {
        setUser(null);
        setIsLoading(false);
        return;
      }

      try {
        // 嘗試解析使用者資料 JSON
        const userData = JSON.parse(userStr);
        setUser(userData); // 設定使用者資料
      } catch (error) {
        console.error("解析使用者資訊失敗：", error);
        setUser(null); // 解析失敗則清空使用者資料
      } finally {
        setIsLoading(false); // 結束載入
      }
    };

    loadUser(); // 初始化時載入使用者資料

    // 監聽自訂事件 "user-logged-in"，登入後重新載入資料
    window.addEventListener("user-logged-in", loadUser);

    // 元件卸載時移除事件監聽，避免記憶體洩漏
    return () => {
      window.removeEventListener("user-logged-in", loadUser);
    };
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,                // 當前使用者資料
        isLoggedIn: !!user,  // 是否已登入（user 不為 null）
        isLoading,           // 是否正在載入
        setUser,             // 更新使用者資料的方法
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// 自訂 Hook，用於取得 Auth Context
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth 必須在 AuthProvider 中使用");
  }
  return context;
}