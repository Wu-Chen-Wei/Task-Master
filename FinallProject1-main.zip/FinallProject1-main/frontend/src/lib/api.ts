// API configuration and utility functions
const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:4000";

/**
 * Creates a complete API URL by combining base URL with endpoint
 */
export const createApiUrl = (endpoint: string): string => {
  // Remove leading slash if present to avoid double slashes
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint.slice(1) : endpoint;
  return `${API_BASE_URL}/${cleanEndpoint}`;
};

/**
 * Static API endpoints
 */
export const API_ENDPOINTS = {
  missions: '/api/missions',
  users: '/api/users',
  projects: '/api/v1/projects',
  auth: '/api/auth',
};

/**
 * Dynamic endpoint generators for different API resources
 */
export const createDynamicEndpoint = {
  // Mission endpoints
  missionById: (id: number | string) => `/api/missions/${id}`,
  missionSign: (id: number | string) => `/api/missions/${id}/sign`,
  missionAssignQA: (id: number | string) => `/api/missions/${id}/assign-qa`,
  
  // User endpoints
  userById: (id: number | string) => `/api/users/${id}`,
  
  // Project endpoints
  projectById: (id: number | string) => `/api/v1/projects/${id}`,
};