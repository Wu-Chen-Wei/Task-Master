// frontend/src/lib/types/kanban.ts

export interface Issue {
  IssueID: number;
  Title: string;
  ProjectID: number;
  StatusID: number;
  StatusName: string;
  AssignedToUserID: number;
  Priority?: string;
  DueDate?: string; 
}

export interface KanbanBoard {
  [columnName: string]: Issue[];
}

export interface KanbanMovePayload {
  issueId: number;
  newStatusId: number;
  sourceStatusId: number; 
  newKanbanOrder?: number;
}