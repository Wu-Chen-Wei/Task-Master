// src/components/SummaryCard.tsx
import React from 'react';

interface SummaryCardProps {
  title: string;   // 卡片的標題
  value: any;      // 顯示的值（可以是數字或字符串）
  subtext?: string; // 可選的額外文字（如已完成的數量）
  icon: string;    // 顯示的圖標
}

const SummaryCard: React.FC<SummaryCardProps> = ({ title, value, subtext = '', icon }) => {
  return (
    <div className="bg-white p-4 shadow rounded-lg">
      <div className="flex items-center">
        <span className="text-3xl mr-4">{icon}</span> {/* 顯示圖標 */}
        <div>
          <h4 className="text-sm font-semibold text-gray-500">{title}</h4> {/* 顯示標題 */}
          <p className="text-lg font-bold">{value}</p> {/* 顯示值 */}
          {subtext && <p className="text-sm text-gray-400">{subtext}</p>} {/* 顯示額外文字（如果有） */}
        </div>
      </div>
    </div>
  );
};

export { SummaryCard }; // 正確匯出組件
