"use client";
// 📌 宣告此檔案為 Client Component（Next.js 特有），允許使用 useState / useEffect。

import { ProfileModal } from "@/components/ProfileModal";
// 📦 匯入個人資料編輯彈窗元件（點頭像後會開啟）

import { useEffect, useState } from "react";
// 📦 匯入 React Hook：useState(狀態) 與 useEffect(生命週期事件)

import {
  LayoutDashboard,
  Folder,
  ClipboardList,
  Bell,
  Target,
  User,
  UserPlus,
  LogOut,
  Shield, // ⭐ 新增：管理員圖示（顯示在特定功能旁）
  Settings, // ⭐ 新增：設定圖示
  Mail, // ⭐ 新增：郵件圖示
  AlertCircle, // ⭐ 新增：警告圖示
} from "lucide-react";
// 📦 匯入 lucide-react 的圖示套件（提供 SVG icon）

import Link from "next/link";
// 📦 Next.js 的內建元件，用來在前端頁面之間切換，不會整頁重整。

// ==================== 型別定義 ====================
interface UserData {
  userID: number; // 使用者 ID
  Email: string; // Email
  FullName: string; // 使用者姓名
  Title?: string; // 職稱（可選）
  Roles?: string[]; // 使用者角色（例如 ['SystemAdmin', 'PM']）
  EmailVerified?: boolean; // ⭐ 新增：Email 驗證狀態
  AvatarURL?: string; // 頭像 URL
}

// ==================== Sidebar 主組件 ====================
export function Sidebar() {
  // 🎯 狀態管理
  const [isLoggedIn, setIsLoggedIn] = useState(false); // 紀錄是否登入
  const [user, setUser] = useState<UserData | null>(null); // 儲存登入後的使用者資訊
  const [showProfile, setShowProfile] = useState(false);

  // ⭐ 新增狀態：未讀通知數
  const [unreadCount, setUnreadCount] = useState<number>(0);

  // ⭐ 新增：Email 驗證相關狀態
  const [showEmailWarning, setShowEmailWarning] = useState(false);
  const [isResending, setIsResending] = useState(false);

  // ==================== 登入狀態載入 ====================
  useEffect(() => {
    // 📘 定義載入使用者資訊的函式
    const loadUser = () => {
      const token = localStorage.getItem("token"); // 從 localStorage 取 JWT Token
      const userStr = localStorage.getItem("user"); // 取使用者資訊 JSON

      // ❌ 若沒 token 或 user → 視為未登入
      if (!token || !userStr) {
        setIsLoggedIn(false);
        setUser(null);
        setShowEmailWarning(false); // ⭐ 清除警告
        return;
      }

      try {
        // ✅ 解析 JSON → 設定使用者狀態
        const userData = JSON.parse(userStr);
        setUser(userData);
        setIsLoggedIn(true);

        // ⭐ 檢查 Email 是否已驗證
        if (!userData.EmailVerified) {
          setShowEmailWarning(true);
        } else {
          setShowEmailWarning(false);
        }

        console.log("載入使用者資訊：", userData);
      } catch (error) {
        // ❌ 解析錯誤 → 重設狀態
        console.error("解析使用者資訊失敗：", error);
        setIsLoggedIn(false);
        setUser(null);
        setShowEmailWarning(false);
      }
    };

    loadUser(); // 首次載入時執行

    // 📡 監聽全域事件：用於登入後其他頁面能同步更新 Sidebar
    window.addEventListener("user-logged-in", loadUser);

    // 🧹 組件卸載時移除監聽
    return () => {
      window.removeEventListener("user-logged-in", loadUser);
    };
  }, []); // 只在元件掛載/卸載時執行

 

  // ==================== 角色判斷函式 ====================
  const hasRole = (role: string): boolean => {
    // 檢查使用者角色陣列中是否包含指定角色
    return user?.Roles?.includes(role) ?? false;
  };

  const hasAnyRole = (roles: string[]): boolean => {
    // 若使用者包含任一角色 → 回傳 true
    return roles.some((role) => hasRole(role));
  };

  // ⭐ 新增：重新發送驗證信
  const handleResendEmail = async () => {
    if (!user?.Email) return;

    setIsResending(true);

    try {
      console.log("🔵 前端：重新發送驗證信");

      const res = await fetch(
        "http://localhost:4000/api/users/resend-verification",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email: user.Email }),
        }
      );

      const data = await res.json();
      console.log("🔵 前端：收到回應", data);

      if (data.success) {
        alert("✅ " + data.message);
      } else {
        alert("❌ " + data.message);
      }
    } catch (err) {
      console.error("❌ 前端：重新發送驗證信錯誤:", err);
      alert("❌ 發送失敗，請稍後再試");
    } finally {
      setIsResending(false);
    }
  };

  // ==================== 未讀通知數即時更新（SSE） ====================


useEffect(() => {
  if (!isLoggedIn) return;

  // 初次載入未讀數
  const fetchUnreadCount = async () => {
    try {
      const res = await fetch("http://localhost:4000/api/list/unread-count");
      const data = await res.json();
      setUnreadCount(data.unreadCount);
    } catch (err) {
      console.error("❌ 取得未讀通知數失敗:", err);
    }
  };
  fetchUnreadCount();

  // 建立 SSE 連線（只需一條）
  const eventSource = new EventSource("http://localhost:4000/api/list/stream");

  // 🔔 收到新通知
  eventSource.addEventListener("newNotification", (event) => {
    const newNotification = JSON.parse(event.data);
    console.log("📩 收到新通知:", newNotification);
    setUnreadCount((prev) => prev + 1);
  });

  // 📊 收到未讀數更新
  eventSource.addEventListener("unreadCount", (event) => {
    const data = JSON.parse(event.data);
    console.log("🔄 未讀數更新:", data.unreadCount);
    setUnreadCount(data.unreadCount);
  });

  eventSource.onerror = (err) => {
    console.error("⚠️ SSE 錯誤:", err);
  };

  return () => {
    eventSource.close();
  };
}, [isLoggedIn]);


  // ==================== 導覽選單定義 ====================
  const menuItems = [
    {
      href: "/dashboard",
      label: "Dashboard",
      icon: LayoutDashboard,
      allowedRoles: [], // ✅ 所有登入使用者皆可見
    },

    // 👥 帳號管理 - 只有 SystemAdmin 和 AccountAdmin 能看
    {
      href: "/users",
      label: "帳號管理",
      icon: User,
      allowedRoles: ["Admin", "AccountAdmin"], // 只有這兩角色能看
    },

    // 📁 專案管理 - PM, RD_Leader, SystemAdmin 能看
    {
      href: "/projects",
      label: "專案管理",
      icon: Folder,
      allowedRoles: ["PM", "RDL", "RD", "QA", "Admin"],
    },

    // 🎯 Mission 管理 - PM, RD_Leader, RD, QA, SystemAdmin 能看
    {
      href: "/missions",
      label: "Mission 管理",
      icon: Target,
      allowedRoles: ["PM", "RDL", "RD", "QA", "Admin"],
    },

    // 🔔 通知中心 - 所有人都能看
    {
      href: "/notifications",
      label: "通知中心",
      icon: Bell,
      allowedRoles: [], // 所有人都能看
    },

/*     // ⚙️ 系統設定 - 只有 SystemAdmin 能看
    {
      href: "/settings",
      label: "系統設定",
      icon: Settings,
      allowedRoles: ["SystemAdmin"], // 只有 SystemAdmin 能看
    }, */
  ];

  // ==================== 過濾可見選單 ====================
  const visibleMenuItems = menuItems.filter((item) => {
    // 如果 allowedRoles 是空陣列，表示所有人都能看
    if (item.allowedRoles.length === 0) return true;

    // 檢查使用者是否有任一允許的角色
    return hasAnyRole(item.allowedRoles);
  });

  // ==================== JSX 畫面 ====================
  return (
    <aside className="w-64 h-auto bg-white border-r flex flex-col">
      {/* ⭐ 改用 flex flex-col，確保布局正確 */}

      {/* 上半部內容 - 使用 flex-1 讓它佔滿剩餘空間 */}
      <div className="flex-1 overflow-y-auto">
        {/* === Logo 區 === */}
        <div className="flex flex-col items-center py-6 border-b">
          <img src="/logo.png" alt="Easytrack" className="w-10 h-10 mb-2" />
          <h1 className="font-bold text-lg text-gray-800">Easytrack</h1>
          <p className="text-sm text-gray-500">
            {isLoggedIn ? `${user?.Title ?? "一般使用者"}工作台` : "請先登入"}
          </p>
        </div>

        {/* === 使用者頭像區 === */}
        <div className="flex items-center gap-3 px-6 py-4 border-b">
          <div
            onClick={() => {
              if (!isLoggedIn) return;
              setShowProfile(true);
            }}
            className={`w-10 h-10 flex items-center justify-center rounded-full transition-all duration-200 overflow-hidden ${
              isLoggedIn
                ? "cursor-pointer hover:ring-2 hover:ring-blue-400"
                : "bg-gray-300 cursor-not-allowed"
            }`}
            title={isLoggedIn ? "點擊查看個人資料" : "請先登入"}
          >
            {/* ⭐ 根據是否有頭像顯示不同內容 */}
            {isLoggedIn && user?.AvatarURL ? (
              // 有頭像 → 顯示圖片
              <img
                src={user.AvatarURL}
                alt={user.FullName}
                className="w-full h-full object-cover"
                onError={(e) => {
                  // 圖片載入失敗 → 顯示文字
                  const img = e.target as HTMLImageElement;
                  img.style.display = "none";
                  const parent = img.parentElement;
                  if (parent) {
                    parent.classList.add("bg-orange-400", "text-white");
                    parent.innerHTML = `<span class="text-lg font-semibold">${
                      user?.FullName?.charAt(0).toUpperCase() || "U"
                    }</span>`;
                  }
                }}
              />
            ) : isLoggedIn ? (
              // 沒有頭像但已登入 → 顯示名字首字母
              <div className="w-full h-full bg-orange-400 text-white flex items-center justify-center text-lg font-semibold">
                {user?.FullName?.charAt(0).toUpperCase() || "U"}
              </div>
            ) : (
              // 未登入 → 顯示預設圖示
              <User size={20} className="text-gray-500" />
            )}
          </div>

          <div className="flex-1">
            <p className="font-semibold text-sm">
              {isLoggedIn ? user?.FullName : "未登入"}
            </p>
            <p className="text-xs text-gray-500">
              {isLoggedIn ? user?.Title : "訪客"}
            </p>

            {isLoggedIn && user?.Roles && user.Roles.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-1">
                {user.Roles.map((role) => (
                  <span
                    key={role}
                    className="text-[10px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded"
                  >
                    {role}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
              {/* ⭐ 下半部：登入/登出按鈕 - 固定在底部 */}
      <div className="border-t  border-b  px-6 py-4 flex-shrink-0">
        {isLoggedIn ? (
          // 已登入 → 顯示登出按鈕
          <button
            onClick={() => {
              localStorage.removeItem("token");
              localStorage.removeItem("user");
              setIsLoggedIn(false);
              setUser(null);
              setShowEmailWarning(false); // ⭐ 清除警告
              window.location.href = "/landingpage"; // ⭐ 導向登入頁
            }}
            className="w-full flex items-center justify-center gap-2 text-gray-600 hover:text-red-600 font-medium transition-colors "
          >
            <LogOut size={16} /> 登出
          </button>
        ) : (
          // 未登入 → 顯示登入/註冊按鈕
          <div className="flex gap-3 justify-center">
            <Link
              href="/login"
              className="flex items-center gap-2 text-blue-600 hover:text-blue-800 font-medium"
            >
              <User size={16} /> 登入
            </Link>

            <Link
              href="/register"
              className="flex items-center gap-2 text-green-600 hover:text-green-800 font-medium"
            >
              <UserPlus size={16} /> 註冊
            </Link>
          </div>
        )}
      </div>

        {/* ⭐ Email 驗證警告卡片 */}
        {isLoggedIn && showEmailWarning && (
          <div className="mx-4 my-3 bg-yellow-50 border border-yellow-200 rounded-lg p-3">
            <div className="flex items-start gap-2 mb-2">
              <AlertCircle className="w-4 h-4 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-xs font-semibold text-yellow-800 mb-1">
                  Email 尚未驗證
                </p>
                <p className="text-xs text-yellow-700 mb-2">
                  部分功能將受到限制，請前往信箱完成驗證。
                </p>
              </div>
            </div>
            <button
              onClick={handleResendEmail}
              disabled={isResending}
              className="w-full text-xs bg-yellow-500 hover:bg-yellow-600 text-white py-1.5 px-3 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1"
            >
              <Mail size={12} />
              {isResending ? "發送中..." : "重新發送驗證信"}
            </button>
          </div>
        )}

        {/* === 導覽選單 === */}
        <nav className="flex flex-col px-4 py-6 space-y-2 text-sm">
          {visibleMenuItems.map((item, idx) => (
            <Link
              key={idx}
              href={isLoggedIn ? item.href : "#"}
              className={`flex items-center gap-2 px-3 py-2 rounded-md transition-colors ${
                isLoggedIn
                  ? "hover:bg-gray-100 text-gray-700"
                  : "text-gray-400 cursor-not-allowed"
              }`}
            >
              <item.icon size={16} />
              {item.label}

              {/* ⭐ 通知中心顯示未讀數 */}
              {item.label === "通知中心" && unreadCount > 0 && (
                <span className="ml-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                  {unreadCount}
                </span>
              )}

              {/* ⭐ SystemAdmin 專屬項目顯示小圖示 */}
              {item.allowedRoles.includes("SystemAdmin") &&
                item.allowedRoles.length === 1 && (
                  <Shield size={12} className="ml-auto text-red-500" />
                )}
            </Link>
          ))}
        </nav>
      </div>



      {/* ProfileModal 彈窗 */}
      {showProfile && (
        <ProfileModal
          user={user}
          open={showProfile}
          onClose={() => setShowProfile(false)}
          onSave={(updatedUser) => {
            setUser(updatedUser);
            localStorage.setItem("user", JSON.stringify(updatedUser));

            // ⭐ 更新後重新檢查驗證狀態
            if (updatedUser.EmailVerified) {
              setShowEmailWarning(false);
            }
          }}
        />
      )}
    </aside>
  );
}
