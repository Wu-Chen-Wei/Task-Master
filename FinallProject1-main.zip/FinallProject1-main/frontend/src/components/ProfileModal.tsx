"use client";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

// ✅ 定義 User 型別
interface User {
  userID: number;
  FullName: string;
  Email: string;
  NotificationEmail?: string; // ✅ 新增
  Title?: string;
  AvatarURL?: string;
  EmailVerified?: boolean;
  Roles?: string[];
}

// ✅ 定義 Props 型別
interface ProfileModalProps {
  user: User | null;
  open: boolean;
  onClose: () => void;
  onSave: (updatedUser: User) => void;
}

export function ProfileModal({
  user,
  open,
  onClose,
  onSave,
}: ProfileModalProps) {
  // ✅ 定義 formData 型別
  interface FormData {
    fullName: string;
    email: string;
    notificationEmail: string; // ✅ 新增
    title: string;
    avatarURL: string;
  }

  const [formData, setFormData] = useState<FormData>({
    fullName: user?.FullName || "",
    email: user?.Email || "",
    notificationEmail: user?.NotificationEmail || "", // ✅ 新增
    title: user?.Title || "",
    avatarURL: user?.AvatarURL || "",
  });

  const [isLoading, setIsLoading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewURL, setPreviewURL] = useState<string>("");

  // ✅ 圖片預設
  const getDefaultAvatar = () => {
    const imageNumber = user?.userID ? (user.userID % 70) + 1 : 1;
    return `https://i.pravatar.cc/150?img=${imageNumber}`;
  };

  // ✅ 檔案選擇
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      alert("請選擇圖片檔案");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      alert("圖片大小不能超過 5MB");
      return;
    }

    setSelectedFile(file);
    const reader = new FileReader();
    reader.onloadend = () => setPreviewURL(reader.result as string);
    reader.readAsDataURL(file);
  };

  // ✅ 上傳頭像
  const handleUploadAvatar = async () => {
    if (!selectedFile) return;
    const token = localStorage.getItem("token");
    if (!token) {
      alert("請先登入");
      return;
    }

    setIsLoading(true);
    try {
      const uploadForm = new FormData();
      uploadForm.append("avatar", selectedFile);

      const res = await fetch("http://localhost:4000/api/users/me/avatar", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: uploadForm,
      });

      const data = await res.json();
      if (data.success) {
        localStorage.setItem("user", JSON.stringify(data.user));
        window.dispatchEvent(new Event("user-logged-in"));
        onSave(data.user);
        onClose();
        alert("✅ 頭像上傳成功");
        setSelectedFile(null);
        setPreviewURL("");
      } else {
        alert("❌ " + data.message);
      }
    } catch (err) {
      console.error("上傳失敗:", err);
      alert("上傳失敗，請稍後再試");
    } finally {
      setIsLoading(false);
    }
  };

  interface UpdateUserPayload {
   FullName?: string;
    NotificationEmail?: string;
    Title?: string;
    AvatarURL?: string;
  }

  // ✅ 更新個人資料
  const handleSubmit = async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      alert("請先登入");
      return;
    }

    // ✅ 驗證通知 Email 格式（如果有填）
    if (
      formData.notificationEmail &&
      !formData.notificationEmail.includes("@")
    ) {
      alert("請輸入正確的 Email 格式");
      return;
    }

    const dataToSend: UpdateUserPayload = {};

    if (formData.fullName.trim()) dataToSend.FullName = formData.fullName;
    if (formData.notificationEmail.trim()) {
      console.log("✅ 準備加入 NotificationEmail:", formData.notificationEmail);
      dataToSend.NotificationEmail = formData.notificationEmail;
    } // ✅ 大駝峰
    if (formData.title.trim()) dataToSend.Title = formData.title;
    if (formData.avatarURL.trim()) dataToSend.AvatarURL = formData.avatarURL;
    // ⭐ 加上這行 Debug
    console.log("🔵 formData:", formData);
    console.log("🔵 dataToSend:", dataToSend); // ← 這個應該要有 NotificationEmail

    if (Object.keys(dataToSend).length === 0) {
      alert("請至少修改一個欄位");
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch("http://localhost:4000/api/users/profile", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(dataToSend),
      });

      const data: { success: boolean; user?: User; message?: string } =
        await res.json();

      if (data.success && data.user) {
        alert("✅ 資料已更新");
        localStorage.setItem("user", JSON.stringify(data.user));
        window.dispatchEvent(new Event("user-logged-in"));
        onSave(data.user);
        onClose();
      } else {
        alert(data.message || "更新失敗");
      }
    } catch (err) {
      console.error("更新失敗:", err);
      alert("伺服器連線錯誤");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[450px] bg-gray-300">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold">
            編輯個人資料
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          {/* ⭐ 頭像上傳區 */}
          <div className="flex flex-col items-center gap-3">
            <img
              src={previewURL || formData.avatarURL || getDefaultAvatar()}
              alt="Avatar Preview"
              className="w-24 h-24 rounded-full object-cover border-2"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                if (!target.src.includes("pravatar.cc")) {
                  target.src = getDefaultAvatar();
                  target.onerror = null;
                }
              }}
            />
            <div className="flex flex-col items-center gap-2">
              <input
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
                id="avatar-upload"
                disabled={isLoading}
              />
              <label
                htmlFor="avatar-upload"
                className="px-4 py-2 bg-blue-500 text-white rounded-lg cursor-pointer hover:bg-blue-600 transition-colors text-sm"
              >
                選擇圖片
              </label>

              {selectedFile && (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={handleUploadAvatar}
                    disabled={isLoading}
                  >
                    上傳頭像
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setSelectedFile(null);
                      setPreviewURL("");
                    }}
                    disabled={isLoading}
                  >
                    取消
                  </Button>
                </div>
              )}

              <p className="text-xs text-gray-500 text-center">
                支援 JPG, PNG, GIF, WebP
                <br />
                最大 5MB
              </p>
            </div>
          </div>

          {/* 分隔線 */}
          <div className="border-t pt-4">
            <p className="text-sm text-gray-600 mb-3">或使用網址設定頭像</p>
            <div className="grid gap-1">
              <Label htmlFor="avatarURL">頭像網址</Label>
              <Input
                id="avatarURL"
                name="avatarURL"
                value={formData.avatarURL}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    avatarURL: e.target.value,
                  }))
                }
                placeholder="https://example.com/avatar.jpg"
                disabled={isLoading}
              />
            </div>
          </div>

          {/* 其他欄位 */}
          <div className="grid gap-1">
            <Label htmlFor="fullName">姓名</Label>
            <Input
              id="fullName"
              name="fullName"
              value={formData.fullName}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, fullName: e.target.value }))
              }
              placeholder="輸入姓名"
              disabled={isLoading}
            />
          </div>

          <div className="grid gap-1">
            <Label htmlFor="email">
              登入 Email
              <span className="text-xs text-gray-500 ml-2">🔒 無法修改</span>
            </Label>
            <Input
              id="email"
              name="email"
              value={formData.email}
              disabled
              className="bg-gray-100 text-gray-600 cursor-not-allowed"
            />
          </div>

          {/* ✅ 新增：通知 Email */}
          <div className="grid gap-1">
            <Label htmlFor="notificationEmail">通知 Email</Label>
            <Input
              id="notificationEmail"
              name="notificationEmail"
              type="email"
              value={formData.notificationEmail}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  notificationEmail: e.target.value,
                }))
              }
              placeholder="接收通知的 Email（選填）"
              disabled={isLoading}
            />
            <p className="text-xs text-gray-500">
              💡 如果不填，系統會使用您的登入 Email 發送通知
            </p>
          </div>

          <div className="grid gap-1">
            <Label htmlFor="title">職稱</Label>
            <Input
              id="title"
              name="title"
              value={formData.title}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, title: e.target.value }))
              }
              placeholder="例如：軟體工程師"
              disabled={isLoading}
            />
          </div>
        </div>

        {/* 底部按鈕 */}
        <div className="flex justify-end gap-3 mt-6">
          <Button variant="outline" onClick={onClose} disabled={isLoading}>
            取消
          </Button>
          <Button onClick={handleSubmit} disabled={isLoading}>
            {isLoading ? "儲存中..." : "儲存"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
