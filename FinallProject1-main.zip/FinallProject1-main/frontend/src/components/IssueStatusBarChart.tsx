import React, { useEffect, useRef } from "react";
import * as d3 from "d3";

interface IssueStatusBarChartProps {
  data: any[];  // 建議使用更明確的類型，例如: { status: string; count: number }[]
}

const IssueStatusBarChart: React.FC<IssueStatusBarChartProps> = ({ data }) => {
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!data || !svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const width = svg.node()?.clientWidth || 500;
    const height = svg.node()?.clientHeight || 300;

    const colorScale = d3.scaleOrdinal(d3.schemeCategory10);

    const xScale = d3.scaleBand()
      .domain(data.map(d => d.status))
      .range([0, width])
      .padding(0.1);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.count) || 0])
      .nice()
      .range([height, 0]);

    // 繪製柱狀圖
    svg.append("g")
      .selectAll(".bar")
      .data(data)
      .enter()
      .append("rect")
      .attr("class", "bar")
      .attr("x", d => xScale(d.status) || 0)
      .attr("y", d => yScale(d.count))
      .attr("width", xScale.bandwidth())
      .attr("height", d => height - yScale(d.count))
      .attr("fill", (d, i) => colorScale(i.toString()));  // 修復：將 index 轉為 string

    // 繪製 X 軸
    svg.append("g")
      .attr("transform", `translate(0, ${height})`)
      .call(d3.axisBottom(xScale));

    // 繪製 Y 軸
    svg.append("g")
      .call(d3.axisLeft(yScale));

  }, [data]);

  return (
    <svg ref={svgRef} width="100%" height="300px"></svg>
  );
}

export default IssueStatusBarChart;