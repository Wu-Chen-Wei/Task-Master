"use client";

import { useState, useEffect } from "react";
import { X } from "lucide-react";

interface EditUserModalProps {
  open: boolean;
  onClose: () => void;
  user: {
    userId: number;
    name: string;
    email: string;
    title?: string;
    status: string;
  };
  onSave: () => void; // 父層更新使用者列表
}

export function EditUserModal({
  open,
  onClose,
  user,
  onSave,
}: EditUserModalProps) {
  // ✅ 表單資料
  const [formData, setFormData] = useState({
    fullName: user.name,
    title: user.title || "",
    status: user.status,
  });

  // ✅ 角色狀態
  const [roles, setRoles] = useState<string[]>([]);
  const availableRoles = [
    { value: "Admin", label: "系統管理員" },
    { value: "AccountAdmin", label: "帳號管理員" },
    { value: "PM", label: "專案經理" },
    { value: "RDL", label: "研發組長" },
    { value: "RD", label: "研發人員" },
    { value: "QA", label: "品質保證" },
  ];

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  // ✅ 當 user 或 open 改變時 → 更新表單並載入角色
  useEffect(() => {
    if (open) {
      setFormData({
        fullName: user.name,
        title: user.title || "",
        status: user.status,
      });
      fetchUserRoles();
    }
  }, [user, open]);

  // ✅ 從後端載入使用者角色
  // ✅ 從後端載入使用者角色
  const fetchUserRoles = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(
        `http://localhost:4000/api/users/${user.userId}/roles`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      const data = await res.json();
      console.log("🔵 前端：載入角色回應", data);

      if (data.success && Array.isArray(data.roles)) {
        // ✅ 確保轉換成字串陣列
        const roleNames = data.roles.map((role: any) =>
          typeof role === "string" ? role : role.RoleName
        );
        console.log("✅ 轉換後的角色:", roleNames);
        setRoles(roleNames);
      } else {
        setRoles([]);
      }
    } catch (err) {
      console.error("❌ 無法取得使用者角色:", err);
      setRoles([]);
    }
  };

  // ✅ 勾選 / 取消角色
  const handleRoleToggle = (role: string) => {
    if (roles.includes(role)) {
      setRoles(roles.filter((r) => r !== role));
    } else {
      setRoles([...roles, role]);
    }
  };

  if (!open) return null;

  // ✅ 表單送出（同時更新基本資料與角色）
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const token = localStorage.getItem("token");
      console.log("🔵 前端：發送更新使用者資料與角色", {
        user,
        formData,
        roles,
      });

      // 1️⃣ 更新基本資料
      const res1 = await fetch(
        `http://localhost:4000/api/users/${user.userId}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(formData),
        }
      );

      const data1 = await res1.json();
      if (!data1.success)
        throw new Error(data1.message || "更新使用者基本資料失敗");

      // 2️⃣ 更新角色（PUT）
      const res2 = await fetch(
        `http://localhost:4000/api/users/${user.userId}/roles`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ roles }),
        }
      );

      const data2 = await res2.json();
      if (!data2.success) throw new Error(data2.message || "更新角色失敗");

      alert("✅ 使用者資料與角色更新成功！");
      onSave();
      onClose();
    } catch (err: any) {
      console.error("❌ 更新錯誤:", err);
      setError(err.message || "更新失敗，請稍後再試");
    } finally {
      setIsLoading(false);
    }
  };

  // ✅ UI 結構
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      onClick={onClose}
    >
      {/* 透明背景（不遮罩） */}
      <div className="absolute inset-0 bg-transparent" />

      {/* Modal 卡片（阻擋背景點擊） */}
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg p-8 overflow-y-auto max-h-[85vh]"
      >
        {/* 標題列 */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">編輯使用者</h2>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition"
          >
            <X size={24} />
          </button>
        </div>

        {/* 表單內容（保持原本邏輯不動） */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email
            </label>
            <input
              type="email"
              value={user.email}
              disabled
              className="w-full px-3 py-2 border rounded-lg bg-gray-100 text-gray-500 cursor-not-allowed"
            />
            <p className="text-xs text-gray-500 mt-1">Email 無法修改</p>
          </div>

          {/* 姓名 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              姓名 <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={formData.fullName}
              onChange={(e) =>
                setFormData({ ...formData, fullName: e.target.value })
              }
              required
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none"
              placeholder="請輸入姓名"
            />
          </div>

          {/* 職稱 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              職稱
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) =>
                setFormData({ ...formData, title: e.target.value })
              }
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none"
              placeholder="例如：QA Engineer"
            />
          </div>

          {/* 狀態 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              狀態 <span className="text-red-500">*</span>
            </label>
            <select
              value={formData.status}
              onChange={(e) =>
                setFormData({ ...formData, status: e.target.value })
              }
              required
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none"
            >
              <option value="Active">啟用</option>
              <option value="Suspended">停用</option>
              <option value="Archived">封存</option>
            </select>
          </div>

          {/* 角色設定 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              角色設定 <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {availableRoles.map((role) => (
                <label key={role.value} className="flex items-center gap-2 p-1">
                  <input
                    type="checkbox"
                    checked={roles.includes(role.value)}
                    onChange={() => handleRoleToggle(role.value)}
                    className="w-4 h-4 text-blue-500 rounded focus:ring-2 focus:ring-blue-400"
                  />
                  <span className="text-sm">{role.label}</span>
                </label>
              ))}
            </div>

            {roles.length === 0 && (
              <p className="text-xs text-red-500 mt-1">請至少選擇一個角色</p>
            )}
          </div>

          {/* 錯誤訊息 */}
          {error && (
            <div className="bg-red-100 text-red-600 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          {/* 按鈕 */}
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border rounded-lg text-gray-700 hover:bg-gray-100 transition-colors"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? "儲存中..." : "儲存"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
