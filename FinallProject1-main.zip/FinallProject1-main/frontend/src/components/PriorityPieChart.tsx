import React, { useEffect, useRef } from "react";
import * as d3 from "d3";

// 定義更明確的數據類型
interface PriorityData {
  priority: string;
  count: number;
}

interface PriorityPieChartProps {
  data: PriorityData[];
}

const PriorityPieChart: React.FC<PriorityPieChartProps> = ({ data }) => {
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!data || !svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const width = svg.node()?.clientWidth || 500;
    const height = svg.node()?.clientHeight || 500;
    const radius = Math.min(width, height) / 2;

    // 修復：添加正確的類型註解
    const pie = d3.pie<PriorityData>().value(d => d.count);
    
    // 修復：明確指定 arc 的類型
    const arc = d3.arc<d3.PieArcDatum<PriorityData>>()
      .innerRadius(0)
      .outerRadius(radius);
    
    const colorScale = d3.scaleOrdinal(d3.schemeCategory10);

    const pieData = pie(data);

    // 修復：移除多餘的選擇器，直接使用 selectAll
    const g = svg.append("g")
      .attr("transform", `translate(${width / 2}, ${height / 2})`);

    g.selectAll("path")
      .data(pieData)
      .enter()
      .append("path")
      .attr("d", arc)  // 修復：現在類型匹配了
      .attr("fill", (d, i) => colorScale(i.toString()))  // 修復：將 index 轉為 string
      .attr("stroke", "white")
      .style("stroke-width", "2px");

    // 可選：添加標籤
    g.selectAll("text")
      .data(pieData)
      .enter()
      .append("text")
      .attr("transform", d => `translate(${arc.centroid(d)})`)
      .attr("text-anchor", "middle")
      .attr("dy", "0.35em")
      .text(d => d.data.priority);

  }, [data]);

  return (
    <svg ref={svgRef} width="100%" height="300px"></svg>
  );
};

export default PriorityPieChart;