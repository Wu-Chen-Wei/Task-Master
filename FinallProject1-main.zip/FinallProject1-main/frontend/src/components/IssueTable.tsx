// src/components/IssueTable.tsx
import React from 'react';

// 定義 Issue 物件的結構
interface Issue {
  id: number;
  name: string;
  status: string;
  priority: string;
}

interface IssueTableProps {
  issues: Issue[]; // 來自父組件的 Issue 數據
  onEdit: (issue: Issue) => void; // 編輯函數
}

const IssueTable: React.FC<IssueTableProps> = ({ issues, onEdit }) => {
  return (
    <table className="min-w-full table-auto">
      <thead>
        <tr>
          <th className="px-4 py-2 text-left">ID</th>
          <th className="px-4 py-2 text-left">Name</th>
          <th className="px-4 py-2 text-left">Status</th>
          <th className="px-4 py-2 text-left">Priority</th>
          <th className="px-4 py-2 text-left">Actions</th>
        </tr>
      </thead>
      <tbody>
        {issues.map((issue) => (
          <tr key={issue.id}>
            <td className="px-4 py-2">{issue.id}</td>
            <td className="px-4 py-2">{issue.name}</td>
            <td className="px-4 py-2">{issue.status}</td>
            <td className="px-4 py-2">{issue.priority}</td>
            <td className="px-4 py-2">
              <button
                onClick={() => onEdit(issue)}
                className="text-blue-500 hover:underline"
              >
                Edit
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export { IssueTable };
