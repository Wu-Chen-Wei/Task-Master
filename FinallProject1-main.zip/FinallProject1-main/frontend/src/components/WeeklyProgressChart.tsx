// components/charts/WeeklyProgressChart.tsx
'use client';

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface WeeklyProgressChartProps {
  data: Array<{
    date: string;
    completed: number;
    inProgress: number;
  }>;
}

export const WeeklyProgressChart: React.FC<WeeklyProgressChartProps> = ({ data }) => {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="date" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="completed" stroke="#22c55e" name="已完成" />
        <Line type="monotone" dataKey="inProgress" stroke="#3b82f6" name="進行中" />
      </LineChart>
    </ResponsiveContainer>
  );
};