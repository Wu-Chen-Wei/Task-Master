// components/UniversalDashboard.tsx
"use client";

import { Calendar, Clock, TrendingUp, AlertCircle } from "lucide-react";
import Link from "next/link";

interface DashboardProps {
  data: {
    role?: string; // ✅ 加上角色
    roleTitle?: string; // ✅ 加上中文標題
    overview: {
      totalUsers: number;
      totalProjects: number;
      totalMissions: number;
      inProgressMissions: number;
    };
    myTasks: {
      inProgress: number;
      testing: number;
      total: number;
    };
    upcomingDeadlines: Array<{
      id: number;
      title: string;
      dueDate: string;
      priority: string;
      daysLeft: number;
    }>;
    recentActivities: Array<{
      id: number;
      field: string;
      oldValue: string;
      newValue: string;
      timestamp: string;
      missionTitle: string;
      missionId: number;
      userName: string;
    }>;
    projects: Array<{
      id: number;
      name: string;
      totalMissions: number;
    }>;
  };
}

export const UniversalDashboard: React.FC<DashboardProps> = ({ data }) => {
  // ✅ 2️⃣ 修改 isAdmin 判斷
  const isAdmin = data.role === "Admin" || data.role === "AccountAdmin";

  // ❌ 舊的 getTitle() 移除
  // const getTitle = () => {...}

  // ✅ 3️⃣ 改成簡單易維護的標題
  const dashboardTitle = data.roleTitle
    ? `${data.roleTitle} Dashboard`
    : "Dashboard";

  // 時間格式化（保持原本程式）
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return `${date.getMonth() + 1}/${date.getDate()}`;
  };

  const getTimeAgo = (timestamp: string) => {
    const now = new Date();
    const past = new Date(timestamp);
    const diffMs = now.getTime() - past.getTime();
    const diffMins = Math.floor(diffMs / 60000);

    if (diffMins < 60) return `${diffMins} 分鐘前`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} 小時前`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} 天前`;
  };

  const priorityColors: Record<string, string> = {
    Critical: "text-red-600 bg-red-50",
    High: "text-orange-600 bg-orange-50",
    Medium: "text-yellow-600 bg-yellow-50",
    Low: "text-gray-600 bg-gray-50",
  };

  return (
    <div className="space-y-6">
      {/* ✅ 4️⃣ 修改標題呈現 */}
      <h1 className="text-2xl font-bold">{dashboardTitle}</h1>

      {/* 系統總覽 */}
      <section>
        <h2 className="text-lg font-semibold mb-4">系統總覽</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* 只有 Admin 顯示使用者數 */}
          {isAdmin && (
            <div className="bg-white p-6 rounded-lg shadow">
              <p className="text-sm text-gray-600">總使用者</p>
              <p className="text-3xl font-bold text-blue-600">
                {data.overview.totalUsers}
              </p>
            </div>
          )}

          <div className="bg-white p-6 rounded-lg shadow">
            <p className="text-sm text-gray-600">總專案</p>
            <p className="text-3xl font-bold text-green-600">
              {data.overview.totalProjects}
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <p className="text-sm text-gray-600">總任務</p>
            <p className="text-3xl font-bold text-purple-600">
              {data.overview.totalMissions}
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <p className="text-sm text-gray-600">進行中任務</p>
            <p className="text-3xl font-bold text-orange-600">
              {data.overview.inProgressMissions}
            </p>
          </div>
        </div>
      </section>

      {/* 其餘部分保持不變... */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 我的任務摘要 */}
        <section className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="text-blue-500" size={20} />
            <h2 className="text-lg font-semibold">我的任務摘要</h2>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-blue-50 rounded">
              <span className="text-gray-700">進行中</span>
              <span className="font-bold text-blue-600">
                {data.myTasks.inProgress} 個
              </span>
            </div>

            <div className="flex justify-between items-center p-3 bg-purple-50 rounded">
              <span className="text-gray-700">待測試</span>
              <span className="font-bold text-purple-600">
                {data.myTasks.testing} 個
              </span>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-50 rounded border-t-2 border-gray-300">
              <span className="text-gray-700 font-semibold">總計</span>
              <span className="font-bold text-gray-800">
                {data.myTasks.total} 個
              </span>
            </div>
          </div>

          <Link
            href="/missions"
            className="mt-4 block text-center text-blue-600 hover:text-blue-700 text-sm"
          >
            查看所有任務 →
          </Link>
        </section>

        {/* 即將到期提醒 */}
        <section className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center gap-2 mb-4">
            <AlertCircle className="text-orange-500" size={20} />
            <h2 className="text-lg font-semibold">即將到期</h2>
          </div>

          {data.upcomingDeadlines.length === 0 ? (
            <p className="text-gray-500 text-sm">目前沒有即將到期的任務 ✨</p>
          ) : (
            <div className="space-y-3">
              {data.upcomingDeadlines.map((task) => (
                <Link
                  key={task.id}
                  href={`/missions/${task.id}`}
                  className="block p-3 border rounded hover:bg-gray-50 transition"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <p className="font-medium text-gray-800 line-clamp-1">
                        {task.title}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <Calendar size={14} className="text-gray-400" />
                        <span className="text-xs text-gray-500">
                          {formatDate(task.dueDate)}
                        </span>
                        <span
                          className={`text-xs px-2 py-0.5 rounded ${
                            priorityColors[task.priority]
                          }`}
                        >
                          {task.priority}
                        </span>
                      </div>
                    </div>
                    <div
                      className={`text-sm font-semibold ${
                        task.daysLeft <= 2 ? "text-red-600" : "text-orange-600"
                      }`}
                    >
                      {task.daysLeft === 0 ? "今天" : `${task.daysLeft} 天`}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* 最近活動 */}
      <section className="bg-white p-6 rounded-lg shadow">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="text-green-500" size={20} />
          <h2 className="text-lg font-semibold">最近活動</h2>
        </div>

        {data.recentActivities.length === 0 ? (
          <p className="text-gray-500 text-sm">暫無活動記錄</p>
        ) : (
          <div className="space-y-3">
            {data.recentActivities.map((activity) => (
              <div
                key={activity.id}
                className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded transition"
              >
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <div className="flex-1">
                  <p className="text-sm text-gray-800">
                    <span className="font-semibold">{activity.userName}</span>{" "}
                    更新了「
                    <Link
                      href={`/missions/${activity.missionId}`}
                      className="text-blue-600 hover:underline"
                    >
                      {activity.missionTitle}
                    </Link>
                    」
                    {activity.field === "Status" && (
                      <span>
                        {" "}
                        →{" "}
                        <span className="font-medium">{activity.newValue}</span>
                      </span>
                    )}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    {getTimeAgo(activity.timestamp)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 所有專案 */}
      <section>
        <h2 className="text-lg font-semibold mb-4">
          {isAdmin ? "所有專案" : "我的專案"}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {data.projects.map((project) => (
            <div key={project.id} className="bg-white p-6 rounded-lg shadow">
              <h3 className="font-bold text-lg">{project.name}</h3>
              <div className="flex justify-between items-center mt-2">
                <span className="text-sm text-gray-600">總任務</span>
                <span className="font-semibold">{project.totalMissions}</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
