"use client";

import { useState } from "react";
import { X } from "lucide-react";

interface AddUserModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function AddUserModal({ open, onClose, onSuccess }: AddUserModalProps) {
  // ✅ 使用者輸入資料
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    fullName: "",
    title: "",
    roles: [] as string[],
  });

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  // ✅ 固定角色清單（對應 Roles 資料表）
  const availableRoles = [
    { value: "Admin", label: "系統管理員" },
    { value: "AccountAdmin", label: "帳號管理員" },
    { value: "PM", label: "專案經理" },
    { value: "RDL", label: "研發組長" },
    { value: "RD", label: "研發人員" },
    { value: "QA", label: "品質保證" },
  ];

  if (!open) return null;

  // ✅ 表單送出事件
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    // 🧱 Step 1：基本欄位驗證
    const { email, password, fullName, roles } = formData;
    if (!email || !password || !fullName) {
      setError("請填寫所有必填欄位");
      return;
    }

    // 🧱 Step 2：密碼格式驗證（至少8字元，含大小寫與數字）
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    if (!passwordRegex.test(password)) {
      setError("密碼至少 8 個字元，且必須包含大小寫字母與數字");
      return;
    }

    // 🧱 Step 3：角色驗證
    if (roles.length === 0) {
      setError("請至少選擇一個角色");
      return;
    }

    // 🧱 Step 4：發送 API
    setIsLoading(true);
    try {
      const token = localStorage.getItem("token");
      if (!token) throw new Error("找不到登入權杖，請重新登入");

      // 🔵 傳送資料結構：與後端的 adminCreateUser 對齊
      const requestBody = {
        email: formData.email,
        password: formData.password,
        fullName: formData.fullName,
        title: formData.title || null,
        roleNames: formData.roles, // ⭐ 後端預期名稱
      };

      console.log("📤 發送新增使用者請求：", requestBody);

      const res = await fetch("http://localhost:4000/api/users/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(requestBody),
      });

      const data = await res.json();
      console.log("📥 收到回應：", data);

      if (data.success) {
        alert("✅ 使用者新增成功！已寄出驗證信。");
        onSuccess();
        onClose();

        // ✅ 重置表單
        setFormData({
          email: "",
          password: "",
          fullName: "",
          title: "",
          roles: [],
        });
      } else {
        setError(data.message || "新增失敗，請稍後再試");
      }
    } catch (err: any) {
      console.error("❌ 新增使用者錯誤:", err);
      setError(err.message || "伺服器發生錯誤");
    } finally {
      setIsLoading(false);
    }
  };

  // ✅ 勾選/取消角色
  const handleRoleToggle = (role: string) => {
    setFormData((prev) => ({
      ...prev,
      roles: prev.roles.includes(role)
        ? prev.roles.filter((r) => r !== role)
        : [...prev.roles, role],
    }));
  };

  // --------------------------------------------
  // 🧱 Modal 結構（UI）
  // --------------------------------------------
  return (
    <div className="fixed inset-0 bg-transparent flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6 max-h-[90vh] overflow-y-auto">
        {/* 標題列 */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-800">新增使用者</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* 表單 */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) =>
                setFormData({ ...formData, email: e.target.value })
              }
              required
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none"
              placeholder="user@example.com"
            />
          </div>

          {/* 密碼 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              密碼 <span className="text-red-500">*</span>
            </label>
            <input
              type="password"
              value={formData.password}
              onChange={(e) =>
                setFormData({ ...formData, password: e.target.value })
              }
              required
              minLength={8}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none"
              placeholder="至少 8 個字元，包含大小寫字母和數字"
            />
            <p className="text-xs text-gray-500 mt-1">
              範例：Test1234、Password1、Abc12345
            </p>
          </div>

          {/* 姓名 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              姓名 <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={formData.fullName}
              onChange={(e) =>
                setFormData({ ...formData, fullName: e.target.value })
              }
              required
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none"
              placeholder="請輸入姓名"
            />
          </div>

          {/* 職稱 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              職稱
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) =>
                setFormData({ ...formData, title: e.target.value })
              }
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none"
              placeholder="例如：QA Engineer"
            />
          </div>

          {/* 角色選擇 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              指派角色 <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {availableRoles.map((role) => (
                <label
                  key={role.value}
                  className="flex items-center gap-2 p-1 cursor-pointer hover:bg-gray-50 rounded"
                >
                  <input
                    type="checkbox"
                    checked={formData.roles.includes(role.value)}
                    onChange={() => handleRoleToggle(role.value)}
                    className="w-4 h-4 text-blue-500 rounded focus:ring-2 focus:ring-blue-400"
                  />
                  <span className="text-sm text-gray-700">{role.label}</span>
                </label>
              ))}
            </div>
            {formData.roles.length === 0 && (
              <p className="text-xs text-red-500 mt-2">請至少選擇一個角色</p>
            )}
          </div>

          {/* 錯誤訊息 */}
          {error && (
            <div className="bg-red-100 text-red-600 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          {/* 按鈕列 */}
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 active:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-offset-2 transition-colors"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 active:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? "新增中..." : "新增使用者"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
