"use client";

import { useState } from "react";
import { EditUserModal } from "./EditUserModal";

interface UserCardProps {
  userId: number;
  name: string;
  email: string;
  status: string;
  role: string;
  title?: string;
  avatarUrl?: string;
  provider: string;
  emailVerified: boolean;
  onUpdate?: () => void;
}

export function UserCard({
  userId,
  name,
  email,
  status,
  role,
  title,
  avatarUrl,
  provider,
  emailVerified,
  onUpdate,
}: UserCardProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);

  // 狀態顏色對應
  const statusStyles = {
    Active: "bg-green-100 text-green-700",
    Suspended: "bg-red-100 text-red-700",
    Archived: "bg-gray-100 text-gray-700",
  };

  // 狀態中文對應
  const statusText = {
    Active: "啟用",
    Suspended: "停用",
    Archived: "封存",
  };

  // Provider 顯示文字
  const providerText = {
    local: "Email",
    google: "Google",
    facebook: "Facebook",
    github: "GitHub",
  };

  // ⭐ 處理狀態切換（包含軟刪除）
  const handleStatusChange = async () => {
    let newStatus: string;
    let confirmMessage: string;

    if (status === "Active") {
      // 啟用 → 停用
      newStatus = "Suspended";
      confirmMessage = "確定要停用此使用者嗎？";
    } else if (status === "Suspended") {
      // 停用 → 封存（軟刪除）
      newStatus = "Archived";
      confirmMessage = "確定要封存（軟刪除）此使用者嗎？封存後將無法再啟用。";
    } else if (status === "Archived") {
      // 封存狀態不可操作
      alert("封存的使用者無法修改狀態");
      return;
    } else {
      return;
    }

    if (!confirm(confirmMessage)) {
      return;
    }

    setIsLoading(true);

    try {
      const token = localStorage.getItem("token");
      
      console.log('🔵 前端：更新狀態', { userId, from: status, to: newStatus });

      const res = await fetch(`http://localhost:4000/api/users/${userId}/status`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });

      const data = await res.json();
      console.log('🔵 前端：收到回應', data);

      if (data.success) {
        const newStatusText = statusText[newStatus as keyof typeof statusText];
        alert(`狀態更新成功！已改為「${newStatusText}」`);
        onUpdate?.();
      } else {
        alert(data.message || "更新失敗");
      }
    } catch (err) {
      console.error("❌ 前端：更新狀態錯誤:", err);
      alert("更新失敗，請稍後再試");
    } finally {
      setIsLoading(false);
    }
  };

  // ⭐ 決定按鈕文字和樣式
  const getButtonConfig = () => {
    if (status === "Active") {
      return {
        text: "停用",
        className: "bg-red-50 text-red-600 hover:bg-red-100 border border-red-200",
        disabled: false,
      };
    } else if (status === "Suspended") {
      return {
        text: "封存",
        className: "bg-gray-50 text-gray-600 hover:bg-gray-100 border border-gray-200",
        disabled: false,
      };
    } else if (status === "Archived") {
      return {
        text: "已封存",
        className: "bg-gray-100 text-gray-400 cursor-not-allowed",
        disabled: true,
      };
    }
    return {
      text: "操作",
      className: "bg-gray-100 text-gray-400 cursor-not-allowed",
      disabled: true,
    };
  };

  const buttonConfig = getButtonConfig();

  return (
    <>
      <div className="bg-white border rounded-lg p-6 hover:shadow-lg transition-shadow">
        {/* 頭像與基本資訊 */}
        <div className="flex items-center gap-4 mb-4">
          <img
            src={
              avatarUrl ||
              `https://ui-avatars.com/api/?name=${encodeURIComponent(
                name
              )}&background=random`
            }
            alt={name}
            className="w-16 h-16 rounded-full object-cover border-2 border-gray-200"
          />
          <div className="flex-1">
            <h3 className="font-semibold text-lg text-gray-800">{name}</h3>
            <p className="text-sm text-gray-500">{email}</p>
            {title && <p className="text-xs text-gray-400 mt-1">{title}</p>}
          </div>
        </div>

        {/* 狀態與角色 */}
        <div className="flex gap-2 mb-4 flex-wrap">
          <span
            className={`text-xs px-3 py-1 rounded-full font-medium ${
              statusStyles[status as keyof typeof statusStyles] ||
              "bg-gray-100 text-gray-700"
            }`}
          >
            {statusText[status as keyof typeof statusText] || status}
          </span>
          <span className="text-xs px-3 py-1 rounded-full bg-blue-100 text-blue-700 font-medium">
            {role}
          </span>
        </div>

        {/* 額外資訊 */}
        <div className="text-xs text-gray-500 space-y-1 mb-4">
          <div className="flex items-center gap-2">
            <span>登入方式:</span>
            <span className="font-medium">
              {providerText[provider as keyof typeof providerText] || provider}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span>Email 驗證:</span>
            <span className="font-medium">
              {emailVerified ? "✅ 已驗證" : "❌ 未驗證"}
            </span>
          </div>
        </div>

        {/* ⭐ 操作按鈕 */}
        <div className="flex gap-2">
          <button
            onClick={handleStatusChange}
            disabled={isLoading || buttonConfig.disabled}
            className={`flex-1 px-3 py-2 rounded-lg transition-colors text-sm font-medium ${buttonConfig.className} disabled:opacity-50 disabled:cursor-not-allowed`}
            title={
              status === "Archived"
                ? "封存的使用者無法修改狀態"
                : status === "Suspended"
                ? "點擊封存（軟刪除）此使用者"
                : "點擊停用此使用者"
            }
          >
            {isLoading ? "處理中..." : buttonConfig.text}
          </button>

          <button
            onClick={() => setShowEditModal(true)}
            disabled={status === "Archived"}
            className={`flex-1 px-3 py-2 rounded-lg transition-colors text-sm font-medium ${
              status === "Archived"
                ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                : "bg-blue-500 text-white hover:bg-blue-600"
            }`}
            title={status === "Archived" ? "封存的使用者無法編輯" : "編輯使用者資料"}
          >
            編輯
          </button>
        </div>
      </div>

      {/* 編輯 Modal */}
      {showEditModal && status !== "Archived" && (
        <EditUserModal
          open={showEditModal}
          onClose={() => setShowEditModal(false)}
          user={{
            userId,
            name,
            email,
            title,
            status,
          }}
          onSave={() => {
            onUpdate?.();
          }}
        />
      )}
    </>
  );
}