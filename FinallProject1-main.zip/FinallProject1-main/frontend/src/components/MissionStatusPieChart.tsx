// components/charts/MissionStatusPieChart.tsx
'use client';

import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

interface MissionStatusPieChartProps {
  data: {
    open: number;
    inProgress: number;
    testing: number;
    closed: number;
  };
}

const COLORS = {
  open: '#22c55e',        // 綠色
  inProgress: '#3b82f6',  // 藍色
  testing: '#a855f7',     // 紫色
  closed: '#6b7280',      // 灰色
};

export const MissionStatusPieChart: React.FC<MissionStatusPieChartProps> = ({ data }) => {
  const chartData = [
    { name: '待處理', value: data.open, color: COLORS.open },
    { name: '進行中', value: data.inProgress, color: COLORS.inProgress },
    { name: '測試中', value: data.testing, color: COLORS.testing },
    { name: '已關閉', value: data.closed, color: COLORS.closed },
  ].filter(item => item.value > 0); // 只顯示有數據的項目

  return (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie
          data={chartData}
          cx="50%"
          cy="50%"
          labelLine={false}
          label={(entry) => `${entry.name}: ${entry.value}`}
          outerRadius={80}
          fill="#8884d8"
          dataKey="value"
        >
          {chartData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.color} />
          ))}
        </Pie>
        <Tooltip />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );
};