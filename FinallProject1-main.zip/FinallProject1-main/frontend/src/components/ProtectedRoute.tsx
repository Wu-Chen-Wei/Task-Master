"use client";

/**
 * 受保護的路由元件
 * 需要登入才能存取
 */
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRoles?: string[]; // 需要的角色（可選）
}

export default function ProtectedRoute({
  children,
  requiredRoles,
}: ProtectedRouteProps) {
  const router = useRouter();
  const { isAuthenticated, isLoading, hasAnyRole } = useAuth();

  useEffect(() => {
    if (!isLoading) {
      // 未登入，導向登入頁
      if (!isAuthenticated) {
        router.push("/login");
        return;
      }

      // 已登入，但角色不符
      if (requiredRoles && !hasAnyRole(requiredRoles)) {
        alert("權限不足，無法存取此頁面");
        router.push("/dashboard");
      }
    }
  }, [isAuthenticated, isLoading, requiredRoles, router, hasAnyRole]);

  // 載入中
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-gray-600">載入中...</div>
      </div>
    );
  }

  // 未登入
  if (!isAuthenticated) {
    return null;
  }

  // 角色不符
  if (requiredRoles && !hasAnyRole(requiredRoles)) {
    return null;
  }

  // 通過驗證，顯示內容
  return <>{children}</>;
}