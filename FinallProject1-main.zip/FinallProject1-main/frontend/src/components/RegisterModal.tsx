"use client";

import { X } from "lucide-react";
import { useState } from "react";

interface RegisterModalProps {
  onClose: () => void; // 關閉視窗
}

export default function RegisterModal({ onClose }: RegisterModalProps) {
  // 註冊表單資料
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      alert("密碼與確認密碼不一致！");
      return;
    }

    // 模擬註冊 API
    alert(`註冊成功！\nEmail: ${formData.email}`);
    onClose(); // 關閉 modal
  };

  return (
    <div className="fixed inset-0 bg-gray-200 bg-opacity-80 flex justify-center items-center z-50">
      <div className="bg-white rounded-xl shadow-lg p-8 w-[400px] relative">
        {/* 關閉按鈕 */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-500 hover:text-gray-800"
        >
          <X size={18} />
        </button>

        {/* 標題 */}
        <h2 className="text-xl font-semibold text-center mb-6">註冊新帳號</h2>

        {/* 表單內容 */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">電子郵件</label>
            <input
              type="email"
              name="email"
              required
              value={formData.email}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-400"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">密碼</label>
            <input
              type="password"
              name="password"
              required
              value={formData.password}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-400"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">確認密碼</label>
            <input
              type="password"
              name="confirmPassword"
              required
              value={formData.confirmPassword}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-400"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-green-500 text-white py-2 rounded-md hover:bg-green-600 transition"
          >
            立即註冊
          </button>
        </form>
      </div>
    </div>
  );
}
