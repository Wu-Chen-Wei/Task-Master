"use client";

import { useState, useEffect } from "react";
import { Mail, X } from "lucide-react";

export function EmailVerificationBanner() {
  const [show, setShow] = useState(false);
  const [isResending, setIsResending] = useState(false);

  useEffect(() => {
    const userStr = localStorage.getItem("user");
    if (userStr) {
      const user = JSON.parse(userStr);
      if (!user.EmailVerified) {
        setShow(true);
      }
    }
  }, []);

  const handleResendEmail = async () => {
    const userStr = localStorage.getItem("user");
    if (!userStr) return;

    const user = JSON.parse(userStr);
    setIsResending(true);

    try {
      const res = await fetch(
        "http://localhost:4000/api/users/resend-verification",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email: user.Email }),
        }
      );

      const data = await res.json();

      if (data.success) {
        alert(data.message);
      } else {
        alert(data.message);
      }
    } catch (err) {
      console.error("重新發送驗證信錯誤:", err);
      alert("發送失敗，請稍後再試");
    } finally {
      setIsResending(false);
    }
  };

  if (!show) return null;

  return (
    <div className="bg-yellow-50 border-b border-yellow-200 px-4 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Mail className="w-5 h-5 text-yellow-600" />
          <p className="text-sm text-yellow-800">
            您的 Email 尚未驗證，部分功能將受到限制。
            <button
              onClick={handleResendEmail}
              disabled={isResending}
              className="ml-2 text-yellow-900 font-semibold hover:underline disabled:opacity-50"
            >
              {isResending ? "發送中..." : "重新發送驗證信"}
            </button>
          </p>
        </div>
        <button
          onClick={() => setShow(false)}
          className="text-yellow-600 hover:text-yellow-800"
        >
          <X className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}