// components/charts/PriorityBarChart.tsx
'use client';

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface PriorityBarChartProps {
  data: {
    critical: number;
    high: number;
    medium: number;
    low: number;
  };
}

export const PriorityBarChart: React.FC<PriorityBarChartProps> = ({ data }) => {
  const chartData = [
    { name: '緊急', value: data.critical, fill: '#ef4444' },
    { name: '高', value: data.high, fill: '#f97316' },
    { name: '中', value: data.medium, fill: '#eab308' },
    { name: '低', value: data.low, fill: '#9ca3af' },
  ];

  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="value" name="任務數量" />
      </BarChart>
    </ResponsiveContainer>
  );
};