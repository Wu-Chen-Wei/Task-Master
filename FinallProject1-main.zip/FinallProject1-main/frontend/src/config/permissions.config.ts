import { useAuth } from "@/hooks/useAuth";

// 權限檢查函數的類型
type PermissionChecker = ReturnType<typeof useAuth>;

// ==================== 頁面權限配置 ====================
export const pagePermissions: Record<string, (auth: any) => boolean> = {
  // 需要特定權限的頁面
  "/users": (auth) => auth.canManageUsers(),
  "/projects": (auth) => auth.canManageProjects(),
  "/missions": (auth) => auth.canManageMissions(),
  "/settings": (auth) => auth.canManageSettings(),

  // 所有登入使用者都能訪問的頁面
  "/dashboard": () => true,
  "/notifications": () => true,
  "/profile": () => true,
};

// ==================== 輔助函數 ====================

/**
 * 檢查使用者是否有訪問特定路徑的權限
 */
export const checkPagePermission = (
  pathname: string,
  auth: PermissionChecker
): boolean => {
  // 找出匹配的權限配置
  const matchedKey = Object.keys(pagePermissions).find(
    (key) => pathname === key || pathname.startsWith(key + "/")
  );

  // 如果沒有配置，預設不允許（更安全）
  if (!matchedKey) return false;

  // 執行權限檢查
  return pagePermissions[matchedKey](auth);
};