/**
 * 路由配置檔
 * 集中管理所有路由定義
 */

// ==================== 公開路由（不需登入） ====================
export const publicRoutes = [
  "/",
  "/landingpage",
  "/login",
  "/register",
  "/verify-email",
  "/reset-password",
  "/forgot-password",
  "/403", // 權限不足頁面
  "/404", // 找不到頁面
] as const;

// ==================== 受保護路由（需要登入） ====================
export const protectedRoutes = [
  "/dashboard",
  "/users",
  "/projects",
  "/missions",
  "/notifications",
  "/settings",
  "/profile",
] as const;

// ==================== 特殊路由 ====================
export const loginRoute = "/login";
export const registerRoute = "/register";
export const defaultRoute = "/dashboard"; // 登入後的預設頁面
export const forbiddenRoute = "/403";     // 權限不足頁面
export const notFoundRoute = "/404";      // 找不到頁面

// ==================== 路由類型 ====================
export type PublicRoute = typeof publicRoutes[number];
export type ProtectedRoute = typeof protectedRoutes[number];
export type AllRoute = PublicRoute | ProtectedRoute;