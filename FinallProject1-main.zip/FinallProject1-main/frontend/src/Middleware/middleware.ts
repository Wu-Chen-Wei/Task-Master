import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // ==================== 1. 定義公開路徑 ====================
  const publicPaths = [
    "/",
    "/landingpage",
    "/login",
    "/register",
    "/verify-email",
    "/reset-password",
    "/forgot-password",
  ];

  // ==================== 2. 定義需要登入的路徑 ====================
  const protectedPaths = [
    "/dashboard",
    "/users",
    "/projects",
    "/missions",
    "/notifications",
    "/settings",
    "/profile",
  ];

  // ==================== 3. 定義管理員專屬路徑 ====================
  const adminOnlyPaths = [
    "/users",
    "/settings",
  ];

  // ==================== 4. 檢查是否為靜態資源 ====================
  if (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/api") ||
    pathname.includes(".")
  ) {
    return NextResponse.next();
  }

  // ==================== 5. 取得 Token ====================
  const token = request.cookies.get("token")?.value;
  
  // 如果沒有 cookie token，檢查 localStorage（但 middleware 無法直接存取）
  // 所以我們需要在 client side 處理

  // ==================== 6. 未登入使用者訪問受保護路徑 ====================
  const isProtectedPath = protectedPaths.some((path) =>
    pathname.startsWith(path)
  );

  if (isProtectedPath && !token) {
    // 重導向到登入頁面，並記錄原本想去的頁面
    const url = new URL("/login", request.url);
    url.searchParams.set("redirect", pathname);
    return NextResponse.redirect(url);
  }

  // ==================== 7. 已登入使用者訪問登入/註冊頁 ====================
  if (token && (pathname === "/login" || pathname === "/register")) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  // ==================== 8. 通過檢查 ====================
  return NextResponse.next();
}

// 設定 middleware 要處理的路徑
export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!_next/static|_next/image|favicon.ico).*)",
  ],
};