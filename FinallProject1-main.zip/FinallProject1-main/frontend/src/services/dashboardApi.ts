// src/services/dashboardApi.ts
import axios from "axios";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

const api = axios.create({
  baseURL: `${API_BASE_URL}/api/dashboard`,
  headers: {
    "Content-Type": "application/json",
  },
});

// 自動加入 JWT Token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token && config.headers) {
    // ✅ 加入 config.headers 檢查
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const dashboardApi = {
  // 取得角色專屬 Dashboard
  getHome: () => api.get("/overview"),
  // ✅ 新增：搜尋 Missions
  searchMissions: (filters: {
    projectId?: string;
    assigneeId?: string;
    status?: string;
    priority?: string;
    tags?: string[];
    keyword?: string;
    startDate?: string;
    endDate?: string;
  }) => {
    const params = new URLSearchParams();

    if (filters.projectId) params.append("projectId", filters.projectId);
    if (filters.assigneeId) params.append("assigneeId", filters.assigneeId);
    if (filters.status) params.append("status", filters.status);
    if (filters.priority) params.append("priority", filters.priority);
    if (filters.tags && filters.tags.length > 0)
      params.append("tags", filters.tags.join(","));
    if (filters.keyword) params.append("keyword", filters.keyword);
    if (filters.startDate) params.append("startDate", filters.startDate);
    if (filters.endDate) params.append("endDate", filters.endDate);

    return api.get(`/missions/search?${params.toString()}`);
  },
  // ✅ 新增：專案進度統計
  getProjectProgress: (
    projectId: string,
    dateRange?: { startDate: string; endDate: string }
  ) => {
    const params = new URLSearchParams();
    if (dateRange) {
      params.append("startDate", dateRange.startDate);
      params.append("endDate", dateRange.endDate);
    }
    return api.get(`/projects/${projectId}/progress?${params.toString()}`);
  },

  // ✅ 新增：專案進度趨勢
  getProjectProgressTrend: (
    projectId: string,
    startDate: string,
    endDate: string
  ) => {
    return api.get(
      `/projects/${projectId}/progress/trend?startDate=${startDate}&endDate=${endDate}`
    );
  },

  // ✅ 新增：標籤分析
  getTagsAnalysis: (
    projectId: string,
    dateRange?: { startDate: string; endDate: string }
  ) => {
    const params = new URLSearchParams();
    if (dateRange) {
      params.append("startDate", dateRange.startDate);
      params.append("endDate", dateRange.endDate);
    }
    return api.get(`/projects/${projectId}/tags/analysis?${params.toString()}`);
  },

  // ✅ 新增：優先度分析
  getPriorityAnalysis: (projectId: string) => {
    return api.get(`/projects/${projectId}/priority/analysis`);
  },
  // ✅ 新增：甘特圖
  getGanttChart: (projectId: string) => {
    return api.get(`/projects/${projectId}/gantt`);
  },

  // ✅ 新增：Kanban 看板
  getKanbanBoard: (projectId: string) => {
    return api.get(`/projects/${projectId}/kanban`);
  },

  // ✅ 新增：更新任務狀態
  updateMissionStatus: (missionId: string, status: string) => {
    return api.put(`/missions/${missionId}/status`, { status });
  },
};
