"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  User,
  Mail,
  Bell,  // ✅ 新增：通知 icon
  Briefcase,
  Shield,
  Calendar,
  CheckCircle,
  XCircle,
  Edit2,
  Save,
  X,
} from "lucide-react";

interface UserData {
  userID: number;
  Email: string;
  NotificationEmail?: string;  // ✅ 已加
  FullName: string;
  Title?: string;
  AvatarURL?: string;
  EmailVerified: boolean;
  Status: string;
  CreatedAt: string;
  Roles: string[];
}

export default function ProfilePage() {
  const router = useRouter();
  const [user, setUser] = useState<UserData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // 編輯狀態
  const [editFullName, setEditFullName] = useState("");
  const [editTitle, setEditTitle] = useState("");
  const [editNotificationEmail, setEditNotificationEmail] = useState("");  // ✅ 已加

  // 載入個人資料
  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        router.push("/login");
        return;
      }

      const res = await fetch("http://localhost:4000/api/users/me", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();

      if (data.success) {
        setUser(data.user);
        setEditFullName(data.user.FullName);
        setEditTitle(data.user.Title || "");
        setEditNotificationEmail(data.user.NotificationEmail || "");  // ✅ 新增：載入通知 Email
      } else {
        alert("❌ " + data.message);
        router.push("/login");
      }
    } catch (err) {
      console.error("❌ 載入個人資料失敗:", err);
      alert("❌ 載入失敗，請重新登入");
      router.push("/login");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!editFullName.trim()) {
      alert("請輸入姓名");
      return;
    }

    // ✅ 新增：驗證通知 Email 格式（如果有填）
    if (editNotificationEmail && !editNotificationEmail.includes("@")) {
      alert("請輸入正確的 Email 格式");
      return;
    }

    setIsSaving(true);

    try {
      const token = localStorage.getItem("token");

      const res = await fetch("http://localhost:4000/api/users/me", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          fullName: editFullName,
          title: editTitle || null,
          notificationEmail: editNotificationEmail || null,  // ✅ 新增：送出通知 Email
        }),
      });

      const data = await res.json();

      if (data.success) {
        setUser(data.user);
        localStorage.setItem("user", JSON.stringify(data.user));
        setIsEditing(false);
        alert("✅ 個人資料更新成功");
      } else {
        alert("❌ " + data.message);
      }
    } catch (err) {
      console.error("❌ 更新失敗:", err);
      alert("❌ 更新失敗,請稍後再試");
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    setEditFullName(user?.FullName || "");
    setEditTitle(user?.Title || "");
    setEditNotificationEmail(user?.NotificationEmail || "");  // ✅ 新增：重置通知 Email
    setIsEditing(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">載入中...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* 標題 */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">個人資料</h1>
          <p className="text-gray-600 mt-1">查看和編輯您的個人資訊</p>
        </div>

        {/* 主要卡片 */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {/* 頭部 */}
          <div className="bg-gradient-to-r from-blue-500 to-purple-600 px-6 py-8">
            <div className="flex items-center gap-4">
              {/* 頭像 */}
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center text-3xl font-bold text-blue-500">
                {user.FullName.charAt(0).toUpperCase()}
              </div>

              {/* 基本資訊 */}
              <div className="flex-1 text-white">
                <h2 className="text-2xl font-bold">{user.FullName}</h2>
                <p className="text-blue-100">{user.Title || "未設定職稱"}</p>
                <div className="flex gap-2 mt-2">
                  {user.Roles.map((role) => (
                    <span
                      key={role}
                      className="text-xs bg-white/20 px-2 py-1 rounded"
                    >
                      {role}
                    </span>
                  ))}
                </div>
              </div>

              {/* 編輯按鈕 */}
              {!isEditing && (
                <button
                  onClick={() => setIsEditing(true)}
                  className="px-4 py-2 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors flex items-center gap-2"
                >
                  <Edit2 size={16} />
                  編輯資料
                </button>
              )}
            </div>
          </div>

          {/* 內容 */}
          <div className="p-6 space-y-6">
            {/* Email 驗證狀態 */}
            <div className="bg-gray-50 rounded-lg p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {user.EmailVerified ? (
                  <CheckCircle className="text-green-500" size={24} />
                ) : (
                  <XCircle className="text-red-500" size={24} />
                )}
                <div>
                  <p className="font-semibold text-gray-900">Email 驗證狀態</p>
                  <p className="text-sm text-gray-600">
                    {user.EmailVerified ? "已驗證" : "尚未驗證"}
                  </p>
                </div>
              </div>
              {!user.EmailVerified && (
                <button className="text-sm text-blue-600 hover:underline">
                  重新發送驗證信
                </button>
              )}
            </div>

            {/* 編輯表單 */}
            {isEditing ? (
              <div className="space-y-4">
                {/* 姓名 */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    姓名 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={editFullName}
                    onChange={(e) => setEditFullName(e.target.value)}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    placeholder="請輸入姓名"
                  />
                </div>

                {/* 職稱 */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    職稱
                  </label>
                  <input
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    placeholder="請輸入職稱（選填）"
                  />
                </div>

                {/* ✅ 新增：通知 Email */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    通知 Email
                  </label>
                  <input
                    type="email"
                    value={editNotificationEmail}
                    onChange={(e) => setEditNotificationEmail(e.target.value)}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    placeholder="請輸入接收通知的 Email（選填）"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    💡 如果不填，系統會使用您的登入 Email 發送通知
                  </p>
                </div>

                {/* 按鈕 */}
                <div className="flex gap-3">
                  <button
                    onClick={handleSave}
                    disabled={isSaving}
                    className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    <Save size={16} />
                    {isSaving ? "儲存中..." : "儲存"}
                  </button>
                  <button
                    onClick={handleCancel}
                    disabled={isSaving}
                    className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    <X size={16} />
                    取消
                  </button>
                </div>
              </div>
            ) : (
              /* 資訊顯示 */
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Email（登入用） */}
                <div className="flex items-start gap-3">
                  <Mail className="text-gray-400 mt-1" size={20} />
                  <div>
                    <p className="text-sm text-gray-500">登入 Email</p>
                    <p className="font-medium text-gray-900">{user.Email}</p>
                    <p className="text-xs text-gray-400 mt-1">🔒 無法修改</p>
                  </div>
                </div>

                {/* ✅ 新增：通知 Email */}
                <div className="flex items-start gap-3">
                  <Bell className="text-gray-400 mt-1" size={20} />
                  <div>
                    <p className="text-sm text-gray-500">通知 Email</p>
                    <p className="font-medium text-gray-900">
                      {user.NotificationEmail || user.Email}
                    </p>
                    {!user.NotificationEmail && (
                      <p className="text-xs text-gray-400 mt-1">使用登入 Email</p>
                    )}
                  </div>
                </div>

                {/* 姓名 */}
                <div className="flex items-start gap-3">
                  <User className="text-gray-400 mt-1" size={20} />
                  <div>
                    <p className="text-sm text-gray-500">姓名</p>
                    <p className="font-medium text-gray-900">{user.FullName}</p>
                  </div>
                </div>

                {/* 職稱 */}
                <div className="flex items-start gap-3">
                  <Briefcase className="text-gray-400 mt-1" size={20} />
                  <div>
                    <p className="text-sm text-gray-500">職稱</p>
                    <p className="font-medium text-gray-900">
                      {user.Title || "未設定"}
                    </p>
                  </div>
                </div>

                {/* 角色 */}
                <div className="flex items-start gap-3">
                  <Shield className="text-gray-400 mt-1" size={20} />
                  <div>
                    <p className="text-sm text-gray-500">角色</p>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {user.Roles.map((role) => (
                        <span
                          key={role}
                          className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded"
                        >
                          {role}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* 註冊日期 */}
                <div className="flex items-start gap-3">
                  <Calendar className="text-gray-400 mt-1" size={20} />
                  <div>
                    <p className="text-sm text-gray-500">註冊日期</p>
                    <p className="font-medium text-gray-900">
                      {new Date(user.CreatedAt).toLocaleDateString("zh-TW")}
                    </p>
                  </div>
                </div>

                {/* 帳號狀態 */}
                <div className="flex items-start gap-3">
                  <CheckCircle className="text-gray-400 mt-1" size={20} />
                  <div>
                    <p className="text-sm text-gray-500">帳號狀態</p>
                    <p className="font-medium text-gray-900">
                      {user.Status === "Active" ? "正常" : user.Status}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 返回按鈕 */}
        <div className="mt-6">
          <button
            onClick={() => router.push("/dashboard")}
            className="text-blue-600 hover:underline"
          >
            ← 返回 Dashboard
          </button>
        </div>
      </div>
    </div>
  );
}