"use client";

import { useRouter } from "next/navigation";
import { FileQuestion } from "lucide-react";
import { defaultRoute } from "@/config/routes.config";

export default function NotFoundPage() {
  const router = useRouter();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
        <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <FileQuestion className="w-10 h-10 text-blue-500" />
        </div>

        <h1 className="text-4xl font-bold text-gray-900 mb-4">404</h1>
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">
          找不到頁面
        </h2>
        <p className="text-gray-600 mb-8">
          抱歉，您訪問的頁面不存在。<br />
          請檢查網址是否正確，或返回首頁。
        </p>

        <div className="space-y-3">
          <button
            onClick={() => router.push(defaultRoute)}
            className="w-full bg-blue-500 text-white py-3 rounded-lg font-medium hover:bg-blue-600 transition-colors"
          >
            返回 Dashboard
          </button>

          <button
            onClick={() => router.push("/landingpage")}
            className="w-full bg-gray-200 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-300 transition-colors"
          >
            返回首頁
          </button>
        </div>
      </div>
    </div>
  );
}