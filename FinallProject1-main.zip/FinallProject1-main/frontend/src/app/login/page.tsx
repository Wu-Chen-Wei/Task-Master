"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff } from "lucide-react";
import Link from "next/link";

// ⭐ 快速登入帳號清單
const QUICK_LOGIN_ACCOUNTS = [
  {
    label: "SysAdmin(Tom SmithXX)",
    email: "zse811022@gmail.com",
    role: "系統管理員",
    color: "bg-red-100 text-red-700 border-red-200 hover:bg-red-200",
  },
  {
    label: "PM (Jane Doe)",
    email: "jept19921022@gmail.com",
    role: "專案經理",
    color: "bg-blue-100 text-blue-700 border-blue-200 hover:bg-blue-200",
  },
  {
    label: "PM(Quen Lin)",
    email: "pm1@gmail.com",
    role: "專案經理",
    color: "bg-blue-100 text-blue-700 border-blue-200 hover:bg-blue-200",
  },
  {
    label: "RD Leader (Tom)",
    email: "x06082010@gmail.com",
    role: "研發主管",
    color: "bg-green-100 text-green-700 border-green-200 hover:bg-green-200",
  },
  {
    label: "RD (Alice)",
    email: "kevin27385940@gmail.com",
    role: "工程師",
    color: "bg-green-50 text-green-600 border-green-200 hover:bg-green-100",
  },
  {
    label: "RD (Bob)",
    email: "linx71203@gmail.com",
    role: "工程師",
    color: "bg-green-50 text-green-600 border-green-200 hover:bg-green-100",
  },
  {
    label: "QA(Charlie Brown)",
    email: "cce1123tp@gmail.com",
    role: "測試人員",
    color:
      "bg-yellow-100 text-yellow-700 border-yellow-200 hover:bg-yellow-200",
  },
  {
    label: "權限Demo",
    email: "ubuntu19921022@gmail.com",
    role: "測試人員",
    color:
      "bg-yellow-100 text-yellow-700 border-yellow-200 hover:bg-yellow-200",
  },
];

const DEFAULT_PASSWORD = "TestPassword123";

export default function LoginPage() {
  const router = useRouter();

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // ⭐ 更新表單欄位
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    setError("");
  };

  // ⭐ 共用登入邏輯（Email 登入 + 快速登入）
  const performLogin = async (email: string, password: string) => {
    setError("");
    setIsLoading(true);

    try {
      const res = await fetch("http://localhost:4000/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (data.success) {
        localStorage.setItem("token", data.token);
        localStorage.setItem("user", JSON.stringify(data.user));
        window.dispatchEvent(new Event("user-logged-in"));
        router.push("/dashboard");
      } else {
        setError(data.message || "登入失敗，請稍後再試");
      }
    } catch (err) {
      console.error("登入錯誤:", err);
      setError("伺服器連線錯誤，請稍後再試");
    }

    setIsLoading(false);
  };

  // ⭐ Email 提交登入
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.email || !formData.password) {
      setError("請填寫所有欄位");
      return;
    }
    await performLogin(formData.email, formData.password);
  };

  // ⭐ 快速登入
  const handleQuickLogin = (email: string) => {
    setFormData({ email, password: DEFAULT_PASSWORD });
    performLogin(email, DEFAULT_PASSWORD);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 py-10">
      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        {/* 標題 */}
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">使用者登入</h2>
        </div>

        {/* 錯誤訊息 */}
        {error && (
          <div className="bg-red-100 text-red-600 px-4 py-2 rounded mb-4 text-sm">
            {error}
          </div>
        )}

        {/* 分隔線 */}
        <div className="relative mb-4">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-300"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-white text-gray-500">Email 登入</span>
          </div>
        </div>

        {/* Email 登入表單 */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              電子郵件
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
              placeholder="輸入您的 Email"
              disabled={isLoading}
            />
          </div>

          {/* 密碼 */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-sm font-medium text-gray-700">
                密碼
              </label>
              <Link
                href="/forgot-password"
                className="text-sm text-blue-600 hover:underline"
              >
                忘記密碼？
              </Link>
            </div>

            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                value={formData.password}
                onChange={handleChange}
                className="w-full border rounded-lg px-3 py-2 pr-10 focus:ring-2 focus:ring-blue-400 focus:outline-none"
                placeholder="輸入您的密碼"
                disabled={isLoading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          {/* 登入按鈕 */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition-colors disabled:bg-gray-400"
          >
            {isLoading ? "登入中..." : "登入"}
          </button>
        </form>
        {/* 註冊連結 */}
        <p className="text-center text-sm text-gray-500 mb-4">
          還沒有帳號？{" "}
          <Link href="/register" className="text-blue-600 hover:underline">
            立即註冊
          </Link>
        </p>

        {/* 快速登入區 */}
        <div className="mt-6 pt-4 border-t border-gray-100">
          <details className="group">
            <summary className="flex items-center justify-between text-xs font-bold text-gray-400 hover:text-gray-600 cursor-pointer select-none list-none">
              <span>⚡ 快速登入 (Dev Only)</span>
              <span className="hidden group-open:inline text-gray-400">▼</span>
              <span className="text-[10px] bg-gray-100 px-2 py-0.5 rounded-full text-gray-500 group-open:hidden">
                展開選單
              </span>
            </summary>

            <div className="flex flex-wrap gap-2 mt-3">
              {QUICK_LOGIN_ACCOUNTS.map((acc) => (
                <button
                  key={acc.email}
                  type="button"
                  onClick={() => handleQuickLogin(acc.email)}
                  disabled={isLoading}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-medium transition-all ${
                    acc.color
                  } ${
                    isLoading
                      ? "opacity-50 cursor-not-allowed"
                      : "hover:scale-105"
                  }`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-current opacity-60"></span>
                  {acc.label}
                </button>
              ))}
            </div>
          </details>
        </div>
      </div>
    </div>
  );
}
