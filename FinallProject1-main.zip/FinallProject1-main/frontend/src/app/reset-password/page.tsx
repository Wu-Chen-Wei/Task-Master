"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Lock, CheckCircle, XCircle } from "lucide-react";

export default function ResetPasswordPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get("token");

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);

  // 檢查是否有 token
  useEffect(() => {
    if (!token) {
      setError("無效的重設連結");
    }
  }, [token]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    // 驗證
    if (!password || !confirmPassword) {
      setError("請填寫所有欄位");
      return;
    }

    if (password.length < 6) {
      setError("密碼長度至少需要 6 個字元");
      return;
    }

    if (password !== confirmPassword) {
      setError("兩次輸入的密碼不一致");
      return;
    }

    setIsLoading(true);

    try {
      const res = await fetch("http://localhost:4000/api/auth/reset-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          token,
          newPassword: password,
        }),
      });

      const data = await res.json();

      if (data.success) {
        setIsSuccess(true);
        // 3 秒後自動跳轉到登入頁
        setTimeout(() => {
          router.push("/login");
        }, 3000);
      } else {
        setError(data.message || "重設失敗，請稍後再試");
      }
    } catch (err) {
      console.error("❌ 重設密碼失敗:", err);
      setError("伺服器連線錯誤，請稍後再試");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
        {!isSuccess ? (
          <>
            {/* 標題 */}
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lock className="w-8 h-8 text-purple-500" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">
                重設密碼
              </h1>
              <p className="text-gray-600 text-sm">
                請輸入您的新密碼
              </p>
            </div>

            {/* 錯誤提示 */}
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg mb-4 text-sm flex items-start gap-2">
                <XCircle size={20} className="flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            {/* 表單 */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* 新密碼 */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  新密碼
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition-all"
                    placeholder="至少 6 個字元"
                    disabled={isLoading || !token}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    tabIndex={-1}
                  >
                    {showPassword ? "🙈" : "👁️"}
                  </button>
                </div>
              </div>

              {/* 確認密碼 */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  確認新密碼
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition-all"
                    placeholder="再次輸入新密碼"
                    disabled={isLoading || !token}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    tabIndex={-1}
                  >
                    {showConfirmPassword ? "🙈" : "👁️"}
                  </button>
                </div>
              </div>

              {/* 密碼強度提示 */}
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-3">
                <p className="text-xs text-gray-600 mb-2 font-medium">
                  密碼要求：
                </p>
                <ul className="text-xs text-gray-600 space-y-1">
                  <li className={password.length >= 6 ? "text-green-600" : ""}>
                    {password.length >= 6 ? "✓" : "○"} 至少 6 個字元
                  </li>
                  <li className={password && confirmPassword && password === confirmPassword ? "text-green-600" : ""}>
                    {password && confirmPassword && password === confirmPassword ? "✓" : "○"} 兩次密碼相同
                  </li>
                </ul>
              </div>

              <button
                type="submit"
                disabled={isLoading || !token}
                className="w-full bg-purple-500 text-white py-3 rounded-lg font-medium hover:bg-purple-600 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                {isLoading ? "重設中..." : "重設密碼"}
              </button>
            </form>

            {/* 返回登入 */}
            <div className="mt-6 text-center">
              <Link
                href="/login"
                className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
              >
                返回登入頁面
              </Link>
            </div>
          </>
        ) : (
          /* 成功畫面 */
          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              ✅ 密碼重設成功！
            </h2>
            <p className="text-gray-600 mb-6">
              您的密碼已成功更新
            </p>

            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
              <p className="text-sm text-green-800">
                🎉 現在可以使用新密碼登入了
                <br />
                ⏰ 3 秒後自動跳轉至登入頁面...
              </p>
            </div>

            <button
              onClick={() => router.push("/login")}
              className="w-full bg-blue-500 text-white py-3 rounded-lg font-medium hover:bg-blue-600 transition-colors"
            >
              立即前往登入
            </button>
          </div>
        )}
      </div>
    </div>
  );
}