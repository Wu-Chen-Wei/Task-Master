"use client";

import { useEffect, useState } from "react";
import { UserCard } from "@/components/UserCard";
import { AddUserModal } from "@/components/AddUserModal";
import { useRouter } from "next/navigation";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface User {
  UserID: number;
  Email: string;
  FullName: string;
  Title?: string;
  Status: string;
  EmailVerified: boolean;
  Provider: string;
  AvatarURL?: string;
  Roles?: string[];
}

export default function UsersPage() {
  const router = useRouter();

  /* ======== State ======== */
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);

  const [page, setPage] = useState(1);
  const [pageSize] = useState(9);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("Active");

  useEffect(() => {
    fetchUsers();
  }, [page, searchTerm, statusFilter]);

  const fetchUsers = async () => {
    try {
      setIsLoading(true);
      const token = localStorage.getItem("token");
      if (!token) {
        router.push("/login");
        return;
      }

      const params = new URLSearchParams({
        page: page.toString(),
        pageSize: pageSize.toString(),
        search: searchTerm,
        status: statusFilter,
      });

      const res = await fetch(`http://localhost:4000/api/users?${params}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = await res.json();
      if (data.success) {
        setUsers(data.users);
        setTotal(data.total);
        setTotalPages(data.totalPages);
      } else {
        setError(data.message || "無法載入使用者列表");
      }
    } catch (err) {
      setError("載入失敗，請稍後再試");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = (val: string) => {
    setSearchTerm(val);
    setPage(1);
  };

  const handleStatusFilter = (val: string) => {
    setStatusFilter(val);
    setPage(1);
  };

  const statusText = {
    Active: "啟用",
    Suspended: "停用",
    Archived: "封存",
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      
      {/* ================ Main Content ================ */}
      <main className="flex-1 p-10">

        {/* Page Title */}
        <div className="mb-10">
          <h1 className="text-3xl font-semibold text-gray-900">帳號管理模組</h1>
          <p className="text-gray-500 mt-2">
            共 {total} 位使用者（{statusText[statusFilter as keyof typeof statusText]}）
            {searchTerm && `｜搜尋：${searchTerm}`}
          </p>
        </div>

        {/* Filter Bar */}
        <div className="bg-white shadow-sm border rounded-lg p-5 flex gap-4 mb-8">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="搜尋姓名或 Email..."
            className="flex-1 px-4 py-2 border rounded-lg"
          />
          <select
            value={statusFilter}
            onChange={(e) => handleStatusFilter(e.target.value)}
            className="px-4 py-2 border rounded-lg min-w-[150px]"
          >
            <option value="Active">啟用</option>
            <option value="Suspended">停用</option>
            <option value="Archived">封存</option>
          </select>

          <button
            onClick={() => setShowAddModal(true)}
            className="bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700"
          >
            + 新增使用者
          </button>
        </div>

        {/* Loading */}
        {isLoading && (
          <div className="text-center py-20 text-gray-500">
            載入中...
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="bg-red-100 text-red-600 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}

        {/* Empty */}
        {!isLoading && users.length === 0 && (
          <div className="text-center py-20 text-gray-500">
            找不到符合條件的使用者
          </div>
        )}

        {/* User Cards */}
        {!isLoading && users.length > 0 && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
              {users.map((u) => (
                <UserCard
                  key={u.UserID}
                  userId={u.UserID}
                  name={u.FullName}
                  email={u.Email}
                  status={u.Status}
                  role={u.Roles?.[0] || "使用者"}
                  title={u.Title}
                  avatarUrl={u.AvatarURL}
                  provider={u.Provider}
                  emailVerified={u.EmailVerified}
                  onUpdate={fetchUsers}
                />
              ))}
            </div>

            {/* Pagination */}
            <div className="bg-white border rounded-lg shadow-sm p-5 flex items-center justify-between">
              
              {/* Left Text */}
              <div className="text-gray-600 text-sm">
                顯示 {(page - 1) * pageSize + 1} - {Math.min(page * pageSize, total)} 筆，
                共 {total} 筆
              </div>

              {/* Page Buttons */}
              <div className="flex items-center gap-2">
                <button
                  disabled={page === 1}
                  onClick={() => setPage(page - 1)}
                  className="p-2 border rounded disabled:opacity-40"
                >
                  <ChevronLeft size={20} />
                </button>

                {[...Array(totalPages)].map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setPage(i + 1)}
                    className={`px-3 py-1 border rounded ${
                      page === i + 1 ? "bg-blue-600 text-white" : ""
                    }`}
                  >
                    {i + 1}
                  </button>
                ))}

                <button
                  disabled={page === totalPages}
                  onClick={() => setPage(page + 1)}
                  className="p-2 border rounded disabled:opacity-40"
                >
                  <ChevronRight size={20} />
                </button>
              </div>

              {/* Jump Input */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-600">跳至</span>
                <input
                  type="number"
                  min="1"
                  max={totalPages}
                  value={page}
                  onChange={(e) => {
                    const newPage = Number(e.target.value);
                    if (newPage >= 1 && newPage <= totalPages) setPage(newPage);
                  }}
                  className="w-16 border rounded text-center py-1"
                />
                <span className="text-sm text-gray-600">頁</span>
              </div>
            </div>
          </>
        )}
      </main>

      {/* ======== Add User Modal (安全 overlay) ======== */}
      {showAddModal && (
        <AddUserModal
          open={showAddModal}
          onClose={() => setShowAddModal(false)}
          onSuccess={() => {
            fetchUsers();
            setPage(1);
          }}
        />
      )}
    </div>
  );
}
