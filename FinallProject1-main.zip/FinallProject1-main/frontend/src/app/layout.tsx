"use client";

import "./globals.css";
import { Sidebar } from "@/components/Sidebar";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import {
  publicRoutes,
  protectedRoutes,
  loginRoute,
  defaultRoute,
  forbiddenRoute,
  notFoundRoute,
} from "@/config/routes.config";
import { checkPagePermission } from "@/config/permissions.config";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const auth = useAuth();
  const { isAuthenticated, isLoading } = auth;
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    // 等待載入完成
    if (isLoading) return;

    // ==================== 步驟 1：檢查路由是否合法 ====================
    const allValidRoutes = [...publicRoutes, ...protectedRoutes];
    const isValidRoute = allValidRoutes.some(
      (route) => pathname === route || pathname.startsWith(route + "/")
    );

    if (!isValidRoute) {
      console.log(`❌ 無效路由: ${pathname}，導向 404`);
      router.replace(notFoundRoute);
      return;
    }

    // ==================== 步驟 2：檢查是否為受保護路由 ====================
    const isProtectedPage = protectedRoutes.some(
      (page) => pathname === page || pathname.startsWith(page + "/")
    );

    // ==================== 步驟 3：未登入 + 受保護頁面 → 登入頁 ====================
    if (!isAuthenticated && isProtectedPage) {
      console.log("⚠️ 未登入，導向登入頁");
      router.replace(loginRoute);
      return;
    }

    // ==================== 步驟 4：已登入 + 登入/註冊頁 → Dashboard ====================
    if (isAuthenticated && (pathname === loginRoute || pathname === "/register")) {
      console.log("✅ 已登入，導向 Dashboard");
      router.replace(defaultRoute);
      return;
    }

    // ==================== 步驟 5：已登入 + 權限檢查 ====================
    if (isAuthenticated && isProtectedPage) {
      const hasPermission = checkPagePermission(pathname, auth);

      if (!hasPermission) {
        console.log(`❌ 無權限訪問 ${pathname}，導向 403`);
        router.replace(forbiddenRoute);
        return;
      }

      console.log(`✅ 有權限訪問 ${pathname}`);
    }
  }, [pathname, isAuthenticated, isLoading, router, auth]);

  // ==================== 載入中 ====================
  if (isLoading) {
    return (
      <html lang="zh-TW">
        <body className="bg-gray-100 min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
            <p className="text-gray-600">載入中...</p>
          </div>
        </body>
      </html>
    );
  }

  // ==================== 未登入 ====================
  if (!isAuthenticated) {
    return (
      <html lang="zh-TW">
        <body className="bg-gray-100 min-h-screen">{children}</body>
      </html>
    );
  }

  // ==================== 已登入 ====================
  return (
    <html lang="zh-TW">
      <body className="flex bg-gray-100 text-gray-900 min-h-screen">
        <Sidebar />
        <main className="flex-1 p-8 bg-gray-100 min-h-screen overflow-y-auto">
          {children}
        </main>
      </body>
    </html>
  );
}