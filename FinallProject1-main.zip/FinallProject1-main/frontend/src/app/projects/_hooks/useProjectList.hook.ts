// frontend\src\app\projects\_hooks\useProjectList.hook.ts

"use client";

import {useState, useEffect, useCallback} from "react";
import {useRouter, useSearchParams} from "next/navigation";
import {
  ProjectData,
  PaginationMeta,
  ProjectListResponse,
  ProjectFilters,
  CurrentUser,
  AuthenticatedUserFromServer,
  QuickFilterMode,
  MIN_LOADING_TIME,
  CoreID,
} from "../_types/project.types";

// 輔助函數：最小載入時間延遲
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// 預設篩選狀態 (從版本一 ProjectCardList 內搬遷)
const DEFAULT_FILTERS: ProjectFilters = {
  page: 1,
  limit: 12,
  search: "",
  sortBy: "EndDate",
  sortOrder: "ASC",
};

/**
 * 核心職責：專案列表數據總管 Hook。
 * 實施契約：雙端點路由邏輯、權限檢查、URL 狀態同步。
 */
export const useProjectList = () => {
  const router = useRouter();
  const searchParams = useSearchParams();

  // --- 狀態定義 (從版本一 page.tsx 搬遷) ---
  const [projects, setProjects] = useState<ProjectData[]>([]);
  const [meta, setMeta] = useState<PaginationMeta>({
    totalProjects: 0,
    totalPages: 1,
    currentPage: 1,
  });
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState<CurrentUser | null>(null);
  const [userLoading, setUserLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [currentMode, setCurrentMode] = useState<QuickFilterMode>("MINE"); // 預設為 MINE

  // --- 輔助函數：URL 篩選器處理 ---
  const getFiltersFromUrl = useCallback((): {
    filters: ProjectFilters;
    mode: QuickFilterMode;
  } => {
    const params = new URLSearchParams(searchParams.toString());

    // 解析基礎篩選器
    const filters: Partial<ProjectFilters> = {
      page: parseInt(params.get("page") || "1"),
      limit: parseInt(params.get("limit") || "12"),
      search: params.get("search") || "",
      status: params.has("status")
        ? parseInt(params.get("status")!)
        : undefined,
      tagId: params.has("tagId") ? parseInt(params.get("tagId")!) : undefined,
      sortBy: params.get("sortBy") || "EndDate",
      sortOrder: (params.get("sortOrder") || "ASC") as "ASC" | "DESC",
    };

    const mode: QuickFilterMode =
      (params.get("mode") as QuickFilterMode) || "MINE";

    return {filters: {...DEFAULT_FILTERS, ...filters} as ProjectFilters, mode};
  }, [searchParams]);

  /**
   * 核心修正區域：更新 URL 篩選器並確保模式 (mode) 持久化。
   */
  const updateUrlFilters = useCallback(
    (newFilters: Partial<ProjectFilters>) => {
      const currentParams = new URLSearchParams(searchParams.toString());

      let shouldResetPage = false;

      // 1. 處理所有新/變更的篩選器
      Object.entries(newFilters).forEach(([key, value]) => {
        // 如果是 mode, search, status, tagId 變動，標記需要重設頁碼
        if (key !== "page" && value !== undefined) {
          shouldResetPage = true;
        }

        if (
          value === undefined ||
          value === null ||
          String(value).length === 0
        ) {
          // 如果明確傳入 undefined/null/空字串，則刪除參數
          currentParams.delete(key);
        } else {
          // 設置或更新參數 (這將保留 currentParams 中未被觸及的參數，例如 mode)
          currentParams.set(key, String(value));
        }
      });

      // 2. 處理頁碼邏輯
      if (newFilters.page !== undefined) {
        // 如果明確傳入 page 參數 (來自分頁元件)，則使用它
        currentParams.set("page", String(newFilters.page));
      } else if (shouldResetPage) {
        // 如果是搜索、狀態或模式變動，但沒有傳入 page，則重設到第一頁
        currentParams.set("page", "1");
      }

      router.replace(`/projects?${currentParams.toString()}`);
    },
    [searchParams, router]
  );

  // --- 身份驗證邏輯 ---
  const fetchCurrentUser = useCallback(async () => {
    setUserLoading(true);
    const token = localStorage.getItem("token");
    const backendUrl =
      process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:4000";

    if (!token) {
      setAuthError("認證 Token 不存在。");
      setUserLoading(false);
      return;
    }

    try {
      const response = await fetch(`${backendUrl}/api/auth/me`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) throw new Error("認證失敗");

      const result = await response.json();
      const userFromBackend = result.user as AuthenticatedUserFromServer;

      const fetchedUser: CurrentUser = {
        userID: String(userFromBackend.UserID) as CoreID,
        email: userFromBackend.Email,
        Roles: userFromBackend.Roles || [], // 關鍵契約：使用 Roles 陣列進行權限檢查
      };

      setCurrentUser(fetchedUser);
    } catch (error: any) {
      console.error("認證錯誤:", error);
      setAuthError(error.message || "無法取得使用者資訊");
    } finally {
      setUserLoading(false);
    }
  }, []);

  // --- 核心數據獲取邏輯 ---
  const fetchProjects = useCallback(async () => {
    if (userLoading || !currentUser) return;

    setLoading(true);
    const {filters, mode} = getFiltersFromUrl(); // 獲取最新篩選器和模式

    const backendUrl =
      process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:4000";

    // 權限檢查：使用 Roles 陣列判斷 PM/Admin 權限
    const userRoles = currentUser.Roles || [];
    const isProjectManagerOrAdmin =
      userRoles.includes("PM") || userRoles.includes("Admin");

    let endpoint = `${backendUrl}/api/v1/projects`;

    // 實施雙端點路由邏輯契約 (PM/Admin 且選擇 ALL 模式)
    if (mode === "ALL" && isProjectManagerOrAdmin) {
      endpoint = `${backendUrl}/api/v1/projects/all`;
    }

    const token = localStorage.getItem("token");

    try {
      const params = new URLSearchParams();

      Object.entries(filters).forEach(([key, value]) => {
        // 排除客戶端狀態 mode
        if (
          key !== "mode" &&
          value !== undefined &&
          value !== null &&
          String(value).length > 0
        ) {
          params.append(key, String(value));
        }
      });

      // 實施 1 秒最小緩衝時間契約
      const [response, _delayResult] = await Promise.all([
        fetch(`${endpoint}?${params.toString()}`, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }),
        delay(MIN_LOADING_TIME),
      ]);

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          errorData.message || `無法取得專案列表 (HTTP ${response.status})`
        );
      }

      const result: ProjectListResponse = await response.json();
      setProjects(result.data);
      setMeta(result.meta);
    } catch (error) {
      console.error("數據獲取過程中發生錯誤:", error);
      setAuthError("數據獲取失敗，請檢查網路或權限。");
    } finally {
      setLoading(false);
    }
  }, [getFiltersFromUrl, currentUser, userLoading, searchParams, router]);

  // --- 載入與副作用管理 (Effect) ---

  useEffect(() => {
    fetchCurrentUser();
  }, [fetchCurrentUser]);

  // URL 參數或用戶變更時，觸發數據獲取
  useEffect(() => {
    const {mode} = getFiltersFromUrl();
    setCurrentMode(mode); // 同步當前模式
    if (currentUser) {
      fetchProjects();
    }
  }, [fetchProjects, currentUser, searchParams]);

  // --- Hook 導出 (API) ---

  const {filters} = getFiltersFromUrl();

  // 實作權限旗標導出 (供 Buttonbar 使用)
  const isPM =
    (currentUser?.Roles || []).includes("PM") ||
    (currentUser?.Roles || []).includes("Admin");

  return {
    projects,
    meta,
    loading,
    userLoading,
    authError,
    isPM,
    currentMode,
    updateUrlFilters,
    initialFilters: filters,
  };
};
