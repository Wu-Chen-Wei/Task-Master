// frontend/src/app/projects/[projectId]/members/page.tsx

"use client";

import React, {useState, useCallback, useEffect, useMemo} from "react";
// 移除 router, 我們不再需要它
// import {useRouter} from "next/navigation";

import {
  useProjectDetailContext,
  ROLE_COLORS,
  // ⭐ 修正 1: 移除 useProjectMembers (我們將在組件內自己 fetch)
  // useProjectMembers,
} from "../_hooks/ProjectDetailContext";

import {
  Users,
  Plus,
  Loader2,
  Trash2,
  User,
  Info,
  AlertTriangle,
  X,
  ChevronDown,
} from "lucide-react";

import {CoreID} from "../../_types/project.types";

const BUTTON_COLOR = "#1AA1D9";

const HINT_CLASS =
  "flex items-center space-x-2 p-3 rounded-[8px] bg-[#FFBB00] border border-[#FFE58F] text-[#FFFFFF] text-sm mt-3";

const INPUT_STYLE =
  "mt-1 block w-full rounded-[8px ] border border-gray-300 shadow-sm p-2 text-sm focus:border-blue-500 focus:ring-blue-500";

const BACKEND_URL =
  process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:4000";

interface AssignableUser {
  userID: CoreID;
  fullName: string;
  title: string;
  roleID: CoreID;
}

const ROLE_IDS = {
  ADMIN: 1,
  PM: 3,
  RDL: 4,
  RD: 5,
  QA: 6,
};

const ADDABLE_ROLES = [
  {id: ROLE_IDS.RD, name: "研發工程師 (RD)"},
  {id: ROLE_IDS.QA, name: "品質保證 (QA)"},
];

export default function MembersPage() {
  // const router = useRouter(); // 移除

  // 這次我們只需要 Context 中的權限和 ID
  const {project, isLocked, canManageMembersOrAttachments} =
    useProjectDetailContext();
  const projectId = project?.projectID || "0";

  // ⭐ 修正 2: 將 useProjectMembers 的邏輯移入組件
  const [members, setMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // ⭐ 修正 3: 建立我們自己的 fetchMembers 函數 (這就是 refetch)
  const fetchMembers = useCallback(async () => {
    if (!projectId || projectId === "0") return;

    setLoading(true);
    setError(null);
    const token = localStorage.getItem("token");

    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/${projectId}/members`, // 假設這是獲取成員的 API
        {
          method: "GET",
          headers: {Authorization: `Bearer ${token}`},
        }
      );
      if (!response.ok) {
        throw new Error("獲取成員列表失敗");
      }
      const result = await response.json();
      setMembers(result.data || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  // ⭐ 修正 4: 在組件加載時呼叫 fetchMembers
  useEffect(() => {
    fetchMembers();
  }, [fetchMembers]);

  // --- Modal 狀態 (保持不變) ---
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAdding, setIsAdding] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);

  const [targetRole, setTargetRole] = useState<number>(ROLE_IDS.RD);

  const [selectedUserId, setSelectedUserId] = useState<CoreID>("");
  const [allAssignableUsers, setAllAssignableUsers] = useState<
    AssignableUser[]
  >([]);
  const [usersLoading, setUsersLoading] = useState(false);

  const [highlightedMemberId, setHighlightedMemberId] = useState<CoreID | null>(
    null
  );
  const [removingMemberId, setRemovingMemberId] = useState<CoreID | null>(null);

  // fetchAssignableUsers (保持不變)
  const fetchAssignableUsers = useCallback(async () => {
    setUsersLoading(true);
    const token = localStorage.getItem("token");
    setModalError(null);
    if (!token) {
      setModalError("認證 Token 不存在。");
      setUsersLoading(false);
      return;
    }

    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/assignable`,
        {
          method: "GET",
          headers: {Authorization: `Bearer ${token}`},
        }
      );
      if (!response.ok) throw new Error("無法獲取指派人員清單");
      const result = await response.json();
      setAllAssignableUsers(result.data as AssignableUser[]);
    } catch (error: any) {
      setModalError(error.message || "載入可指派人員列表失敗。");
    } finally {
      setUsersLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isModalOpen) {
      fetchAssignableUsers();
    }
  }, [isModalOpen, fetchAssignableUsers]);

  // availableUsers (保持不變)
  const availableUsers = useMemo(() => {
    const targetRoleNumber = targetRole;

    const nonMembers = allAssignableUsers.filter(
      (u) => !members.some((m: any) => m.userID === u.userID)
    );

    const filteredUsers = nonMembers.filter((user) => {
      const userRoleID = Number(user.roleID);

      if (userRoleID === ROLE_IDS.PM || userRoleID === ROLE_IDS.RDL) {
        return false;
      }

      return userRoleID === targetRoleNumber || userRoleID === ROLE_IDS.ADMIN;
    });

    return filteredUsers;
  }, [allAssignableUsers, members, targetRole]);

  // useEffect (保持不變)
  useEffect(() => {
    if (availableUsers.length > 0) {
      if (
        !selectedUserId ||
        !availableUsers.some((u) => u.userID === selectedUserId)
      ) {
        setSelectedUserId(availableUsers[0].userID);
      }
    } else {
      setSelectedUserId("");
    }
  }, [availableUsers, selectedUserId]);

  // ⭐ 修正 5: 修改 handleAddMember
  const handleAddMember = useCallback(async () => {
    if (!selectedUserId || !targetRole) {
      setModalError("請選擇一位成員和角色。");
      return;
    }

    const payload = {
      userId: selectedUserId,
      roleId: targetRole,
    };
    const token = localStorage.getItem("token");
    setIsAdding(true);
    setModalError(null);

    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/${projectId}/members`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(payload),
        }
      );

      if (response.ok) {
        alert("成員已成功新增。");

        // 1. 優先關閉 Modal 並重設表單
        setIsModalOpen(false);
        setSelectedUserId("");
        setTargetRole(ROLE_IDS.RD);

        // 2. 開始高亮動畫
        setHighlightedMemberId(selectedUserId);

        // 3. ⭐ 呼叫我們自己的 fetchMembers 來刷新
        // 並且在動畫播放完畢後才執行
        setTimeout(() => {
          fetchMembers(); // <--- 呼叫刷新
          setHighlightedMemberId(null); // 刷新後清除高亮
        }, 1500); // 1.5秒 (對應 'highlightAdded' 動畫時間)
      } else {
        const errorData = await response.json();
        setModalError(
          `新增失敗：【${errorData.code || response.status}】${
            errorData.message || response.statusText
          }`
        );
      }
    } catch (error) {
      setModalError("新增成員時發生網絡錯誤。");
    } finally {
      setIsAdding(false);
    }
  }, [projectId, selectedUserId, targetRole, fetchMembers]); // <--- 加入 fetchMembers 依賴

  // ⭐ 修正 6: 修改 handleRemoveMember
  const handleRemoveMember = async (memberId: CoreID) => {
    if (!confirm("確定要將該成員從專案中移除嗎？")) return;

    const token = localStorage.getItem("token");
    // 1. 開始移除動畫
    setRemovingMemberId(memberId);

    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/${project?.projectID}/members/${memberId}`,
        {
          method: "DELETE",
          headers: {Authorization: `Bearer ${token}`},
        }
      );

      if (response.ok || response.status === 204) {
        alert("成員已成功移除。");

        // 2. ⭐ 呼叫我們自己的 fetchMembers 來刷新
        // 並在動畫播放完畢後才執行
        setTimeout(() => {
          fetchMembers(); // <--- 呼叫刷新
          setRemovingMemberId(null); // 清除移除中的高亮
        }, 1000); // 1 秒 (給動畫和 API 緩衝)
      } else {
        const errorData = await response.json();
        alert(
          `移除失敗：【${errorData.code || response.status}】${
            errorData.message || response.statusText
          }`
        );
        setRemovingMemberId(null); // 失敗也要清除高亮
      }
    } catch (error) {
      alert("移除成員時發生網絡錯誤。");
      setRemovingMemberId(null); // 失敗也要清除高亮
    }
  };

  if (loading)
    return (
      <div className='text-center p-8 text-gray-500'>
        <Loader2 className='animate-spin inline mr-2' /> 載入成員列表...
      </div>
    );

  if (error)
    return (
      <div className='text-center p-8 text-red-700'>
        成員數據載入失敗: {error}
      </div>
    );

  const currentRoleName =
    ADDABLE_ROLES.find((r) => r.id === targetRole)?.name || "RD";

  return (
    <div className='space-y-6'>
      {/* 動畫 CSS 定義 (保持不變) */}
      <style jsx>{`
        @keyframes highlightAdded {
          0% {
            background-color: #d1e7dd;
          } /* 淺綠色 */
          50% {
            background-color: #b2d7b2;
          }
          100% {
            background-color: transparent;
          }
        }
        @keyframes highlightRemoving {
          0% {
            background-color: #f8d7da;
          } /* 淺紅色 */
          50% {
            background-color: #e6b3b3;
          }
          100% {
            background-color: transparent;
          }
        }
        .highlight-added {
          animation: highlightAdded 1.5s ease-out forwards;
        }
        .highlight-removing {
          animation: highlightRemoving 0.5s ease-out forwards;
        }
      `}</style>

      {/* 標題與新增按鈕 */}
      <div className='flex justify-between items-center'>
        <h2 className='text-xl font-semibold flex items-center space-x-2'>
          <Users size={20} className='text-gray-600' />
          <span>成員 ({members.length})</span>
        </h2>
        {canManageMembersOrAttachments && !isLocked && (
          <button
            onClick={() => {
              setIsModalOpen(true);
              setModalError(null);
            }}
            style={{backgroundColor: BUTTON_COLOR}}
            className={`text-white font-bold py-2 px-4 rounded-[8px] text-sm flex items-center shadow-sm transition-colors`}>
            <Plus size={18} className='mr-1' />
            新增成員
          </button>
        )}
      </div>

      <p className='text-gray-500 text-sm mb-4'>專案的所有團隊成員。</p>

      {/* 提示：PM 和 RDL 不能被移除 [3] */}
      <div className='flex items-center space-x-2 p-3 rounded-[8px] bg-[#FFBB00] border border-[#FFE58F] text-white text-sm mt-3'>
        <AlertTriangle size={16} className='text-yellow-700' />
        <span>專案經理 (PM) 和研發主管 (RDL) 無法被移除。</span>
      </div>

      {/* 成員列表 (表格) */}
      <div className='bg-white border border-gray-200 rounded-lg overflow-hidden'>
        <table className='min-w-full divide-y divide-gray-200'>
          <thead className='bg-[#F5F5F5]'>
            <tr>
              <th className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase w-2/5'>
                成員名稱
              </th>
              <th className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'>
                角色
              </th>
              <th className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'>
                加入日期
              </th>
              <th className='px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase'>
                操作
              </th>
            </tr>
          </thead>
          <tbody className='divide-y divide-gray-200'>
            {members.length === 0 ? (
              <tr>
                <td
                  colSpan={4}
                  className='px-6 py-4 text-center text-sm text-gray-500'>
                  此專案目前沒有任何成員。
                </td>
              </tr>
            ) : (
              members.map((member: any) => {
                const isFixedRole =
                  member.roleName === "PM" || member.roleName === "RDL";

                // 動畫 - 根據狀態應用不同的類別
                const rowClassName = `
                  hover:bg-gray-50
                  ${
                    highlightedMemberId === member.userID
                      ? "highlight-added"
                      : ""
                  }
                  ${
                    removingMemberId === member.userID
                      ? "highlight-removing"
                      : ""
                  }
                `;

                return (
                  <tr key={member.userID} className={rowClassName}>
                    <td className='px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 flex items-center space-x-2'>
                      <User size={18} className='text-gray-500' />
                      <span>{member.fullName}</span>
                    </td>
                    <td className='px-6 py-4 whitespace-nowrap'>
                      <span
                        className={`px-2 py-1 rounded-full text-xs font-medium text-white`}
                        style={{
                          backgroundColor:
                            ROLE_COLORS[member.roleName] || ROLE_COLORS.Default,
                        }}>
                        {member.roleName}
                      </span>
                    </td>
                    <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-600'>
                      {new Date(member.joinedAt).toLocaleDateString()}
                    </td>
                    <td className='px-6 py-4 whitespace-nowrap text-center text-sm font-medium'>
                      {/* 移除成員按鈕：P6 權限控制，且不能移除 PM/RDL [12] */}
                      {canManageMembersOrAttachments &&
                        !isLocked &&
                        !isFixedRole && (
                          <button
                            title='移除成員'
                            onClick={() => handleRemoveMember(member.userID)}
                            className='text-red-500 hover:text-red-700'>
                            <Trash2 size={16} />
                          </button>
                        )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* 提示訊息 */}
      <div className={HINT_CLASS}>
        <Info size={16} className='text-yellow-700' />
        <span>新增成員後，加入時間將自動記錄為當前時間。</span>
      </div>

      {/* ========================================================= */}
      {/* Modal: + 新增成員 (遵循 Figma 規格 [13]) */}
      {/* ========================================================= */}
      {isModalOpen && (
        <div className='fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50'>
          <div className='bg-white rounded-lg shadow-xl w-full max-w-md p-6 transform transition-all'>
            {/* Modal Header */}
            <div className='flex justify-between items-start border-b pb-3 mb-4'>
              <div className='space-y-1'>
                <h3 className='text-xl font-semibold flex items-center space-x-2'>
                  <Users size={20} className='text-blue-500' />
                  <span>+ 新增成員</span>
                </h3>
                <p className='text-sm text-gray-500'>將團隊成員加入到此專案</p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className='text-gray-400 hover:text-gray-600'>
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className='space-y-4'>
              {modalError && (
                <div className='bg-red-100 border border-red-400 text-red-700 p-3 rounded text-sm'>
                  {modalError}
                </div>
              )}

              {/* 1. 角色選擇下拉選單 (先選角色) */}
              <div>
                <label
                  htmlFor='role-select'
                  className='block text-sm font-medium text-gray-700 mb-1'>
                  指派角色
                </label>
                <div className='relative'>
                  <select
                    id='role-select'
                    value={targetRole}
                    onChange={(e) => {
                      setTargetRole(Number(e.target.value));
                      setSelectedUserId(""); // 角色變動時清空選定的使用者
                    }}
                    disabled={isAdding || usersLoading}
                    className={`${INPUT_STYLE} appearance-none cursor-pointer pr-8`}>
                    {ADDABLE_ROLES.map((role) => (
                      <option key={role.id} value={role.id}>
                        {role.name}
                      </option>
                    ))}
                  </select>
                  <ChevronDown
                    size={16}
                    className='absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 pointer-events-none'
                  />
                </div>
              </div>

              {/* 2. 成員選擇下拉選單 (後選該角色中的誰) */}
              <div>
                <label
                  htmlFor='member-select'
                  className='block text-sm font-medium text-gray-700 mb-1'>
                  成員姓名 ({currentRoleName} 角色)
                </label>
                {usersLoading ? (
                  <div className='text-gray-500 text-center py-2'>
                    <Loader2 className='animate-spin inline mr-2' size={16} />
                    載入名單...
                  </div>
                ) : availableUsers.length === 0 ? (
                  <p className='text-sm text-gray-500 p-3 bg-gray-50 border rounded'>
                    沒有符合 {currentRoleName} 角色且未加入專案的成員。
                  </p>
                ) : (
                  <div className='relative'>
                    <select
                      id='member-select'
                      value={selectedUserId}
                      onChange={(e) => setSelectedUserId(e.target.value)}
                      disabled={isAdding}
                      className={`${INPUT_STYLE} appearance-none cursor-pointer pr-8`}>
                      <option value='' disabled>
                        請選擇成員
                      </option>
                      {availableUsers.map((user) => (
                        <option key={user.userID} value={user.userID}>
                          {user.fullName} ({user.title} / Role ID: {user.roleID}
                          )
                        </option>
                      ))}
                    </select>
                    <ChevronDown
                      size={16}
                      className='absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 pointer-events-none'
                    />
                  </div>
                )}
              </div>

              {/* 提示區域 */}
              <div className='flex items-center space-x-2 p-3 rounded-[8px] bg-[#FFBB00] border border-[#FFE58F] text-[#595959] text-sm'>
                <Info size={16} className='text-yellow-700' />
                <span>加入時間將自動記錄為當前時間。</span>
              </div>
            </div>

            {/* Modal Footer */}
            <div className='mt-6 flex justify-end space-x-3'>
              <button
                type='button'
                onClick={() => setIsModalOpen(false)}
                disabled={isAdding}
                className='bg-gray-100 border border-gray-300 text-gray-700 hover:bg-gray-200 px-4 py-2 rounded-[8px] text-sm'>
                取消
              </button>
              <button
                type='button'
                onClick={handleAddMember}
                // 禁用條件：正在新增中 或 沒有選中成員
                disabled={
                  isAdding || !selectedUserId || availableUsers.length === 0
                }
                style={{backgroundColor: BUTTON_COLOR}}
                className='text-white font-bold py-2 px-4 rounded-[8px] text-sm flex items-center shadow-sm transition-colors'>
                {isAdding && (
                  <Loader2 size={18} className='animate-spin mr-2' />
                )}
                <span>新增成員</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
