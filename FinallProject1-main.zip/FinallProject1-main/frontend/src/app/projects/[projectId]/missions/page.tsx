// frontend/src/app/projects/[projectId]/missions/page.tsx
"use client";

import React from "react";
import {
  useProjectDetailContext,
  getMissionStatusProps,
  MissionSummary,
} from "../_hooks/ProjectDetailContext";
import {List, User, Calendar, CheckCircle} from "lucide-react";

export default function MissionsPage() {
  const {project, loading} = useProjectDetailContext();

  if (loading) return <div>載入中...</div>;
  if (!project) return <div>找不到專案詳情。</div>;

  const missions = project.missionSummary || [];

  return (
    <div className='space-y-6'>
      <h2 className='text-xl font-semibold mb-4 flex items-center space-x-2'>
        <List size={20} className='text-gray-600' />
        <span>所有任務 ({missions.length})</span>
      </h2>
      <p className='text-gray-500 text-sm mb-4'>
        專案包含所有開發任務和其完成狀態。
      </p>

      <div className='space-y-4'>
        {missions.length === 0 ? (
          <p className='text-gray-500 p-4 bg-[#F5F5F5] rounded-[8px]'>
            此專案目前沒有任何任務。
          </p>
        ) : (
          missions.map((mission, index) => {
            const statusProps = getMissionStatusProps(
              mission.status as MissionSummary["status"]
            );
            // 範例中第一個任務標記為「優先」 [22]
            const isHighPriority = index === 0;
            // C3 聚合驗證契約：Status 必須是 'Closed' 且 qaSignedByUserID 存在 [19]
            const isQAAudited =
              mission.status === "Closed" && mission.qaSignedByUserID;

            return (
              <div
                key={mission.missionID}
                className='bg-white p-5 border border-gray-200 rounded-[8px] shadow-sm'>
                {/* 頂部標題與標籤 */}
                <div className='flex justify-between items-center mb-3 border-b pb-2 border-dashed'>
                  <h3 className='font-semibold text-lg text-gray-800'>
                    {mission.title}
                  </h3>
                  <div className='flex space-x-2'>
                    {isHighPriority && (
                      <span className='text-white text-xs px-2 py-1 rounded-[8px] bg-red-600'>
                        優先
                      </span>
                    )}
                    <span
                      className={`text-white text-xs px-2 py-1 rounded-[8px] ${statusProps.color}`}>
                      {statusProps.label}
                    </span>
                  </div>
                </div>
                {/* 描述 */}
                <p className='text-gray-600 text-sm mb-4'>
                  {mission.description || "無描述"}
                </p>
                {/* 資訊行 - 期限與指派人 */}
                <div className='flex justify-between text-sm text-gray-500 border-t pt-3'>
                  <div className='flex items-center space-x-2'>
                    <User size={16} className='text-green-600' />
                    <span>指派人 ID: {mission.assigneeID || "未指派"}</span>
                  </div>
                  <div className='flex items-center space-x-2'>
                    <Calendar size={16} className='text-red-500' />
                    <span>期限: {mission.dueDate}</span>
                  </div>
                </div>
                {/* QA 驗證資訊 (遵循 Figma 規格 [12]) */}
                {isQAAudited && (
                  <div className='mt-4 pt-3 border-t border-gray-100 space-y-2'>
                    <div className='flex items-center space-x-1 text-sm text-blue-600'>
                      <CheckCircle size={16} />
                      <span className='font-medium'>QA已驗證完畢</span>
                    </div>
                    <p className='text-xs text-gray-500'>
                      驗證人 ID: {mission.qaSignedByUserID}
                    </p>
                    <p className='text-xs text-gray-500'>
                      驗證時間: N/A (MissionSummary DTO 未提供時間戳)
                    </p>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
