"use client";

// 導入 useMemo, useEffect, useCallback
import React, {useState, useMemo, useEffect, useCallback} from "react";

// 引入所需的 ICON
import {
  Paperclip,
  Plus,
  Download,
  Trash2,
  Info,
  Loader2,
  AlertTriangle,
} from "lucide-react";

// 導入 ProjectMemberObject 類型 (用於建立 Map)
import {
  useProjectDetailContext,
  CoreID,
  ProjectMemberObject,
  AttachmentObject, // 確保 AttachmentObject 被導入
} from "../_hooks/ProjectDetailContext";

// 風格常數
const BUTTON_COLOR = "#1AA1D9";
const HINT_CLASS =
  "flex items-center space-x-2 p-3 rounded-[8px] bg-[#FFBB00] border border-[#FFE58F] text-[#FFFFFF] text-sm mt-3";

const BACKEND_URL =
  process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:4000";

// 輔助類型：用於緩存 UserID -> FullName 的映射
interface UserMap {
  [userId: string]: string;
}

// =========================================================
// 新增附件 Modal 輔助元件 (Modal 2)
// (此部分保持不變)
// =========================================================

interface AddAttachmentModalProps {
  projectId: CoreID;
  onClose: () => void;
  onSuccess: () => void;
}

const AddAttachmentModal: React.FC<AddAttachmentModalProps> = ({
  projectId,
  onClose,
  onSuccess,
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [newFileName, setNewFileName] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0]; // 確保只取一個檔案
      setSelectedFile(file);
      setNewFileName(file.name);
    } else {
      setSelectedFile(null);
      setNewFileName("");
    }
  };

  // 實作檔案上傳 (POST /api/v1/attachments) 邏輯
  const handleUpload = async () => {
    if (!selectedFile) {
      setError("請選擇一個檔案。");
      return;
    }

    setIsUploading(true);
    setError(null);

    const token = localStorage.getItem("token");
    const formData = new FormData();

    formData.append("files", selectedFile);
    formData.append("projectId", projectId);
    formData.append("fileName", newFileName);

    try {
      const response = await fetch(`${BACKEND_URL}/api/v1/attachments`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      if (response.status === 201) {
        alert("附件上傳成功！");
        onSuccess();
        onClose();
      } else {
        const errorData = await response.json();
        const code = errorData.code || response.status;
        const message =
          errorData.message || `上傳失敗 (HTTP ${response.status})`;
        setError(`[Code ${code}] ${message}`);
      }
    } catch (error) {
      setError("網絡連線錯誤，無法連接伺服器。");
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className='fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50'>
      <div className='bg-white rounded-lg shadow-xl w-full max-w-md p-6'>
        {/* 標題與副標題 */}
        <div className='flex items-center space-x-2 mb-4'>
          <Paperclip size={20} className='text-gray-600' />
          <h3 className='text-lg font-semibold'>新增專案附件</h3>
        </div>
        <p className='text-gray-500 text-sm mb-4'>上傳文件或檔案到此專案。</p>

        {/* 錯誤提示 */}
        {error && (
          <div className='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4 flex items-center shadow-sm'>
            <AlertTriangle size={20} className='mr-2' />
            {error}
          </div>
        )}

        <div className='space-y-4'>
          {/* 專案 ID 提示 */}
          <div className='p-2 bg-gray-50 rounded text-xs'>
            <strong>所屬專案 ID (自動帶入):</strong> {projectId}
          </div>

          {/* 檔案名稱 (選填) */}
          <div>
            <label className='block text-xs font-medium text-gray-700'>
              檔案名稱 (選填)
            </label>
            <input
              type='text'
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              placeholder='預設為上傳檔案的原名稱'
              className='mt-1 block w-full border border-gray-300 rounded-[8px] shadow-sm p-2 text-sm disabled:bg-gray-50'
              disabled={isUploading}
            />
          </div>

          {/* 選擇檔案區域 */}
          <div>
            <label className='block text-xs font-medium text-gray-700 mb-1'>
              選擇檔案
            </label>
            <input
              type='file'
              onChange={handleFileChange}
              disabled={isUploading}
              className='w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100'
            />
            {selectedFile && (
              <p className='text-xs text-gray-500 mt-2'>
                已選檔案: {selectedFile.name}
              </p>
            )}
          </div>

          {/* 提示區域 */}
          <div className={HINT_CLASS}>
            <Info size={16} className='text-white' />
            <span>系統將自動記錄當前使用者為當前時間</span>
          </div>
        </div>

        {/* 底部按鈕 */}
        <div className='mt-6 flex justify-end space-x-3'>
          <button
            onClick={onClose}
            type='button'
            className='bg-gray-200 text-gray-700 hover:bg-gray-300 px-4 py-2 rounded-[8px] text-sm font-medium'
            disabled={isUploading}>
            取消
          </button>
          <button
            onClick={handleUpload}
            type='button'
            style={{backgroundColor: BUTTON_COLOR}}
            className='text-white hover:bg-[#114574] px-4 py-2 rounded-[8px] text-sm font-medium flex items-center shadow-md'
            disabled={!selectedFile || isUploading}>
            {isUploading && <Loader2 size={18} className='animate-spin mr-2' />}
            新增附件
          </button>
        </div>
      </div>
    </div>
  );
};

// =========================================================
// 主附件頁面元件
// =========================================================

export default function AttachmentsPage() {
  const {
    project,
    loading,
    isLocked,
    canManageMembersOrAttachments,
    fetchProjectData,
  } = useProjectDetailContext();

  // Modal 狀態管理
  const [showAddModal, setShowAddModal] = useState(false);

  // 狀態：用於緩存「已離開」成員的 UserID -> FullName 映射
  const [fetchedUserMap, setFetchedUserMap] = useState<UserMap>({});

  // ⭐ 1. 新增 State: 用於追蹤「正在抓取」的 ID
  const [pendingFetchIds, setPendingFetchIds] = useState<CoreID[]>([]);

  // 數據刷新函數：觸發 Context 中的數據獲取
  const handleDataRefresh = () => {
    if (typeof fetchProjectData === "function") {
      fetchProjectData();
    } else {
      window.location.reload(); // 後備刷新
    }
  };

  // 建立「目前」成員的查找 Map (Fast Path)
  const currentMemberMap = useMemo(() => {
    const members: ProjectMemberObject[] = project?.members || [];
    return new Map(members.map((member) => [member.userID, member.fullName]));
  }, [project?.members]);

  // Effect (Slow Path)，僅抓取「目前」成員 Map 中沒有的 ID
  useEffect(() => {
    const attachments = project?.attachments || [];
    if (attachments.length === 0) return;

    // 篩選出尚未緩存的唯一 UserID
    const uniqueUserIds = Array.from(
      new Set(attachments.map((att: AttachmentObject) => att.uploadedByUserID))
    );

    // ⭐ 2. 修正：只抓取「目前Map」、「已抓取Map」和「正在抓取List」中都沒有的 ID
    const idsToFetch = uniqueUserIds.filter(
      (userId) =>
        !currentMemberMap.has(userId) && // 1. 不是目前成員
        !fetchedUserMap[userId] && // 2. 尚未抓取過
        !pendingFetchIds.includes(userId) // 3. 且沒有正在抓取
    );

    if (idsToFetch.length === 0) return;

    // ⭐ 3. 將這些 ID 標記為「正在抓取」
    setPendingFetchIds((prevPending) => [...prevPending, ...idsToFetch]);

    const token = localStorage.getItem("token");
    const getAuthHeaders = (token: string) => ({
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    });

    const fetchUserNames = async () => {
      const newUserMap: UserMap = {};
      const fetchPromises = idsToFetch.map(async (userId) => {
        try {
          // API 契約：GET /api/users/:id
          const response = await fetch(`${BACKEND_URL}/api/users/${userId}`, {
            method: "GET",
            headers: getAuthHeaders(token || ""),
          });

          if (response.ok) {
            const result = await response.json();
            newUserMap[userId] = result.user.FullName || `用戶 ID: ${userId}`;
          } else {
            newUserMap[userId] = `未知用戶 (${userId})`;
          }
        } catch (error) {
          newUserMap[userId] = `錯誤 (${userId})`;
        }
      });

      await Promise.all(fetchPromises);

      // 更新「已抓取」的 Map 狀態
      setFetchedUserMap((prevMap) => ({
        ...prevMap,
        ...newUserMap,
      }));

      // ⭐ 4. 從「正在抓取」列表中移除剛剛完成的 ID
      setPendingFetchIds((prevPending) =>
        prevPending.filter((id) => !idsToFetch.includes(id))
      );
    };

    fetchUserNames();
    // ⭐ 5. 加入 pendingFetchIds 依賴
  }, [project?.attachments, currentMemberMap, fetchedUserMap, pendingFetchIds]);

  if (loading) return <div>載入中...</div>;

  if (!project) return <div>找不到專案詳情。</div>;

  const projectId = project.projectID as CoreID;
  const attachments = project.attachments || [];

  interface AttachmentDownloadProps extends AttachmentObject {}

  // =========================================================
  // 1. 實作下載附件功能 (Download Attachment)
  // ⭐⭐⭐ 修正：使用 async/await 並檢查 content-type 防止崩潰 ⭐⭐⭐
  // =========================================================

  const handleDownloadAttachment = async (att: AttachmentDownloadProps) => {
    const downloadUrl = `${BACKEND_URL}/api/v1/attachments/${att.attachmentID}/download`;
    const token = localStorage.getItem("token");

    if (!token) {
      alert("請先登入以執行下載操作。");
      return;
    }

    try {
      const response = await fetch(downloadUrl, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      // 1. 檢查回應狀態
      if (!response.ok) {
        const contentType = response.headers.get("content-type");
        // 如果回傳的是 JSON (代表後端有捕捉到錯誤並回傳 JSON)，我們才解析
        if (contentType && contentType.includes("application/json")) {
          const errorData = await response.json();
          throw new Error(
            errorData.message || `下載失敗 (HTTP ${response.status})`
          );
        } else {
          // 如果回傳的不是 JSON (例如 404/500 HTML 頁面)，直接拋出錯誤，不要 call .json()
          throw new Error(
            `伺服器錯誤 (HTTP ${response.status}) - 可能檔案不存在或路徑錯誤`
          );
        }
      }

      // 2. 解析檔名 (Content-Disposition)
      const contentDisposition = response.headers.get("Content-Disposition");
      let filename = att.fileName; // 預設使用列表上的檔名 (Fallback)

      if (contentDisposition) {
        // 優先嘗試解析 UTF-8 標準格式: filename*=UTF-8''...
        const utf8Match = contentDisposition.match(/filename\*=UTF-8''(.+)/i);
        if (utf8Match && utf8Match.length > 1) {
          try {
            filename = decodeURIComponent(utf8Match[1].trim());
          } catch (e) {
            console.warn("檔名解碼失敗，使用預設檔名");
          }
        } else {
          // 嘗試解析舊式格式: filename="..."
          const stdMatch = contentDisposition.match(/filename="?([^";]+)"?/i);
          if (stdMatch && stdMatch.length > 1) {
            filename = stdMatch[1];
          }
        }
      }

      // 3. 轉換 Blob 並觸發下載
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error: any) {
      console.error("下載錯誤:", error);
      alert(`下載文件失敗: ${error.message}`);
    }
  };

  // =========================================================
  // 2. 實作刪除附件功能 (Delete Attachment)
  // (保持不變)
  // =========================================================

  const handleDeleteAttachment = async (
    attachmentId: CoreID,
    fileName: string
  ) => {
    if (!confirm(`確定要刪除附件「${fileName}」嗎？此操作將執行軟刪除。`))
      return;

    const token = localStorage.getItem("token");

    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/attachments/${attachmentId}`,
        {
          method: "DELETE",
          headers: {Authorization: `Bearer ${token}`},
        }
      );

      if (response.status === 204) {
        alert("附件已成功刪除。");
        handleDataRefresh();
      } else {
        const errorData = await response.json();
        const code = errorData.code || response.status;
        alert(
          `刪除失敗 (Code: ${code})：${
            errorData.message || response.statusText
          }`
        );
      }
    } catch (error) {
      alert("刪除附件時發生網絡錯誤。");
    }
  };

  return (
    <div className='space-y-6'>
      {/* 標題與新增按鈕 */}
      <div className='flex justify-between items-center'>
        <h2 className='text-xl font-semibold flex items-center space-x-2'>
          <Paperclip size={20} className='text-gray-600' />
          <span>附件 ({attachments.length})</span>
        </h2>

        {/* 新增附件按鈕 */}
        {canManageMembersOrAttachments && !isLocked && (
          <button
            onClick={() => setShowAddModal(true)}
            style={{backgroundColor: BUTTON_COLOR}}
            className={`text-white font-bold py-2 px-4 rounded-[8px] text-sm flex items-center shadow-sm transition-colors`}>
            <Plus size={18} className='mr-1' />
            新增附件
          </button>
        )}
      </div>

      <p className='text-gray-500 text-sm mb-4'>專案相關的文件和檔案。</p>

      {attachments.length === 0 ? (
        <p className='text-gray-500 p-4 bg-[#F5F5F5] rounded-[8px]'>
          此專案尚未上傳任何附件。
        </p>
      ) : (
        <div className='border rounded-lg overflow-hidden'>
          {/* 表頭 */}
          <div className='grid grid-cols-12 bg-[#F5F5F5] text-xs font-semibold text-gray-600 p-3 border-b'>
            <span className='col-span-6'>附件名稱</span>
            <span className='col-span-2'>上傳者</span> {/* 顯示人名 */}
            <span className='col-span-2'>上傳日期</span>
            <span className='col-span-2 text-center'>操作</span>
          </div>

          {attachments.map((att: AttachmentObject) => (
            <div
              key={att.attachmentID}
              className='grid grid-cols-12 items-center p-3 border-b last:border-b-0 hover:bg-gray-50'>
              {/* 附件資訊 */}
              <div className='flex items-center space-x-2 text-sm font-medium text-gray-800 col-span-6'>
                <Paperclip size={14} className='mr-2 text-gray-400' />
                <span className='truncate max-w-xs'>{att.fileName}</span>
              </div>

              {/* ⭐ 6. 修正：使用 state (pendingFetchIds) 來檢查載入狀態 */}
              <span className='text-xs text-gray-500 col-span-2'>
                {
                  currentMemberMap.get(att.uploadedByUserID) || // 1. 檢查目前成員 (快)
                    fetchedUserMap[att.uploadedByUserID] || // 2. 檢查已抓取成員 (慢)
                    (pendingFetchIds.includes(att.uploadedByUserID) // 3. 檢查是否正在抓取
                      ? "載入中..."
                      : att.uploadedByUserID) // 4. Fallback 顯示 ID
                }
              </span>

              <span className='text-xs text-gray-500 col-span-2'>
                {new Date(att.uploadedAt).toLocaleDateString()}
              </span>

              {/* 操作區：下載和刪除 */}
              <div className='flex space-x-3 justify-center col-span-2'>
                {/* 下載按鈕 */}
                <button
                  title='下載'
                  onClick={() => handleDownloadAttachment(att)}
                  className='text-blue-500 hover:text-blue-700 p-1 rounded transition-colors'>
                  <Download size={16} />
                </button>

                {/* 刪除按鈕 */}
                {canManageMembersOrAttachments && !isLocked && (
                  <button
                    title='刪除'
                    onClick={() =>
                      handleDeleteAttachment(att.attachmentID, att.fileName)
                    }
                    className='text-red-500 hover:text-red-700 p-1 rounded transition-colors'>
                    <Trash2 size={16} />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 底部提示訊息 */}
      <div className='mt-4 space-y-2'>
        <div className={HINT_CLASS}>
          <Info size={16} className='text-white' />
          <span>系統將自動記錄當前使用者與當前時間</span>
        </div>
      </div>

      {/* 渲染 Modal */}
      {showAddModal && (
        <AddAttachmentModal
          projectId={projectId}
          onClose={() => setShowAddModal(false)}
          onSuccess={handleDataRefresh}
        />
      )}
    </div>
  );
}
