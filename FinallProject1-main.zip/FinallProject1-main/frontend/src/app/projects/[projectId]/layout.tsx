//
"use client";

import React, {useMemo, useState, useEffect, useCallback} from "react";

import Link from "next/link";

import {
  ArrowLeft,
  Pencil,
  FileText,
  List,
  Paperclip,
  Users,
  Clock,
  Briefcase,
  Archive,
  Loader2,
  AlertTriangle,
  CheckCircle,
  User,
  Calendar,
  ArrowRight,
} from "lucide-react";

// ⭐ 1. 導入 useParams
import {usePathname, useRouter, useParams} from "next/navigation";

import {
  ProjectDetailContext,
  CoreID,
  ProjectObject,
  CurrentUser,
  PROJECT_STATE_IDS,
  getProjectStatusLabel,
  MissionSummary,
  AttachmentObject,
} from "./_hooks/ProjectDetailContext";

// =========================================================
// I. 常數與風格定義
// =========================================================

const BUTTON_COLOR = "#1AA1D9"; // 主要按鈕色 / 活躍邊框色
const RDL_COLOR = "#FF9800";
const PM_COLOR = "#4CAF50";
const BACKEND_URL =
  process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:4000";

// 腳色與完成色定義
const ROLE_COLORS_HEX = {
  PM: "#4CAF50",
  RDL: "#FF9800",
  RD: "#D32F2F",
  COMPLETED: "#71BF48", // 完成色
};

const ACTIVE_TAB_COLOR = "#1AA1D9"; // 主色調作為活躍文本和背景色
const INACTIVE_BORDER_COLOR = "#E8E8E8"; // 靜態灰邊色

// 流程步驟定義 (包含副標題)
const PROJECT_WORKFLOW_STEPS = [
  {id: 10, name: "專案建立", role: "PM", subtitle: "專案經理建立專案"},
  {id: 20, name: "分析中", role: "RDL", subtitle: "研發主管分析中"},
  {id: 30, name: "開發中", role: "RD", subtitle: "開發人員開發中"},
  {id: 40, name: "審查中", role: "RDL", subtitle: "研發主管審查中"}, // READY_FOR_CLOSURE
  {id: 50, name: "待歸檔", role: "PM", subtitle: "專案經理檢查中"}, // COMPLETED
];

const TABS = [
  {name: "基本資訊", path: "info", icon: FileText, dataKey: null},
  {name: "任務列表", path: "missions", icon: List, dataKey: "missionSummary"},
  {name: "附件", path: "attatchments", icon: Paperclip, dataKey: "attachments"},
  {name: "成員", path: "members", icon: Users, dataKey: null},
  {name: "歷史紀錄", path: "records", icon: Clock, dataKey: null},
];

const getAuthHeaders = (token: string) => ({
  "Content-Type": "application/json",
  Authorization: `Bearer ${token}`,
});

/**
 * 輔助函數：將 ISO 日期字串轉換為 台灣 YYYY/MM/DD 格式
 */
const formatDate = (dateString: string | null): string => {
  if (!dateString) return "";
  try {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}/${month}/${day}`;
  } catch {
    return dateString;
  }
};

// =========================================================
// II. Hook 1: 專案詳情核心數據獲取 (useProjectDetail)
// =========================================================

const useProjectDetail = (projectId: CoreID) => {
  const [state, setState] = useState({
    project: null as ProjectObject | null,
    currentUser: null as CurrentUser | null,
    loading: true,
    error: null as string | null,
  });
  const router = useRouter();

  // 1. 獲取當前使用者身份
  const fetchCurrentUser = useCallback(async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      return null;
    }
    try {
      const response = await fetch(`${BACKEND_URL}/api/auth/me`, {
        method: "GET",
        headers: getAuthHeaders(token),
      });
      if (!response.ok) throw new Error("無法獲取使用者資訊");
      const result = await response.json();
      return {
        userID: String(result.user.UserID),
        email: result.user.Email,
        title: result.user.Title,
        fullName: result.user.FullName,
        Roles: result.user.Roles || [],
      } as CurrentUser;
    } catch (error: any) {
      console.error("認證錯誤:", error);
      return null;
    }
  }, []);

  // 2. 獲取專案詳情數據
  const fetchProjectData = useCallback(
    async (showLoading = true) => {
      if (!projectId) return;
      // 如果指定要顯示 Loading 才轉圈圈，避免背景更新時畫面閃爍
      if (showLoading) {
        setState((prev) => ({...prev, loading: true, error: null}));
      }

      const token = localStorage.getItem("token");
      try {
        const [user, projectResponse] = await Promise.all([
          fetchCurrentUser(),
          fetch(
            `${BACKEND_URL}/api/v1/projects/${projectId}?ts=${new Date().getTime()}`,
            {
              method: "GET",
              headers: {
                ...getAuthHeaders(token || ""),
                "Cache-Control": "no-cache, no-store, must-revalidate",
                Pragma: "no-cache",
                Expires: "0",
              },
              cache: "no-store",
            }
          ),
        ]);

        if (projectResponse.status === 404) {
          throw new Error("專案不存在或已被軟刪除 (40401 NOT_FOUND)");
        }
        if (!projectResponse.ok) {
          throw new Error("無法載入專案詳情");
        }
        const projectResult = await projectResponse.json();

        setState((prev) => ({
          ...prev,
          project: projectResult.data as ProjectObject,
          currentUser: user,
          loading: false,
        }));
      } catch (err: any) {
        setState((prev) => ({
          ...prev,
          loading: false,
          error: err.message || "數據獲取失敗",
        }));
      }
    },
    [projectId, fetchCurrentUser]
  );

  // ⭐ 新增功能：手動更新本地狀態 (樂觀更新用)
  const updateLocalProject = useCallback((updates: Partial<ProjectObject>) => {
    setState((prev) => {
      if (!prev.project) return prev;
      return {
        ...prev,
        project: {...prev.project, ...updates},
      };
    });
  }, []);

  useEffect(() => {
    fetchProjectData(true);
  }, [fetchProjectData]);

  const isPM =
    state.currentUser?.Roles.includes("PM") ||
    state.currentUser?.Roles.includes("Admin");

  const isRDL =
    state.currentUser?.Roles.includes("RDL") ||
    state.currentUser?.Roles.includes("Admin");

  const isLocked = state.project
    ? state.project.currentStateID >= PROJECT_STATE_IDS.COMPLETED
    : false;

  return {
    ...state,
    isPM,
    isRDL,
    isLocked,
    fetchProjectData,
    updateLocalProject, // 匯出此函式
  };
};

// =========================================================
// III. 輔助元件：狀態時間軸 (ProjectTimeline)
// =========================================================

const ProjectTimeline: React.FC<{
  project: ProjectObject;
  isPM: boolean;
  isRDL: boolean;
  fetchProjectData: (showLoading?: boolean) => Promise<void>;
  updateLocalProject: (updates: Partial<ProjectObject>) => void; // 接收新函式
}> = ({project, isPM, isRDL, fetchProjectData, updateLocalProject}) => {
  const router = useRouter();
  const currentStateID = project.currentStateID;
  const projectId = project.projectID;
  const isLocked = currentStateID >= PROJECT_STATE_IDS.COMPLETED;

  const {UNSTARTED, PendingReview, Active, READY_FOR_CLOSURE, COMPLETED} =
    PROJECT_STATE_IDS;

  const missions = project.missionSummary || [];
  const allMissionsAudited =
    missions.length > 0 &&
    missions.every(
      (m: MissionSummary) => m.status === "Closed" && m.qaSignedByUserID
    );

  const isTargetStatus =
    currentStateID === Active ||
    currentStateID === READY_FOR_CLOSURE ||
    currentStateID === COMPLETED;

  const canTransition10to20 = isPM && currentStateID === UNSTARTED;
  const canTransition20to30 = isRDL && currentStateID === PendingReview;
  const isReadyForClosure = currentStateID === READY_FOR_CLOSURE;
  const canStampRDL = isRDL && isReadyForClosure && allMissionsAudited;
  const canArchivePM =
    isPM &&
    currentStateID === COMPLETED &&
    project.rdlApprovedByUserID !== null;

  const handleManualTransition = async (
    targetStateId: number,
    confirmationMessage: string
  ) => {
    if (!window.confirm(confirmationMessage)) return;
    const token = localStorage.getItem("token");
    if (!token || !projectId) return;
    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/${projectId}`,
        {
          method: "PATCH",
          headers: getAuthHeaders(token),
          body: JSON.stringify({targetStateId: targetStateId}),
        }
      );
      if (!response.ok) {
        const errorData = await response.json();
        alert(`操作失敗: ${errorData.message}`);
        return;
      }
      alert(`專案已成功流轉至狀態 ${targetStateId}！`);

      // 樂觀更新：先變色
      updateLocalProject({currentStateID: targetStateId});
      // 背景更新：確保資料正確
      fetchProjectData(false);
      router.refresh();
    } catch (error) {
      alert("狀態轉換時發生網絡錯誤。");
    }
  };

  // 處理 RDL 蓋章 (40 -> 50)
  const handleRdlStamp = async () => {
    const confirmationMessage = `請注意!!!請確認所有任務均已通過QA驗證，且達成專案預期目標，進行蓋章後，專案將轉給PM進行最終結案處理。`;
    if (!window.confirm(`RDL蓋章確認\n\n${confirmationMessage}`)) return;
    const token = localStorage.getItem("token");
    if (!token || !projectId) return;
    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/${projectId}`,
        {
          method: "PATCH",
          headers: getAuthHeaders(token),
          body: JSON.stringify({rdlApproved: true}),
        }
      );
      if (!response.ok) {
        const errorData = await response.json();
        alert(`操作失敗: ${errorData.message}`);
        return;
      }

      alert("RDL 蓋章成功！專案狀態已轉換到 50 (Completed)，請通知 PM 歸檔。");

      // ⭐⭐⭐ 關鍵修正：樂觀更新 (Optimistic Update) ⭐⭐⭐
      // 不等後端查詢結果，直接手動將前端狀態改為 50。
      // 這樣使用者會立刻看到時間軸變綠色，不用等。
      updateLocalProject({
        currentStateID: 50,
        rdlApprovedByUserID: "CURRENT_USER", // 暫時填值讓按鈕邏輯通過
        rdlApprovedAt: new Date().toISOString(),
      });

      // 雙重保險：在背景延遲 500ms 後重新抓取真實數據，確保一致性
      setTimeout(async () => {
        router.refresh(); // 清除 Next.js 快取
        fetchProjectData(false); // 抓取 DB 真實數據 (不顯示 Loading 轉圈)
      }, 500);
    } catch (error) {
      alert("RDL 蓋章時發生網絡錯誤。");
    }
  };

  const handlePmArchive = async () => {
    const confirmationMessage = `請注意!!!請確認專案內容無誤，專案歸檔後將轉為唯讀模式，所有資訊將保存在系統中，並通知所有團隊成員。`;
    if (!window.confirm(`PM專案歸檔確認\n\n${confirmationMessage}`)) return;
    const token = localStorage.getItem("token");
    if (!token || !projectId) return;
    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/${projectId}/archive`,
        {
          method: "PATCH",
          headers: getAuthHeaders(token),
        }
      );
      if (!response.ok) {
        const errorData = await response.json();
        alert(`操作失敗: ${errorData.message}`);
        return;
      }
      alert("專案已成功歸檔 (60)！");

      // 樂觀更新
      updateLocalProject({currentStateID: 60});

      setTimeout(() => {
        fetchProjectData(false);
        router.refresh();
      }, 500);
    } catch (error) {
      alert("PM 歸檔時發生網絡錯誤。");
    }
  };

  return (
    <div className='bg-white p-5 rounded-lg shadow-sm border border-gray-100 mb-6'>
      {/* 時間軸渲染邏輯 */}
      <div className='flex justify-between items-start mb-4'>
        {PROJECT_WORKFLOW_STEPS.map((step, index) => {
          const isActive = step.id <= currentStateID;
          const isCurrent = step.id === currentStateID;
          let iconStyle: React.CSSProperties = {};
          let subtitleTime = "";

          if (isCurrent) {
            iconStyle.backgroundColor =
              ROLE_COLORS_HEX[step.role as keyof typeof ROLE_COLORS_HEX];
          } else if (isActive) {
            iconStyle.backgroundColor = ROLE_COLORS_HEX.COMPLETED;
          } else {
            iconStyle.backgroundColor = "#E2E2E2";
          }

          if (isActive) {
            if (step.id === PROJECT_STATE_IDS.UNSTARTED) {
              subtitleTime = formatDate(project.startDate);
            } else if (step.id >= PROJECT_STATE_IDS.READY_FOR_CLOSURE) {
              if (project.rdlApprovedAt) {
                subtitleTime = formatDate(project.rdlApprovedAt);
              }
            }
          }

          const nextStep = PROJECT_WORKFLOW_STEPS[index + 1];
          const lineColor =
            nextStep && nextStep.id <= currentStateID
              ? BUTTON_COLOR
              : INACTIVE_BORDER_COLOR;

          return (
            <React.Fragment key={step.id}>
              <div className='flex flex-col items-center justify-start w-28 shrink-0'>
                <div
                  className={`w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-semibold shadow-md transition-colors duration-500`}
                  style={iconStyle}>
                  {isLocked && step.id >= COMPLETED ? (
                    <Archive size={32} />
                  ) : isActive ? (
                    isCurrent ? (
                      <Clock size={32} />
                    ) : (
                      <CheckCircle size={32} />
                    )
                  ) : (
                    step.id / 10
                  )}
                </div>
                <span
                  className={`text-lg mt-2 text-center font-medium`}
                  style={{
                    color:
                      isCurrent || isActive
                        ? iconStyle.backgroundColor
                        : undefined,
                  }}>
                  {step.name}
                </span>
                <span className='text-sm text-gray-500 text-center'>
                  {isActive
                    ? `${step.subtitle}${
                        subtitleTime ? ` (${subtitleTime})` : ""
                      }`
                    : "\u00A0"}
                </span>
              </div>

              {index < PROJECT_WORKFLOW_STEPS.length - 1 && (
                <div
                  className={`flex-1 h-1 transition-colors duration-500 mx-2`}
                  style={{
                    backgroundColor: lineColor,
                    marginTop: "30px",
                  }}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* QA 驗證標記與按鈕 */}
      <div className='flex justify-between items-center border-t border-dashed pt-4 mt-4'>
        {allMissionsAudited ? (
          <div className='text-sm text-green-600 flex items-center space-x-1 mr-auto'>
            <CheckCircle size={18} />
            <span>所有 Mission 已完成並通過 QA 驗證</span>
          </div>
        ) : (
          isRDL &&
          isTargetStatus && (
            <div className='text-sm text-yellow-600 flex items-center space-x-1 mr-auto'>
              <AlertTriangle size={18} />
              <span>部分 Mission 仍在進行中或未通過 QA 驗證</span>
            </div>
          )
        )}
        <div className='flex space-x-3'>
          {canTransition10to20 && (
            <button
              style={{backgroundColor: PM_COLOR}}
              className={`hover:bg-green-600 text-white font-bold py-2 px-4 text-sm flex items-center shadow-sm transition-colors rounded-[8px]`}
              onClick={() =>
                handleManualTransition(
                  PendingReview,
                  `已經確定內容無誤，轉交給研發主管: ${
                    project.rdlApprovedByName || "未指派"
                  } 分析。`
                )
              }>
              <ArrowRight size={18} className='mr-1' /> 轉交分析
            </button>
          )}

          {canTransition20to30 && (
            <button
              style={{backgroundColor: RDL_COLOR}}
              className={`hover:bg-orange-600 text-white font-bold py-2 px-4 text-sm flex items-center shadow-sm transition-colors rounded-[8px]`}
              onClick={() =>
                handleManualTransition(
                  Active,
                  `確認已經分配好 mission 給 RD 且內容無誤，轉交給 RD 進行開發。`
                )
              }>
              <ArrowRight size={18} className='mr-1' /> 轉交開發
            </button>
          )}

          {canStampRDL && (
            <button
              style={{backgroundColor: RDL_COLOR}}
              className={`hover:bg-orange-600 text-white font-bold py-2 px-4 rounded-[8px] text-sm flex items-center shadow-sm transition-colors`}
              onClick={handleRdlStamp}>
              <Briefcase size={18} className='mr-1' /> RDL蓋章
            </button>
          )}

          {canArchivePM && (
            <button
              style={{backgroundColor: PM_COLOR}}
              className={`hover:bg-green-600 text-white font-bold py-2 px-4 rounded-[8px] text-sm flex items-center shadow-sm transition-colors`}
              onClick={handlePmArchive}>
              <Archive size={18} className='mr-1' /> PM 歸檔
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

// =========================================================
// IV. 主 Layout 元件 (ProjectDetailProvider)
// =========================================================

export default function ProjectDetailLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const params = useParams();
  const projectId = params.projectId as CoreID;
  const pathname = usePathname();
  const router = useRouter();

  const {
    project,
    currentUser,
    loading,
    error,
    isPM,
    isRDL,
    isLocked,
    fetchProjectData,
    updateLocalProject,
  } = useProjectDetail(projectId);

  const isEditPage = pathname.endsWith("/edit");

  const currentTab = useMemo(() => {
    const parts = pathname.split("/");
    const lastPart = parts[parts.length - 1];
    if (lastPart === projectId) return "info";
    if (TABS.find((t) => t.path === lastPart)) return lastPart;
    return "info";
  }, [pathname, projectId]);

  const canManageMembersOrAttachments = useMemo(() => {
    return isPM || isRDL;
  }, [isPM, isRDL]);

  if (loading) {
    return (
      <div className='p-8 text-center text-gray-500 h-dvh bg-[#F5F7FA]'>
        <Loader2 className='animate-spin inline mr-2' size={24} />{" "}
        專案數據載入中...
      </div>
    );
  }

  if (error || !project || !currentUser) {
    return (
      <div className='p-8 text-center text-red-700 h-dvh bg-[#F5F7FA]'>
        <AlertTriangle className='inline mr-2' size={24} /> 錯誤:{" "}
        {error || "無法找到專案詳情或身份認證失敗"}
      </div>
    );
  }

  const contextValue: any = {
    project,
    currentUser,
    loading,
    error,
    isLocked,
    isPM,
    isRDL,
    canManageMembersOrAttachments,
    fetchProjectData,
    updateLocalProject,
  };

  return (
    <ProjectDetailContext.Provider value={contextValue}>
      <div className='p-8 h-full bg-[#F5F7FA]'>
        <div className='flex justify-between items-start mb-6'>
          <div className='space-y-1'>
            <Link
              href='/projects'
              className='text-sm text-blue-600 hover:text-blue-800 flex items-center space-x-1'>
              <ArrowLeft size={16} />
              <span>返回專案列表</span>
            </Link>
            <h1 className='text-3xl font-bold mt-2'>{project.projectName}</h1>
            <p className='text-gray-500'>專案ID: {project.projectID}</p>
          </div>

          {isPM && !isLocked && !isEditPage && (
            <button
              onClick={() => router.push(`/projects/${projectId}/edit`)}
              style={{backgroundColor: PM_COLOR}}
              className={`text-white font-bold py-2 px-4 text-sm flex items-center shadow-sm transition-colors rounded-[8px]`}>
              <Pencil size={18} className='mr-1' />
              編輯專案
            </button>
          )}
        </div>

        {!isEditPage && (
          <ProjectTimeline
            project={project}
            isPM={isPM}
            isRDL={isRDL}
            fetchProjectData={fetchProjectData}
            updateLocalProject={updateLocalProject}
          />
        )}

        {!isEditPage && (
          <div
            className='flex w-full border-b'
            style={{borderColor: INACTIVE_BORDER_COLOR}}>
            {TABS.map((tab) => {
              const href =
                tab.path === "info"
                  ? `/projects/${projectId}`
                  : `/projects/${projectId}/${tab.path}`;
              const isActive = currentTab === tab.path;

              let count = 0;
              if (tab.path === "attatchments")
                count = project.attachments?.length || 0;
              if (tab.path === "missions")
                count = project.missionSummary?.length || 0;

              if (tab.path === "members") count = 4;
              if (tab.path === "records") count = 8;

              const activeClasses = `
                                flex-1 bg-[${ACTIVE_TAB_COLOR}] text-white font-bold
                                z-10 
                            `;
              const inactiveClasses = `
                                flex-1 text-gray-600 bg-[#F5F7FA] hover:bg-white/50
                            `;

              return (
                <Link
                  key={tab.path}
                  href={href}
                  className={`
                                            px-4 py-3 text-sm 
                                            transition-colors flex items-center justify-center space-x-2
                                            rounded-t-[8px] cursor-pointer
                                            ${
                                              isActive
                                                ? activeClasses
                                                : inactiveClasses
                                            }
                                    `}
                  style={{
                    border: "1px solid transparent",
                    borderBottom: isActive ? "none" : "1px solid transparent",
                    paddingBottom: isActive ? "12px" : "11px",
                  }}>
                  <tab.icon size={16} className='mr-1' />
                  <span>
                    {tab.name} {count > 0 ? `(${count})` : ""}
                  </span>
                </Link>
              );
            })}
          </div>
        )}

        {isEditPage ? (
          <>{children}</>
        ) : (
          <div className='p-6 bg-white shadow-lg border border-gray-100 rounded-b-lg'>
            {children}
          </div>
        )}
      </div>
    </ProjectDetailContext.Provider>
  );
}
