// frontend\src\app\projects\[projectId]\edit\page.tsx

"use client";

import React, {useState, useEffect, useCallback, useMemo} from "react";

import {useRouter} from "next/navigation";

import {
  FileText,
  Users,
  Calendar,
  Paperclip,
  Loader2,
  AlertTriangle,
  Info,
  ChevronDown,
  Briefcase,
  X,
  Pencil, // 編輯按鈕圖示，雖然這裡沒用但保留常見圖示
  Trash2, // 刪除按鈕圖示
} from "lucide-react";

// 從 Context 導入核心 Hook 和 DTO 契約

import {
  useProjectDetailContext,
  PROJECT_STATE_IDS,
  ProjectObject,
  ProjectMemberObject,
  CoreID, // 確保 CoreID 可用
} from "../_hooks/ProjectDetailContext";

// 類型定義

interface AssignableUserObject {
  userID: CoreID;

  fullName: string;

  title: string;

  // ⭐ 確保 DTO 包含 roleID
  roleID: CoreID;
}

// 專案更新請求 DTO 契約

interface ProjectUpdateRequestPayload {
  projectName?: string;

  description?: string;

  startDate?: string;

  endDate?: string;

  projectTagID?: number | null;

  ownerUserID?: CoreID; // 必須使用 DTO 契約名稱

  rdlApprovedByUserID?: CoreID; // 必須使用 DTO 契約名稱

  rdUserIds?: CoreID[];

  qaUserIds?: CoreID[];
}

// =========================================================

// I. 常數與風格定義 (應用 NEW/Figma 風格)

// =========================================================

const PM_COLOR = "#4CAF50"; // PM 顏色 (綠色)

const BACKEND_URL =
  process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:4000";

const CARD_STYLE =
  "bg-white border border-[#E8E8E8] rounded-[8px] shadow-md p-6";

const INPUT_STYLE =
  "mt-1 block w-full rounded-[8px] border border-[#D9D9D9] shadow-sm p-2 text-sm focus:border-blue-500 focus:ring-blue-500";

const DISABLED_INPUT_STYLE =
  "mt-1 block w-full rounded-[8px] border border-[#D9D9D9] bg-[#F5F5F5] text-[#8C8C8C] p-2 text-sm cursor-not-allowed";

// 應用 NEW/Figma 的黃色提示框風格 (#FFBB00 背景, 白色文字, 8px 圓角)

const HINT_CLASS =
  "flex items-center space-x-2 p-3 rounded-[8px] bg-[#FFBB00] text-[#FFFFFF] text-sm mt-3";

// 保持紅色的警告風格，但應用 8px 圓角
const RED_WARNING_CLASS =
  "flex items-center space-x-2 p-3 rounded-[8px] bg-red-100 border border-red-400 text-red-700 text-sm mt-3";

const MODAL_OVERLAY_CLASS =
  "fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center";

// 標籤選項

const TAG_OPTIONS = [
  {id: 5, name: "優先"},

  {id: 1, name: "一般"},
];

/** 輔助函數：將 ISO 日期字串轉換為 YYYY-MM-DD 格式 (HTML Date Input 所需) */

const formatHtmlDate = (dateString: string | null): string => {
  if (!dateString) return "";

  try {
    return dateString.substring(0, 10);
  } catch {
    return "";
  }
};

// =========================================================

// 輔助元件：PM 轉讓 Modal
// =========================================================

interface PmTransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  candidates: AssignableUserObject[];
  currentOwnerId: CoreID;
  currentOwnerName: string;
  projectId: CoreID;
  onTransferSuccess: () => void;
}

const PmTransferModal: React.FC<PmTransferModalProps> = ({
  isOpen,
  onClose,
  candidates,
  currentOwnerId,
  currentOwnerName,
  projectId,
  onTransferSuccess,
}) => {
  const [selectedCandidateId, setSelectedCandidateId] = useState("");
  const [isTransferring, setIsTransferring] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const LOCAL_INPUT_STYLE =
    "mt-1 block w-full rounded-[8px] border border-[#D9D9D9] shadow-sm p-2 text-sm focus:border-blue-500 focus:ring-blue-500";

  const RED_WARNING_CLASS_MODAL =
    "flex items-center space-x-2 p-3 rounded-[8px] bg-[#FB495E] border border-red-400 text-white text-sm mt-3";

  const handleExecuteTransfer = async () => {
    if (!selectedCandidateId) {
      alert("請選擇一位新的專案經理。");
      return;
    }
    if (selectedCandidateId === currentOwnerId) {
      alert("您不能轉讓給自己，請選擇其他 PM/Admin。");
      return;
    }

    setIsTransferring(true);
    setError(null);
    const token = localStorage.getItem("token");

    const payload: ProjectUpdateRequestPayload = {
      ownerUserID: selectedCandidateId,
    };

    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/${projectId}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(payload),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        const code = errorData.code || response.status;
        const message = errorData.message || `PM 轉讓失敗。`;
        if (code === 50001) {
          setError(
            `【50001 PM_TRANSFER_FAILED】PM 轉讓原子交易失敗，已執行回滾。錯誤信息: ${message}`
          );
        } else {
          setError(`【${code}】${message}`);
        }
        throw new Error(message);
      }

      // 成功
      alert("專案經理已成功轉讓。");
      onTransferSuccess(); // 呼叫父層的成功回調 (例如跳轉)
      onClose(); // 關閉 Modal
    } catch (err: any) {
      // 錯誤已在 response.ok 檢查中設定
    } finally {
      setIsTransferring(false);
    }
  };

  const title = "專案經理轉讓確認";
  const subtitle = "請選擇要轉讓的專案經理，此操作將立即執行。";

  return (
    <div className={MODAL_OVERLAY_CLASS}>
      <div className='bg-white rounded-[8px] shadow-xl w-full max-w-md p-6'>
        {/* Header */}
        <div className='flex justify-between items-center border-b pb-3 mb-4'>
          <h3 className='text-xl font-semibold text-gray-800'>{title}</h3>
          <button
            onClick={onClose}
            className='text-gray-500 hover:text-gray-800'
            disabled={isTransferring}>
            <X size={24} />
          </button>
        </div>

        <p className='text-gray-600 text-sm mb-4'>{subtitle}</p>

        {/* Modal 內部的錯誤提示 */}
        {error && (
          <div className='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-[8px] relative mb-4 flex items-center shadow-sm'>
            <AlertTriangle size={20} className='mr-2' />
            {error}
          </div>
        )}

        {/* 警告框應用 8px 圓角 */}
        <div className={RED_WARNING_CLASS_MODAL}>
          <AlertTriangle size={18} className='mr-2' />
          警告：轉讓後您將不再是專案 PM (Owner)，無法再次編輯此專案。
        </div>

        {/* 資訊塊應用 8px 圓角 */}
        <div className='p-3 bg-[#E2E2E2] rounded-[8px] mt-4 mb-4 text-sm'>
          <p className='font-semibold'>當前 PM:</p>
          <p>
            {currentOwnerName} (ID: {currentOwnerId})
          </p>
        </div>

        <div className='space-y-4'>
          {/* 新 PM 選擇 */}
          <label className='block text-sm font-medium text-gray-700'>
            選擇新的專案經理 (PM 或 Admin 角色)
          </label>
          <div className='relative'>
            <select
              value={selectedCandidateId}
              onChange={(e) => setSelectedCandidateId(e.target.value)}
              className={LOCAL_INPUT_STYLE + " appearance-none cursor-pointer"}
              disabled={isTransferring}>
              <option value='' disabled>
                請從列表中選擇一位候選人
              </option>
              {candidates.length > 0 ? (
                candidates.map((user) => (
                  <option key={user.userID} value={user.userID}>
                    {user.fullName} ({user.title} | ID: {user.userID})
                  </option>
                ))
              ) : (
                <option disabled>無其他合格的 PM 或 Admin 可供選擇</option>
              )}
            </select>
            <ChevronDown
              size={16}
              className='absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 pointer-events-none'
            />
          </div>
        </div>

        {/* Footer */}
        <div className='mt-6 pt-4 border-t flex justify-end space-x-3'>
          <button
            type='button'
            onClick={onClose}
            className='bg-gray-100 border border-gray-300 text-gray-700 hover:bg-gray-200 px-4 py-2 rounded-[8px] text-sm'
            disabled={isTransferring}>
            取消
          </button>
          <button
            type='button'
            onClick={handleExecuteTransfer}
            disabled={
              !selectedCandidateId ||
              selectedCandidateId === currentOwnerId ||
              isTransferring
            }
            style={{backgroundColor: PM_COLOR}}
            className='text-white hover:bg-green-600 px-4 py-2 rounded-[8px] flex items-center shadow-md text-sm'>
            {isTransferring && (
              <Loader2 size={18} className='animate-spin mr-2' />
            )}
            確認轉讓
          </button>
        </div>
      </div>
    </div>
  );
};

// =========================================================

// 輔助元件：刪除專案 Modal (保持不變)

// =========================================================

interface DeleteProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  projectId: CoreID;
  projectName: string;
  onConfirm: () => void;
}

const DeleteProjectModal: React.FC<DeleteProjectModalProps> = ({
  isOpen,
  onClose,
  projectId,
  projectName,
  onConfirm,
}) => {
  if (!isOpen) return null;

  const DANGER_COLOR = "#FB495E"; // 危險操作色 [3]

  return (
    <div className={MODAL_OVERLAY_CLASS}>
      <div className='bg-white rounded-[8px] shadow-xl w-full max-w-lg p-6'>
        {/* Header */}
        <div className='flex justify-between items-center border-b pb-3 mb-4'>
          <h3 className='text-xl font-semibold text-red-700 flex items-center'>
            <AlertTriangle size={24} className='mr-2' /> 刪除專案確認
          </h3>
          <button
            onClick={onClose}
            className='text-gray-500 hover:text-gray-800'>
            <X size={24} />
          </button>
        </div>

        <p className='text-lg text-gray-700 mb-4'>
          確定要刪除專案編號：
          <span className='font-mono font-bold text-red-600'>
            {projectId}
          </span>{" "}
          專案名稱：
          <span className='font-bold text-red-600'>{projectName}</span>{" "}
          的專案嗎?
        </p>

        {/* 警告內容 */}
        <div className='p-4 bg-red-50 border border-red-400 rounded-[8px] mb-4'>
          <p className='text-red-700 font-semibold flex items-center'>
            <Info size={18} className='mr-2' />
            此動作無法復原！專案將被軟刪除，但會保留歷史紀錄。
          </p>
        </div>

        <p className='text-sm text-gray-500'>
          注意：此操作將觸發後端 `PROJECT_DELETED` 歷史紀錄寫入。
        </p>

        {/* Footer */}
        <div className='mt-6 pt-4 border-t flex justify-end space-x-3'>
          <button
            type='button'
            onClick={onClose}
            className='bg-gray-100 border border-gray-300 text-gray-700 hover:bg-gray-200 px-4 py-2 rounded-[8px] text-sm'>
            取消
          </button>
          <button
            type='button'
            onClick={onConfirm}
            style={{backgroundColor: DANGER_COLOR}}
            className='text-white hover:bg-red-700 px-4 py-2 rounded-[8px] flex items-center shadow-md text-sm'>
            <Trash2 size={18} className='mr-1' /> 確認刪除
          </button>
        </div>
      </div>
    </div>
  );
};

// =========================================================

// III. 主編輯頁面元件

// =========================================================

export default function EditProjectPage() {
  const router = useRouter();

  const {
    project,
    currentUser,
    loading: contextLoading,
    isLocked,
    isPM,
    fetchProjectData, // 引入用於數據刷新的函數
  } = useProjectDetailContext();

  // --- 內部狀態 ---
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState(
    {} as ProjectUpdateRequestPayload & {startDate: string; endDate: string}
  );
  const [initialProject, setInitialProject] = useState(
    null as ProjectObject | null
  );
  const [fieldErrors, setFieldErrors] = useState(
    {} as {[key: string]: string | null}
  );

  // PM Transfer State
  const [allAssignableUsers, setAllAssignableUsers] = useState<
    AssignableUserObject[]
  >([]);
  const [isPmTransferModalOpen, setIsPmTransferModalOpen] = useState(false);

  // ⭐ 刪除專案 Modal 狀態
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  // ---------------------------------------------
  // 契約檢查與輔助函數
  // ---------------------------------------------

  const isProjectStarted = project
    ? project.currentStateID > PROJECT_STATE_IDS.UNSTARTED // 10
    : false;

  // 判斷是否允許刪除：PM 且狀態為 Unstarted(10) 或 PendingReview(20) [1]
  const canSoftDelete =
    isPM &&
    project &&
    (project.currentStateID === PROJECT_STATE_IDS.UNSTARTED ||
      project.currentStateID === PROJECT_STATE_IDS.PendingReview);

  const currentTagName = useMemo(() => {
    const tagId = formData.projectTagID;
    const tag = TAG_OPTIONS.find((t) => t.id === tagId);
    return tag ? tag.name : "請選擇標籤";
  }, [formData.projectTagID]);

  // ---------------------------------------------
  // II. 數據載入與初始化
  // ---------------------------------------------

  const fetchAssignableUsers = useCallback(async (): Promise<
    AssignableUserObject[]
  > => {
    const token = localStorage.getItem("token");
    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/assignable`,
        {
          method: "GET",
          headers: {Authorization: `Bearer ${token}`},
        }
      );
      if (!response.ok) throw new Error(`無法獲取指派人員清單`);
      const result = await response.json();
      setAllAssignableUsers(result.data as AssignableUserObject[]);
      return result.data as AssignableUserObject[];
    } catch (error) {
      console.error(error);
      setError("無法載入指派人員清單。");
      return [];
    }
  }, []);

  const fetchCurrentMembers = useCallback(async (): Promise<
    ProjectMemberObject[]
  > => {
    // ... 此處省略獲取當前成員的邏輯，但保留函數結構
    return [];
  }, []);

  useEffect(() => {
    if (project && !initialProject) {
      // 專案數據初始化
      const initData = {
        projectName: project.projectName,
        description: project.description,
        startDate: formatHtmlDate(project.startDate),
        endDate: formatHtmlDate(project.endDate),
        projectTagID: project.projectTagID,
        ownerUserID: project.ownerUserID,
        rdlApprovedByUserID: project.rdlApprovedByUserID,
        rdMembers: [],
        qaMembers: [],
      };
      setFormData(initData);
      setInitialProject(project);

      // 載入可轉讓 PM 清單
      fetchAssignableUsers();
      fetchCurrentMembers();
    }
  }, [
    project,
    currentUser,
    initialProject,
    fetchAssignableUsers,
    fetchCurrentMembers,
  ]);

  // ---------------------------------------------
  // III. 篩選可指派人員列表 (僅保留 PM 轉讓所需)
  // ---------------------------------------------

  const PM_TRANSFER_CANDIDATES = useMemo(() => {
    const currentOwnerID = project?.ownerUserID;

    // ⭐⭐⭐ 修正：篩選邏輯改為依賴 roleID (1=Admin, 3=PM) ⭐⭐⭐
    const eligibleUsers = allAssignableUsers.filter(
      (u) => Number(u.roleID) === 3 || Number(u.roleID) === 1
    );

    // 排除當前 Owner (因為不能轉讓給自己)
    return eligibleUsers.filter((u) => u.userID !== currentOwnerID);
  }, [allAssignableUsers, project?.ownerUserID]);

  // ---------------------------------------------
  // IV. 表單處理函數與 Modal 控制
  // ---------------------------------------------

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const {name, value} = e.target;
    setFormData((prev) => ({...prev, [name]: value}));
    setFieldErrors((prev) => ({...prev, [name]: null}));
  };

  const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const {name, value} = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === "projectTagID" ? (value ? Number(value) : null) : value,
    }));
    setFieldErrors((prev) => ({...prev, [name]: null}));
  };

  const handlePmTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    setIsPmTransferModalOpen(true);
  };

  const handleTransferSuccess = () => {
    // 轉讓成功後，用戶權限可能已變更，導航回專案詳情頁
    router.push(`/projects/${project.projectID}`);
  };

  const handleCancelTransfer = () => {
    setIsPmTransferModalOpen(false);
  };

  // 專案刪除邏輯 (DELETE /api/v1/projects/{projectId})
  const handleDeleteProject = async () => {
    if (!project || !project.projectID) return;

    setShowDeleteModal(false); // 關閉警告 Modal
    setIsLoading(true);
    setError(null);

    const token = localStorage.getItem("token");

    try {
      // 執行 DELETE /api/v1/projects/{projectId} 軟刪除
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/${project.projectID}`,
        {
          method: "DELETE",
          headers: {Authorization: `Bearer ${token}`},
        }
      );

      if (response.status === 204) {
        // 成功軟刪除回傳 204 No Content
        alert(`專案 ${project.projectID} 已成功刪除 (軟刪除)。`);
        router.push("/projects"); // 導航回專案列表頁
      } else {
        const errorData = await response.json();
        const code = errorData.code || response.status;
        const message = errorData.message || `刪除失敗。`;

        if (code === 40901) {
          setError(`【40901 PROJECT_STATE_IMMUTABLE】專案已鎖定，禁止刪除。`);
        } else if (code === 40301) {
          setError(`【40301 PERMISSION_DENIED】您沒有權限刪除此專案。`);
        } else {
          setError(`刪除失敗：【${code}】${message}`);
        }
      }
    } catch (err: any) {
      setError("伺服器連線或處理錯誤。");
    } finally {
      setIsLoading(false);
    }
  };

  // 處理表單提交 (更新專案)
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!project || !initialProject) return;

    setIsLoading(true);
    setError(null);

    let hasCoreChanges = false;
    const token = localStorage.getItem("token");
    const initial = initialProject;

    // 檢查核心欄位是否有變動 (已移除 PM 轉讓檢查)
    if (
      formData.projectName !== initial.projectName ||
      formData.description !== initial.description ||
      formData.projectTagID !== initial.projectTagID ||
      formData.endDate !== formatHtmlDate(initial.endDate) ||
      formData.startDate !== formatHtmlDate(initial.startDate)
    ) {
      hasCoreChanges = true;
    }

    if (!hasCoreChanges) {
      setError("請至少修改一個核心欄位後再提交。");
      setIsLoading(false);
      return;
    }

    // ----------------------------------------------------
    // 階段一：更新專案核心數據 (PATCH)
    // ----------------------------------------------------

    const payload: ProjectUpdateRequestPayload = {
      projectName: formData.projectName,
      description: formData.description,
      startDate: formData.startDate,
      endDate: formData.endDate,
      projectTagID: formData.projectTagID,
    };

    let updateErrorMessage: string | null = null;

    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/${project.projectID}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(payload),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        const code = errorData.code || response.status;
        const message = errorData.message || `專案更新失敗。`;

        if (code === 40901) {
          updateErrorMessage = `【40901 PROJECT_STATE_IMMUTABLE】專案已鎖定，禁止修改。`;
        } else {
          updateErrorMessage = `【${code}】${message} (更新失敗)`;
        }
        throw new Error(message);
      }

      alert("專案已成功更新。");
      // 使用 window.location.href 強制瀏覽器重新載入，解決數據不新鮮問題
      window.location.href = `/projects/${project.projectID}`;
    } catch (err: any) {
      if (updateErrorMessage) {
        setError(updateErrorMessage);
      } else {
        setError("伺服器連線或處理錯誤。請檢查日誌。");
      }
    } finally {
      setIsLoading(false);
    }
  };

  if (
    contextLoading ||
    !project ||
    !formData.startDate ||
    allAssignableUsers.length === 0
  ) {
    return (
      <div className='text-center p-8 text-gray-500'>
        <Loader2 className='animate-spin inline mr-2' size={24} />
        載入專案數據與成員列表...
      </div>
    );
  }

  if (!isPM) {
    return (
      <div className='text-center p-8 text-red-700'>
        <AlertTriangle className='inline mr-2' size={24} />
        您沒有權限編輯此專案。編輯專案僅限 PM 執行。
      </div>
    );
  }

  return (
    <div className='space-y-6'>
      {/* 頂部標題區 - 遵循 NEW/Figma 風格，新增刪除按鈕 */}
      <div className='flex justify-between items-start'>
        <div className='space-y-1'>
          <h1 className='text-[24px] font-bold text-[#262626]'>編輯專案</h1>
          <p className='text-[14px] text-[#8C8C8C]'>管理和監控專案進度</p>
        </div>

        {/* 刪除專案按鈕 (最右側) */}
        {canSoftDelete && (
          <button
            onClick={() => setShowDeleteModal(true)}
            style={{backgroundColor: PM_COLOR}}
            disabled={isLoading}
            className={`hover:bg-green-600 text-white font-bold py-2 px-4 rounded-[8px] text-sm flex items-center shadow-sm transition-colors h-[40px]`}>
            <Trash2 size={18} className='mr-1' />
            刪除專案
          </button>
        )}
      </div>

      {/* 頂部全域錯誤提示區塊 */}
      {error && (
        <div className='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-[8px] relative mb-6 flex items-center shadow-sm'>
          <AlertTriangle size={20} className='mr-2' />
          <span className='block sm:inline'>{error}</span>
        </div>
      )}

      {/* P1 狀態鎖定提示 */}
      {isLocked && (
        <div className={RED_WARNING_CLASS}>
          <AlertTriangle size={20} className='mr-2' />
          專案已處於唯讀狀態 (已完成或已歸檔)，所有欄位已鎖定 (40901
          PROJECT_STATE_IMMUTABLE)。
        </div>
      )}

      <form onSubmit={handleSubmit} className='space-y-6'>
        {/* 1. 卡片一：基本資訊 (📇) */}
        <section className={CARD_STYLE}>
          <h2 className='text-[16px] font-bold mb-4 flex items-center space-x-3'>
            <div className='bg-[#F0F2F5] p-2 rounded-full'>
              <FileText size={16} className='text-[#262626]' />
            </div>
            <span>基本資訊</span>
          </h2>
          <p className='text-[12px] text-[#8C8C8C] mb-4'>
            填寫專案的基本詳細資訊
          </p>
          <div className='grid grid-cols-1 md:grid-cols-2 gap-6 mt-4'>
            {/* 專案 ID (不可修改) */}
            <div>
              <label className='block text-[12px] font-normal text-[#595959]'>
                專案ID(不可修改)
              </label>
              <input
                type='text'
                value={project.projectID}
                disabled
                className={DISABLED_INPUT_STYLE}
              />
            </div>
            {/* 專案名稱 (必填，可修改) */}
            <div>
              <label
                htmlFor='projectName'
                className='block text-[12px] font-normal text-[#595959]'>
                專案名稱(必填) <span className='text-red-500'>*</span>
              </label>
              <input
                type='text'
                id='projectName'
                name='projectName'
                value={formData.projectName || ""}
                onChange={handleChange}
                required
                className={isLocked ? DISABLED_INPUT_STYLE : INPUT_STYLE}
                disabled={isLocked}
              />
              {fieldErrors.projectName && (
                <p className='text-xs text-red-500 mt-1'>
                  {fieldErrors.projectName}
                </p>
              )}
            </div>
          </div>
          {/* 專案描述 (必填，可修改) */}
          <div className='mt-6'>
            <label
              htmlFor='description'
              className='block text-[12px] font-normal text-[#595959]'>
              專案描述(必填) <span className='text-red-500'>*</span>
            </label>
            <textarea
              id='description'
              name='description'
              rows={4}
              value={formData.description || ""}
              onChange={handleChange}
              required
              className={isLocked ? DISABLED_INPUT_STYLE : INPUT_STYLE}
              disabled={isLocked}
            />
            {fieldErrors.description && (
              <p className='text-xs text-red-500 mt-1'>
                {fieldErrors.description}
              </p>
            )}
          </div>
          {/* 標籤 (選填，可修改) */}
          <div className='mt-6'>
            <label
              htmlFor='projectTagID'
              className='block text-[12px] font-normal text-[#595959]'>
              標籤(選填)
            </label>
            <div className='relative'>
              <select
                id='projectTagID'
                name='projectTagID'
                onChange={handleSelectChange}
                value={formData.projectTagID || ""}
                className={`${
                  isLocked ? DISABLED_INPUT_STYLE : INPUT_STYLE
                } appearance-none cursor-pointer pr-8`}
                disabled={isLocked}>
                <option
                  value=''
                  disabled={formData.projectTagID !== null}
                  className='text-[#BFBFBF]'>
                  {formData.projectTagID === null
                    ? "請選擇標籤"
                    : currentTagName}
                </option>
                {TAG_OPTIONS.map((tag) => (
                  <option key={tag.id} value={tag.id}>
                    {tag.name}
                  </option>
                ))}
              </select>
              <ChevronDown
                size={16}
                className='absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 pointer-events-none'
              />
            </div>
          </div>
        </section>
        {/* 2. 卡片二：人員配置 (核心) */}
        <section className={CARD_STYLE}>
          <h2 className='text-[16px] font-bold mb-4 flex items-center space-x-3'>
            <div className='bg-[#F0F2F5] p-2 rounded-full'>
              <Users size={16} className='text-green-600' />
            </div>
            <span>人員配置 (核心)</span>
          </h2>
          <p className='text-[12px] text-[#8C8C8C] mb-4'>
            指定專案的 PM 和 RDL，成員管理請至「成員」分頁。
          </p>

          <div className='grid grid-cols-1 md:grid-cols-2 gap-6 mt-6'>
            {/* 專案經理 PM (唯讀欄位，顯示 FullName) */}
            <div>
              <label
                htmlFor='ownerUserID'
                className='block text-[12px] font-normal text-[#595959]'>
                專案經理_PM
              </label>
              <input
                type='text'
                value={project.ownerName}
                disabled
                className={DISABLED_INPUT_STYLE}
              />
              <p className='text-xs text-gray-500 mt-1'>
                當前 PM ID: {project.ownerUserID}
              </p>
              {/* 轉讓專案經理按鈕 - 觸發 Modal */}
              {!isLocked && (
                <button
                  type='button'
                  onClick={handlePmTransfer}
                  style={{backgroundColor: PM_COLOR}}
                  className={`hover:bg-green-600 text-white font-bold py-2 px-4 rounded-[8px] text-sm flex items-center shadow-sm transition-colors mt-2`}>
                  <Users size={18} className='mr-1' /> 轉讓專案經理
                </button>
              )}
            </div>
            {/* 研發主管 RDL (永久唯讀 - 狀態鎖定提示) */}
            <div>
              <label
                htmlFor='rdlUserId'
                className='block text-[12px] font-normal text-[#595959]'>
                研發主管_RDL (目前指派)
              </label>
              <input
                type='text'
                id='rdlUserId'
                name='rdlUserId'
                value={project.rdlApprovedByName || "未指派 (ID: N/A)"}
                disabled
                className={DISABLED_INPUT_STYLE}
              />
              {fieldErrors.rdlUserId && (
                <p className='text-xs text-red-500 mt-1'>
                  {fieldErrors.rdlUserId}
                </p>
              )}
              <div className={HINT_CLASS}>
                <Info size={16} className='mr-2 text-white' />
                RDL 欄位已鎖定，不允許透過此編輯頁面修改。
              </div>
            </div>
          </div>
          {/* RD & QA 成員提示 (已移除管理功能) */}
          <div className={HINT_CLASS}>
            <Info size={16} className='mr-2 text-white' />
            若要新增或移除 RD/QA 成員，請至專案詳情頁的「成員」分頁操作。
          </div>
        </section>
        {/* 3. 卡片三：時程資訊 (📅) */}
        <section className={CARD_STYLE}>
          <h2 className='text-[16px] font-bold mb-4 flex items-center space-x-3'>
            <div className='bg-[#F0F2F5] p-2 rounded-full'>
              <Calendar size={16} className='text-[#1AA1D9]' />
            </div>
            <span>時程資訊</span>
          </h2>
          <p className='text-[12px] text-[#8C8C8C] mb-4'>
            設定專案的開始與結束日期
          </p>
          <div className='p-3 bg-gray-100 rounded-[8px] mb-4 text-sm grid grid-cols-2 gap-4'>
            <div>
              <span className='block text-xs text-gray-600 font-semibold'>
                專案原開始日期 (唯讀)
              </span>
              <span className='font-mono'>
                {formatHtmlDate(project.startDate)}
              </span>
            </div>
            <div>
              <span className='block text-xs text-gray-600 font-semibold'>
                專案原預計結束日期 (唯讀)
              </span>
              <span className='font-mono'>
                {formatHtmlDate(project.endDate)}
              </span>
            </div>
          </div>
          <div className='grid grid-cols-1 md:grid-cols-2 gap-6'>
            {/* 開始日期 (不可修改契約) */}
            <div>
              <label
                htmlFor='startDate'
                className='block text-[12px] font-normal text-[#595959]'>
                開始日期(不可修改) <span className='text-red-500'>*</span>
              </label>
              <input
                type='date'
                id='startDate'
                name='startDate'
                value={formData.startDate || ""}
                onChange={handleChange}
                required
                disabled={isProjectStarted || isLocked}
                className={
                  isProjectStarted || isLocked
                    ? DISABLED_INPUT_STYLE
                    : INPUT_STYLE
                }
              />
              {fieldErrors.startDate && (
                <p className='text-xs text-red-500 mt-1'>
                  {fieldErrors.startDate}
                </p>
              )}
              {/* 開始日期鎖定提示 */}
              {(isProjectStarted || isLocked) && (
                <div className={HINT_CLASS}>
                  <Info size={16} className='mr-2 text-white' />
                  專案已開始或已鎖定，開始日期無法進行更改。
                </div>
              )}
            </div>
            {/* 結束日期 (必填，可修改) */}
            <div>
              <label
                htmlFor='endDate'
                className='block text-[12px] font-normal text-[#595959]'>
                新的結束日期(必填) <span className='text-red-500'>*</span>
              </label>
              <input
                type='date'
                id='endDate'
                name='endDate'
                value={formData.endDate || ""}
                onChange={handleChange}
                required
                disabled={isLocked}
                className={isLocked ? DISABLED_INPUT_STYLE : INPUT_STYLE}
              />
              {fieldErrors.endDate && (
                <p className='text-xs text-red-500 mt-1'>
                  {fieldErrors.endDate}
                </p>
              )}
              <p className='text-xs text-gray-500 mt-1'>
                請輸入專案最新的預計完成日期。
              </p>
            </div>
          </div>
        </section>
        {/* 4. 卡片四：附件 (📎) */}
        <section className={CARD_STYLE}>
          <h2 className='text-[16px] font-bold mb-4 flex items-center space-x-3'>
            <div className='bg-[#F0F2F5] p-2 rounded-full'>
              <Paperclip size={16} className='text-gray-500' />
            </div>
            <span>附件管理</span>
          </h2>
          <p className='text-[12px] text-[#8C8C8C] mb-4'>管理專案相關文件</p>
          <div className={HINT_CLASS}>
            <Info size={16} className='mr-2 text-white' />
            專案附件管理功能已移至專案詳情頁的「附件」分頁中。
          </div>
        </section>
      </form>

      {/* 底部操作欄 (Footer Action Bar) */}
      <div className='mt-8 pt-4 border-t border-gray-200 flex justify-end space-x-3 bg-[#F5F7FA]'>
        {/* 按鈕 1: 取消 */}
        <button
          type='button'
          onClick={() => router.push(`/projects/${project.projectID}`)}
          // 應用 8px 圓角
          className='bg-white border border-[#D9D9D9] text-[#262626] hover:bg-gray-50 px-4 py-2 rounded-[8px] text-sm h-[40px]'>
          取消
        </button>
        {/* 按鈕 2: 更新專案 (主要按鈕，藍色背景 #1890FF) */}
        <button
          type='submit'
          onClick={handleSubmit}
          // 應用主要按鈕契約和 8px 圓角
          className='btn-primary bg-[#1890FF] hover:bg-blue-700 text-white px-4 py-2 rounded-[8px] flex items-center shadow-md text-sm w-auto h-[40px]'
          disabled={isLoading || isLocked}>
          {isLoading && <Loader2 size={18} className='animate-spin mr-2' />}
          更新專案
        </button>
      </div>

      {/* PM 轉讓 Modal 元件 */}
      {isPmTransferModalOpen && project.ownerUserID && project.ownerName && (
        <PmTransferModal
          isOpen={isPmTransferModalOpen}
          onClose={handleCancelTransfer}
          candidates={PM_TRANSFER_CANDIDATES}
          currentOwnerId={project.ownerUserID}
          currentOwnerName={project.ownerName}
          projectId={project.projectID as CoreID}
          onTransferSuccess={handleTransferSuccess}
        />
      )}

      {/* 刪除專案 Modal 元件 */}
      {showDeleteModal && project && (
        <DeleteProjectModal
          isOpen={showDeleteModal}
          onClose={() => setShowDeleteModal(false)}
          projectId={project.projectID as CoreID}
          projectName={project.projectName}
          onConfirm={handleDeleteProject}
        />
      )}
    </div>
  );
}
