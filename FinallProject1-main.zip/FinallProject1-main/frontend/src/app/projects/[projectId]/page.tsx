// frontend/src/app/projects/[projectId]/page.tsx
"use client";

import React from "react";
import {
  useProjectDetailContext,
  getProjectStatusLabel,
  MissionSummary,
  ProjectObject,
} from "./_hooks/ProjectDetailContext";
import {
  FileText,
  Users,
  List,
  Calendar,
  CheckCircle,
  Clock,
  Briefcase,
} from "lucide-react";

// =========================================================
// I. 輔助元件與介面 (InfoGridItem)
// =========================================================

interface InfoGridItemProps {
  label: string;
  value: string;
  icon: React.ElementType;
  color?: string;
}

const InfoGridItem: React.FC<InfoGridItemProps> = ({
  icon: Icon,
  label,
  value,
  color = "text-gray-500",
}) => (
  // ⭐ 樣式調整：增加 min-height 確保在堆疊時高度一致
  <div className='bg-white p-4 border border-gray-100 rounded-[8px] shadow-sm min-h-[90px]'>
    <div className='flex items-center space-x-2 text-sm text-gray-500 mb-2'>
      <Icon size={16} className={color} />
      <span>{label}</span>
    </div>
    <p className='font-semibold text-gray-800 text-lg'>{value || "N/A"}</p>
  </div>
);

// =========================================================
// II. 輔助函數 (Mission 聚合計算 & 日期格式化)
// =========================================================

/**
 * 計算任務進度 (用於 Info Tab)
 */
const calculateMissionProgress = (missions: MissionSummary[] | undefined) => {
  const safeMissions = missions || [];
  const total = safeMissions.length;

  // C3 聚合驗證契約：Status 必須是 'Closed' 且 qaSignedByUserID 存在 [19]
  const qaAudited = safeMissions.filter(
    (m) => m.status === "Closed" && m.qaSignedByUserID
  ).length;
  const completed = safeMissions.filter((m) => m.status === "Closed").length;

  return {
    missionProgress: `${completed}/${total}`, // 任務數量 [12]
    qaVerification: `${qaAudited}/${total}`, // QA 驗證次數 [12]
  };
};

/**
 * ⭐ 新增：將 ISO 日期字串轉換為台灣時區的 YYYY年MM月DD日 格式
 * @param dateString ISO 格式的時間字串 (e.g., 2025-11-09T16:00:00.000Z)
 * @returns 格式化後的台灣時間字串 (e.g., 2025年11月10日)
 */
const formatTaiwanDate = (dateString: string | null): string => {
  if (!dateString) return "N/A"; // 或返回空字串 ""

  try {
    const date = new Date(dateString);

    // 檢查是否為無效日期
    if (isNaN(date.getTime())) {
      return "無效日期";
    }

    const options: Intl.DateTimeFormatOptions = {
      // 強制使用台灣時區
      timeZone: "Asia/Taipei",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    };

    // 使用 'zh-TW' (台灣中文) 地區設定來獲取 YYYY/MM/DD 格式
    const formattedDate = new Intl.DateTimeFormat("zh-TW", options).format(
      date
    );

    // 分割並重組為 "YYYY年MM月DD日"
    const [year, month, day] = formattedDate.split("/");

    return `${year}年${month}月${day}日`;
  } catch (error) {
    console.error("Date formatting error:", error);
    return dateString; // 格式化失敗時返回原始字串
  }
};

// =========================================================
// III. 主要頁面元件 (Info Page)
// = =========================================================

export default function ProjectInfoPage() {
  const {project, loading} = useProjectDetailContext();

  if (loading) return <div>載入中...</div>;
  if (!project) return <div>找不到專案詳情。</div>;

  const missions = project.missionSummary;
  const {missionProgress, qaVerification} = calculateMissionProgress(missions);

  // RDL 蓋章資訊判斷：根據 rdlApprovedByUserID 是否存在
  const isRdlApproved = !!project.rdlApprovedByUserID;

  return (
    <div className='space-y-6'>
      <h2 className='text-xl font-semibold mb-4 flex items-center space-x-2'>
        <FileText size={20} className='text-gray-600' />
        <span>專案基本資訊</span>
      </h2>
      <p className='text-gray-500 text-sm'>分頁內容_專案描述</p>

      {/* 描述框 */}
      <div className='p-4 bg-[#F5F5F5] rounded-[8px] border border-gray-200'>
        <p className='text-sm text-gray-700'>
          {project.description || "無描述"}
        </p>
      </div>

      {/* ⭐ 修正 1: 資訊格排版調整 (改為 1 欄，中等螢幕 3 欄) */}
      {/* 我們將 grid-cols-2 改為 grid-cols-1，並用內部 div 堆疊 */}
      <div className='grid grid-cols-1 md:grid-cols-3 gap-4'>
        {/* 第 1 欄: 專案經理 & 專案狀態 */}
        <div className='space-y-4'>
          <InfoGridItem
            label='專案經理'
            value={project.ownerName}
            icon={Users}
            color='text-green-600'
          />
          <InfoGridItem
            label='專案狀態'
            value={getProjectStatusLabel(project.currentStateID)}
            icon={Clock}
            color='text-orange-500'
          />
        </div>

        {/* 第 2 欄: 任務數量 & QA驗證 */}
        <div className='space-y-4'>
          <InfoGridItem
            label='任務數量'
            value={missionProgress}
            icon={List}
            color='text-blue-500'
          />
          <InfoGridItem
            label='QA驗證'
            value={qaVerification}
            icon={CheckCircle}
            color='text-blue-600'
          />
        </div>

        {/* 第 3 欄: 日期 */}
        <div className='space-y-4'>
          <InfoGridItem
            label='開始日期'
            // ⭐ 修正 2: 套用新日期格式
            value={formatTaiwanDate(project.startDate)}
            icon={Calendar}
            color='text-gray-500'
          />
          <InfoGridItem
            label='預計完成'
            // ⭐ 修正 2: 套用新日期格式
            value={formatTaiwanDate(project.endDate)}
            icon={Calendar}
            color='text-red-500'
          />
        </div>
      </div>

      {/* RDL 蓋章資訊 (如果已蓋章則顯示) */}
      {isRdlApproved && (
        <div className='mt-4 p-4 bg-[#FF9800] border border-[#91D5FF] rounded-[8px] text-sm text-[#FFFFFF]'>
          <div className='flex items-center space-x-2'>
            <Briefcase size={16} />
            <span className='font-medium'>RDL 已蓋章確認</span>
          </div>
          <p className='mt-1 text-xs'>
            驗證主管: {project.rdlApprovedByName || "N/A"} | 驗證時間:{" "}
            {/* ⭐ 修正 2: 套用新日期格式 */}
            {formatTaiwanDate(project.rdlApprovedAt)}
          </p>
        </div>
      )}
    </div>
  );
}
