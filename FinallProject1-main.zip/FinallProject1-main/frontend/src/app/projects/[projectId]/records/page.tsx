"use client";

// ⭐ 1. 導入 React Hooks
import React, {useMemo, useState, useEffect, useCallback} from "react";

import {
  useProjectDetailContext,
  useProjectHistory,
  getIconForType,
  HISTORY_CHANGE_TYPES,
  ProjectMemberObject,
  CoreID,
} from "../_hooks/ProjectDetailContext";

import {
  Clock,
  Loader2,
  User,
  Calendar,
  ArrowRight,
  AlertTriangle,
  FileText,
} from "lucide-react";

const BACKEND_URL =
  process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:4000";

// ⭐ 核心修正 1-A: 狀態 ID 到中文名稱的映射表 (根據來源 [3-5])
const PROJECT_STATE_ID_MAP: {[key: number]: string} = {
  10: "未開始", // UNSTARTED [6]
  20: "分析中", // PendingReview [6]
  30: "開發中", // Active [6]
  40: "審查中", // READY_FOR_CLOSURE [6]
  50: "待歸檔", // COMPLETED [7]
  60: "已歸檔", // ARCHIVED [7]
};

/**
 * 輔助函數：根據狀態 ID 獲取中文名稱
 */
const getStatusName = (id: string | number) => {
  const numId = typeof id === "string" ? parseInt(id, 10) : id;
  return PROJECT_STATE_ID_MAP[numId] || `狀態ID ${numId}`;
};

// ⭐ 核心修正 1-B: 變更類型中文化對照表 (根據來源 [8-12])
const HISTORY_LABELS: Record<keyof typeof HISTORY_CHANGE_TYPES, string> = {
  PROJECT_CREATED: "專案建立",
  PROJECT_DELETED: "專案軟刪除",
  PROJECT_NAME_UPDATE: "專案名稱更新",
  DESCRIPTION_UPDATE: "專案描述更新",
  DATE_UPDATE: "專案時程更新",
  STATE_TRANSITION: "專案狀態流轉",
  RDL_STAMP: "RDL 蓋章確認",
  PM_TRANSFER: "專案經理轉讓",
  ATTACHMENT_UPDATE: "附件變動",
  PROJECT_TAG_UPDATE: "專案標籤更新",
  PROJECT_PROJECTMEMBERS_UPDATE: "專案成員變動",
};

// 輔助函數：根據 HISTORY_CHANGE_TYPES 獲取中文標籤
const getChangeTypeLabel = (
  type: keyof typeof HISTORY_CHANGE_TYPES
): string => {
  return HISTORY_LABELS[type] || type.replace(/_/g, " ");
};

// 建立 Role ID 查找表 (來自來源 [13-15])
const ROLE_ID_TO_NAME_MAP: {[key: string]: string} = {
  "1": "Admin (系統管理員)",
  "3": "專案經理 (PM)",
  "4": "研發主管 (RDL)",
  "5": "開發人員 (RD)",
  "6": "品保工程師 (QA)",
};

/**
 * 輔助函數：格式化歷史紀錄中的值 (用於 OldValue/NewValue)
 */
const formatHistoryValue = (value: string | null): string => {
  if (!value) return "N/A";

  // 檢查值是否是 Role ID
  if (ROLE_ID_TO_NAME_MAP[value]) {
    return `${ROLE_ID_TO_NAME_MAP[value]} (ID: ${value})`;
  }

  return value;
};

// 輔助類型：用於緩存 UserID -> FullName 的映射
interface UserMap {
  [userId: string]: string;
}

export default function RecordsPage() {
  const {project} = useProjectDetailContext();

  // 呼叫獨立 Hook 獲取歷史紀錄列表 (API 擴展 4)
  const {history, loading, error} = useProjectHistory(
    project?.projectID || "0",
    "records"
  );

  // 狀態/緩存邏輯
  const [fetchedUserMap, setFetchedUserMap] = useState<UserMap>({});
  const [pendingFetchIds, setPendingFetchIds] = useState<CoreID[]>([]);

  // 建立「目前」成員的查找 Map (Fast Path)
  const currentMemberMap = useMemo(() => {
    const members: ProjectMemberObject[] = (project as any)?.members || [];
    return new Map(members.map((member) => [member.userID, member.fullName]));
  }, [project]);

  // 增強 useEffect，抓取所有相關 User ID
  useEffect(() => {
    if (history.length === 0) return;

    // 1. 收集所有需要名稱的 ID (操作者 + OldValue/NewValue 中可能包含的 User ID)
    const allRelevantIds = new Set<CoreID>();
    history.forEach((record) => {
      // 抓取操作者 ID
      if (record.changedByUserID) {
        allRelevantIds.add(record.changedByUserID);
      }
      // 抓取 PM_TRANSFER 和 PROJECT_PROJECTMEMBERS_UPDATE 的 Old/New Value (User ID)
      if (
        record.changeType === HISTORY_CHANGE_TYPES.PM_TRANSFER ||
        record.changeType === HISTORY_CHANGE_TYPES.PROJECT_PROJECTMEMBERS_UPDATE
      ) {
        if (record.oldValue) allRelevantIds.add(record.oldValue);
        if (record.newValue) allRelevantIds.add(record.newValue);
      }
    });

    // 2. 過濾已緩存、已在成員列表或正在抓取的 ID
    const idsToFetch = Array.from(allRelevantIds).filter(
      (id) =>
        !currentMemberMap.has(id) &&
        !fetchedUserMap[id] &&
        !pendingFetchIds.includes(id)
    );

    if (idsToFetch.length === 0) return;

    setPendingFetchIds((prev) => [...prev, ...idsToFetch]);

    const token = localStorage.getItem("token");
    const getAuthHeaders = (token: string) => ({
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    });

    const fetchUserNames = async () => {
      const newUserMap: UserMap = {};
      const fetchPromises = idsToFetch.map(async (userId) => {
        // API 契約：GET /api/users/:id
        try {
          const response = await fetch(`${BACKEND_URL}/api/users/${userId}`, {
            method: "GET",
            headers: getAuthHeaders(token || ""),
          });

          if (response.ok) {
            const result = await response.json();
            newUserMap[userId] = result.user.FullName || `用戶 ID: ${userId}`;
          } else {
            newUserMap[userId] = `未知用戶 (${userId})`;
          }
        } catch (error) {
          newUserMap[userId] = `錯誤 (${userId})`;
        }
      });

      await Promise.all(fetchPromises);

      setFetchedUserMap((prevMap) => ({
        ...prevMap,
        ...newUserMap,
      }));

      // 清理 pending 狀態
      setPendingFetchIds((prevPending) =>
        prevPending.filter((id) => !idsToFetch.includes(id))
      );
    };

    fetchUserNames();
  }, [
    history,
    currentMemberMap,
    fetchedUserMap,
    pendingFetchIds,
    BACKEND_URL,
    project,
  ]);

  /**
   * 輔助函數：獲取人名 (用於 Goal 1 - 操作者)
   */
  const getUserDisplay = (record: any): string => {
    const userId = record.changedByUserID;
    if (!userId) {
      if (record.changeType === HISTORY_CHANGE_TYPES.PROJECT_CREATED)
        return "系統";
      return "系統/未知操作者";
    }

    // 1. 從目前成員 Map 找 (Fast)
    const currentName = currentMemberMap.get(userId);
    if (currentName) return `${currentName}`;

    // 2. 從已抓取 Map 找 (Slow)
    const fetchedName = fetchedUserMap[userId];
    if (fetchedName) return `${fetchedName}`;

    // 3. 檢查是否正在抓取
    if (pendingFetchIds.includes(userId)) return `載入中...`;

    // 4. Fallback: 使用 DTO 中的名稱
    if (record.changedByUserName && record.changedByUserName !== userId) {
      return `${record.changedByUserName}`;
    }

    return `未知用戶 (${userId})`;
  };

  /**
   * ⭐ 核心修正 2: 格式化 Detail 內容，轉換狀態 ID 和成員 ID 為名稱
   */
  const formatDetailContent = (record: any): string => {
    const type = record.changeType as keyof typeof HISTORY_CHANGE_TYPES;
    let detail = record.detail || "無詳細描述";

    // 案例 A: 狀態轉換 (10 -> 20) - 將 ID 轉為中文名稱
    if (type === HISTORY_CHANGE_TYPES.STATE_TRANSITION) {
      const oldId = record.oldValue;
      const newId = record.newValue;

      // 使用 OldValue/NewValue 重建字串
      if (oldId && newId) {
        return `專案狀態從 ${getStatusName(oldId)} 流轉到 ${getStatusName(
          newId
        )}。`;
      }
    }

    // ⭐ 案例 B: 專案經理轉讓 (PM_TRANSFER) - 核心修復點
    if (type === HISTORY_CHANGE_TYPES.PM_TRANSFER) {
      const oldPmId = record.oldValue;
      const newPmId = record.newValue;

      // 使用已緩存的人名，若無則顯示 ID (待載入)
      const oldPmName = fetchedUserMap[oldPmId] || oldPmId;
      const newPmName = fetchedUserMap[newPmId] || newPmId;

      return `專案經理角色由 ${oldPmName} 轉讓給 ${newPmName}。`;
    }

    // 案例 C: 成員變動 (PROJECT_PROJECTMEMBERS_UPDATE)
    if (type === HISTORY_CHANGE_TYPES.PROJECT_PROJECTMEMBERS_UPDATE) {
      // 1. 處理移除成員
      if (record.oldValue && !record.newValue) {
        const memberId = record.oldValue;
        const memberName = fetchedUserMap[memberId] || `ID: ${memberId}`;
        return `從專案中移除了成員 ${memberName}。`;
      }

      // 2. 處理新增成員
      if (record.newValue && !record.oldValue) {
        const memberId = record.newValue;
        const memberName = fetchedUserMap[memberId] || `ID: ${memberId}`;
        return `新增成員 ${memberName} 至專案。`;
      }
    }

    // 案例 D: RDL 蓋章確認 (RDL_STAMP)
    if (type === HISTORY_CHANGE_TYPES.RDL_STAMP) {
      return "RDL 對專案執行最終蓋章確認，專案進入待歸檔狀態。";
    }

    // 案例 E: 附件變動 (ATTACHMENT_UPDATE)
    if (type === HISTORY_CHANGE_TYPES.ATTACHMENT_UPDATE) {
      if (record.newValue === null && record.oldValue) {
        // 假設 OldValue 包含刪除的附件名稱 (如後端歷史紀錄契約 [16])
        const match = record.oldValue.match(/"fileName":"(.+?)"/);
        const fileName = match ? match[17] : "未知附件";
        return `軟刪除了附件：${fileName}。`;
      }
    }

    // 預設返回原始 Detail
    return detail;
  };

  // --- 載入與錯誤狀態 ---
  if (loading)
    return (
      <div className='text-center p-8 text-gray-500'>
        <Loader2 className='animate-spin inline mr-2' /> 載入歷史記錄...
      </div>
    );

  if (error)
    return (
      <div className='text-center p-8 text-red-700'>
        歷史記錄載入失敗: {error}
      </div>
    );

  // --- 主要內容渲染 ---
  return (
    <div className='space-y-6'>
      <h2 className='text-xl font-semibold mb-4 flex items-center space-x-2'>
        <Clock size={20} className='text-gray-600' />
        <span>歷史紀錄 ({history.length})</span>
      </h2>

      <p className='text-gray-500 text-sm mb-4'>
        專案的所有變更紀錄 (共追蹤 {Object.keys(HISTORY_CHANGE_TYPES).length}{" "}
        種變動類型)。
      </p>

      <div className='space-y-4'>
        {history.length === 0 ? (
          <p className='text-gray-500 p-4 bg-[#F5F5F5] rounded-md'>
            此專案目前沒有歷史記錄。
          </p>
        ) : (
          history.map((record, index) => (
            <div key={index} className='flex space-x-4'>
              {/* 左側圖示：根據 ChangeType 顯示 */}
              <div className='pt-1'>{getIconForType(record.changeType)}</div>

              {/* 右側內容：時間軸樣式 */}
              <div className='flex-1 border-l pl-4 border-gray-200'>
                <h3 className='font-semibold text-base text-gray-800 mb-1'>
                  {/* 應用中文化標籤 */}
                  {getChangeTypeLabel(record.changeType)}
                </h3>

                {/* 詳情描述 (Detail) - 應用動態格式化 */}
                <p className='text-sm text-gray-700 mb-2'>
                  {formatDetailContent(record)}
                </p>

                {/* 舊值與新值 (用於追蹤欄位變更) */}
                {(record.oldValue || record.newValue) && (
                  <div className='text-xs mt-1 p-2 bg-gray-50 rounded'>
                    {record.oldValue && (
                      <p>
                        舊值 (OldValue):{" "}
                        <span className='font-mono'>
                          {/* 應用 Role ID 轉換 */}
                          {formatHistoryValue(record.oldValue)}
                        </span>
                      </p>
                    )}
                    {record.newValue && (
                      <p>
                        新值 (NewValue):{" "}
                        <span className='font-mono'>
                          {/* 應用 Role ID 轉換 */}
                          {formatHistoryValue(record.newValue)}
                        </span>
                      </p>
                    )}
                  </div>
                )}

                {/* 資訊行：操作者與日期 */}
                <div className='flex items-center space-x-3 text-xs text-gray-500 mt-2'>
                  <div className='flex items-center space-x-1'>
                    <User size={12} className='text-blue-500' />
                    <span>操作者: {getUserDisplay(record)}</span>
                  </div>

                  <div className='flex items-center space-x-1'>
                    <Calendar size={12} className='text-gray-400' />
                    <span>
                      紀錄日期:{" "}
                      {new Date(record.changedAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
