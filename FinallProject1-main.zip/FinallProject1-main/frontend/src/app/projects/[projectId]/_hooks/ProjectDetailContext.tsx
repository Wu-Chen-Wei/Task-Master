// frontend/src/app/projects/[projectId]/_hooks/ProjectDetailContext.ts
"use client";

import React from "react"; // <--- 確保這一行存在，用於定義 JSX 命名空間

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
} from "react";
import {
  Loader2,
  ArrowRight,
  Users,
  Briefcase,
  Paperclip,
  User,
  CheckCircle,
  AlertCircle,
  Clock,
  FileText,
} from "lucide-react";

// =========================================================
// I. 數據契約 (DTOs) 和常數 (Foundation)
// =========================================================

type CoreID = string; // ID 類型契約：所有 ID 在 JSON 傳輸中必須是 string [15]

// 環境與風格常數
const BACKEND_URL =
  process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:4000";
const HINT_CLASS =
  "flex items-center space-x-2 p-3 rounded-[8px] bg-[#FFFBE6] border border-[#FFE58F] text-[#595959] text-sm mt-3";

export const ROLE_COLORS: {[key: string]: string} = {
  PM: "#4CAF50",
  RDL: "#FF9800",
  RD: "#D32F2F",
  QA: "#2196F3",
  Default: "#8C8C8C",
};

export const PROJECT_STATE_IDS = {
  UNSTARTED: 10,
  PendingReview: 20,
  Active: 30,
  READY_FOR_CLOSURE: 40,
  COMPLETED: 50,
  ARCHIVED: 60,
} as const;

export const HISTORY_CHANGE_TYPES = {
  PROJECT_CREATED: "PROJECT_CREATED",
  PROJECT_DELETED: "PROJECT_DELETED",
  PROJECT_NAME_UPDATE: "PROJECT_NAME_UPDATE",
  DESCRIPTION_UPDATE: "DESCRIPTION_UPDATE",
  DATE_UPDATE: "DATE_UPDATE",
  STATE_TRANSITION: "STATE_TRANSITION",
  RDL_STAMP: "RDL_STAMP",
  PM_TRANSFER: "PM_TRANSFER",
  ATTACHMENT_UPDATE: "ATTACHMENT_UPDATE",
  PROJECT_TAG_UPDATE: "PROJECT_TAG_UPDATE",
  PROJECT_PROJECTMEMBERS_UPDATE: "PROJECT_PROJECTMEMBERS_UPDATE",
};

// 專案核心 DTO [3]
export interface ProjectObject {
  projectID?: CoreID;
  projectName: string;
  description: string;
  ownerUserID: CoreID;
  ownerName: string;
  startDate: string;
  endDate: string;
  currentStateID: number;
  rdlApprovedByUserID: CoreID | null;
  rdlApprovedByName?: string;
  rdlApprovedAt: string | null;
  projectTagID: number | null;
  attachments?: AttachmentObject[];
  missionSummary?: MissionSummary[];
}

// 附件 DTO [16]
export interface AttachmentObject {
  attachmentID: CoreID;
  projectID: CoreID;
  fileName: string;
  filePath: string;
  uploadedByUserID: CoreID;
  uploadedAt: string;
}

// 任務摘要 DTO [15]
export interface MissionSummary {
  missionID: CoreID;
  title: string;
  description: string;
  status: "Open" | "In Progress" | "Testing" | "Reopened" | "Closed";
  assigneeID: CoreID | null;
  qaSignedByUserID: CoreID | null;
  dueDate: string;
}

// 當前使用者資訊
export interface CurrentUser {
  userID: CoreID;
  Roles: string[];
  fullName: string;
}

// API 擴展 2: 成員 DTO [4]
export interface ProjectMemberObject {
  userID: CoreID;
  fullName: string;
  roleID: number;
  roleName: string;
  joinedAt: string;
}

// API 擴展 4: 歷史記錄 DTO [5]
export interface ProjectHistoryObject {
  historyID: CoreID;
  changedByUserID: CoreID;
  changedByUserName: string;
  changeType: keyof typeof HISTORY_CHANGE_TYPES;
  detail: string | null;
  oldValue: string | null;
  newValue: string | null;
  changedAt: string;
}

// =========================================================
// II. Context Interface & Hook
// =========================================================

interface ProjectDetailContextType {
  project: ProjectObject | null;
  currentUser: CurrentUser | null;
  loading: boolean;
  error: string | null;
  isLocked: boolean; // P1 鎖定契約 [8]
  isPM: boolean;
  isRDL: boolean;
  canManageMembersOrAttachments: boolean; // P6 權限 [10]
  fetchProjectData: () => Promise<void>;
}

// 創建 Context 物件
export const ProjectDetailContext = createContext<
  ProjectDetailContextType | undefined
>(undefined);

// Context Hook (Consumer) - 解決 Context 錯誤的核心
export const useProjectDetailContext = (): ProjectDetailContextType => {
  const context = useContext(ProjectDetailContext);
  if (context === undefined) {
    // 嚴格拋出錯誤，通知開發者 Hook 位於 Provider 外部
    throw new Error(
      "useProjectDetailContext 必須在 ProjectDetailProvider 內部使用 (位於 [projectId]/layout.tsx 中)"
    );
  }
  return context;
};

// =========================================================
// III. 輔助函數 (Utility Functions)
// =========================================================

const getAuthHeaders = (token: string) => ({
  "Content-Type": "application/json",
  Authorization: `Bearer ${token}`,
});

export const getProjectStatusLabel = (id: number): string => {
  const options = [
    {name: "未開始", id: 10},
    {name: "分析中", id: 20},
    {name: "開發中", id: 30},
    {name: "審查中", id: 40},
    {name: "待歸檔", id: 50},
    {name: "已歸檔", id: 60},
  ];
  const option = options.find((opt) => opt.id === id);
  return option ? option.name : "未知狀態";
};

// --- 輔助函數：任務狀態標籤樣式 ---
export const getMissionStatusProps = (status: MissionSummary["status"]) => {
  switch (status) {
    case "Closed":
      return {label: "已完成", color: "bg-green-500"};
    case "In Progress":
      return {label: "進行中", color: "bg-blue-500"};
    case "Testing":
      return {label: "審核中", color: "bg-yellow-500"};
    case "Reopened":
      return {label: "已退回", color: "bg-red-500"};
    case "Open":
    default:
      return {label: "未開始", color: "bg-gray-400"};
  }
};

/**
 * 輔助函數：根據歷史類型決定圖示
 */
export const getIconForType = (
  type: keyof typeof HISTORY_CHANGE_TYPES
): JSX.Element => {
  switch (type) {
    case HISTORY_CHANGE_TYPES.STATE_TRANSITION:
    case HISTORY_CHANGE_TYPES.PROJECT_DELETED: // 雖然 PROJECT_DELETED 邏輯上不使用，但保留
      return <ArrowRight size={18} className='text-blue-500' />;
    case HISTORY_CHANGE_TYPES.PM_TRANSFER:
    case HISTORY_CHANGE_TYPES.PROJECT_PROJECTMEMBERS_UPDATE:
      return <Users size={18} className='text-purple-500' />;
    case HISTORY_CHANGE_TYPES.RDL_STAMP:
      return <Briefcase size={18} className='text-orange-500' />;
    case HISTORY_CHANGE_TYPES.ATTACHMENT_UPDATE:
      return <Paperclip size={18} className='text-gray-500' />;
    default:
      return <User size={18} className='text-gray-500' />;
  }
};

// =========================================================
// IV. 獨立 API 擴展 Hook (Tab 4: Members, Tab 5: Records)
// =========================================================

/**
 * Hook 實作 API 擴展 2：獲取專案成員清單 (GET /api/v1/projects/:projectId/members) [6]
 */
export const useProjectMembers = (projectId: CoreID, currentTab: string) => {
  const [members, setMembers] = useState<ProjectMemberObject[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchMembers = useCallback(async () => {
    const token = localStorage.getItem("token");
    if (!projectId || currentTab !== "members" || !token) {
      setMembers([]);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/${projectId}/members`, // API 擴展 2
        {headers: getAuthHeaders(token)}
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          errorData.message || `成員清單獲取失敗 (HTTP ${response.status})`
        );
      }
      const result = await response.json();
      setMembers(result.data as ProjectMemberObject[]);
    } catch (err: any) {
      setError(err.message || "成員數據載入失敗");
    } finally {
      setLoading(false);
    }
  }, [projectId, currentTab]);

  useEffect(() => {
    fetchMembers();
  }, [fetchMembers]);

  return {members, loading, error};
};

/**
 * Hook 實作 API 擴展 4：獲取專案歷史記錄清單 (GET /api/v1/projects/:projectId/history) [6]
 */
export const useProjectHistory = (projectId: CoreID, currentTab: string) => {
  const [history, setHistory] = useState<ProjectHistoryObject[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchHistory = useCallback(async () => {
    const token = localStorage.getItem("token");
    if (!projectId || currentTab !== "records" || !token) {
      setHistory([]);
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/${projectId}/history`, // API 擴展 4
        {headers: getAuthHeaders(token)}
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          errorData.message || `歷史記錄獲取失敗 (HTTP ${response.status})`
        );
      }
      const result = await response.json();
      setHistory(result.data as ProjectHistoryObject[]);
    } catch (err: any) {
      setError(err.message || "歷史記錄載入失敗");
    } finally {
      setLoading(false);
    }
  }, [projectId, currentTab]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  return {history, loading, error};
};
