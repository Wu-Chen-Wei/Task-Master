"use client";

import React, {useState, useEffect, useCallback} from "react";

import {useRouter} from "next/navigation";

import {
  FileText,
  Users,
  Calendar,
  Paperclip,
  Loader2,
  AlertTriangle,
  Info,
  ChevronDown,
  Calendar as CalendarIcon, // 修正名稱衝突
} from "lucide-react";

// 契約定義
type CoreID = string;

// 後端 Assignable User DTO 契約
interface AssignableUser {
  userID: CoreID;
  fullName: string;
  title: string;
}

// 專案建立請求 DTO 契約
interface ProjectCreationRequest {
  projectName: string;
  description: string;
  startDate: string;
  endDate: string;
  projectTagID: number | null;
  ownerUserID: CoreID;
  rdlUserId: CoreID;
  rdUserIds: CoreID[];
  qaUserIds: CoreID[];
}

// 當前使用者資訊介面
interface CurrentUser {
  userID: CoreID;
  email: string;
  title: string;
  fullName: string;
  Roles: string[];
}

// 固定數據與風格
const MOCK_PROJECT_ID: string = "PROH0002"; // 專案 ID 佔位符
const BACKEND_URL =
  process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:4000";

const CARD_STYLE =
  "bg-white border border-[#E8E8E8] rounded-[8px] shadow-md p-6";
const INPUT_STYLE =
  "mt-1 block w-full rounded-[8px] border border-[#D9D9D9] shadow-sm p-2 text-sm focus:border-blue-500 focus:ring-blue-500";
const HINT_CLASS =
  "flex items-center space-x-2 p-3 rounded-[8px] bg-[#FFFBE6] border border-[#FFE58F] text-[#595959] text-sm mt-3";

// 標籤選項
const TAG_OPTIONS = [
  {id: 5, name: "優先"},
  {id: 1, name: "一般"},
];

// 自動帶入資料常數
const AUTO_FILL_DATA = {
  projectName: "Parking 會員系統",
  description:
    "開發一套整合車牌識別與線上支付的停車場會員管理系統，目標在 12 週內完成基本功能並上線測試。",
  startDate: "2024-10-01",
  endDate: "2024-11-26",
  projectTagID: 5 as number | null,
  rdlUserId: "RDL001_Tom" as CoreID,
  rdUserIds: [] as CoreID[],
  qaUserIds: [] as CoreID[],
};

export default function NewProjectPage() {
  const router = useRouter();

  // --- 狀態定義 ---
  const [currentUser, setCurrentUser] = useState<CurrentUser | null>(null);
  const [userLoading, setUserLoading] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);

  // 可指派使用者清單 (從 API 獲取真實數據)
  const [allAssignableUsers, setAllAssignableUsers] = useState<
    AssignableUser[]
  >([]);
  const [usersLoading, setUsersLoading] = useState(false);

  const [formData, setFormData] = useState({
    projectName: "",
    description: "",
    startDate: "",
    endDate: "",
    projectTagID: null as number | null,
    ownerUserID: "" as CoreID,
    rdlUserId: "" as CoreID,
    rdUserIds: [] as CoreID[],
    qaUserIds: [] as CoreID[],
  });

  // --- API 交互邏輯 ---
  const fetchCurrentUser = useCallback(async () => {
    setUserLoading(true);
    const token = localStorage.getItem("token");
    if (!token) {
      setError("請先登入，認證 Token 不存在。");
      setUserLoading(false);
      return;
    }

    try {
      const response = await fetch(`${BACKEND_URL}/api/auth/me`, {
        method: "GET",
        headers: {Authorization: `Bearer ${token}`},
      });
      if (!response.ok) throw new Error("無法獲取使用者資訊");

      const result = await response.json();
      // 處理 CurrentUser 結構 (來自 Source: project.types.tsx 和 member的程式碼)
      const fetchedUser: CurrentUser = {
        userID: String(result.user.UserID),
        email: result.user.Email,
        title: result.user.Title || "",
        fullName: result.user.FullName,
        Roles: result.user.Roles || [],
      };
      setCurrentUser(fetchedUser);

      setFormData((prev) => ({...prev, ownerUserID: fetchedUser.userID}));
    } catch (error: any) {
      setError("無法取得使用者身份資訊。請檢查網路連線或登入狀態。");
    } finally {
      setUserLoading(false);
    }
  }, []);

  const fetchAssignableUsers = useCallback(async () => {
    setUsersLoading(true);
    const token = localStorage.getItem("token");
    try {
      const response = await fetch(
        `${BACKEND_URL}/api/v1/projects/assignable`,
        {
          method: "GET",
          headers: {Authorization: `Bearer ${token}`},
        }
      );
      if (!response.ok) throw new Error("無法獲取指派人員清單");

      const result = await response.json();
      setAllAssignableUsers(result.data as AssignableUser[]);
    } catch (error: any) {
      console.error("獲取可指派人員錯誤:", error);
      setError("無法載入專案指派人員列表。");
    } finally {
      setUsersLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCurrentUser();
    fetchAssignableUsers();
  }, [fetchCurrentUser, fetchAssignableUsers]);

  // --- 表單處理邏輯 ---

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const {name, value} = e.target;
    setFormData((prev) => ({...prev, [name]: value}));
  };

  const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const {name, value} = e.target;
    if (name === "rdlUserId") {
      setFormData((prev) => ({...prev, [name]: value as CoreID}));
    } else {
      setFormData((prev) => ({...prev, [name]: value ? Number(value) : null}));
    }
  };

  // 處理多選 Select (RD/QA)
  const handleMultiSelectChange = (
    e: React.ChangeEvent<HTMLSelectElement>,
    name: "rdUserIds" | "qaUserIds"
  ) => {
    const selectedOptions = Array.from(
      e.target.selectedOptions,
      (option) => option.value as CoreID
    );
    setFormData((prev) => ({...prev, [name]: selectedOptions}));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setSelectedFiles(e.target.files);
    }
  };

  // 自動帶入資料函數
  const handleAutoFill = () => {
    setFormData((prev) => ({
      ...prev,
      ...AUTO_FILL_DATA,
      ownerUserID: prev.ownerUserID,
    }));
    setError(null);
    alert("已自動填入 Parking 會員系統 專案資料。成員配置請手動填寫 RDL ID。");
  };

  const handleReset = () => {
    setFormData((prev) => ({
      ...prev,
      projectName: "",
      description: "",
      startDate: "",
      endDate: "",
      projectTagID: null,
      ownerUserID: currentUser?.userID || "",
      rdlUserId: "",
      rdUserIds: [],
      qaUserIds: [],
    }));
    setSelectedFiles(null);
    setError(null);
  };

  // --- 輔助函數：執行附件上傳 (第二階段) ---
  const uploadAttachments = async (
    projectId: CoreID,
    files: FileList,
    token: string
  ) => {
    if (files.length === 0) return true;

    const formData = new FormData();
    formData.append("projectId", projectId);

    Array.from(files).forEach((file) => {
      formData.append("files", file);
    });

    try {
      const response = await fetch(`${BACKEND_URL}/api/v1/attachments`, {
        method: "POST",
        headers: {
          // Multer 上傳不需要 Content-Type
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        const code = errorData.code || response.status;
        const message = errorData.message || `附件上傳失敗。`;
        // P6 權限不足可能導致 40301 錯誤 [1]
        throw new Error(`附件上傳失敗：【${code}】${message}`);
      }
      // 成功響應契約是 201 Created [1]
      return true;
    } catch (error) {
      throw error;
    }
  };

  // --- 實作表單提交邏輯 ---

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setIsLoading(true);
    setError(null);

    // 前端簡易驗證 (必填欄位)
    if (
      !formData.projectName ||
      !formData.description ||
      !formData.startDate ||
      !formData.endDate ||
      !formData.rdlUserId
    ) {
      // 預期後端拋出 40001 VALIDATION_FAILED [2, 3]
      setError("【40001 VALIDATION_FAILED】請填寫所有必填欄位。");
      setIsLoading(false);
      return;
    }

    if (new Date(formData.startDate) > new Date(formData.endDate)) {
      setError("【40001 VALIDATION_FAILED】開始日期不得晚於結束日期。");
      setIsLoading(false);
      return;
    }

    if (!formData.ownerUserID) {
      setError("PM 身份資訊尚未載入，無法建立專案。");
      setIsLoading(false);
      return;
    }

    const token = localStorage.getItem("token");

    // 轉換為後端 ProjectCreationRequest 契約
    const payload: ProjectCreationRequest = {
      projectName: formData.projectName,
      description: formData.description,
      startDate: formData.startDate,
      endDate: formData.endDate,
      projectTagID: formData.projectTagID,
      ownerUserID: formData.ownerUserID,
      rdlUserId: formData.rdlUserId,
      rdUserIds: formData.rdUserIds,
      qaUserIds: formData.qaUserIds,
    };

    let newProjectID: CoreID | undefined;

    try {
      // 階段一：建立專案 (POST /api/v1/projects)
      const projectResponse = await fetch(`${BACKEND_URL}/api/v1/projects`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!projectResponse.ok) {
        const errorData = await projectResponse.json();
        const code = errorData.code || projectResponse.status;
        const message = errorData.message || `專案建立失敗。`;
        // 檢查 RDL 權限或必填欄位失敗預期 40001 [4, 5]
        setError(`【${code}】${message} (檢查 RDL 權限或必填欄位)`);
        throw new Error(message);
      }

      const result = await projectResponse.json();
      newProjectID = result.data.projectID as CoreID; // 獲取新專案的 CoreID

      // 階段二：上傳附件 (POST /api/v1/attachments)
      if (selectedFiles && selectedFiles.length > 0) {
        await uploadAttachments(newProjectID, selectedFiles, token!);
      }

      // 兩階段全部成功，導航回列表
      router.push("/projects");
    } catch (err: any) {
      if (newProjectID && selectedFiles && selectedFiles.length > 0) {
        console.error("附件上傳失敗:", err);
        setError(
          `專案 ${newProjectID} 已成功建立，但附件上傳失敗。錯誤信息: ${err.message}。請進入編輯頁面手動上傳。`
        );
      } else if (!error) {
        setError(err.message || "伺服器連線或處理錯誤。");
      }
    } finally {
      setIsLoading(false);
    }
  };

  // 載入中狀態
  if (userLoading || usersLoading) {
    return (
      <div className='p-8 text-xl text-gray-500 flex items-center justify-center h-screen'>
        <Loader2 className='animate-spin mr-2' size={24} />
        正在載入使用者和指派人員清單...
      </div>
    );
  }

  const pmDisplayName = currentUser?.fullName || "未知用戶";
  const pmDisplayTitle = currentUser?.title || "未授權";

  // 依角色過濾可指派人員
  const RDL_TITLES = [
    "RDL",
    "研發主管",
    "RD Leader",
    "Admin",
    "System Administrator",
  ];

  const RDL_USERS = allAssignableUsers.filter((u) =>
    RDL_TITLES.some((role) => u.title.includes(role))
  );

  const RD_USERS = allAssignableUsers.filter(
    (u) =>
      (u.title.includes("RD") ||
        u.title.includes("Developer") ||
        u.title.includes("工程師")) &&
      !RDL_USERS.includes(u as AssignableUser)
  );

  const QA_USERS = allAssignableUsers.filter(
    (u) =>
      u.title.includes("QA") ||
      u.title.includes("品質保證") ||
      u.title.includes("Tester")
  );

  // 底部按鈕樣式
  const primaryBtnClass =
    "bg-[#1890FF] hover:bg-blue-700 text-white px-4 py-2 rounded-[8px] flex items-center shadow-md text-sm w-auto h-[40px]";
  const secondaryBtnClass =
    "bg-white border border-[#D9D9D9] text-[#262626] hover:bg-gray-50 px-4 py-2 rounded-[8px] text-sm h-[40px]";

  return (
    <div className='bg-[#F5F7FA] min-h-screen p-8'>
      <div className='max-w-[1072px] mx-auto'>
        <h1 className='text-[24px] font-bold text-[#262626]'>新增專案</h1>
        <p className='text-[14px] text-[#8C8C8C] mb-6'>管理和監控專案進度</p>

        {/* 錯誤提示區塊 */}
        {error && (
          <div className='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6 flex items-center shadow-sm'>
            <AlertTriangle size={20} className='mr-2' />
            <span className='block sm:inline'>{error}</span>
          </div>
        )}

        {/* 自動帶入資料按鈕區塊 */}
        <div className='flex justify-end mb-4'>
          <button
            type='button'
            onClick={handleAutoFill}
            className='bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-md flex items-center shadow-sm text-sm'
            disabled={isLoading}>
            <Info size={18} className='mr-2' />
            自動帶入資料 (Parking 會員系統)
          </button>
        </div>

        <form className='space-y-6' onSubmit={handleSubmit}>
          {/* 1. 卡片一：基本資訊 (📇) */}
          <section className={CARD_STYLE}>
            <h2 className='text-[16px] font-bold mb-4 flex items-center space-x-3'>
              <div className='bg-[#F0F2F5] p-2 rounded-full'>
                <FileText size={16} className='text-[#262626]' />
              </div>
              <span>基本資訊</span>
            </h2>

            <p className='text-[12px] text-[#8C8C8C] mb-4'>
              填寫專案的基本詳細資訊
            </p>

            <div className='grid grid-cols-1 md:grid-cols-2 gap-6 mt-4'>
              {/* 專案 ID (自動生成) */}
              <div>
                <label className='block text-[12px] font-normal text-[#595959]'>
                  專案ID(自動生成)
                </label>
                <input
                  type='text'
                  value={MOCK_PROJECT_ID}
                  disabled
                  className='mt-1 block w-full rounded-[8px] border border-[#D9D9D9] bg-[#F5F5F5] text-[#BFBFBF] p-2 text-sm cursor-not-allowed'
                />
              </div>

              {/* 專案名稱 (必填) */}
              <div>
                <label
                  htmlFor='projectName'
                  className='block text-[12px] font-normal text-[#595959]'>
                  專案名稱(必填) <span className='text-red-500'>*</span>
                </label>
                <input
                  type='text'
                  id='projectName'
                  name='projectName'
                  value={formData.projectName}
                  onChange={handleChange}
                  required
                  className={INPUT_STYLE}
                />
              </div>
            </div>

            {/* 專案描述 (必填) */}
            <div className='mt-6'>
              <label
                htmlFor='description'
                className='block text-[12px] font-normal text-[#595959]'>
                專案描述(必填) <span className='text-red-500'>*</span>
              </label>
              <textarea
                id='description'
                name='description'
                rows={4}
                value={formData.description}
                onChange={handleChange}
                required
                className={INPUT_STYLE}
              />
            </div>

            {/* 標籤 (選填) */}
            <div className='mt-6'>
              <label
                htmlFor='projectTagID'
                className='block text-[12px] font-normal text-[#595959]'>
                標籤(選填)
              </label>
              <div className='relative'>
                <select
                  id='projectTagID'
                  name='projectTagID'
                  onChange={handleSelectChange}
                  value={formData.projectTagID || ""}
                  className={`${INPUT_STYLE} appearance-none cursor-pointer pr-8`}>
                  <option
                    value=''
                    disabled={formData.projectTagID !== null}
                    className='text-[#BFBFBF]'>
                    請選擇標籤
                  </option>
                  {TAG_OPTIONS.map((tag) => (
                    <option key={tag.id} value={tag.id}>
                      {tag.name}
                    </option>
                  ))}
                </select>
                <ChevronDown
                  size={16}
                  className='absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 pointer-events-none'
                />
              </div>
            </div>
          </section>

          {/* 2. 卡片二：人員配置 (👥) */}
          <section className={CARD_STYLE}>
            <h2 className='text-[16px] font-bold mb-2 flex items-center space-x-3'>
              <div className='bg-[#F0F2F5] p-2 rounded-full'>
                <Users size={16} className='text-green-600' />
              </div>
              <span>人員配置</span>
            </h2>
            <p className='text-[12px] text-[#8C8C8C] mb-4'>
              指定專案的負責人員
            </p>

            <div className={HINT_CLASS}>
              <div className='bg-white rounded-full'>
                <Info size={16} className='text-yellow-700' />
              </div>
              <span>本帳會自動帶入專案創建者</span>
            </div>

            <div className='grid grid-cols-1 md:grid-cols-2 gap-6 mt-6'>
              {/* 專案經理 PM (動態帶入創建者) */}
              <div>
                <label
                  htmlFor='ownerUserID'
                  className='block text-[12px] font-normal text-[#595959]'>
                  專案經理_PM
                </label>
                <input
                  type='text'
                  id='ownerUserID'
                  name='ownerUserID'
                  value={pmDisplayName}
                  disabled
                  className='mt-1 block w-full rounded-[8px] border border-[#D9D9D9] bg-[#F5F5F5] text-[#262626] p-2 text-sm cursor-not-allowed'
                />
                <p className='text-xs text-gray-500 mt-1'>
                  職位: {pmDisplayTitle} | 傳輸 ID: {formData.ownerUserID}
                </p>
              </div>

              {/* 研發主管 RDL (必填) - 使用真實姓名下拉選單 */}
              <div>
                <label
                  htmlFor='rdlUserId'
                  className='block text-[12px] font-normal text-[#595959]'>
                  研發主管_RDL(必填) <span className='text-red-500'>*</span>
                </label>
                <div className='relative'>
                  <select
                    id='rdlUserId'
                    name='rdlUserId'
                    onChange={handleSelectChange}
                    value={formData.rdlUserId}
                    required
                    className={`${INPUT_STYLE} appearance-none cursor-pointer pr-8`}>
                    <option value='' className='text-[#BFBFBF]'>
                      請選擇研發主管
                    </option>
                    {RDL_USERS.map((user) => (
                      <option key={user.userID} value={user.userID}>
                        {user.fullName} ({user.title})
                      </option>
                    ))}
                  </select>
                  <ChevronDown
                    size={16}
                    className='absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 pointer-events-none'
                  />
                </div>
                <p className='text-xs text-gray-500 mt-1'>
                  後端將執行縱深防禦契約：驗證 RDL (ID: 4) 或 Admin (ID: 1)
                  角色。
                </p>
              </div>
            </div>

            {/* RD & QA 配置 (多選) - 使用真實姓名下拉選單 */}
            <div className='grid grid-cols-1 md:grid-cols-2 gap-6 mt-6'>
              {/* 研發工程師 RD (選填) - 使用多選 Select */}
              <div>
                <label
                  htmlFor='rdUserIds'
                  className='block text-[12px] font-normal text-[#595959]'>
                  研發工程師_RD(選填)
                </label>
                <div className='relative'>
                  <select
                    id='rdUserIds'
                    name='rdUserIds'
                    multiple
                    size={3}
                    onChange={(e) => handleMultiSelectChange(e, "rdUserIds")}
                    value={formData.rdUserIds}
                    className={`${INPUT_STYLE} h-auto cursor-pointer`}>
                    {RD_USERS.map((user) => (
                      <option key={user.userID} value={user.userID}>
                        {user.fullName} ({user.title})
                      </option>
                    ))}
                  </select>
                </div>
                <p className='text-xs text-gray-500 mt-1'>
                  按住 Ctrl/Cmd 可多選成員。
                </p>
              </div>

              {/* 品質保證 QA (選填) - 使用多選 Select */}
              <div>
                <label
                  htmlFor='qaUserIds'
                  className='block text-[12px] font-normal text-[#595959]'>
                  品質保證 QA (選填)
                </label>
                <div className='relative'>
                  <select
                    id='qaUserIds'
                    name='qaUserIds'
                    multiple
                    size={3}
                    onChange={(e) => handleMultiSelectChange(e, "qaUserIds")}
                    value={formData.qaUserIds}
                    className={`${INPUT_STYLE} h-auto cursor-pointer`}>
                    {QA_USERS.map((user) => (
                      <option key={user.userID} value={user.userID}>
                        {user.fullName} ({user.title})
                      </option>
                    ))}
                  </select>
                </div>
                <p className='text-xs text-gray-500 mt-1'>
                  按住 Ctrl/Cmd 可多選成員。
                </p>
              </div>
            </div>
          </section>

          {/* 3. 卡片三：時程資訊 (📅) */}
          <section className={CARD_STYLE}>
            <h2 className='text-[16px] font-bold mb-2 flex items-center space-x-3'>
              <div className='bg-[#F0F2F5] p-2 rounded-full'>
                <Calendar size={16} className='text-[#1AA1D9]' />
              </div>
              <span>時程資訊</span>
            </h2>
            <p className='text-[12px] text-[#8C8C8C] mb-4'>
              設定專案的開始與結束日期
            </p>

            <div className='grid grid-cols-1 md:grid-cols-2 gap-6'>
              {/* 開始日期 (必填) */}
              <div>
                <label
                  htmlFor='startDate'
                  className='block text-[12px] font-normal text-[#595959]'>
                  開始日期(必填) <span className='text-red-500'>*</span>
                </label>
                <div className='relative'>
                  <CalendarIcon
                    size={16}
                    className='absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none'
                  />
                  <input
                    type='date'
                    id='startDate'
                    name='startDate'
                    value={formData.startDate}
                    onChange={handleChange}
                    required
                    placeholder='YYYY/MM/DD'
                    className={`${INPUT_STYLE} pl-10`}
                  />
                </div>
              </div>

              {/* 結束日期 (必填) */}
              <div>
                <label
                  htmlFor='endDate'
                  className='block text-[12px] font-normal text-[#595959]'>
                  結束日期(必填) <span className='text-red-500'>*</span>
                </label>
                {/* ⭐ 修正點: 修正 JSX 屬性錯誤 */}
                <div className='relative'>
                  <CalendarIcon
                    size={16}
                    className='absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none'
                  />
                  <input
                    type='date'
                    id='endDate'
                    name='endDate'
                    value={formData.endDate}
                    onChange={handleChange}
                    required
                    placeholder='YYYY/MM/DD'
                    className={`${INPUT_STYLE} pl-10`}
                  />
                </div>
                <p className='text-xs text-gray-500 mt-1'>
                  後端將檢查結束日期是否大於開始日期。
                </p>
              </div>
            </div>
          </section>

          {/* 4. 卡片四：附件 (📎) */}
          <section className={CARD_STYLE}>
            <h2 className='text-[16px] font-bold mb-4 flex items-center space-x-3'>
              <div className='bg-[#F0F2F5] p-2 rounded-full'>
                <Paperclip size={16} className='text-gray-500' />
              </div>
              <span>附件</span>
            </h2>

            <p className='text-[12px] text-[#8C8C8C] mb-4'>
              選填專案的相關文件
            </p>

            {/* 提示欄位 */}
            <div className={HINT_CLASS}>
              <div className='bg-white rounded-full'>
                <Info size={16} className='text-yellow-700' />
              </div>
              <span>上傳者將自動記錄為當前使用者</span>
            </div>
            <div className={`${HINT_CLASS} mb-6`}>
              <div className='bg-white rounded-full'>
                <Info size={16} className='text-yellow-700' />
              </div>
              <span>上傳時間將自動記錄為當前時間</span>
            </div>

            <div>
              <label className='block text-[12px] font-normal text-[#595959]'>
                選擇檔案
              </label>
              <div className='mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-[#D9D9D9] border-dashed rounded-md bg-[#FAFAFA] hover:bg-gray-100 transition-colors cursor-pointer'>
                <div className='space-y-1 text-center'>
                  <Paperclip
                    size={28}
                    className='mx-auto h-8 w-8 text-gray-400'
                  />
                  <div className='flex text-sm text-gray-600 justify-center'>
                    <label
                      htmlFor='file-upload'
                      className='relative cursor-pointer rounded-md bg-transparent font-normal text-[#1890FF] hover:text-blue-800 focus-within:outline-none'>
                      <span>點擊此處來選擇檔案</span>
                      <input
                        id='file-upload'
                        name='files'
                        type='file'
                        className='sr-only'
                        multiple
                        onChange={handleFileChange}
                        disabled={isLoading}
                      />
                    </label>
                  </div>
                  <p className='text-sm text-[#8C8C8C]'>
                    (支援PDF,DOC,XLS,PNG,JPG等格式)
                  </p>
                </div>
              </div>
            </div>

            {/* 顯示已選擇的檔案列表 */}
            {selectedFiles && selectedFiles.length > 0 && (
              <div className='mt-3 p-3 border rounded-md bg-white'>
                <p className='text-xs font-semibold text-[#595959] mb-2'>
                  已選擇 ({selectedFiles.length}) 個檔案:
                </p>
                <ul className='space-y-1'>
                  {Array.from(selectedFiles).map((file, index) => (
                    <li
                      key={index}
                      className='text-xs text-gray-700 truncate flex items-center'>
                      <Paperclip size={12} className='mr-1 text-[#1890FF]' />
                      {file.name} ({Math.round(file.size / 1024)} KB)
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </section>
        </form>

        {/* 底部操作欄 (Footer) - 自然流動 */}
        <div className='mt-8 pt-4 border-t border-gray-200 flex justify-end space-x-3'>
          {/* 按鈕 1: 重置表單 */}
          <button
            type='button'
            onClick={handleReset}
            className={secondaryBtnClass}
            disabled={isLoading}>
            重置表單
          </button>

          {/* 按鈕 2: 取消 */}
          <button
            type='button'
            onClick={() => router.push("/projects")}
            className={secondaryBtnClass}>
            取消
          </button>

          {/* 按鈕 3: 建立專案 (主要按鈕) */}
          <button
            type='button'
            onClick={handleSubmit}
            className={primaryBtnClass}
            disabled={isLoading || userLoading || !currentUser}>
            {isLoading && <Loader2 size={18} className='animate-spin mr-2' />}
            <span>建立專案</span>
          </button>
        </div>
      </div>
    </div>
  );
}
