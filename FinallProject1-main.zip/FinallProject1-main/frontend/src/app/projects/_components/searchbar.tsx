// frontend\src\app\projects\_components\Searchbar.tsx

"use client";

import React, {useState, useEffect} from "react";
import {Search, ChevronDown, Loader2} from "lucide-react";
import {ProjectFilters, PROJECT_STATE_OPTIONS} from "../_types/project.types";

interface SearchbarProps {
  updateUrlFilters: (newFilters: Partial<ProjectFilters>) => void;
  initialSearchTerm: string;
  initialStatusId: number;
  loading: boolean;
}

/**
 * Searchbar 元件，實現文字搜尋和狀態篩選。
 */
export default function Searchbar({
  updateUrlFilters,
  initialSearchTerm,
  initialStatusId,
  loading,
}: SearchbarProps) {
  const [searchTerm, setSearchTerm] = useState(initialSearchTerm);
  const [statusId, setStatusId] = useState(initialStatusId);

  // 確保在 URL 變動時同步內部狀態
  useEffect(() => {
    setSearchTerm(initialSearchTerm);
    setStatusId(initialStatusId);
  }, [initialSearchTerm, initialStatusId]);

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value);
  };

  const handleStatusChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const newStatusId = parseInt(event.target.value);
    setStatusId(newStatusId);

    // 實作狀態篩選契約：傳輸 PROJECT_STATE_IDS 數值
    updateUrlFilters({
      status: newStatusId > 0 ? newStatusId : undefined,
      page: 1, // 任何篩選變動都重設頁碼
    });
  };

  const handleApplyFilters = () => {
    updateUrlFilters({search: searchTerm, page: 1});
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter") {
      handleApplyFilters();
    }
  };

  return (
    <div className='flex space-x-4 mb-6'>
      {/* 搜尋框 */}
      <div className='flex items-center w-full max-w-lg bg-white border border-gray-300 rounded-lg shadow-sm h-10'>
        <input
          type='text'
          placeholder='搜尋專案名稱、描述或負責人...'
          className='grow h-full px-4 text-sm focus:outline-none rounded-l-lg disabled:bg-gray-50'
          value={searchTerm}
          onChange={handleSearchChange}
          onKeyDown={handleKeyDown}
          disabled={loading}
        />
        <button
          onClick={handleApplyFilters}
          className='bg-[#1AA1D9] hover:bg-[#114574] text-white p-2 rounded-r-lg h-full transition-colors flex items-center justify-center w-12 disabled:bg-gray-400'
          disabled={loading}>
          {loading ? (
            <Loader2 size={18} className='animate-spin' />
          ) : (
            <Search size={18} />
          )}
        </button>
      </div>

      {/* 狀態篩選下拉選單 */}
      <div className='relative flex items-center bg-white border border-gray-300 rounded-lg shadow-sm h-10'>
        <select
          value={statusId}
          onChange={handleStatusChange}
          className='h-full w-40 appearance-none bg-transparent pl-3 pr-8 text-sm cursor-pointer focus:outline-none disabled:bg-gray-50'
          disabled={loading}>
          {PROJECT_STATE_OPTIONS.map((option) => (
            <option key={option.id} value={option.id}>
              {option.name}
            </option>
          ))}
        </select>
        <ChevronDown
          size={16}
          className='absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 pointer-events-none'
        />
      </div>
    </div>
  );
}
