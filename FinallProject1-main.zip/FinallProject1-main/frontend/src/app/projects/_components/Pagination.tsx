// frontend\src\app\projects\_components\Pagination.tsx

import React from "react";
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
} from "lucide-react";
import {PaginationMeta} from "../_types/project.types";

const MAX_PAGES_DISPLAYED = 5;

export interface PaginationProps {
  meta: PaginationMeta;
  onPageChange: (page: number) => void;
}

/**
 * 分頁元件，負責顯示頁碼並處理頁碼變動。
 */
export default function Pagination({meta, onPageChange}: PaginationProps) {
  const {totalProjects, totalPages, currentPage} = meta;

  if (totalPages <= 1) return null;

  const getPageRange = () => {
    let startPage: number, endPage: number;
    if (totalPages <= MAX_PAGES_DISPLAYED) {
      startPage = 1;
      endPage = totalPages;
    } else {
      const maxPagesBeforeCurrentPage = Math.floor(MAX_PAGES_DISPLAYED / 2);
      const maxPagesAfterCurrentPage = Math.ceil(MAX_PAGES_DISPLAYED / 2) - 1;

      if (currentPage <= maxPagesBeforeCurrentPage) {
        startPage = 1;
        endPage = MAX_PAGES_DISPLAYED;
      } else if (currentPage + maxPagesAfterCurrentPage >= totalPages) {
        startPage = totalPages - MAX_PAGES_DISPLAYED + 1;
        endPage = totalPages;
      } else {
        startPage = currentPage - maxPagesBeforeCurrentPage;
        endPage = currentPage + maxPagesAfterCurrentPage;
      }
    }
    return Array.from(Array(endPage + 1 - startPage).keys()).map(
      (i) => startPage + i
    );
  };
  const pages = getPageRange();

  // 分頁基礎樣式 (不使用 .btn-primary)
  const baseClasses =
    "h-10 w-10 flex items-center justify-center rounded-lg transition-colors";
  const defaultClasses = "text-gray-600 hover:bg-gray-100";
  const activeClasses = "bg-[#1AA1D9] text-white";
  const disabledClasses = "text-gray-300 cursor-not-allowed";

  return (
    <div className='mt-8 flex justify-center items-center space-x-1'>
      <span className='text-sm text-gray-600 mr-4'>
        共 {totalProjects} 筆 | 第 {currentPage} / {totalPages} 頁
      </span>

      {/* 第一頁按鈕 */}
      <button
        onClick={() => onPageChange(1)}
        disabled={currentPage === 1}
        className={`${baseClasses} ${
          currentPage === 1 ? disabledClasses : defaultClasses
        }`}
        title='第一頁'>
        <ChevronsLeft size={18} />
      </button>

      {/* 上一頁按鈕 */}
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className={`${baseClasses} ${
          currentPage === 1 ? disabledClasses : defaultClasses
        }`}>
        <ChevronLeft size={18} />
      </button>

      {/* 頁碼按鈕 */}
      {pages.map((page) => (
        <button
          key={page}
          onClick={() => onPageChange(page)}
          className={`${baseClasses} ${
            page === currentPage ? activeClasses : defaultClasses
          }`}>
          {page}
        </button>
      ))}

      {/* 下一頁按鈕 */}
      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className={`${baseClasses} ${
          currentPage === totalPages ? disabledClasses : defaultClasses
        }`}>
        <ChevronRight size={18} />
      </button>

      {/* 最後一頁按鈕 */}
      <button
        onClick={() => onPageChange(totalPages)}
        disabled={currentPage === totalPages}
        className={`${baseClasses} ${
          currentPage === totalPages ? disabledClasses : defaultClasses
        }`}
        title='最後一頁'>
        <ChevronsRight size={18} />
      </button>
    </div>
  );
}
