// frontend\src\app\projects\_components\Buttonbar.tsx

"use client";

import React from "react";
import {Briefcase, User, AlertCircle, Plus} from "lucide-react";
import {useRouter} from "next/navigation";
import {
  QuickFilterMode,
  URGENT_TAG_ID,
  ProjectFilters,
} from "../_types/project.types";
import "../../globals.css";

export interface ButtonbarProps {
  isPM: boolean;
  currentMode: QuickFilterMode;
  updateUrlFilters: (newFilters: Partial<ProjectFilters>) => void;
}

export default function Buttonbar({
  isPM,
  currentMode,
  updateUrlFilters,
}: ButtonbarProps) {
  const router = useRouter();

  const handleFilterChange = (mode: QuickFilterMode) => {
    let newFilters: Partial<ProjectFilters> = {
      page: 1,
      tagId: undefined,
      search: undefined,
      status: undefined,
    };

    if (mode === "URGENT") {
      newFilters.tagId = URGENT_TAG_ID;
    }

    updateUrlFilters({
      ...newFilters,
      mode: mode,
    });
  };

  // 輔助函式：根據當前模式決定按鈕樣式
  const getButtonClass = (mode: QuickFilterMode) => {
    // 應用 .btn-primary 的核心契約，但覆寫寬度 (w-auto px-4)
    const base =
      "btn-primary flex items-center justify-center transition-colors duration-150  h-[40px] p-2 text-sm font-medium shadow-sm w-auto px-4";

    // 活躍狀態：使用主色調 #114574
    const active = `${base} bg-[#114574] text-white hover:bg-[#114574]`;

    // 非活躍狀態：使用非主要色
    const inactive = `${base} bg-gray-100 text-gray-700 hover:bg-gray-200`;

    return currentMode === mode ? active : inactive;
  };

  // 新增專案按鈕樣式 (應用 PM 顏色 #4CAF50)
  const newProjectBtnClass =
    "w-[131px] h-[40px] p-2 rounded-[8px] text-white text-[17px] bg-[#4CAF50] hover:bg-[#114574] cursor-pointer transition duration-150 ease-in-out flex items-center justify-center transition-colors duration-150 text-sm font-medium shadow-sm";

  return (
    <div className='flex justify-between '>
      {/* 左側：快速篩選按鈕組 */}
      <div className='flex gap-3'>
        {/* 1. 全部專案：僅 PM/Admin 可見 */}
        {isPM && (
          <button
            className={getButtonClass("ALL")}
            onClick={() => handleFilterChange("ALL")}>
            <div className='flex items-center space-x-2'>
              <Briefcase size={18} />
              <span>全部專案</span>
            </div>
          </button>
        )}

        {/* 2. 我的專案 (所有人預設) */}
        <button
          className={getButtonClass("MINE")}
          onClick={() => handleFilterChange("MINE")}>
          <div className='flex items-center space-x-2'>
            <User size={18} />
            <span>我的專案</span>
          </div>
        </button>

        {/* 3. 優先處理 */}
        <button
          className={getButtonClass("URGENT")}
          onClick={() => handleFilterChange("URGENT")}>
          <div className='flex items-center space-x-2'>
            <AlertCircle size={18} />
            <span>優先處理</span>
          </div>
        </button>

        {isPM && (
          <div className=''>
            <button
              className={newProjectBtnClass}
              onClick={() => {
                router.push("/projects/new");
              }}>
              <div className='flex items-center space-x-2 '>
                <Plus size={18} />
                <span>新增專案</span>
              </div>
            </button>
          </div>
        )}
      </div>

      {/* 右側：新增專案：僅 PM/Admin 可見 */}
    </div>
  );
}
