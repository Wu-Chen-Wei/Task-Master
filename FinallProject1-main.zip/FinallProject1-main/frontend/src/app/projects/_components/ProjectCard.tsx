// frontend\src\app\projects\_components\ProjectCard.tsx

import React from "react";
import {Calendar, User, AlertCircle} from "lucide-react";
import {ProjectData, URGENT_TAG_ID} from "../_types/project.types";

/**
 * 腳色顏色常數定義 (修正為靜態 Tailwind 類別字串)
 */
const ROLE_COLORS = {
  // PM: #4CAF50
  PM: "bg-[#4CAF50]",
  // RDL: #FF9800
  RDL: "bg-[#FF9800]",
  // RD: #D32F2F
  RD: "bg-[#D32F2F]",
  // Admin: #9E9E9E
  Admin: "bg-[#9E9E9E]",
  // Default/未指定: #8C8C8C
  Default: "bg-[#8C8C8C]",
};

/**
 * 輔助方法：根據狀態 ID 計算進度百分比 (10-50 各占 20%)
 */
const calculateProgressPercentage = (stateId: number): number => {
  switch (stateId) {
    case 10:
      return 20;
    case 20:
      return 40;
    case 30:
      return 60;
    case 40:
      return 80;
    case 50:
      return 100;
    case 60:
      return 100;
    default:
      return 0;
  }
};

/**
 * 輔助方法：將日期轉換為 YYYY年MM月DD日 (台灣時間)
 */
const formatTaiwanDate = (dateString: string): string => {
  if (!dateString) return "";
  try {
    const date = new Date(dateString);
    const formatter = new Intl.DateTimeFormat("zh-TW", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
    return formatter.format(date).replace("月", "月").replace("日", "日");
  } catch (e) {
    return dateString;
  }
};

/**
 * 輔助方法：獲取狀態標籤的屬性 (已修正為狀態名稱和靜態腳色顏色)
 */
const getStatusProps = (stateId: number) => {
  switch (stateId) {
    case 10:
      // 10 未開始: PM 負責
      return {label: "未開始", color: ROLE_COLORS.PM};
    case 20:
      // 20 分析中: RDL 負責
      return {label: "分析中", color: ROLE_COLORS.RDL};
    case 30:
      // 30 開發中: RD 負責
      return {label: "開發中", color: ROLE_COLORS.RD};
    case 40:
      // 40 審查中: RDL 負責
      return {label: "審查中", color: ROLE_COLORS.RDL};
    case 50:
      // 50 待歸檔: PM 負責
      return {label: "待歸檔", color: ROLE_COLORS.PM};
    case 60:
      // 60 已歸檔: Admin/System 負責
      return {label: "已歸檔", color: ROLE_COLORS.Admin};
    default:
      return {label: "未知", color: ROLE_COLORS.Default};
  }
};

/**
 * 輔助方法：獲取標籤屬性
 */
const getTagProps = (tagId: number | null) => {
  if (tagId === URGENT_TAG_ID) {
    return {label: "優先處理", color: "bg-red-600"};
  }
  return {label: "一般", color: "bg-indigo-500"};
};

export interface ProjectCardProps {
  project: ProjectData;
}

export const ProjectCardSkeleton = () => (
  // 應用 .card-base 類別
  <div className='card-base p-5 w-[330px]  flex flex-col space-y-4 animate-pulse shadow-md'>
    <div className='flex justify-between mb-4'>
      <div className='h-4 bg-gray-200 rounded w-1/4'></div>
      <div className='h-4 bg-gray-200 rounded w-1/5'></div>
    </div>
    <div className='h-6 bg-gray-300 rounded w-3/4'></div>
    <div className='h-12 bg-gray-200 rounded'></div>
    <div className='h-2 bg-gray-300 rounded'></div>
    <div className='flex space-x-2 mt-4'>
      <div className='h-4 bg-gray-200 rounded w-1/3'></div>
      <div className='h-4 bg-gray-200 rounded w-1/3'></div>
    </div>
    <div className='flex space-x-2 mt-2'>
      <div className='h-4 bg-gray-200 rounded w-1/3'></div>
      <div className='h-4 bg-gray-200 rounded w-1/3'></div>
    </div>
    <div className='flex space-x-2 mt-2'>
      <div className='h-4 bg-gray-200 rounded w-full'></div>
    </div>
  </div>
);

export default function ProjectCard({project}: ProjectCardProps) {
  const progressPercent = calculateProgressPercentage(project.currentStateID);
  const statusProps = getStatusProps(project.currentStateID);
  const tagProps = getTagProps(project.projectTagID);

  const handleCardClick = () => {
    window.location.href = `/projects/${project.projectID}`;
  };

  let progressBarColor = "bg-gray-300";
  if (progressPercent === 100) {
    progressBarColor = "bg-[#114574]";
  } else if (progressPercent > 0) {
    progressBarColor = "bg-[#1AA1D9]";
  }

  return (
    // 應用 .card-base 類別
    <div
      onClick={handleCardClick}
      className='card-base p-5 w-[330px] flex flex-col justify-between shadow-lg hover:shadow-xl transition-shadow duration-300 cursor-pointer border border-gray-100 group'>
      {/* 頂部狀態與標籤 */}
      <div className='flex justify-between mb-4'>
        <span
          // 應用動態腳色顏色
          className={`text-white text-xs px-3 py-1 rounded-md font-medium shadow-sm ${statusProps.color}`}>
          {statusProps.label}
        </span>
        <span
          className={`${tagProps.color} text-white text-xs px-3 py-1 rounded-md font-medium shadow-sm`}>
          {tagProps.label}
        </span>
      </div>

      {/* 核心內容 */}
      <div>
        <h3 className='font-semibold text-lg text-gray-800 mb-2 group-hover:text-[#1AA1D9] transition-colors'>
          {project.projectName}
        </h3>
        <p className='text-sm text-gray-500 h-10 overflow-hidden line-clamp-2 mb-4'>
          {project.description}
        </p>

        {/* 進度條 */}
        <div className='text-xs text-gray-600 mb-1 flex justify-between'>
          <span>進度條</span>
          <span>{progressPercent}%</span>
        </div>
        <div className='w-full bg-gray-200 rounded-full h-2.5 mb-4'>
          <div
            className={`${progressBarColor} h-2.5 rounded-full transition-all duration-500`}
            style={{width: `${progressPercent}%`}}></div>
        </div>
      </div>

      {/* 底部時間與人員 */}
      <div className='space-y-2 mt-4'>
        <div className='flex items-center space-x-2 text-blcak'>
          <Calendar size={18} />
          <span className='text-sm font-medium'>
            起：{formatTaiwanDate(project.startDate)}
          </span>
        </div>
        <div className='flex items-center space-x-2 text-red-500'>
          <Calendar size={18} />
          <span className='text-sm font-medium'>
            訖：{formatTaiwanDate(project.endDate)}
          </span>
        </div>

        <div className='flex items-center space-x-2 border-t border-gray-100 pt-2'>
          <User size={18} className='text-green-600' />
          <span className='text-sm text-gray-700'>PM: {project.ownerName}</span>
        </div>
        <div className='flex items-center space-x-2'>
          <User size={18} className='text-orange-500' />
          <span className='text-sm text-gray-700'>
            RDL: {project.rdlApprovedByName || "未指派"}
          </span>
        </div>
      </div>
    </div>
  );
}
