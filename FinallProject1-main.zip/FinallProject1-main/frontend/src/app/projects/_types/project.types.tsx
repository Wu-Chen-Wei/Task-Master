// frontend\src\app\projects\_types\project.types.tsx

// 核心契約與依賴：
// 1. ID 資料類型轉換契約：所有 CoreID 在 JSON 傳輸中必須是 string 類型 [5, 6]。
// 2. 專案狀態契約：定義 PROJECT_STATE_IDS 數值，用於狀態篩選 [5, 7]。

/**
 * 通用核心 ID 類型 (例如 ProjectID, UserID, AttachmentID)。
 * 根據 ID 資料類型轉換契約，在 JSON 傳輸中必須是 string 類型 [6]。
 */
export type CoreID = string;

// ================================================================
// 1. 詳情頁 DTOs (Project Detail Data Transfer Objects)
// ================================================================

/**
 * Missions 摘要結構，用於在 Project Object 中提供唯讀的任務資訊 [8]。
 */
export interface MissionSummary {
  missionID: CoreID; // 任務唯一識別碼 (string) [8]
  title: string;
  description: string;
  /** Missions.Status 欄位的 ENUM 值 [8] */
  status: "Open" | "In Progress" | "Testing" | "Reopened" | "Closed";
  assigneeID: CoreID | null; // 任務指派人 ID (string) [8]
  qaSignedByUserID: CoreID | null; // QA 蓋章者 ID (string) [8]
  dueDate: string; // 預計到期日期 (YYYY-MM-DD 格式) [8]
}

/**
 * 附件 JSON 結構 [9]。
 * UploadedByUserID 是 T4A 轉讓流程的目標欄位 [9]。
 */
export interface AttachmentObject {
  attachmentID: CoreID; // 附件唯一識別碼 (string) [9]
  projectID: CoreID; // 所屬專案 ID (string) [9]
  fileName: string;
  filePath: string;
  uploadedByUserID: CoreID; // 上傳者 ID (string) [9]
  uploadedAt: string; // 時間戳記格式 [9]
}

/**
 * 專案核心表 JSON 結構 (DTO) [10]。
 * GET /api/v1/projects/{projectID} 的回應格式。
 */
export interface ProjectObject {
  projectID?: CoreID; // 專案 ID (string) [10]
  projectName: string;
  description: string;
  ownerUserID: CoreID; // PM ID (OwnerUserID) [10]
  ownerName: string; // 來自 ProjectDBRow 擴展 [10]
  startDate: string; // YYYY-MM-DD 格式 [10]
  endDate: string; // YYYY-MM-DD 格式 [10]
  currentStateID: number; // 當前專案狀態 ID (P1 狀態鎖定依據) [10]
  rdlApprovedByUserID: CoreID | null; // RDL 蓋章者 ID [10]
  rdlApprovedByName: string; // 來自 ProjectDBRow 擴展 [11]
  rdlApprovedAt: string | null;
  projectTagID: number | null; // 專案標籤 ID [11]
  deletedAt?: string | null; // 軟刪除時間戳記 [11]

  // 關聯數據 (詳情頁面各 Tab 數據摘要)
  attachments?: AttachmentObject[]; // 附件列表 [11]
  missionSummary?: MissionSummary[]; // 任務摘要列表 (唯讀) [11]
}

// ================================================================
// 2. 列表 DTOs (List Data Transfer Objects)
// ================================================================

/**
 * ProjectData 專門用於列表頁 (區塊 III) 的輕量級數據 [5]。
 */
export interface ProjectData {
  projectID: CoreID;
  projectName: string;
  description: string;
  ownerUserID: CoreID;
  rdlApprovedByUserID: CoreID | null;
  ownerName: string; // PM 全名 [5]
  rdlApprovedByName: string; // RDL 全名 [5]
  startDate: string;
  endDate: string;
  currentStateID: number;
  projectTagID: number | null;
}

export interface PaginationMeta {
  totalProjects: number;
  totalPages: number;
  currentPage: number;
}

export interface ProjectListResponse {
  success: boolean;
  data: ProjectData[];
  meta: PaginationMeta;
}

/**
 * 列表篩選器契約 [12]。
 */
export interface ProjectFilters {
  page: number;
  limit: number;
  search: string;
  status?: number;
  tagId?: number;
  sortBy: string;
  sortOrder: "ASC" | "DESC";
  mode?: QuickFilterMode; // ALL/MINE/URGENT
}

// ================================================================
// 3. 身份驗證與常數 (Auth & Constants)
// ================================================================

/**
 * 實際使用者資訊介面 (從 /api/auth/me 獲取) [12]。
 */
export interface CurrentUser {
  userID: CoreID;
  email: string;
  Roles: string[]; // 角色陣列，用於權限檢查 [12]
}

/**
 * 匹配後端 AuthenticatedUser 的回應格式 [4]。
 * 後端會從 INT 轉為 string (CoreID) 傳輸 [13]。
 */
export interface AuthenticatedUserFromServer {
  UserID: number;
  Email: string;
  FullName: string;
  Title: string;
  Roles?: string[]; // 確保包含 Roles 陣列 [4]
}

/**
 * QuickFilterMode 定義 [4]。
 */
export type QuickFilterMode = "ALL" | "MINE" | "URGENT";

/**
 * 優先處理標籤 ID (URGENT_TAG_ID) [4]。
 */
export const URGENT_TAG_ID = 5;

/**
 * 最小載入時間契約 (1000ms)，用於避免閃爍 [2, 4]。
 * ⭐ 此為修復您當前錯誤的核心常數。
 */
export const MIN_LOADING_TIME = 1000;

/**
 * 專案狀態選項（用於 Searchbar）[14]。
 */
export const PROJECT_STATE_OPTIONS = [
  {name: "全部狀態", id: 0},
  {name: "未開始", id: 10},
  {name: "分析中", id: 20},
  {name: "開發中", id: 30},
  {name: "審查中", id: 40},
  {name: "待歸檔", id: 50},
  {name: "已歸檔", id: 60},
];
