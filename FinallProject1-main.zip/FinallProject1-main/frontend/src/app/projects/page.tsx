// frontend\src\app\projects\page.tsx

"use client";

import React from "react";
// 導入新命名元件
import Buttonbar from "../projects/_components/buttonbar";
import Searchbar from "../projects/_components/searchbar";
import {useProjectList} from "./_hooks/useProjectList.hook";
import ProjectCard, {ProjectCardSkeleton} from "./_components/ProjectCard";
import Pagination from "./_components/Pagination";
import {Loader2} from "lucide-react";

/**
 * ProjectCardList 頁面：列表協調者 (Orchestrator)。
 * 核心職責：調用 Hook，並將數據分發給 UI 元件，不含業務邏輯。
 */
export default function ProjectCardList() {
  // --- 步驟 1: 調用中央數據總管 Hook ---
  const {
    projects,
    meta,
    loading,
    userLoading,
    authError,
    isPM,
    currentMode,
    updateUrlFilters,
    initialFilters,
  } = useProjectList();

  const currentSearchTerm = initialFilters.search || "";
  const currentStatusId = initialFilters.status || 0;
  const currentPage = initialFilters.page;

  // --- 步驟 2: 處理載入和錯誤狀態 ---
  if (userLoading) {
    return (
      <div className='p-8 text-xl text-gray-500 flex items-center h-dvh justify-center'>
        <Loader2 className='animate-spin mr-2' size={24} />{" "}
        正在驗證使用者身份...
      </div>
    );
  }

  if (authError) {
    return (
      <div className='p-8 text-xl text-red-600'>
        認證錯誤或數據載入失敗：{authError} 請嘗試重新登入。
      </div>
    );
  }

  // 分頁回調函數
  const handlePageChange = (newPage: number) => {
    updateUrlFilters({page: newPage});
  };

  return (
    <>
      {/* 頁面標題 (已從 layout 移除) */}
      <div className='mb-6'>
        <h1 className='text-3xl font-bold'>專案管理</h1>
        <p className='text-xl'>管理和監控專案進度</p>
      </div>

      {/* 1. 頂部操作列：Buttonbar */}
      <Buttonbar
        currentMode={currentMode}
        updateUrlFilters={updateUrlFilters}
        isPM={isPM}
      />

      {/* 2. 頂部操作列：Searchbar */}
      <Searchbar
        updateUrlFilters={updateUrlFilters}
        initialSearchTerm={currentSearchTerm}
        initialStatusId={currentStatusId}
        loading={loading}
      />

      <div className='py-6'>
        {/* 3. 卡片清單渲染 */}
        <div className='grid gap-[21px] grid-cols-[repeat(auto-fill,330px)] justify-start'>
          {loading ? (
            // 顯示骨架屏
            Array.from({length: 9}).map((_, index) => (
              <ProjectCardSkeleton key={index} />
            ))
          ) : projects.length === 0 ? (
            <p className='text-gray-600'>找不到符合條件的專案。</p>
          ) : (
            // 渲染專案卡片
            projects.map((project) => (
              <ProjectCard key={project.projectID} project={project} />
            ))
          )}
        </div>

        {/* 4. 分頁元件 */}
        {meta.totalPages > 1 && (
          <Pagination
            meta={{...meta, currentPage: currentPage}}
            onPageChange={handlePageChange}
          />
        )}
      </div>
    </>
  );
}
