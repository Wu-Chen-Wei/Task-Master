// frontend\src\app\projects\layout.tsx

import React from "react";

export default function ProjectsLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return <div className='flex-col space-y-[21px] p-0 h-dvh'>{children}</div>;
}
