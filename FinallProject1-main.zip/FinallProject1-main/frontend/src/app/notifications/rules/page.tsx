"use client";
import { useEffect, useState } from "react";
import Image from "next/image";
import { Toaster, toast } from "react-hot-toast";


interface AutomationRule {
  RuleID: number;
  ProjectID: number;
  MissionID: number;
  Name: string;
  Descriptions: string;
  TriggerDefinition: string; // JSON 字串
  ActionDefinition: string;  // JSON 字串
  IsEnabled: boolean;
}

export default function NotificationsListPage() {

const [showForm, setShowForm] = useState(false);
const [isEnabled, setIsEnabled] = useState(true);
const [rules, setRules] = useState<AutomationRule[]>([]);

const [currentPage, setCurrentPage] = useState(1);
const pageSize = 5; // 每頁顯示 5 筆
const totalPages = Math.ceil(rules.length / pageSize);

const [editingRule, setEditingRule] = useState<AutomationRule | null>(null);
const [isEditing, setIsEditing] = useState(false);

const currentRules = rules.slice(
  (currentPage - 1) * pageSize,
  currentPage * pageSize
);

const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) setCurrentPage(page);
  };


  useEffect(() => {
  fetch(`http://localhost:4000/api/rule/all`)
    .then(res => res.json())
    .then(data => {
      console.log("API 回傳內容:", data);
      setRules(data.automationrules || []); // ← 修正這裡
    })
    .catch(err => console.error(err));
}, []);

const [formData, setFormData] = useState({
  name: "",
  description: "",
  trigger: "",
  action: "",
  recipientUserId: 2, // 這裡可以讓使用者選擇要通知的對象
  tag: "Urgent",
  toStatus: "Closed",
});

const toggleRuleStatus = async (ruleId: number, currentStatus: boolean) => {
  const newStatus = !currentStatus;

  try {
    const response = await fetch(`http://localhost:4000/api/rule/toggle/${ruleId}`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ isEnabled: newStatus }),
    });

    if (!response.ok) throw new Error("更新失敗");

    // ✅ 即時更新前端狀態
    setRules(prevRules =>
      prevRules.map(rule =>
        rule.RuleID === ruleId ? { ...rule, IsEnabled: newStatus } : rule
      )
    );
  } catch (err) {
    console.error("切換啟用狀態失敗:", err);
  }
};

const handleDeleteAutomationRule = async (automationrules: AutomationRule) => {
  try {
    const res = await fetch(`http://localhost:4000/api/rule/delete/${automationrules.RuleID}`, {
      method: "PUT",
    });
    const data = await res.json();

    if (data.success) {
      // ✅ 從 state 中過濾掉被刪除的那一筆
      setRules((prevRules) =>
        prevRules.filter((n) => n.RuleID !== automationrules.RuleID)
      );
    }
  } catch (err) {
    console.error("❌ 刪除通知失敗:", err);
  }
};


  return (
    <div className="self-stretch flex-1 flex flex-col justify-start items-start gap-3.5">
      <Toaster position="top-right" />
      {/* ===== Header ===== */}
      <div className="self-stretch bg-white inline-flex justify-between items-center overflow-hidden">
        <div className="inline-flex flex-col justify-center items-start gap-2.5">
          <div className="text-black text-xl font-normal font-['Microsoft_YaHei']">
            自動化規則引擎
          </div>
          <div className="text-neutral-500 text-xs font-normal font-['Microsoft_YaHei']">
            設定條件觸發動作，實現智能化通知管理
          </div>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="px-3.5 py-1.5 bg-[#1AA1D9] rounded-[10px] inline-flex justify-center items-center gap-2.5 overflow-hidden hover:bg-[#2482DC]"
        >
          <span className="text-white text-xs font-normal font-['Microsoft_YaHei'] cursor-pointer">
            + 新增規則
          </span>
        </button>
      </div>

      {/* ===== 若無規則 ===== */}
      {!showForm && rules.length === 0 && (
        <div className="self-stretch p-6 flex justify-center items-center">
          <div className="text-neutral-500 text-base font-normal font-['Microsoft_YaHei']">
            尚未設定任何自動化規則
          </div>
        </div>
      )}

      {/* ===== 顯示規則列表 ===== */}
      {currentRules.map((rule) => {
        let trigger, action;
        try {
            trigger = typeof rule.TriggerDefinition === "string"
                ? JSON.parse(rule.TriggerDefinition)
                : rule.TriggerDefinition;

            action = typeof rule.ActionDefinition === "string"
                ? JSON.parse(rule.ActionDefinition)
                : rule.ActionDefinition;
            } catch {
            trigger = {};
            action = {};
            }

        return (
          <div
            key={rule.RuleID ?? crypto.randomUUID()}
            className="self-stretch px-7 py-2.5 bg-neutral-100 rounded-2xl outline-1 outline-offset-[-1px] outline-neutral-200 inline-flex justify-between items-center overflow-hidden"
          >
            <div className="inline-flex flex-col justify-center items-start gap-1">
              {/* 規則名稱 + 狀態 */}
              <div className="inline-flex justify-center items-center gap-2.5">
                <div className="text-black text-xl font-normal font-['Noto_Sans']">
                  {rule.Name}
                </div>
                <div
                  className={`px-3.5 py-[5px] rounded-3xl flex justify-center items-center gap-2.5 overflow-hidden ${
                    rule.IsEnabled ? "bg-green-600" : "bg-gray-400"
                  }`}
                >
                  <div className="text-white text-base font-normal font-['Noto_Sans']">
                    {rule.IsEnabled ? "啟用中" : "停用中"}
                  </div>
                </div>
              </div>

              {/* 規則描述 */}
              <div className="text-zinc-500 text-base font-normal font-['Noto_Sans']">
                {rule.Descriptions}
              </div>

              {/* 觸發 + 動作 */}
              <div className="inline-flex justify-start items-start gap-4">
                <div className="text-zinc-500 text-base font-normal font-['Noto_Sans']">
                  觸發：
                  {trigger?.trigger === "status_changed"
                    ? `狀態變更為「${trigger.to_status}」`
                    : trigger?.trigger === "project_created"
                    ? "新專案建立"
                    : trigger?.trigger === "project_changed"
                    ? "專案變更"
                    : trigger?.trigger === "project_members_change"
                    ? "專案成員變更"
                    : trigger?.trigger === "project_owner_change"
                    ? "專案擁有者轉讓"
                    : trigger?.trigger === "RDL_stamp"
                    ? "RDL蓋章"
                    : trigger?.trigger === "project_deadline_passed"
                    ? "專案逾期"
                    : trigger?.trigger === "project_status_changed"
                    ? "專案狀態變更"
                    : "（未定義）"}
                </div>
                <div className="text-zinc-500 text-base font-normal font-['Noto_Sans']">
                  動作：
                  {action?.action === "send_notification"
                    ? `發送通知給使用者`
                    : action?.action === "send_email"
                    ? "寄出 Email"
                    : "（未定義）"}
                </div>
              </div>
            </div>

            <div className="flex justify-start items-center gap-11">
               <button
                    onClick={() => toggleRuleStatus(rule.RuleID, rule.IsEnabled)}
                    className="relative hover:bg-sky-400 rounded-full p-2.5 cursor-pointer"
                    >
                    <Image
                        alt="power"
                        src="/homepage_image/power-off-solid-full.svg"
                        width={30}
                        height={30}
                        className={`${rule.IsEnabled ? "opacity-60" : "opacity-100"}`}
                    />

                    {/* 🔴 禁用紅線效果 */}
                    {rule.IsEnabled ? (
                        <div
                            className="absolute top-1/2 left-1/2 w-10 h-[2px] bg-red-500 rotate-45 -translate-x-1/2 -translate-y-1/2 rounded-full pointer-events-none"
                        />
                    ) : null}
                </button>
              <button onClick={() => handleDeleteAutomationRule(rule)} className="hover:bg-sky-400 rounded-full p-2.5 cursor-pointer">
                <Image
                  alt="trash"
                  src="/homepage_image/trash-can-solid-full.svg"
                  width={30}
                  height={30}
                />
              </button>
            </div>
          </div>
        );
      })}

      {/* ===== 分頁按鈕區 ===== */}
      {totalPages > 1 && (
        <div className="flex justify-center items-center gap-2 mt-5">
          <button
            onClick={() => handlePageChange(1)}
            disabled={currentPage === 1}
            className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
          >
            ⏮
          </button>
          <button
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
          >
            ◀
          </button>

          {/* ✅ 動態頁碼 */}
          {[...Array(totalPages)].map((_, i) => (
            <button
              key={i}
              onClick={() => handlePageChange(i + 1)}
              className={`px-3 py-1 rounded ${
                currentPage === i + 1
                  ? "bg-sky-400 text-white"
                  : "bg-gray-200 hover:bg-gray-300"
              }`}
            >
              {i + 1}
            </button>
          ))}

          <button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
          >
            ▶
          </button>
          <button
            onClick={() => handlePageChange(totalPages)}
            disabled={currentPage === totalPages}
            className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
          >
            ⏭
          </button>
        </div>
      )}

      {/* ===== 新增規則表單（浮出視窗） ===== */}
      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
          <div className="bg-white rounded-2xl shadow-lg w-[500px] p-6 flex flex-col gap-4">
            {/* 表單標題 */}
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold text-[#1AA1D9]">
                建立新規則
              </h2>
              <button
                onClick={() => setShowForm(false)}
                className="text-gray-400 hover:text-black"
              >
                ✕
              </button>
            </div>

            {/* 規則名稱 */}
            <div className="flex flex-col gap-1">
              <label className="text-sm text-gray-700">規則名稱</label>
              <input
                type="text"
                className="border border-gray-300 rounded-[10px] p-2 text-sm"
                placeholder="例如：任務完成時寄信通知主管"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>

            {/* 描述 */}
            <div className="flex flex-col gap-1">
              <label className="text-sm text-gray-700">描述</label>
              <textarea
                rows={2}
                className="border border-gray-300 rounded-[10px] p-2 text-sm resize-none"
                placeholder="簡短說明這條規則的用途"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            {/* 觸發條件 */}
            <div className="flex flex-col gap-1">
              <label className="text-sm text-gray-700">觸發條件</label>
              <select 
                className="border border-gray-300 rounded-[10px] p-2 text-sm" 
                value={formData.trigger} 
                onChange={(e) => setFormData({ ...formData, trigger: e.target.value })}
            >
                <option value="">請選擇觸發條件</option>
                <option value="project_created">新專案建立</option>
                <option value="project_changed">專案變更</option>
                <option value="project_members_change">專案成員變更</option>
                <option value="project_owner_change">專案擁有者轉讓</option>
                <option value="RDL_stamp">RDL蓋章</option>
                <option value="project_deadline_passed">專案逾期</option>
                <option value="project_status_changed">專案狀態變更</option>
              </select>
            </div>

            {/* 執行動作 */}
            <div className="flex flex-col gap-1">
              <label className="text-sm text-gray-700">執行動作</label>
              <select 
                className="border border-gray-300 rounded-[10px] p-2 text-sm"
                value={formData.action}
                onChange={(e) => setFormData({ ...formData, action: e.target.value })}
              >
                <option value="">請選擇執行動作</option>
                <option value="send_notification">發送通知</option>
                <option value="send_email">寄出Email</option>
              </select>
            </div>

            {/* 啟用開關 */}
            <div className="flex items-center mt-2 gap-2">
              <button
                onClick={() => setIsEnabled(!isEnabled)}
                className={`w-12 h-6 flex items-center rounded-full p-1 transition-all cursor-pointer ${
                  isEnabled ? "bg-[#1AA1D9]" : "bg-gray-300"
                }`}
              >
                <div
                  className={`w-4 h-4 bg-white rounded-full shadow-md transform transition-all ${
                    isEnabled ? "translate-x-6" : "translate-x-0"
                  }`}
                />
              </button>
              <label className="text-sm text-gray-700">啟用規則</label>
            </div>

            {/* 建立按鈕 */}
            <div className="flex justify-end">
                <button
                    onClick={async () => {
                    const payload = {
                        ProjectID: 1,
                        MissionID: 1,
                        Name: formData.name,
                        Descriptions: formData.description,
                        TriggerDefinition: JSON.stringify({
                        tag: formData.tag,
                        trigger: formData.trigger,
                        to_status: formData.toStatus,
                        }),
                        ActionDefinition: JSON.stringify({
                        action: formData.action,
                        recipient_user_id: formData.recipientUserId,
                        }),
                        IsEnabled: isEnabled ? 1 : 0,
                    };

                    try {
                        const res = await fetch(`http://localhost:4000/api/rule/create`, {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify(payload),
                        });

                        const data = await res.json();
                        if (data.success) {
                        toast.success("新規則建立成功");
                        setShowForm(false);

                        // 更新前端列表
                        setRules((prev) => [...prev, data.newRule]);
                        } else {
                        toast.error("❌ 建立失敗：" + data.message);
                        }
                    } catch (err) {
                        console.error("❌ 建立規則錯誤:", err);
                    }
                    }}
                    className="w-20 bg-[#1AA1D9] hover:bg-[#2482DC] text-white py-2 rounded-[10px] mt-4"
                >
                    創建
                </button>
                </div>
          </div>
        </div>
      )}
    </div>
  );
}
