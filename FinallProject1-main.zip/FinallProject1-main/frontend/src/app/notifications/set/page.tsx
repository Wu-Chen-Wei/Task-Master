"use client"
import { useEffect, useState } from "react";
import Image from "next/image";
import { Toaster, toast } from "react-hot-toast";


export default function NotificationsSettingsPage() {

  const [emailIsEnabled, setEmailIsEnabled] = useState(true);
  const [isEnabled, setIsEnabled] = useState(true);
  const [hasEdited, setHasEdited] = useState(false);
  const [emailError, setEmailError] = useState("");

  const [email, setEmail] = useState("");
  const [selectedProvider, setSelectedProvider] = useState<"gmail" | "yahoo" | null>(null); // 從後端抓到的 email
  const [emailFromDB, setEmailFromDB] = useState(""); // 從後端抓到的 email
  const [emailProviderFromDB, setEmailProviderFromDB] = useState<"gmail" | "yahoo" | null>(null);


  const [cronInterval, setCronInterval] = useState(10);
  const [notifyBefore, setNotifyBefore] = useState(360);
  const [cronIsEnabled, setCronIsEnabled] = useState<boolean | null>(null);;

useEffect(() => {
  const userStr = localStorage.getItem("user");

  if (!userStr) {
    console.warn("沒有找到登入者資料");
    return;
  }
  const localUser = JSON.parse(userStr);
  const userId = localUser.userID; 

  console.log("當前使用者ID:", localUser.userID);

  // 呼叫後端取得
  fetch(`http://localhost:4000/api/set/userEmailSearch/${userId}`)
    .then((res) => res.json())
    .then((data) => {
      const email = data.email;
      setEmailFromDB(email);

      // 判斷後端 email Provider
      if (email.includes("@gmail.com")) {
        setEmailProviderFromDB("gmail");
      } else if (email.includes("@yahoo.com") || email.includes("@yahoo.com.tw")) {
        setEmailProviderFromDB("yahoo");
      } else {
        setEmailProviderFromDB(null);
      }
    })
    .catch((err) => console.error("讀取 email 失敗", err));
}, []);

useEffect(() => {
  async function loadSettings() {
    const res = await fetch("http://localhost:4000/api/set/notification-settings-get");
    const data = await res.json();
    setCronInterval(data.CronIntervalMinutes);
    setNotifyBefore(data.NotifyBeforeMinutes);
    setCronIsEnabled(data.IsEnabled === 1);
  }
  loadSettings();
}, []);

async function saveSettings() {

try {
  
  const res = await fetch("http://localhost:4000/api/set/notification-settings-put", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      CronIntervalMinutes: cronInterval,
      NotifyBeforeMinutes: notifyBefore,
      cronIsEnabled: cronIsEnabled ? 1 : 0
    })
  });

  const result = await res.json();

    if (result.success) {
      toast.success("設定已更新！");
    } else {
      toast.error("更新失敗，請稍後再試");
    }

  } catch (err) {
    console.error("錯誤：", err);
    toast.error("更新時發生錯誤");
  }

}

const handleSaveEmail = async () => {
  const userStr = localStorage.getItem("user");
  if (!userStr) return toast.error("找不到登入者資料");

  const localUser = JSON.parse(userStr);
  const userId = localUser.userID;

  try {
    const res = await fetch(`http://localhost:4000/api/set/updateEmail/${userId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email })
    });

    const data = await res.json();
    if (data.success) {
      toast.success("Email 已更新！");
      setEmailFromDB(email); // 更新本地狀態
      // 可以選擇更新 localStorage
      localUser.NotificationEmail = email;
      localStorage.setItem("user", JSON.stringify(localUser));
    } else {
      toast.error("更新失敗");
    }
  } catch (err) {
    console.error("更新 Email 失敗", err);
    toast.error("更新失敗");
  }
};


  

  return (
    <div className="self-stretch bg-white flex flex-col gap-2.5">
      <Toaster position="top-right" />
      <div className="self-stretch px-7 py-4 rounded-2xl outline-1 outline-[#E2E2E2] flex flex-col gap-6">

        {/* 標題 */}
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 relative">
              <Image
                src="/homepage_image/envelope-regular-full.svg"
                width={600}
                height={600}
                alt="Email通知設定"
                className="absolute w-full h-full"
              />
            </div>
            <div className="text-black text-xl font-normal font-['Microsoft_YaHei']">
              Email通知設定
            </div>
          </div>
          <div className="text-neutral-500 text-xs font-normal font-['Microsoft_YaHei']">
            配置Email通知功能
          </div>
        </div>

        {/* Email 服務選擇 */}
        <div className="bg-white p-4 rounded-xl flex flex-col gap-3 shadow-sm ">
          <div className="text-sm font-medium text-neutral-700">選擇 Email 服務：</div>

          {/* Gmail */}
          <div className="flex gap-3">
          <button
            onClick={() => {
              setSelectedProvider("gmail");
              setEmail(""); // 切換 Gmail 清空 input
              setHasEdited(false);
              setEmailError("");
            }}
            className={`px-4 py-2 border rounded cursor-pointer 
              ${selectedProvider === "gmail" ? "border-blue-500 text-blue-500" : "border-gray-300 text-gray-400"}`}
          >
            Gmail
          </button>

          <button
            onClick={() => {
              setSelectedProvider("yahoo")
              setEmail(""); // 切換 Gmail 清空 input
              setHasEdited(false);
              setEmailError("");
            }}
            className={`px-4 py-2 border rounded cursor-pointer 
              ${selectedProvider === "yahoo" ? "border-blue-500 text-blue-500" : "border-gray-300 text-gray-400"}`}
          >
            Yahoo
          </button>
        </div>
        </div>

        {/* Email 輸入欄位（選擇後顯示） */}
        {selectedProvider && (
          <div className="bg-white p-4 rounded-xl flex flex-col gap-2 shadow-sm">
            <div className="text-sm font-medium text-neutral-700">
              輸入 Email：
            </div>

            <input
              type="text"
              value={!hasEdited && selectedProvider === emailProviderFromDB ? emailFromDB : email}
              onChange={(e) => {
                setEmail(e.target.value);
                setHasEdited(true);

                // 前端即時檢查格式
                if (selectedProvider === "gmail") {
                  setEmailError(
                    e.target.value && !/^.+@gmail\.com$/i.test(e.target.value)
                      ? "請輸入有效的 Gmail 地址"
                      : ""
                  );
                } else if (selectedProvider === "yahoo") {
                  setEmailError(
                    e.target.value &&
                      !/^.+@yahoo\.com\.tw?$/i.test(e.target.value)
                      ? "請輸入有效的 Yahoo 地址"
                      : ""
                  );
                }
              }}
              className={`mt-3 p-2 border rounded w-full ${
                emailError ? "border-red-500" : "border-gray-300"
              }`}
            />
            {/* 錯誤訊息 */}
            {emailError && (
              <div className="text-red-500 text-xs mt-1">{emailError}</div>
            )}
          </div>
        )}

        {/* 儲存按鈕 */}
        <button
          onClick={handleSaveEmail}
          disabled={!!emailError || !email} // 有錯誤或沒有輸入 email 就禁止
          className={`self-end px-6 py-2 rounded-xl text-white text-sm shadow transition cursor-pointer
          ${!!emailError || !email
            ? "bg-gray-300 cursor-not-allowed"
            : "bg-[#1AA1D9] hover:bg-[#1380AC]"
          }`}
        >
          儲存設定
        </button>

      </div>
      
      <div className="self-stretch px-7 py-6 rounded-2xl outline-1 outline-offset-[-1px] outline-[#E2E2E2] bg-white shadow-sm flex flex-col gap-6">

  <div className="flex justify-between items-center">
    <div className="flex flex-col gap-1">
      <div className="text-black text-xl font-normal font-['Microsoft_YaHei']">專案提醒設定</div>
      <div className="text-neutral-500 text-xs font-normal font-['Microsoft_YaHei']">設定檢查時間與提醒提前時間</div>
    </div>

    {/* Cron 開關 */}
    <div className="flex items-center gap-2 ">
      <span className="text-sm text-gray-600">啟用提醒</span>
      {cronIsEnabled !== null && (
      <button
      onClick={async () => {
        const newValue = !cronIsEnabled;
        setCronIsEnabled(newValue); // 先更新 UI

        try {
          await fetch("http://localhost:4000/api/set/notification-settings-toggle", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ cronIsEnabled: newValue ? 1 : 0 })
          });
        } catch (err) {
          console.error("更新失敗", err);
          // 如果失敗可回復原本狀態
          setCronIsEnabled(!newValue);
          toast.error("更新失敗，請稍後再試");
        }
      }}
      className={`w-12 h-6 flex items-center rounded-full p-1 transition-all cursor-pointer ${
        cronIsEnabled ? "bg-[#1AA1D9]" : "bg-gray-300"
      }`}
    >
      <div
        className={`w-4 h-4 bg-white rounded-full shadow-md transform transition-all ${
          cronIsEnabled ? "translate-x-6" : "translate-x-0"
        }`}
      />
    </button>
)}
    </div>
  </div>
  {cronIsEnabled && (
    <>
  {/* Cron Interval */}

  {/* Notify Before */}
  <div className="flex flex-col gap-2">
    <label className="text-sm font-medium text-gray-700">到期前多久寄出提醒（分鐘）</label>
    <input
      type="number"
      value={notifyBefore}
      onChange={(e) => setNotifyBefore(Number(e.target.value))}
      className="border border-gray-300 px-3 py-2 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-blue-400"
    />
  </div>

  {/* Save button */}
  <div className="flex justify-end">
    <button
      onClick={saveSettings}
      className="bg-[#1AA1D9] hover:bg-[#1380AC] text-white px-6 py-2 rounded-xl shadow transition-all cursor-pointer"
    >
      儲存設定
    </button>
  </div>
  </>
  )}
</div>

      
    </div>
  );
}
