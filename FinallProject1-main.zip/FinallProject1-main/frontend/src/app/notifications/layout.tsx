"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import {  useEffect, useState } from "react";
import React from "react";

export default function NotificationsPage({
  children,
}: {
  children: React.ReactNode;
}) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);  
  const [loading, setLoading] = useState(true);

  const refreshUnreadCount = async () => {
    const res = await fetch("http://localhost:4000/api/list/unread-count");
    const data = await res.json();
    setUnreadCount(data.unreadCount || 0);
  };

  useEffect(() => {
  const fetchData = async () => {
    try {
      await refreshUnreadCount(); // 撈資料
    } catch (err) {
      console.error("撈取未讀數失敗：", err);
    } finally {
      setLoading(false); // ✅ 無論成功或失敗都結束 loading
    }
  };

  fetchData();
}, []);

  const pathname = usePathname();

  const tabs = [
    { key: "list", label: "通知列表", icon: "/homepage_image/bell-solid-full.svg", href: "/notifications/list" },
    { key: "rules", label: "自動化規則", icon: "/homepage_image/filter-solid-full.svg", href: "/notifications/rules" },
    { key: "settings", label: "通知設定", icon: "/homepage_image/gear-solid-full.svg", href: "/notifications/set" },
  ];

// ✅ 當載入中
  if (loading) {
    return (
      <div className="self-stretch p-2.5 inline-flex justify-center items-center gap-2.5">
        <div className="text-neutral-500 text-xl font-normal font-['Microsoft_YaHei']">
          載入中...
        </div>
      </div>
    );
  }
  
  return (
    <div className="w-full h-full self-stretch p-2.5 bg-white outline-1 outline-offset-[-1px] outline-black inline-flex flex-col justify-center items-start gap-2.5">
    <div className="self-stretch bg-white inline-flex justify-start items-center overflow-hidden">
        <div className="flex-1 p-[5px] inline-flex flex-col justify-start items-start gap-1">
            <div className="justify-center text-black text-2xl font-normal font-['Microsoft_YaHei']">通知中心</div>
            <div className="justify-center text-neutral-500 text-base font-normal font-['Microsoft_YaHei']">管理您的通知、自動化規則和提醒設定</div>
        </div>
    </div>
    {/* Tab 切換區 */}
      <div className="w-auto self-stretch px-2.5 py-1.5 bg-gray-200 rounded-md flex justify-between gap-2.5">
        {tabs.map(tab => {
          const isActive = pathname.startsWith(tab.href);
          return (
            <Link
              key={tab.key}
              href={tab.href}
              className={`flex-1 px-4 py-2 rounded-md flex justify-center items-center gap-2.5 whitespace-nowrap transition-all ${
                isActive ? "bg-white shadow-sm text-black" : "bg-transparent text-gray-600 hover:bg-white/50"
              }`}
            >
              <div className="w-6 h-6 relative">
                <Image
                  src={tab.icon}
                  width={600}
                  height={600}
                  alt={tab.label}
                  className={`absolute ${
                    tab.key === "list" ? "w-4 h-5 left-[3.75px] top-[2.5px]" :
                    tab.key === "rules" ? "w-5 h-4 left-[2.5px] top-[5px]" :
                    "w-5 h-5 left-[2.46px] top-[1.8px]"
                  }`}
                />
              </div>
              <div className="text-base font-normal font-['Microsoft_YaHei']">{tab.label}</div>
            </Link>
          );
        })}
      </div>

      {/* 內容區 */}
      <div className="self-stretch flex-1 px-7 py-5 rounded-xl outline-1 outline-offset-[-1px] outline-副色調 flex flex-col gap-3.5">
        {children}
      </div>
    </div>
  );
}