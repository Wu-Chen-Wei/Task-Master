"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";

interface Notification {
  NotificationID: number;
  ProjectID: number;
  ChangeType: string ;
  Content: string;
  CreatedAt: Date;
  IsRead: number;
}

interface Project {
  ProjectID: number;
  ProjectName: string;
  Description: string;
  ProjectTagID: number;
}

export default function NotificationsListPage() {


  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [showUnreadOnly, setShowUnreadOnly] = useState(false); // ✅ 是否僅顯示未讀
  const [currentPage, setCurrentPage] = useState(1); // ✅ 當前頁碼

  const itemsPerPage = 5; // ✅ 每頁顯示 5 筆

  // ✅ 向後端撈資料
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch("http://localhost:4000/api/list/all"); // 你的 express 路徑
        const data = await res.json();

        setNotifications(data.notifications || []);
        setProjects(data.projects || []);
        setUnreadCount(data.unreadCount || 0);
      } catch (err) {
        console.error("❌ 取得通知資料失敗：", err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
  let eventSource: EventSource | null = null;

  const init = async () => {
    // 1️⃣ 先拿初始資料
    const res = await fetch("http://localhost:4000/api/list/all");
    const data = await res.json();
    setNotifications(data.notifications);
    setUnreadCount(data.unreadCount);

    // 2️⃣ 再開 SSE，避免同時更新造成重複
    eventSource = new EventSource("http://localhost:4000/api/list/stream");

    eventSource.addEventListener("newNotification", (event) => {
      const newNotification: Notification = JSON.parse(event.data);
      console.log("📨 收到新通知:", newNotification);

      setNotifications((prev) => {
        const exists = prev.some(
          (n) => n.NotificationID === newNotification.NotificationID
        );
        if (exists) return prev;
        return [newNotification, ...prev];
      });

      setUnreadCount((prev) => prev + 1);
    });

    eventSource.addEventListener("unreadCount", (event) => {
      const { unreadCount } = JSON.parse(event.data);
      setUnreadCount(unreadCount);
    });

    eventSource.onerror = (err) => {
      console.error("⚠️ SSE 錯誤:", err);
    };
  };

  init();

  return () => {
    if (eventSource) eventSource.close();
  };
}, []);

  

  // ✅ 當載入中
  if (loading) {
    return (
      <div className="self-stretch p-2.5 inline-flex justify-center items-center gap-2.5">
        <div className="text-neutral-500 text-xl font-normal font-['Microsoft_YaHei']">
          載入中...
        </div>
      </div>
    );
  }

  

  // ✅ 篩選後的通知列表
  const filteredNotifications = showUnreadOnly
    ? notifications.filter((n) => n.IsRead === 0)
    : notifications;

  


  const handleMarkAsRead = async (notification: Notification) => {
  try {
    const res = await fetch(`http://localhost:4000/api/list/notifications/${notification.NotificationID}`, {
      method: "PUT",
    });
    const data = await res.json();

    if (data.success) {
       // ✅ 根據 NotificationID 找出該筆並更新
      const updated = notifications.map((n) =>
        n.NotificationID === notification.NotificationID
          ? { ...n, IsRead: 1 }
          : n
      );
      setNotifications(updated);
    }
  } catch (err) {
    console.error("❌ 更新通知狀態失敗:", err);
  }
};

const handleDeleteNotification = async (notification: Notification) => {
  try {
    const res = await fetch(`http://localhost:4000/api/list/delete/${notification.NotificationID}`, {
      method: "PUT",
    });
    const data = await res.json();

    if (data.success) {
      // ✅ 根據 ID 過濾（而非 index）
      const updated = notifications.filter(
        (n) => n.NotificationID !== notification.NotificationID
      );
      setNotifications(updated);
    }
  } catch (err) {
    console.error("❌ 刪除通知失敗:", err);
  }
};

// ✅ 分頁邏輯
  const totalPages = Math.ceil(filteredNotifications.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentPageNotifications = filteredNotifications.slice(
    startIndex,
    startIndex + itemsPerPage
  );

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) setCurrentPage(page);
  };

  // ✅ 按鈕事件：切換未讀/全部
  const handleToggleUnread = () => {
    setShowUnreadOnly((prev) => !prev);
    setCurrentPage(1); // ✅ 切換篩選時回到第一頁
  };


  // ✅ 沒通知時顯示「暫無通知」
  if (filteredNotifications.length === 0) {
    return (
      
      <div className="self-stretch flex-1 flex flex-col justify-start items-start gap-3.5">
        {/* ===== Header ===== */}
      <div className="self-stretch bg-white inline-flex justify-between items-center overflow-hidden">
        <div className="inline-flex flex-col justify-center items-start gap-2.5">
          <div className="text-black text-xl font-normal font-['Microsoft_YaHei']">
            所有通知
          </div>
          <div className="text-neutral-500 text-xs font-normal font-['Microsoft_YaHei']">
            查看和管理您的所有通知
          </div>
        </div>

        {/* ✅ 篩選未讀按鈕 */}
        <button
          onClick={handleToggleUnread}
          className={`px-5 py-1 rounded-[10px] flex justify-center items-center gap-2 overflow-hidden transition-colors ${
            showUnreadOnly
              ? "bg-[#1AA1D9] text-white"
              : "bg-gray-200 text-black hover:bg-[#1AA1D9]/70"
          }`}
        >
          <div className="w-6 h-6 relative overflow-hidden">
            <Image
              src="/homepage_image/filter-solid-full.svg"
              width={600}
              height={600}
              alt="filter"
              className="w-5 h-4 left-[2.50px] top-[5px] absolute"
            />
          </div>
          <span className="text-xs font-normal font-['Microsoft_YaHei']">
            {showUnreadOnly ? "顯示全部" : "僅顯示未讀"}
          </span>
        </button>
      </div>
        <div className="text-neutral-500 text-xl w-full flex justify-center font-normal font-['Microsoft_YaHei']">
          暫無通知
        </div>
      </div>
    );
  }


  // ✅ 根據 ChangeType 顯示對應中文
const getChangeTypeText = (changeType?: string) => {
  switch (changeType) {
    case "PROJECT_CREATED":
      return "新專案建立提醒 🆕";
    case "PROJECT_DELETED":
      return "專案資料已更除 ❌";
    case "PROJECT_NAME_UPDATE":
      return "專案資訊已更新 ✏️";
    case "DESCRIPTION_UPDATE":
      return "專案資訊已更新 ✏️";
    case "DATE_UPDATE":
      return "專案資訊已更新 ✏️";
    case "DESCRIPTION_UPDATE":
      return "任務描述已更新 ✏️";
    case "STATE_TRANSITION":
      return "任務完成狀態更新 ✅";
    case "RDL_STAMP":
      return "專案完成 RDL 蓋章 📑";
    case "PM_TRANSFER":
      return "專案負責人變更 🔄";
    case "ATTACHMENT_UPDATE":
      return "專案附件已更新 📎";
    case "PROJECT_PROJECTMEMBERS_UPDATE":
      return "專案成員已更新 👥";
    default:
      return "系統通知 📢";
  }
};

  // ✅ 有通知時顯示通知方框
  return (
    <div className="self-stretch flex-1 flex flex-col justify-start items-start gap-3.5">
      {/* ===== Header ===== */}
      <div className="self-stretch bg-white inline-flex justify-between items-center overflow-hidden">
        <div className="inline-flex flex-col justify-center items-start gap-2.5">
          <div className="text-black text-xl font-normal font-['Microsoft_YaHei']">
            所有通知
          </div>
          <div className="text-neutral-500 text-xs font-normal font-['Microsoft_YaHei']">
            查看和管理您的所有通知
          </div>
        </div>

        {/* ✅ 篩選未讀按鈕 */}
        <button
          onClick={handleToggleUnread}
          className={`px-5 py-1 rounded-[10px] flex justify-center items-center gap-2 overflow-hidden transition-colors ${
            showUnreadOnly
              ? "bg-[#1AA1D9] text-white"
              : "bg-gray-200 text-black hover:bg-[#1AA1D9]/70"
          }`}
        >
          <div className="w-6 h-6 relative overflow-hidden">
            <Image
              src="/homepage_image/filter-solid-full.svg"
              width={600}
              height={600}
              alt="filter"
              className="w-5 h-4 left-[2.50px] top-[5px] absolute"
            />
          </div>
          <span className="text-xs font-normal font-['Microsoft_YaHei']">
            {showUnreadOnly ? "顯示全部" : "僅顯示未讀"}
          </span>
        </button>
      </div>

      {/* ===== 通知列表 ===== */}
      {currentPageNotifications.map((notification, index) => {
        const project = projects.find(
    (p) => p.ProjectID === notification.ProjectID
  ) || projects[0]; // 或者依照實際邏輯取對應專案

        // ✅ 根據 ProjectTagID 顯示不同標籤
        const getTagInfo = (tagId?: number) => {
          switch (tagId) {
            case 1:
              return { label: "一般通知", color: "bg-gray-400" };
            case 2:
              return { label: "進度更新", color: "bg-green-400" };
            case 3:
              return { label: "重要通知", color: "bg-red-400" };
            case 4:
              return { label: "專案開始", color: "bg-blue-400" };
            case 5:
              return { label: "緊急", color: "bg-red-400" };
            default:
              return { label: "一般通知", color: "bg-gray-400" };
          }
        };

        const tagInfo = getTagInfo(project?.ProjectTagID);

        return (
          <div
            key={`${notification.NotificationID}-${index}`}
            className="relative self-stretch px-7 py-2.5 bg-neutral-100 rounded-2xl outline-1 outline-neutral-200 inline-flex justify-between items-center overflow-visible"
          >
            <div className="flex gap-5">
              {/* ✅ 只有未讀顯示鈴鐺 */}
              {notification.IsRead !== 1 && (
                <motion.div
                    className="absolute -top-3 -left-3 bg-white rounded-full p-1 shadow-md"
                    animate={{ rotate: [0, -15, 15, -10, 10, 0] }} // 左右擺動角度
                    transition={{
                      duration: 1.2, // 每次晃動週期
                      repeat: Infinity, // 無限循環
                      ease: "easeInOut",
                    }}
                  >
                  <Image
                    alt="bell"
                    src="/homepage_image/bell-solid-full-red.svg"
                    width={22}
                    height={22}
                  />
                </motion.div>
              )}
              <div className="flex gap-5 ml-2">
                <div className="inline-flex flex-col justify-center items-start gap-1">
                  <div className="inline-flex justify-center items-center gap-2.5">
                    <div className="text-black text-xl font-normal font-['Noto_Sans']">
                      {getChangeTypeText(notification.ChangeType)}
                    </div>
                    {/* ✅ 這裡根據 ProjectTagID 顯示不同顏色與文字 */}
                    <div
                      className={`px-3.5 py-[5px] ${tagInfo.color} rounded-3xl flex justify-center items-center gap-2.5 overflow-hidden`}
                    >
                      <div className="text-white text-base font-normal font-['Noto_Sans']">
                        {tagInfo.label}
                      </div>
                    </div>
                  </div>

                  {/* ✅ 顯示專案描述 */}
                  <div className="text-zinc-500 text-base font-normal font-['Noto_Sans']">
                    {notification?.Content || "無專案描述"}
                  </div>

                  <div className="text-zinc-500 text-base font-normal font-['Noto_Sans']">
                    {new Date(notification.CreatedAt).toLocaleString("zh-TW", {
                      timeZone: "Asia/Taipei",
                    })}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-start items-center gap-11">
              <button
                onClick={() => handleMarkAsRead(notification)}
                className="hover:bg-sky-400 rounded-full p-2.5 cursor-pointer"
              >
                <Image
                  alt="check"
                  src="/homepage_image/check-double-solid-full.svg"
                  width={30}
                  height={30}
                />
              </button>
              <button onClick={() => handleDeleteNotification(notification)} className="hover:bg-sky-400 rounded-full p-2.5 cursor-pointer">
                <Image
                  alt="trash"
                  src="/homepage_image/trash-can-solid-full.svg"
                  width={30}
                  height={30}
                />
              </button>
            </div>
          </div>
        );
      })}
      {/* ===== 分頁按鈕區 ===== */}
      {totalPages > 1 && (
        <div className="flex justify-center items-center gap-2 mt-5">
          <button
            onClick={() => handlePageChange(1)}
            disabled={currentPage === 1}
            className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
          >
            ⏮
          </button>
          <button
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
          >
            ◀
          </button>

          {/* ✅ 動態頁碼 */}
          {[...Array(totalPages)].map((_, i) => (
            <button
              key={i}
              onClick={() => handlePageChange(i + 1)}
              className={`px-3 py-1 rounded ${
                currentPage === i + 1
                  ? "bg-sky-400 text-white"
                  : "bg-gray-200 hover:bg-gray-300"
              }`}
            >
              {i + 1}
            </button>
          ))}

          <button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
          >
            ▶
          </button>
          <button
            onClick={() => handlePageChange(totalPages)}
            disabled={currentPage === totalPages}
            className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
          >
            ⏭
          </button>
        </div>
      )}

    </div>
  );
}
