import { redirect } from "next/navigation";

export default function NotificationsIndexPage() {
  // 預設導向通知列表
  redirect("/notifications/list");

  return null; // 不會渲染任何內容
}