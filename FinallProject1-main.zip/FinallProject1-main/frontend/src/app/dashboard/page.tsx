'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { dashboardApi } from '@/services/dashboardApi';
import { UniversalDashboard } from '@/components/UniversalDashboard';  // ✅ 引入組件

const Page: React.FC = () => {
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      loadDashboard();
    }
  }, [user]);

  const loadDashboard = async () => {
    try {
      setLoading(true);
      const response = await dashboardApi.getHome();
      console.log('📊 Dashboard API 回應:', response.data);
      setDashboardData((response.data as any).data);
    } catch (error) {
      console.error('❌ Dashboard API 錯誤:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">載入中...</p>
        </div>
      </div>
    );
  }

  if (!dashboardData) {
    return <div className="text-center text-gray-500">無資料</div>;
  }

  return <UniversalDashboard data={dashboardData} />;  // ✅ 使用通用組件
};

export default Page;
