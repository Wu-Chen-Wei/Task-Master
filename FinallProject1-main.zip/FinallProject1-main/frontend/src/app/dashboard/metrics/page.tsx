'use client';

import React, { useState, useEffect } from 'react';
import { dashboardApi } from '@/services/dashboardApi';
import { 
  PieChart, Pie, Cell, 
  BarChart, Bar, 
  LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';

const MetricsPage: React.FC = () => {
  const [projectId, setProjectId] = useState('1');
  const [loading, setLoading] = useState(false);
  
  const [progressData, setProgressData] = useState<any>(null);
  const [trendData, setTrendData] = useState<any>(null);
  const [tagsData, setTagsData] = useState<any>(null);
  const [priorityData, setPriorityData] = useState<any>(null);

  const [dateRange, setDateRange] = useState({
    startDate: '2025-10-01',
    endDate: '2025-10-31',
  });

  const loadAllMetrics = async () => {
    try {
      setLoading(true);

      const [progress, trend, tags, priority] = await Promise.all([
        dashboardApi.getProjectProgress(projectId, dateRange),
        dashboardApi.getProjectProgressTrend(projectId, dateRange.startDate, dateRange.endDate),
        dashboardApi.getTagsAnalysis(projectId, dateRange),
        dashboardApi.getPriorityAnalysis(projectId),
      ]);

      setProgressData((progress.data as any).data);
      setTrendData((trend.data as any).data);
      setTagsData((tags.data as any).data);
      setPriorityData((priority.data as any).data);
    } catch (error) {
      console.error('❌ 載入 Metrics 錯誤:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllMetrics();
  }, []);

  const handleSearch = () => {
    loadAllMetrics();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">載入中...</p>
        </div>
      </div>
    );
  }

  // ✅ 準備圓餅圖資料（任務狀態）
  const statusPieData = progressData ? [
    { name: '待處理', value: progressData.openMissions || 0, color: '#6b7280' },
    { name: '進行中', value: progressData.inProgressMissions || 0, color: '#eab308' },
    { name: '已解決', value: progressData.resolvedMissions || 0, color: '#22c55e' },
    { name: '已關閉', value: progressData.closedMissions || 0, color: '#3b82f6' },
  ].filter(item => item.value > 0) : [];

  // ✅ 準備長條圖資料（優先度）
  const priorityBarData = Array.isArray(priorityData?.distribution) 
    ? priorityData.distribution.map((item: any) => ({
        name: item.priority,
        value: item.count,
        fill: item.priority === 'Critical' ? '#ef4444' :
              item.priority === 'High' ? '#f97316' :
              item.priority === 'Medium' ? '#eab308' : '#9ca3af'
      }))
    : [];

  // ✅ 準備折線圖資料（進度趨勢）
  const trendLineData = Array.isArray(trendData)
    ? trendData.map((item: any) => ({
        date: new Date(item.date).toLocaleDateString('zh-TW', { month: '2-digit', day: '2-digit' }),
        open: item.openMissions || 0,
        inProgress: item.inProgressMissions || 0,
        closed: item.closedMissions || 0,
      }))
    : [];

  return (
    <div className="metrics-page">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">專案指標分析</h1>

      {/* 篩選區域 */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">專案 ID</label>
            <input
              type="text"
              value={projectId}
              onChange={(e) => setProjectId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">開始日期</label>
            <input
              type="date"
              value={dateRange.startDate}
              onChange={(e) => setDateRange(prev => ({ ...prev, startDate: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">結束日期</label>
            <input
              type="date"
              value={dateRange.endDate}
              onChange={(e) => setDateRange(prev => ({ ...prev, endDate: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-end">
            <button
              onClick={handleSearch}
              className="w-full px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              查詢
            </button>
          </div>
        </div>
      </div>

      {/* 專案進度統計 */}
      {progressData && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-2xl font-semibold mb-4">專案進度統計</h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <StatCard label="總任務" value={progressData.totalMissions} color="blue" />
            <StatCard label="已完成" value={progressData.completedMissions} color="green" />
            <StatCard label="進行中" value={progressData.inProgressMissions} color="yellow" />
            <StatCard label="待處理" value={progressData.openMissions} color="gray" />
            <StatCard label="完成率" value={`${progressData.completionRate}%`} color="purple" />
          </div>
        </div>
      )}

      {/* ✅ 新增：圖表區域 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* 任務狀態圓餅圖 */}
        {statusPieData.length > 0 && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-semibold mb-4">📊 任務狀態分布</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={statusPieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={(entry) => `${entry.name}: ${entry.value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* 優先度長條圖 */}
        {priorityBarData.length > 0 && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-semibold mb-4">⚡ 優先度分布</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={priorityBarData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="value" name="任務數量" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* ✅ 新增：進度趨勢折線圖 */}
      {trendLineData.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-2xl font-semibold mb-4">📈 進度趨勢</h2>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={trendLineData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="open" stroke="#6b7280" name="待處理" />
              <Line type="monotone" dataKey="inProgress" stroke="#eab308" name="進行中" />
              <Line type="monotone" dataKey="closed" stroke="#22c55e" name="已關閉" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* 優先度分析（原有的表格保留） */}
      {Array.isArray(priorityData?.distribution) && priorityData.distribution.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-2xl font-semibold mb-4">優先度詳細資料</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {priorityData.distribution.map((item: any, index: number) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="text-sm text-gray-500 mb-1">{item.priority}</div>
                <div className="text-3xl font-bold mb-2">{item.count}</div>
                <div className="text-xs text-gray-400">{item.percentage}%</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 標籤分析 */}
      {tagsData && tagsData.tagStats && tagsData.tagStats.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-2xl font-semibold mb-4">🏷️ 熱門標籤</h2>
          <div className="flex flex-wrap gap-3">
            {tagsData.tagStats.map((tag: any, index: number) => (
              <div
                key={index}
                className="px-4 py-2 bg-blue-100 text-blue-800 rounded-full font-medium"
              >
                {tag.tag} ({tag.count})
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// 統計卡片組件
const StatCard: React.FC<{ label: string; value: string | number; color: string }> = ({ 
  label, 
  value, 
  color 
}) => {
  const colors: { [key: string]: string } = {
    blue: 'text-blue-600',
    green: 'text-green-600',
    yellow: 'text-yellow-600',
    gray: 'text-gray-600',
    purple: 'text-purple-600',
  };

  return (
    <div className="bg-gray-50 rounded-lg p-6">
      <div className="text-sm text-gray-500 mb-2">{label}</div>
      <div className={`text-3xl font-bold ${colors[color]}`}>{value}</div>
    </div>
  );
};

export default MetricsPage;