
'use client';

import React, { useState, useEffect } from 'react';
import { dashboardApi } from '@/services/dashboardApi';

const KanbanPage: React.FC = () => {
  const [projectId, setProjectId] = useState('1');
  const [kanbanData, setKanbanData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [draggedCard, setDraggedCard] = useState<any>(null);

  // 載入 Kanban 資料
  const loadKanbanData = async () => {
    try {
      setLoading(true);
      const response = await dashboardApi.getKanbanBoard(projectId);
      console.log('📋 Kanban API 回應:', response.data);
      setKanbanData((response.data as any).data);
    } catch (error) {
      console.error('❌ Kanban API 錯誤:', error);
    } finally {
      setLoading(false);
    }
  };

  // 初始載入
  useEffect(() => {
    loadKanbanData();
  }, []);

  // 處理拖曳開始
  const handleDragStart = (card: any) => {
    setDraggedCard(card);
  };

  // 處理拖曳結束
  const handleDrop = async (newStatus: string) => {
    if (!draggedCard) return;

    // 如果狀態沒變，不做任何事
    if (draggedCard.status === newStatus) {
      setDraggedCard(null);
      return;
    }

    try {
      // 呼叫 API 更新狀態
      await dashboardApi.updateMissionStatus(
        draggedCard.missionID.replace('M_', ''),
        newStatus
      );

      // 重新載入資料
      await loadKanbanData();
      
      console.log('✅ 任務狀態已更新');
    } catch (error) {
      console.error('❌ 更新狀態失敗:', error);
    } finally {
      setDraggedCard(null);
    }
  };

  // 優先度顏色
  const getPriorityColor = (priority: string) => {
    const colors: { [key: string]: string } = {
      'Critical': 'border-red-500 bg-red-50',
      'High': 'border-orange-500 bg-orange-50',
      'Medium': 'border-yellow-500 bg-yellow-50',
      'Low': 'border-green-500 bg-green-50',
    };
    return colors[priority] || 'border-gray-500 bg-gray-50';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">載入中...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="kanban-page">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Kanban 看板</h1>

      {/* 篩選區域 */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex gap-4 items-end">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              專案 ID
            </label>
            <input
              type="text"
              value={projectId}
              onChange={(e) => setProjectId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={loadKanbanData}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            查詢
          </button>
        </div>
      </div>

      {/* Kanban 看板 */}
      {kanbanData && (
        <div className="bg-gray-100 p-6 rounded-lg">
          <div className="flex gap-4 overflow-x-auto pb-4">
            {kanbanData.columns.map((column: any, index: number) => (
              <div
                key={index}
                className="flex-shrink-0 w-80"
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => handleDrop(column.status)}
              >
                {/* 欄位標題 */}
                <div className="bg-white rounded-lg shadow-md mb-3 p-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-semibold text-lg">{column.displayName}</h3>
                    <span className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-sm font-medium">
                      {column.count}
                    </span>
                  </div>
                </div>

                {/* 任務卡片 */}
                <div className="space-y-3 min-h-[200px]">
                  {column.cards.map((card: any, cardIndex: number) => (
                    <div
                      key={cardIndex}
                      draggable
                      onDragStart={() => handleDragStart(card)}
                      className={`bg-white rounded-lg shadow-md p-4 cursor-move hover:shadow-lg transition-shadow border-l-4 ${getPriorityColor(card.priority)}`}
                    >
                      {/* 卡片標題 */}
                      <h4 className="font-semibold text-gray-800 mb-2">{card.title}</h4>

                      {/* 卡片描述 */}
                      {card.description && (
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                          {card.description}
                        </p>
                      )}

                      {/* 優先度標籤 */}
                      <div className="flex items-center gap-2 mb-2">
                        <span className={`px-2 py-1 rounded text-xs font-semibold ${
                          card.priority === 'Critical' ? 'bg-red-500 text-white' :
                          card.priority === 'High' ? 'bg-orange-500 text-white' :
                          card.priority === 'Medium' ? 'bg-yellow-500 text-white' :
                          'bg-green-500 text-white'
                        }`}>
                          {card.priority}
                        </span>
                      </div>

                      {/* 指派人 */}
                      {card.assigneeName && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <span>👤</span>
                          <span>{card.assigneeName}</span>
                        </div>
                      )}

                      {/* 標籤 */}
                      {card.tags && card.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {card.tags.map((tag: string, tagIndex: number) => (
                            <span
                              key={tagIndex}
                              className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}

                      {/* ID */}
                      <div className="text-xs text-gray-400 mt-2">
                        {card.missionID}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 使用說明 */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
        <p className="text-sm text-blue-800">
          💡 <strong>使用提示：</strong>拖曳任務卡片到不同欄位即可更新任務狀態
        </p>
      </div>
    </div>
  );
};

export default KanbanPage;