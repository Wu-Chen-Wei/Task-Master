'use client';

import React, { useState, useEffect, useRef } from 'react';
import { dashboardApi } from '@/services/dashboardApi';
import * as d3 from 'd3';

// ✅ 提升到元件外層，讓整個元件都能使用
const priorityColors: { [key: string]: string } = {
  'Critical': '#ef4444',
  'High': '#f97316',
  'Medium': '#eab308',
  'Low': '#22c55e',
};

const GanttPage: React.FC = () => {
  const [projectId, setProjectId] = useState('1');
  const [ganttData, setGanttData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const loadGanttData = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await dashboardApi.getGanttChart(projectId);
      const rawData = response.data?.data;

      console.log('📦 API 原始回傳:', rawData);

      if (!rawData || !Array.isArray(rawData.tasks)) {
        throw new Error('API 回傳格式錯誤或缺少 tasks 陣列');
      }

      setGanttData(rawData);
    } catch (err: any) {
      console.error('❌ Gantt API 錯誤:', err);
      setGanttData(null);
      setError(err.message || '載入失敗');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadGanttData();
  }, []);

  useEffect(() => {
    if (!ganttData || !svgRef.current || !Array.isArray(ganttData.tasks)) return;
    drawGanttChart(ganttData);
  }, [ganttData]);

  const drawGanttChart = (data: any) => {
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const tasks = data.tasks;
    if (!tasks || tasks.length === 0) return;

    const margin = { top: 50, right: 50, bottom: 50, left: 200 };
    const width = 1200 - margin.left - margin.right;
    const height = tasks.length * 50 + margin.top + margin.bottom;

    svg.attr('width', width + margin.left + margin.right)
       .attr('height', height);

    const g = svg.append('g')
                 .attr('transform', `translate(${margin.left},${margin.top})`);

    const parsedTasks = tasks.map((t: any) => ({
      ...t,
      startDate: new Date(t.startDate),
      endDate: new Date(t.dueDate),
    }));

    const minDate = d3.min(parsedTasks, d => d.startDate) as Date;
    const maxDate = d3.max(parsedTasks, d => d.endDate) as Date;

    const xScale = d3.scaleTime()
      .domain([minDate, maxDate])
      .range([0, width]);

    const yScale = d3.scaleBand()
      .domain(parsedTasks.map((t: any) => t.title))
      .range([0, tasks.length * 50])
      .padding(0.2);

    g.append('g')
      .attr('class', 'x-axis')
      .attr('transform', `translate(0, ${tasks.length * 50})`)
      .call(d3.axisBottom(xScale).ticks(10).tickFormat(d3.timeFormat('%Y-%m-%d') as any))
      .selectAll('text')
      .style('text-anchor', 'end')
      .attr('dx', '-.8em')
      .attr('dy', '.15em')
      .attr('transform', 'rotate(-45)');

    g.append('g')
      .attr('class', 'y-axis')
      .call(d3.axisLeft(yScale));

    g.selectAll('.task-bar')
      .data(parsedTasks)
      .enter()
      .append('rect')
      .attr('class', 'task-bar')
      .attr('x', (d: any) => xScale(d.startDate))
      .attr('y', (d: any) => yScale(d.title)!)
      .attr('width', (d: any) => xScale(d.endDate) - xScale(d.startDate))
      .attr('height', yScale.bandwidth())
      .attr('fill', (d: any) => priorityColors[d.priority] || '#6b7280')
      .attr('rx', 5)
      .style('cursor', 'pointer')
      .on('mouseover', function(event, d: any) {
        d3.select(this).attr('opacity', 0.7);
        const tooltip = d3.select('body').append('div')
          .attr('class', 'tooltip')
          .style('position', 'absolute')
          .style('background', 'rgba(0, 0, 0, 0.8)')
          .style('color', 'white')
          .style('padding', '10px')
          .style('border-radius', '5px')
          .style('pointer-events', 'none')
          .style('font-size', '12px')
          .html(`
            <strong>${d.title}</strong><br/>
            優先度: ${d.priority}<br/>
            狀態: ${d.status}<br/>
            開始: ${d.startDate.toLocaleDateString('zh-TW')}<br/>
            結束: ${d.endDate.toLocaleDateString('zh-TW')}
          `)
          .style('left', `${event.pageX + 10}px`)
          .style('top', `${event.pageY - 10}px`);
      })
      .on('mouseout', function() {
        d3.select(this).attr('opacity', 1);
        d3.selectAll('.tooltip').remove();
      });

    svg.append('text')
      .attr('x', width / 2 + margin.left)
      .attr('y', 30)
      .attr('text-anchor', 'middle')
      .style('font-size', '20px')
      .style('font-weight', 'bold')
      .text(data.projectName || '專案甘特圖');
  };

  return (
    <div className="gantt-page">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">專案甘特圖</h1>

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex gap-4 items-end">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              專案 ID
            </label>
            <input
              type="text"
              value={projectId}
              onChange={(e) => setProjectId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={loadGanttData}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            查詢
          </button>
        </div>
      </div>

      {loading && (
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
            <p className="text-gray-600">載入中...</p>
          </div>
        </div>
      )}

      {error && (
        <div className="text-center text-red-500 mt-4">
          ⚠️ {error}
        </div>
      )}

      {ganttData && (
        <>
          <div className="bg-white rounded-lg shadow-md p-6 overflow-x-auto">
            <svg ref={svgRef}></svg>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6 mt-6">
            <h3 className="text-lg font-semibold mb-4">圖例</h3>
            <div className="flex gap-6">
              {['Critical', 'High', 'Medium', 'Low'].map((level) => (
                <div key={level} className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: priorityColors[level] }}></div>
                  <span className="text-sm">{level}</span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default GanttPage;
