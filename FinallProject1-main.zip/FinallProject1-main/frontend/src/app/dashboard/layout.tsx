// frontend/src/app/dashboard/layout.tsx
"use client";
import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user } = useAuth(); // ✅ 直接取得 user
  const pathname = usePathname();

  // ✅ 取得使用者角色
  const userRole = user?.Roles?.[0] || 'User';

  // ✅ 判斷是否為 Admin 或 PM
  const canViewAdvancedTabs = ['Admin', 'PM'].includes(userRole);

  // 根據角色顯示不同的 tabs
  let tabs = [
    { name: "摘要", href: "/dashboard", icon: "⚡" },
    { name: "列表", href: "/dashboard/list", icon: "📋" },
  ];

  // ✅ 只有 PM 和 Admin 可以看到進階功能
  if (canViewAdvancedTabs) {
    tabs.push(
      { name: "看板", href: "/dashboard/kanban", icon: "🖼️" },
      { name: "時間表", href: "/dashboard/gantt", icon: "🕒" },
      { name: "統計圖表", href: "/dashboard/metrics", icon: "📈" }
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* 顯示頂部 Tab 導航區 */}
      <div className="flex border-b bg-white shadow-sm">
        {tabs.map((tab) => {
          const isActive = pathname === tab.href;
          return (
            <Link
              key={tab.name}
              href={tab.href}
              className={`px-6 py-3 text-center text-sm font-medium transition-colors ${
                isActive ? "border-b-2 border-blue-500 text-blue-600" : "text-gray-500 hover:bg-gray-50"
              }`}
            >
              {tab.icon} {tab.name}
            </Link>
          );
        })}
      </div>

      {/* 內容區 */}
      <main className="flex-grow overflow-y-auto p-6 bg-gray-50">
        {children}
      </main>
    </div>
  );
}