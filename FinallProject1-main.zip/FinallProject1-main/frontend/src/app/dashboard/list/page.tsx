"use client";

import React, { useState, useEffect } from "react";
import { dashboardApi } from "@/services/dashboardApi";

const MissionListPage: React.FC = () => {
  const [missions, setMissions] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // 篩選條件
  const [filters, setFilters] = useState({
    projectId: "",
    assigneeId: "",
    status: "",
    priority: "",
    keyword: "",
    tags: [] as string[],
    startDate: "",
    endDate: "",
  });

  // 載入資料
  const loadMissions = async () => {
    try {
      setLoading(true);
      const response = await dashboardApi.searchMissions(filters);
      console.log("📋 Missions API 完整回應:", response.data);

      const data = (response.data as any).data;
      const missionList = data?.missions || []; // ✅ 取 missions 陣列

      console.log("📋 取得的 missions:", missionList);
      setMissions(missionList);
    } catch (error) {
      console.error("❌ Missions API 錯誤:", error);
      setMissions([]);
    } finally {
      setLoading(false);
    }
  };

  // 初始載入
  useEffect(() => {
    loadMissions();
  }, []);

  // 處理篩選條件變更
  const handleFilterChange = (key: string, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  // 執行搜尋
  const handleSearch = () => {
    loadMissions();
  };

  // 清除篩選
  const handleClearFilters = () => {
    setFilters({
      projectId: "",
      assigneeId: "",
      status: "",
      priority: "",
      keyword: "",
      tags: [],
      startDate: "",
      endDate: "",
    });
  };

  return (
    <div className="mission-list-page">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Mission 管理</h1>

      {/* 篩選區域 */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-lg font-semibold mb-4">篩選條件</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* 關鍵字搜尋 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              關鍵字搜尋
            </label>
            <input
              type="text"
              value={filters.keyword}
              onChange={(e) => handleFilterChange("keyword", e.target.value)}
              placeholder="搜尋標題或描述..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* 狀態 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              狀態
            </label>
            <select
              value={filters.status}
              onChange={(e) => handleFilterChange("status", e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">全部</option>
              <option value="Open">Open</option>
              <option value="In Progress">In Progress</option>
              <option value="Testing">Testing</option>
              <option value="Resolved">Resolved</option>
              <option value="Closed">Closed</option>
              <option value="Reopened">Reopened</option>
            </select>
          </div>

          {/* 優先度 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              優先度
            </label>
            <select
              value={filters.priority}
              onChange={(e) => handleFilterChange("priority", e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">全部</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
        </div>

        {/* 按鈕 */}
        <div className="flex gap-3 mt-4">
          <button
            onClick={handleSearch}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            搜尋
          </button>
          <button
            onClick={handleClearFilters}
            className="px-6 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition-colors"
          >
            清除
          </button>
        </div>
      </div>

      {/* 結果列表 */}
      <div className="bg-white rounded-lg shadow-md">
        {loading ? (
          <div className="p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-4"></div>
            <p className="text-gray-600">載入中...</p>
          </div>
        ) : missions.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            找不到符合條件的 Mission
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    標題
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    專案
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    狀態
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    優先度
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    指派人
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    操作
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {missions.map((mission) => (
                  <tr key={mission.missionID} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {mission.missionID?.replace(/^M_/, '') || mission.missionID}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900">
                      {mission.title}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {mission.projectName}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span
                        className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          mission.status === "Closed"
                            ? "bg-green-100 text-green-800"
                            : mission.status === "In Progress"
                            ? "bg-blue-100 text-blue-800"
                            : mission.status === "Testing"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {mission.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span
                        className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          mission.priority === "Critical"
                            ? "bg-red-100 text-red-800"
                            : mission.priority === "High"
                            ? "bg-orange-100 text-orange-800"
                            : mission.priority === "Medium"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-green-100 text-green-800"
                        }`}
                      >
                        {mission.priority}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {mission.assigneeName || "-"}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                      <button className="text-blue-600 hover:text-blue-900">
                        查看
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 結果統計 */}
      {!loading && missions.length > 0 && (
        <div className="mt-4 text-sm text-gray-600">
          共找到 <span className="font-semibold">{missions.length}</span> 筆資料
        </div>
      )}
    </div>
  );
};

export default MissionListPage;
