"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { CheckCircle, XCircle, Loader2, Mail } from "lucide-react";

export default function VerifyEmailPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get("token");

  const [status, setStatus] = useState<"loading" | "success" | "error">(
    "loading"
  );
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (token) {
      verifyEmail(token);
    } else {
      setStatus("error");
      setMessage("缺少驗證 Token");
    }
  }, [token]);

const verifyEmail = async (token: string) => {
  try {
    console.log("🔵 前端：開始驗證 Email", { token });

    const res = await fetch(
      `http://localhost:4000/api/users/verify-email?token=${token}`
    );

    const data = await res.json();
    console.log("🔵 前端：收到回應", data);

    if (data.success) {
      // ========== 情況 1：驗證成功 ==========
      setStatus("success");
      setMessage(data.message || "Email 驗證成功！");

      // 更新 localStorage
      if (data.user) {
        localStorage.setItem("user", JSON.stringify(data.user));
        console.log("✅ localStorage 已更新（後端資料）:", data.user);
      } else {
        const userStr = localStorage.getItem("user");
        if (userStr) {
          try {
            const user = JSON.parse(userStr);
            user.EmailVerified = true;
            localStorage.setItem("user", JSON.stringify(user));
            console.log("✅ localStorage 已更新（手動更新）:", user);
          } catch (parseErr) {
            console.error("❌ 解析失敗:", parseErr);
          }
        }
      }

      // 觸發事件
      window.dispatchEvent(new Event("user-logged-in"));
      console.log("✅ 已觸發 user-logged-in 事件");

      // 3 秒後跳轉
      setTimeout(() => {
        router.push("/dashboard");
      }, 3000);
      
    } else {
      // ========== 情況 2：驗證失敗 ==========
      console.error("❌ 驗證失敗:", data.message);

      // ⭐⭐⭐ 檢查使用者是否已經驗證過了
      const userStr = localStorage.getItem("user");
      if (userStr) {
        try {
          const user = JSON.parse(userStr);

          // 如果已經驗證過，顯示友善訊息
          if (user.EmailVerified) {
            console.log("✅ 使用者已經驗證過了");
            setStatus("success");
            setMessage("您的 Email 已經驗證過了，無需重複驗證！");

            // 2 秒後跳轉
            setTimeout(() => {
              router.push("/dashboard");
            }, 2000);
            return;
          }
        } catch (parseErr) {
          console.error("❌ 解析 localStorage 失敗:", parseErr);
        }
      }

      // ⭐ 如果還沒驗證，檢查是否是「Token 不存在」的錯誤
      if (data.message === "驗證連結無效" || data.message.includes("Token")) {
        // 可能是：1) Token 過期，2) Token 已被使用，3) 已經驗證過
        // 我們給使用者一個重新發送的選項
        setStatus("error");
        setMessage("驗證連結無效或已過期，請重新發送驗證信");
      } else {
        // 其他錯誤
        setStatus("error");
        setMessage(data.message || "驗證失敗，請稍後再試");
      }
    }
  } catch (err) {
    console.error("❌ 前端：驗證 Email 錯誤:", err);
    setStatus("error");
    setMessage("連線錯誤，請稍後再試");
  }
};

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
        {/* 載入中 */}
        {status === "loading" && (
          <div className="text-center">
            <Loader2 className="w-16 h-16 text-blue-500 animate-spin mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-800 mb-2">驗證中...</h2>
            <p className="text-gray-600">請稍候，正在驗證您的 Email</p>
          </div>
        )}

        {/* 驗證成功 */}
        {status === "success" && (
          <div className="text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-800 mb-2">
              ✅ 驗證成功！
            </h2>
            <p className="text-gray-600 mb-4">{message}</p>

            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
              <p className="text-sm text-green-800">
                🎉 您的 Email 已驗證完成，現在可以使用所有功能！
              </p>
            </div>

            <p className="text-sm text-gray-500 mb-4">
              3 秒後自動跳轉至 Dashboard...
            </p>

            <button
              onClick={() => router.push("/dashboard")}
              className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              立即前往 Dashboard
            </button>
          </div>
        )}

        {/* 驗證失敗 */}
        {status === "error" && (
          <div className="text-center">
            <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-800 mb-2">驗證失敗</h2>
            <p className="text-gray-600 mb-6">{message}</p>

            <button
              onClick={() => router.push("/login")}
              className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              返回登入頁面
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
