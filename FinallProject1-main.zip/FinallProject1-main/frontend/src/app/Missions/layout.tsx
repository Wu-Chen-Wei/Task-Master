"use client";

import React from "react";


export default function MissionsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col space-y-6 p-8 h-dvh bg-gray-100">

      {/* 頁面標題 */}
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Mission 管理</h1>
        <p className="text-gray-500 text-sm">管理與監控任務進度</p>
      </div>

      {/* 上方任務功能列 */}


      {/* 主體 */}
      {children}
    </div>
  );
}

