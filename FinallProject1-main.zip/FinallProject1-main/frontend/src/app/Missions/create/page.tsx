"use client";

import { useRouter, useSearchParams } from "next/navigation";
import MissionForm, { MissionFormData } from "../components/MissionForm";

export default function CreateMissionPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const projectId = searchParams.get('projectId'); // ✅ 從 URL 取得 projectId

  const handleCreate = async (form: MissionFormData) => {
    const token = localStorage.getItem("token");

    if (!token) {
      alert("請先登入！");
      router.push("/login");
      return;
    }

    // ✅ 檢查表單中的 projectId
    if (!form.projectId) {
      alert("請選擇專案!");
      return;
    }

    const statusMap: Record<string, string> = {
      "待處理": "Open",
      "進行中": "In Progress",
      "測試中": "Testing",
      "重新開啟": "Reopened",
      "已關閉": "Closed",
      "To Do": "Open",
    };

    const priorityMap: Record<string, string> = {
      "低": "Low",
      "中等": "Medium",
      "高": "High",
      "緊急": "Critical",
    };

    const payload = {
      projectId: Number(form.projectId),  // ✅ 使用表單選擇的 projectId
      title: form.title,
      desc: form.desc,
      status: statusMap[form.status] || "Open",
      priority: priorityMap[form.priority] || "Medium",
      start_date: form.start,
      end_date: form.end,
      assigneeId: Number(form.rd) || null,
    };

    console.log("最終送出後端 payload:", payload);
    console.log("payload.projectId:", payload.projectId);

    try {
      const res = await fetch("http://localhost:4000/api/missions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errorText = await res.text();
        console.error("❌ 錯誤回應:", errorText);
        throw new Error(`HTTP ${res.status}: ${errorText}`);
      }

      const data = await res.json();

      if (data.success) {
        alert("任務建立成功！");
        router.push(`/projects/${form.projectId}`);  // ✅ 返回專案頁面
      } else {
        alert("建立失敗：" + data.message);
      }
    } catch (error) {
      console.error("❌ 建立任務錯誤:", error);
      alert("建立任務失敗，請檢查 console");
    }
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">新增任務</h1>
      <MissionForm submitText="建立任務" onSubmit={handleCreate} />
    </div>
  );
}