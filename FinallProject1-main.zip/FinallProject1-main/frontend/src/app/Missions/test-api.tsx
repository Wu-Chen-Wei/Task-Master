"use client";

import { useState } from "react";
import { createApiUrl } from "@/lib/api";

export default function TestApiComponent() {
  const [testResults, setTestResults] = useState<any>({});
  const [loading, setLoading] = useState(false);

  const testApis = async () => {
    setLoading(true);
    const token = localStorage.getItem("token");
    const results: any = {};

    try {
      // 測試任務 API
      console.log('🔍 測試任務 API...');
      const missionsRes = await fetch(createApiUrl('/api/missions'), {
        headers: { Authorization: `Bearer ${token}` },
      });
      const missionsData = await missionsRes.json();
      results.missions = {
        status: missionsRes.status,
        success: missionsData.success,
        count: missionsData.data?.length || 0,
        sample: missionsData.data?.[0] || null
      };

      // 測試用戶 API (如果有任務)
      if (missionsData.data?.length > 0) {
        const firstMission = missionsData.data[0];
        if (firstMission.assigneeId) {
          console.log('🔍 測試用戶 API...');
          const userRes = await fetch(createApiUrl(`/api/users/${firstMission.assigneeId}`), {
            headers: { Authorization: `Bearer ${token}` },
          });
          const userData = await userRes.json();
          results.user = {
            status: userRes.status,
            success: userData.success,
            user: userData.user || null
          };
        }

        // 測試專案 API
        if (firstMission.projectId) {
          console.log('🔍 測試專案 API...');
          const projectRes = await fetch(createApiUrl(`/api/v1/projects/${firstMission.projectId}`), {
            headers: { Authorization: `Bearer ${token}` },
          });
          const projectData = await projectRes.json();
          results.project = {
            status: projectRes.status,
            success: projectData.success,
            project: projectData.data || null
          };
        }
      }

    } catch (error) {
      results.error = error.message;
    }

    setTestResults(results);
    setLoading(false);
  };

  return (
    <div className="p-4 bg-white rounded-lg shadow">
      <h3 className="text-lg font-bold mb-4">API 測試工具</h3>
      
      <button
        onClick={testApis}
        disabled={loading}
        className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
      >
        {loading ? '測試中...' : '測試 API'}
      </button>

      {Object.keys(testResults).length > 0 && (
        <div className="mt-4">
          <h4 className="font-semibold mb-2">測試結果:</h4>
          <pre className="bg-gray-100 p-3 rounded text-xs overflow-auto max-h-96">
            {JSON.stringify(testResults, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}