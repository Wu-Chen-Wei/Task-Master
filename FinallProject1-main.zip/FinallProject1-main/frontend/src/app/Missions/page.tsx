"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { useCache } from "@/hooks/useCache";
import { createApiUrl } from "@/lib/api";
import MissionCard from "./components/MissionCard";
import MissionSearchbar from "./components/MissionSearchbar";

export default function MissionsPage() {
  const router = useRouter();
  const { isRDLeader, canManageMissions, isAuthenticated, isAdmin, isLoading } = useAuth();
  const [keyword, setKeyword] = useState("");
  const [status, setStatus] = useState("全部狀態");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  // 使用快取獲取任務資料
  const { data: missionsData, loading, clearCache } = useCache(
    `missions-${keyword}-${status}`,
    async () => {
      const params = new URLSearchParams();
      if (keyword) params.append("search", keyword);
      if (status && status !== "全部狀態") params.append("status", status);

      const token = localStorage.getItem("token");
      console.log('🔍 獲取任務資料:', { keyword, status });
      
      const res = await fetch(createApiUrl(`/api/missions?${params.toString()}`), {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) {
        console.error('❌ 獲取任務失敗:', res.status, res.statusText);
        throw new Error('Failed to fetch missions');
      }
      
      const json = await res.json();
      console.log('✅ 任務資料:', json);
      
      if (!json.success) throw new Error(json.message || 'API error');
      
      return json.data;
    },
    [keyword, status]
  );

  const missions = missionsData || [];

  // 快取用戶資料
  const { data: users = {} } = useCache(
    `users-cache-${missions.map(m => m.assigneeId).join(',')}`,
    async () => {
      if (!missions.length) return {};
      
      const token = localStorage.getItem("token");
      const userIds = [...new Set(missions.map((m: any) => m.assigneeId).filter(Boolean))];
      
      if (userIds.length === 0) return {};
      
      const userPromises = userIds.map(async (id) => {
        try {
          const res = await fetch(createApiUrl(`/api/users/${id}`), {
            headers: { 
              Authorization: `Bearer ${token}`,
              'Cache-Control': 'no-cache'
            },
          });
          
          if (!res.ok) return { id, name: `用戶 ${id}` };
          
          const data = await res.json();
          return { 
            id, 
            name: data.success && data.user ? data.user.FullName : `用戶 ${id}` 
          };
        } catch (error) {
          return { id, name: `用戶 ${id}` };
        }
      });

      const userResults = await Promise.all(userPromises);
      const usersMap: {[key: string]: string} = {};
      userResults.forEach(({ id, name }) => {
        usersMap[id] = name;
      });
      return usersMap;
    },
    [missions]
  );

  // 快取專案資料
  const { data: projects = {} } = useCache(
    `projects-cache-${missions.map(m => m.projectId).join(',')}`,
    async () => {
      if (!missions.length) return {};
      
      const token = localStorage.getItem("token");
      const projectIds = [...new Set(missions.map((m: any) => m.projectId).filter(Boolean))];
      
      if (projectIds.length === 0) return {};
      
      const projectPromises = projectIds.map(async (id) => {
        try {
          const res = await fetch(createApiUrl(`/api/v1/projects/${id}`), {
            headers: { 
              Authorization: `Bearer ${token}`,
              'Cache-Control': 'no-cache'
            },
          });
          
          if (!res.ok) return { id, name: `專案 ${id}` };
          
          const data = await res.json();
          return { 
            id, 
            name: data.success && data.data ? data.data.projectName : `專案 ${id}` 
          };
        } catch (error) {
          return { id, name: `專案 ${id}` };
        }
      });

      const projectResults = await Promise.all(projectPromises);
      const projectsMap: {[key: string]: string} = {};
      projectResults.forEach(({ id, name }) => {
        projectsMap[id] = name;
      });
      return projectsMap;
    },
    [missions]
  );

  // 權限檢查
  useEffect(() => {
    // 等待 loading 完成再檢查權限
    if (isLoading) return;
    
    if (!isAuthenticated) {
      console.log('❌ 未登入，跳轉到登入頁');
      router.push('/login');
      return;
    }
    if (!canManageMissions()) {
      console.log('❌ 沒有權限查看任務');
      alert('您沒有權限查看任務');
      router.push('/');
      return;
    }
    console.log('✅ 權限檢查通過');
  }, [isLoading, isAuthenticated, canManageMissions, router]);



  // 🔍 搜尋
  const handleSearch = (kw: string) => {
    setKeyword(kw);
    setCurrentPage(1);
    clearCache(); // 清除快取以重新獲取資料
  };

  // 🔽 狀態篩選
  const handleStatus = (st: string) => {
    setStatus(st);
    setCurrentPage(1);
    clearCache(); // 清除快取以重新獲取資料
  };

  return (
    <div className="space-y-6">
      <MissionSearchbar
        onSearchChange={handleSearch}
        onStatusChange={handleStatus}
      />

      {loading ? (
        <p className="text-center text-gray-500 py-10">載入中...</p>
      ) : missions.length > 0 ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {missions
              .slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)
              .map((m: any) => (
                <MissionCard 
                  key={m.id} 
                  mission={m} 
                  assigneeName={users[m.assigneeId] || ""}
                  projectName={projects[m.projectId] || ""}
                />
              ))}
          </div>
          
          {/* 分頁導航 */}
          {missions.length > itemsPerPage && (
            <div className="flex justify-center space-x-2 mt-6">
              {Array.from({ length: Math.ceil(missions.length / itemsPerPage) }, (_, i) => (
                <button
                  key={i + 1}
                  onClick={() => setCurrentPage(i + 1)}
                  className={`px-3 py-2 rounded ${
                    currentPage === i + 1
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          )}
        </>
      ) : (
        <p className="text-center text-gray-400 py-10">
          沒有找到符合條件的任務
        </p>
      )}
    </div>
  );
}
