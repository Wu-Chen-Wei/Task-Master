"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { Calendar, User, Tag, Clock, CheckCircle, UserCheck, Building } from "lucide-react";
import Link from "next/link";
import { createApiUrl, API_ENDPOINTS, createDynamicEndpoint } from "@/lib/api";

export default function MissionDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const { isRD, isQA, isRDLeader, canManageMissions, isAuthenticated, isAdmin, isLoading } = useAuth();

  const [loading, setLoading] = useState(true);
  const [mission, setMission] = useState<any>(null);
  const [assigneeName, setAssigneeName] = useState<string>("");
  const [projectName, setProjectName] = useState<string>("");
  const [qaSignedByName, setQaSignedByName] = useState<string>("");

  // 權限檢查
  useEffect(() => {
    // 等待 loading 完成再檢查權限
    if (isLoading) return;
    
    if (!isAuthenticated) {
      console.log('❌ 未登入，跳轉到登入頁');
      router.push('/login');
      return;
    }
    if (!canManageMissions()) {
      console.log('❌ 沒有權限查看任務');
      alert('您沒有權限查看任務');
      router.push('/');
      return;
    }
    console.log('✅ 權限檢查通過');
  }, [isLoading, isAuthenticated, canManageMissions, router]);

  // 🟦 STEP 1：取得任務資料
  useEffect(() => {
    async function fetchMission() {
      const token = localStorage.getItem("token");

      try {
        const res = await fetch(createApiUrl(createDynamicEndpoint.missionById(id as string)), {
          headers: { Authorization: `Bearer ${token}` },
        });

        const json = await res.json();

        if (json.success) {
          setMission(json.data);
          
          // 獲取指派人員姓名
          if (json.data.assigneeId) {
            fetchUserName(json.data.assigneeId, setAssigneeName);
          }
          
          // 獲取專案名稱
          if (json.data.projectId) {
            fetchProjectName(json.data.projectId);
          }
          
          // 獲取 QA 簽核人員姓名
          if (json.data.qaSignedByUserId) {
            fetchUserName(json.data.qaSignedByUserId, setQaSignedByName);
          }
        }

        setLoading(false);
      } catch (err) {
        console.error("❌ 載入任務錯誤:", err);
        setLoading(false);
      }
    }

    if (id) fetchMission();
  }, [id]);

  // 獲取用戶姓名的輔助函數
  const fetchUserName = async (userId: number, setName: (name: string) => void) => {
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(createApiUrl(`/api/users/${userId}`), {
        headers: { Authorization: `Bearer ${token}` },
      });
      
      const json = await res.json();
      console.log('用戶API響應:', json); // 調試用
      if (json.success && json.user) {
        // 檢查多個可能的欄位名稱
        const userName = json.user.FullName || json.user.fullName || json.user.name || `用戶 ${userId}`;
        setName(userName);
      } else {
        setName(`用戶 ${userId}`);
      }
    } catch (err) {
      console.error("獲取用戶姓名失敗:", err);
      setName(`用戶 ${userId}`);
    }
  };

  // 獲取專案名稱的輔助函數
  const fetchProjectName = async (projectId: number) => {
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(createApiUrl(`/api/v1/projects/${projectId}`), {
        headers: { Authorization: `Bearer ${token}` },
      });
      
      const json = await res.json();
      console.log('專案API響應:', json); // 調試用
      if (json.success && json.data) {
        // 檢查多個可能的欄位名稱
        const projectName = json.data.projectName || json.data.ProjectName || json.data.name || `專案 ${projectId}`;
        setProjectName(projectName);
      } else {
        setProjectName(`專案 ${projectId}`);
      }
    } catch (err) {
      console.error("獲取專案名稱失敗:", err);
      setProjectName(`專案 ${projectId}`);
    }
  };

  // QA 簽核
  const handleSign = async () => {
    if (!confirm(`確定要簽核任務「${mission.title}」嗎？`)) return;

    try {
      const token = localStorage.getItem("token");
      const res = await fetch(createApiUrl(createDynamicEndpoint.missionSign(id as string)), {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.ok) {
        alert("任務已簽核關閉");
        window.location.reload();
      } else {
        const data = await res.json();
        alert("簽核失敗：" + (data.message || "未知錯誤"));
      }
    } catch (error) {
      alert("簽核失敗");
    }
  };

  // 指派給 QA
  const handleAssignToQA = async () => {
    const qaUserId = prompt('請輸入 QA 使用者 ID:');
    if (!qaUserId) return;

    try {
      const token = localStorage.getItem("token");
      const res = await fetch(createApiUrl(createDynamicEndpoint.missionAssignQA(id as string)), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ qaUserId: Number(qaUserId) }),
      });

      if (res.ok) {
        alert("已指派給 QA 驗證");
        window.location.reload();
      } else {
        const data = await res.json();
        alert("指派失敗：" + (data.message || "未知錯誤"));
      }
    } catch (error) {
      alert("指派失敗");
    }
  };

  // 🟥 載入中
  if (loading) return <p className="p-8">載入中...</p>;

  // 🟥 找不到資料
  if (!mission) return <p className="p-8">找不到任務</p>;

  const formatDate = (dateString: string) => {
    if (!dateString) return "-";
    return new Date(dateString).toLocaleDateString('zh-TW');
  };

  const statusColors: any = {
    Open: "bg-green-100 text-green-700",
    "In Progress": "bg-blue-100 text-blue-700",
    Testing: "bg-purple-100 text-purple-700",
    Reopened: "bg-red-100 text-red-700",
    Closed: "bg-gray-200 text-gray-600",
  };

  const priorityColors: any = {
    Critical: "bg-red-100 text-red-700",
    High: "bg-orange-100 text-orange-700",
    Medium: "bg-yellow-100 text-yellow-700",
    Low: "bg-gray-100 text-gray-500",
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* 頁面標題 */}


        {/* 主要內容卡片 */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          {/* 任務標題區域 */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 px-8 py-6 border-b border-gray-200">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-gray-900 mb-3">{mission.title}</h2>
                <div className="flex flex-wrap gap-2">
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                    statusColors[mission.status] || "bg-gray-100 text-gray-500"
                  }`}>
                    {mission.status}
                  </span>
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                    priorityColors[mission.priority] || "bg-gray-100 text-gray-500"
                  }`}>
                    {mission.priority}
                  </span>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {/* QA 簽核按鈕 */}
                {isQA() && (mission.status === 'Testing' || mission.status === 'Closed') && (
                  <button
                    onClick={handleSign}
                    className="inline-flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled={mission.status === 'Closed'}
                  >
                    <CheckCircle size={16} />
                    {mission.status === 'Closed' ? 'QA 已簽核' : 'QA 簽核關閉'}
                  </button>
                )}

                {/* RD 指派給 QA */}
                {(isRD() || isRDLeader() || isAdmin()) && mission.status === 'In Progress' && (
                  <button
                    onClick={handleAssignToQA}
                    className="inline-flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
                  >
                    <UserCheck size={16} />
                    指派給 QA
                  </button>
                )}

                {/* 編輯按鈕 */}
                <Link
                  href={`/missions/${id}/edit`}
                  className="inline-flex items-center bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  編輯任務
                </Link>
              </div>
            </div>
          </div>

          {/* 任務內容 */}
          <div className="p-8">
            {/* 任務描述 */}
            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">任務描述</h3>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                  {mission.description || "無描述"}
                </p>
              </div>
            </div>

            {/* 任務詳細資訊 */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* 左側：時間資訊 */}
              <div className="space-y-6">
                <div className="bg-blue-50 rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Calendar className="text-blue-600" size={20} />
                    <h4 className="font-medium text-gray-900">開始日期</h4>
                  </div>
                  <p className="text-lg font-semibold text-gray-800 ml-8">
                    {formatDate(mission.startDate) || "-"}
                  </p>
                </div>

                <div className="bg-red-50 rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Clock className="text-red-600" size={20} />
                    <h4 className="font-medium text-gray-900">截止日期</h4>
                  </div>
                  <p className="text-lg font-semibold text-gray-800 ml-8">
                    {formatDate(mission.dueDate) || "-"}
                  </p>
                </div>
              </div>

              {/* 右側：人員與專案資訊 */}
              <div className="space-y-6">
                <div className="bg-green-50 rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <User className="text-green-600" size={20} />
                    <h4 className="font-medium text-gray-900">指派人員</h4>
                  </div>
                  <div className="ml-8">
                    <p className="text-lg font-semibold text-gray-800">
                      {assigneeName || (mission.assigneeId ? `用戶 ${mission.assigneeId}` : "未指派")}
                    </p>
                    {mission.assigneeId && (
                      <p className="text-sm text-gray-500 mt-1">用戶ID: {mission.assigneeId}</p>
                    )}
                  </div>
                </div>

                <div className="bg-purple-50 rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Building className="text-purple-600" size={20} />
                    <h4 className="font-medium text-gray-900">所屬專案</h4>
                  </div>
                  <div className="ml-8">
                    <p className="text-lg font-semibold text-gray-800">
                      {projectName || (mission.projectId ? `載入中...` : "未指定專案")}
                    </p>
                    {mission.projectId && (
                      <p className="text-sm text-gray-500 mt-1">專案 ID: {mission.projectId}</p>
                    )}
                  </div>
                </div>

                {/* QA 簽核資訊 */}
                {mission.qaSignedByUserId && (
                  <div className="bg-emerald-50 rounded-lg p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <CheckCircle className="text-emerald-600" size={20} />
                      <h4 className="font-medium text-gray-900">QA 簽核人員</h4>
                    </div>
                    <div className="ml-8">
                      <p className="text-lg font-semibold text-gray-800">
                        {qaSignedByName || `載入中...`}
                      </p>
                      <p className="text-sm text-gray-500 mt-1">ID: {mission.qaSignedByUserId}</p>
                      {mission.qaSignedAt && (
                        <p className="text-sm text-gray-500 mt-1">
                          簽核時間: {formatDate(mission.qaSignedAt)}
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* 返回按鈕 */}
        <div className="mt-8">
          <Link
            href="/missions"
            className="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium transition-colors"
          >
            ← 返回任務列表
          </Link>
        </div>
      </div>
    </div>
  );
}
