"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import MissionForm, { MissionFormData } from "../../components/MissionForm";

export default function EditMissionPage() {
  const { id } = useParams();
  const router = useRouter();
  const { canManageMissions, isAuthenticated, isLoading } = useAuth();

  const [loading, setLoading] = useState(true);
  const [mission, setMission] = useState<MissionFormData | null>(null);
  const [qaSignInfo, setQaSignInfo] = useState<{
    qaSignedByUserId?: number;
    qaSignedAt?: string;
  }>({});

  // 權限檢查
  useEffect(() => {
    // 等待 loading 完成再檢查權限
    if (isLoading) return;
    
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }
    if (!canManageMissions()) {
      alert('您沒有權限編輯任務');
      router.push('/missions');
      return;
    }
  }, [isLoading, isAuthenticated, canManageMissions, router]);

  // 取得任務詳細資料
  useEffect(() => {
    async function fetchMission() {
      const token = localStorage.getItem("token");

      try {
        const res = await fetch(`http://localhost:4000/api/missions/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        const json = await res.json();

        console.log("取得任務資料:", json);

        if (json.success) {
          // 轉換日期格式為 YYYY-MM-DD
          const formatDate = (dateStr: string) => {
            if (!dateStr) return "";
            const date = new Date(dateStr);
            return date.toISOString().split('T')[0];
          };

          setMission({
            projectId: json.data.projectId?.toString() || "",
            title: json.data.title,
            desc: json.data.description,
            status: json.data.status,
            priority: json.data.priority,
            start: formatDate(json.data.startDate),
            end: formatDate(json.data.dueDate),
            rd: json.data.assigneeId?.toString() || "",
          });
          
          // 儲存 QA 簽核資訊
          setQaSignInfo({
            qaSignedByUserId: json.data.qaSignedByUserId,
            qaSignedAt: json.data.qaSignedAt,
          });
        }

        setLoading(false);
      } catch (error) {
        console.error("❌ 載入任務失敗:", error);
        setLoading(false);
      }
    }

    fetchMission();
  }, [id]);

  // 更新任務
  const handleUpdate = async (form: MissionFormData) => {
    const token = localStorage.getItem("token");

    const payload = {
      title: form.title,
      description: form.desc,
      status: form.status,
      priority: form.priority,
      startDate: form.start || null,
      dueDate: form.end || null,
      assigneeId: Number(form.rd) || null,
    };

    const res = await fetch(`http://localhost:4000/api/missions/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
    });

    const json = await res.json();
    console.log("更新結果:", json);

    if (json.success) {
      alert("任務更新成功！");
      router.push('/missions'); // ⭐ 跳回任務列表頁
    } else {
      alert("更新失敗：" + json.message);
    }
  };

  if (loading) return <p className="p-8">載入中...</p>;
  if (!mission) return <p className="p-8">找不到任務</p>;

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">編輯任務</h1>

      {/* QA 簽核資訊 */}
      {qaSignInfo.qaSignedByUserId && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
          <h3 className="text-lg font-semibold text-green-800 mb-2">✅ QA 已簽核</h3>
          <div className="text-sm text-green-700">
            <p>簽核人員 ID: {qaSignInfo.qaSignedByUserId}</p>
            {qaSignInfo.qaSignedAt && (
              <p>簽核時間: {new Date(qaSignInfo.qaSignedAt).toLocaleString('zh-TW')}</p>
            )}
          </div>
        </div>
      )}

      <MissionForm
        submitText="更新任務"
        initialData={mission}
        onSubmit={handleUpdate}
      />
    </div>
  );
}
