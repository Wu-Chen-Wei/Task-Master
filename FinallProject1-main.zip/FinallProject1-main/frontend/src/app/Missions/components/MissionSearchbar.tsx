'use client';

import React, { useState, useEffect } from 'react';
import { Search, ChevronDown, Filter } from 'lucide-react';
import Link from 'next/link';

interface MissionSearchbarProps {
  onSearchChange?: (value: string) => void;
  onStatusChange?: (status: string) => void;
  statusList?: string[];
}

export default function MissionSearchbar({
  onSearchChange,
  onStatusChange,
  statusList = ['Open', 'In Progress', 'Closed', 'Reopened','Testing'],
}: MissionSearchbarProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusOpen, setStatusOpen] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState('全部狀態');

  // 🔍 Debounce search
  useEffect(() => {
    const delay = setTimeout(() => {
      onSearchChange?.(searchTerm.trim());
    }, 300);
    return () => clearTimeout(delay);
  }, [searchTerm]);

  const handleSelect = (status: string) => {
    setSelectedStatus(status);
    setStatusOpen(false);
    onStatusChange?.(status);
  };

  return (
    <div className="card-base flex items-center justify-between p-3">

      {/* 🔍 搜尋框 */}
      <div className="relative flex-1 max-w-sm mr-4">
        <Search
          size={18}
          className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
        />
        <input
          type="text"
          placeholder="搜尋任務或描述"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full h-10 pl-10 pr-4 bg-gray-100 text-gray-800 rounded-lg
                     focus:outline-none focus:ring-2 focus:ring-blue-400"
        />
      </div>

      {/* 🔽 狀態下拉 */}
      <div className="relative mr-4">
        <button
          onClick={() => setStatusOpen((p) => !p)}
          className="flex items-center h-10 px-4 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
        >
          <Filter size={18} className="mr-2 text-gray-500" />
          {selectedStatus}
          <ChevronDown size={16} className="ml-2 text-gray-500" />
        </button>

        {statusOpen && (
          <div className="absolute right-0 mt-1 w-40 bg-white border rounded-md shadow-lg z-10">
            {['全部狀態', ...statusList].map((st) => (
              <button
                key={st}
                onClick={() => handleSelect(st)}
                className={`block w-full text-left px-4 py-2 text-sm hover:bg-blue-50 ${
                  selectedStatus === st ? 'bg-blue-100 font-medium' : ''
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ⭐ 新增任務按鈕（保留） */}
      <Link
        href="/missions/create"
        className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 whitespace-nowrap"
      >
       新增任務
      </Link> 

    </div>
  );
}



