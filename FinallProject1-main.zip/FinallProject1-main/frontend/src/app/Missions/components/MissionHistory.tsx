"use client";
import { useEffect, useState } from "react";
import { MessageSquare } from "lucide-react";

export default function MissionHistory({ missionId }: { missionId: string }) {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    fetch(`/api/missions/${missionId}/history`)
      .then((r) => r.json())
      .then((res) => setLogs(res.data || []));
  }, [missionId]);

  return (
    <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 max-h-[480px] overflow-y-auto">
      <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <MessageSquare size={18} /> 歷史紀錄
      </h2>
      <ul className="space-y-4">
        {logs.map((log: any) => (
          <li key={log.id} className="border rounded-lg p-3">
            <p className="font-semibold">{log.status}</p>
            <p className="text-sm">{log.action}</p>
            <p className="text-xs text-gray-500 mt-1">
              操作人：{log.user}　日期：{new Date(log.date).toLocaleDateString()}
            </p>
          </li>
        ))}
      </ul>
    </div>
  );
}

