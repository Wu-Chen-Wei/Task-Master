"use client";
import { useEffect, useState } from "react";
import { UserCircle } from "lucide-react";

export default function MissionMembers({ missionId }: { missionId: string }) {
  const [members, setMembers] = useState([]);

  useEffect(() => {
    fetch(`/api/missions/${missionId}/members`)
      .then((r) => r.json())
      .then((res) => setMembers(res.data || []));
  }, [missionId]);

  return (
    <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
      <h2 className="text-lg font-semibold mb-4">成員</h2>
      <div className="grid grid-cols-2 gap-4">
        {members.map((m: any) => (
          <div key={m.id} className="flex items-center gap-3 p-4 border rounded-lg">
            <UserCircle size={40} className="text-gray-500" />
            <div>
              <p className="font-semibold">{m.name}</p>
              <p className="text-xs text-gray-500">{m.role}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}


