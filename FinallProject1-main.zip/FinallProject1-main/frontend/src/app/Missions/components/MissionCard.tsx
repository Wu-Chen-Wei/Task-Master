"use client";

import { Calendar, User, Edit, Trash2, CheckCircle, UserCheck, Building } from "lucide-react";
import Link from "next/link";
import { useAuth } from "@/hooks/useAuth";
import { createApiUrl, createDynamicEndpoint } from "@/lib/api";


interface MissionCardProps {
  mission: any;
  assigneeName?: string;
  projectName?: string;
}

export default function MissionCard({ mission, assigneeName = "", projectName = "" }: MissionCardProps) {
  const { isRDLeader, isRD, isQA, isAdmin, user } = useAuth();

  const statusColors: any = {
    Open: "bg-green-100 text-green-700",
    "In Progress": "bg-blue-100 text-blue-700",
    Testing: "bg-purple-100 text-purple-700",
    Reopened: "bg-red-100 text-red-700",
    Closed: "bg-gray-200 text-gray-600",
  };

  const priorityColors: any = {
    Critical: "bg-red-100 text-red-700",
    High: "bg-orange-100 text-orange-700",
    Medium: "bg-yellow-100 text-yellow-700",
    Low: "bg-gray-100 text-gray-500",
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return "-";
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  // 刪除處理
  const handleDelete = async () => {
    if (!confirm(`確定要刪除任務「${mission.title}」嗎？`)) return;

    try {
      const token = localStorage.getItem("token");
      const res = await fetch(createApiUrl(createDynamicEndpoint.missionById(mission.id)), {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.ok) {
        alert("任務已刪除");
        window.location.reload();
      } else {
        const data = await res.json();
        alert("刪除失敗：" + (data.message || "未知錯誤"));
      }
    } catch (error) {
      alert("刪除任務失敗");
    }
  };

  // QA 簽核
  const handleSign = async () => {
    if (!confirm(`確定要簽核任務「${mission.title}」嗎？`)) return;

    try {
      const token = localStorage.getItem("token");
      const res = await fetch(createApiUrl(createDynamicEndpoint.missionSign(mission.id)), {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.ok) {
        alert("任務已簽核關閉");
        window.location.reload();
      } else {
        const data = await res.json();
        alert("簽核失敗：" + (data.message || "未知錯誤"));
      }
    } catch (error) {
      alert("簽核失敗");
    }
  };

  // 指派給 QA
  const handleAssignToQA = async () => {
    const qaUserId = prompt('請輸入 QA 使用者 ID:');
    if (!qaUserId) return;

    try {
      const token = localStorage.getItem("token");
      const res = await fetch(createApiUrl(createDynamicEndpoint.missionAssignQA(mission.id)), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ qaUserId: Number(qaUserId) }),
      });

      if (res.ok) {
        alert("已指派給 QA 驗證");
        window.location.reload();
      } else {
        const data = await res.json();
        alert("指派失敗：" + (data.message || "未知錯誤"));
      }
    } catch (error) {
      alert("指派失敗");
    }
  };

  return (
    <div className="bg-white border rounded-lg shadow p-5 hover:shadow-lg transition">
      {/* 狀態和按鈕列 */}
      <div className="flex justify-between items-start mb-2">
        <div className="flex gap-2">
          <span
            className={`px-2 py-1 rounded text-xs font-semibold ${
              statusColors[mission.status] || "bg-gray-100 text-gray-500"
            }`}
          >
            {mission.status}
          </span>

          <span
            className={`px-2 py-1 rounded text-xs font-semibold ${
              priorityColors[mission.priority] || "bg-gray-100 text-gray-500"
            }`}
          >
            {mission.priority}
          </span>
        </div>

        {/* 按鈕區域 */}
        <div className="flex gap-1">
          {/* 編輯按鈕 */}
          <Link
            href={`/missions/${mission.id}/edit`}
            className="p-1 hover:bg-gray-100 rounded"
            title="編輯任務"
          >
            <Edit size={14} className="text-blue-500" />
          </Link>

          {/* QA 簽核按鈕 */}
          {isQA() && mission.status === 'Testing' && (
            <button
              onClick={handleSign}
              className="p-1 hover:bg-gray-100 rounded"
              title="QA 簽核關閉"
            >
              <CheckCircle size={14} className="text-green-500" />
            </button>
          )}

          {/* RD 指派給 QA */}
          {(isRD() || isRDLeader() || isAdmin()) && mission.status === 'In Progress' && (
            <button
              onClick={handleAssignToQA}
              className="p-1 hover:bg-gray-100 rounded"
              title="指派給 QA 驗證"
            >
              <UserCheck size={14} className="text-purple-500" />
            </button>
          )}

          {/* 刪除按鈕（RDL 和 Admin 可刪除） */}
          {(isRDLeader() || isAdmin()) && (
            <button
              onClick={handleDelete}
              className="p-1 hover:bg-gray-100 rounded"
              title="刪除任務"
            >
              <Trash2 size={14} className="text-red-500" />
            </button>
          )}
        </div>
      </div>

      {/* 可點擊的內容區域 */}
      <Link href={`/missions/${mission.id}`} className="block">
        <h2 className="text-lg font-bold hover:text-blue-600">
          {mission.title}
        </h2>
        <p className="text-gray-600 text-sm mt-1 line-clamp-2">
          {mission.description}
        </p>

        {/* 專案資訊 */}
        <div className="mt-3 p-2 bg-gray-50 rounded">
          <div className="flex items-center gap-2 text-sm">
            <Building size={14} className="text-purple-500" />
            <span className="text-gray-600">專案:</span>
            <span className="font-medium text-gray-800">
              {projectName || (mission.projectId ? `專案 ${mission.projectId}` : "未指派專案")}
            </span>
          </div>
        </div>

        <div className="border-t mt-3 pt-2 text-sm space-y-2">
          <div className="flex items-center gap-2 text-gray-700">
            <Calendar size={16} />
            <span>{formatDate(mission.startDate)} → </span>
            <span className="text-red-500">{formatDate(mission.dueDate)}</span>
          </div>

          <div className="flex items-center gap-2 text-gray-700">
            <User size={16} className="text-blue-500" />
            <span>指派給:</span>
            <span className="font-medium">
              {assigneeName || (mission.assigneeId ? `用戶 ${mission.assigneeId}` : "未指派")}
            </span>
          </div>
        </div>
      </Link>
    </div>
  );
}