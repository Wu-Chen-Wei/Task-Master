export default function MissionTabs({ activeTab, setActiveTab }: any) {
  const tabs = [
    { key: "info", label: "基本資訊" },
    { key: "attachments", label: "附件" },
    { key: "members", label: "成員" },
    { key: "history", label: "歷史紀錄" },
  ];

  return (
    <div className="flex gap-4 border-b">
      {tabs.map((tab) => (
        <button
          key={tab.key}
          onClick={() => setActiveTab(tab.key)}
          className={`py-2 px-4 ${
            activeTab === tab.key
              ? "border-b-2 border-blue-500 text-blue-500"
              : "text-gray-500"
          }`}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}
