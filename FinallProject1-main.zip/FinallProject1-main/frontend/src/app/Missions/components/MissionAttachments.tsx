"use client";
import { useEffect, useState } from "react";
import { Download, Trash2, Paperclip } from "lucide-react";

export default function MissionAttachments({ missionId }: { missionId: string }) {
  const [files, setFiles] = useState([]);

  useEffect(() => {
    fetch(`/api/missions/${missionId}/attachments`)
      .then((r) => r.json())
      .then((res) => setFiles(res.data || []));
  }, [missionId]);

  const handleDownload = (fileId: string) => {
    window.open(`/api/attachments/${fileId}/download`, "_blank");
  };

  const handleDelete = async (fileId: string) => {
    if (!confirm("確定刪除此附件？")) return;
    await fetch(`/api/attachments/${fileId}`, { method: "DELETE" });
    setFiles((prev) => prev.filter((f: any) => f.id !== fileId));
  };

  return (
    <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
      <div className="flex items-center gap-2 mb-4">
        <Paperclip size={20} className="text-gray-700" />
        <h2 className="text-lg font-semibold text-gray-800">附件</h2>
      </div>

      <table className="w-full text-sm border-collapse">
        <thead>
          <tr className="border-b border-gray-400">
            <th className="py-2 text-left w-[40%]">名稱</th>
            <th className="text-left w-[20%]">上傳者</th>
            <th className="text-left w-[20%]">上傳日期</th>
            <th className="text-left w-[20%]">操作</th>
          </tr>
        </thead>
        <tbody>
          {files.map((f: any) => (
            <tr key={f.id} className="border-b hover:bg-gray-50">
              <td>{f.name}</td>
              <td>{f.uploader}</td>
              <td>{new Date(f.uploadedAt).toLocaleDateString()}</td>
              <td>
                <div className="flex gap-4">
                  <button onClick={() => handleDownload(f.id)}>
                    <Download size={18} />
                  </button>
                  <button onClick={() => handleDelete(f.id)}>
                    <Trash2 size={18} className="text-red-500" />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}


