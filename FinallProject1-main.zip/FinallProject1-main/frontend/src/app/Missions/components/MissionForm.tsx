"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";

export interface MissionFormData {
  projectId: string;  // ✅ 新增這個
  title: string;
  desc: string;
  status: string;
  priority: string;
  start: string;
  end: string;
  rd: string;
}

interface User {
  UserID: number;
  Name?: string;
  FullName?: string;
  Title?: string;
  Roles?: string[] | string;
  Role?: string;
}

// ✅ 新增 Project 介面
interface Project {
  projectID: string;
  projectName: string;
  description: string;
}

interface MissionFormProps {
  submitText: string;
  onSubmit: (data: MissionFormData) => void;
  initialData?: Partial<MissionFormData>;
}

export default function MissionForm({ submitText, onSubmit, initialData }: MissionFormProps) {
  const { isRD, isQA } = useAuth();
  
  const [form, setForm] = useState<MissionFormData>({
    projectId: "",
    title: "",
    desc: "",
    status: "Open",
    priority: "Medium",
    start: "",
    end: "",
    rd: "",
  });

  // 當 initialData 變更時更新表單
  useEffect(() => {
    if (initialData) {
      setForm({
        projectId: initialData.projectId || "",
        title: initialData.title || "",
        desc: initialData.desc || "",
        status: initialData.status || "Open",
        priority: initialData.priority || "Medium",
        start: initialData.start || "",
        end: initialData.end || "",
        rd: initialData.rd || "",
      });
    }
  }, [initialData]);

  const [users, setUsers] = useState<User[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [projectsLoading, setProjectsLoading] = useState(true);

  // 載入專案和用戶資料
  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        setLoading(false);
        setProjectsLoading(false);
        return;
      }

      try {
        // 並行載入專案和用戶資料
        const [projectsRes, usersRes] = await Promise.all([
          fetch("http://localhost:4000/api/v1/projects", {
            headers: { Authorization: `Bearer ${token}` },
          }),
          fetch("http://localhost:4000/api/users/team-members", {
            headers: { Authorization: `Bearer ${token}` },
          })
        ]);

        // 處理專案資料
        if (projectsRes.ok) {
          const projectJson = await projectsRes.json();
          if (projectJson.success && projectJson.data && Array.isArray(projectJson.data)) {
            setProjects(projectJson.data);
          }
        }

        // 處理用戶資料
        if (usersRes.ok) {
          const userJson = await usersRes.json();
          let usersArray: User[] = [];
          
          if (userJson.data && Array.isArray(userJson.data)) {
            usersArray = userJson.data;
          } else if (userJson.users && Array.isArray(userJson.users)) {
            usersArray = userJson.users;
          } else if (Array.isArray(userJson)) {
            usersArray = userJson;
          }
          
          setUsers(usersArray);
        }
      } catch (error) {
        console.error("❌ 載入資料失敗:", error);
      } finally {
        setLoading(false);
        setProjectsLoading(false);
      }
    };

    fetchData();
  }, []);

  // 根據當前使用者角色決定要顯示的使用者列表
  const assignableUsers = users.filter((user) => {
    let roles: string[] = [];
    
    if (Array.isArray(user.Roles)) {
      roles = user.Roles;
    } else if (typeof user.Roles === 'string') {
      roles = [user.Roles];
    } else if (typeof user.Role === 'string') {
      roles = [user.Role];
    }
    
    // 如果當前使用者是 RD，只顯示 QA
    if (isRD()) {
      const hasQARole = roles.some((role) => {
        const r = role.toLowerCase();
        return r.includes("qa");
      });
      if (hasQARole) return true;
      
      if (user.Title) {
        const title = user.Title.toLowerCase();
        return title.includes("qa");
      }
      return false;
    }
    
    // 如果是其他角色（RDL/Admin），顯示 RD
    if (roles.length > 0) {
      const hasRDRole = roles.some((role) => {
        const r = role.toLowerCase();
        return r.includes("developer") || r.includes("rd");
      });
      if (hasRDRole) return true;
    }
    
    if (user.Title) {
      const title = user.Title.toLowerCase();
      return title.includes("developer") || title.includes("rd");
    }
    
    return false;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // ✅ 驗證專案是否選擇
    if (!form.projectId) {
      alert("請選擇專案!");
      return;
    }
    
    onSubmit(form);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* ✅ 新增:選擇專案 */}
      <div>
        <label className="block font-medium mb-2">所屬專案 <span className="text-red-500">*</span></label>
        {projectsLoading ? (
          <p className="text-gray-500">載入專案中...</p>
        ) : projects.length === 0 ? (
          <p className="text-red-500">⚠️ 無法載入專案列表</p>
        ) : (
          <select
            value={form.projectId}
            onChange={(e) => setForm({ ...form, projectId: e.target.value })}
            className="w-full border px-3 py-2 rounded"
            required
          >
            <option value="">請選擇專案</option>
            {projects.map((project) => (
              <option key={project.projectID} value={project.projectID}>
                {project.projectName}
              </option>
            ))}
          </select>
        )}
      </div>

      {/* 標題 */}
      <div>
        <label className="block font-medium mb-2">任務標題</label>
        <input
          type="text"
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          className="w-full border px-3 py-2 rounded"
          required
        />
      </div>

      {/* 描述 */}
      <div>
        <label className="block font-medium mb-2">描述</label>
        <textarea
          value={form.desc}
          onChange={(e) => setForm({ ...form, desc: e.target.value })}
          className="w-full border px-3 py-2 rounded"
          rows={4}
        />
      </div>

      {/* 狀態 */}
      <div>
        <label className="block font-medium mb-2">狀態</label>
        <select
          value={form.status}
          onChange={(e) => setForm({ ...form, status: e.target.value })}
          className="w-full border px-3 py-2 rounded"
        >
          <option value="Open">待處理</option>
          <option value="In Progress">進行中</option>
          <option value="Testing">測試中</option>
          <option value="Reopened">重新開啟</option>
          <option value="Closed">已關閉</option>
        </select>
      </div>

      {/* 優先度 */}
      <div>
        <label className="block font-medium mb-2">優先度</label>
        <select
          value={form.priority}
          onChange={(e) => setForm({ ...form, priority: e.target.value })}
          className="w-full border px-3 py-2 rounded"
        >
          <option value="Low">低</option>
          <option value="Medium">中等</option>
          <option value="High">高</option>
          <option value="Critical">緊急</option>
        </select>
      </div>

      {/* 開始日期 */}
      <div>
        <label className="block font-medium mb-2">開始日期</label>
        <input
          type="date"
          value={form.start}
          onChange={(e) => setForm({ ...form, start: e.target.value })}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      {/* 結束日期 */}
      <div>
        <label className="block font-medium mb-2">結束日期</label>
        <input
          type="date"
          value={form.end}
          onChange={(e) => setForm({ ...form, end: e.target.value })}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      {/* 指派給使用者 - QA 不顯示此欄位 */}
      {!isQA() && (
        <div>
          <label className="block font-medium mb-2">
            指派給{isRD() ? '(QA)' : '(RD)'}
          </label>
          {loading ? (
            <p className="text-gray-500">載入中...</p>
          ) : assignableUsers.length === 0 ? (
            <p className="text-orange-500">
              ⚠️ 沒有找到 {isRD() ? 'QA' : 'RD'} 使用者
            </p>
          ) : (
            <select
              value={form.rd}
              onChange={(e) => setForm({ ...form, rd: e.target.value })}
              className="w-full border px-3 py-2 rounded"
            >
              <option value="">
                請選擇 {isRD() ? 'QA' : 'RD'} ({assignableUsers.length} 位)
              </option>
              {assignableUsers.map((user) => (
                <option key={user.UserID} value={user.UserID}>
                  {user.FullName || user.Name} — {user.Title || user.Roles}
                </option>
              ))}
            </select>
          )}
        </div>
      )}

      <button
        type="submit"
        className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600"
      >
        {submitText}
      </button>
    </form>
  );
}