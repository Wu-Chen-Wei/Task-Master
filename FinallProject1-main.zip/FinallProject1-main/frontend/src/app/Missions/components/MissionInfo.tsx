"use client";

import { FileText, User, Calendar, CheckCircle2 } from "lucide-react";

export default function MissionInfo({ mission }: any) {
  return (
    <div className="bg-white p-6 rounded-lg shadow border">

      <div className="flex items-center gap-2 mb-4">
        <FileText size={20} />
        <h2 className="text-lg font-semibold">Mission 基本資訊</h2>
      </div>

      <p className="text-sm text-gray-600 mb-2">任務描述</p>
      <div className="bg-gray-100 p-3 rounded mb-6 text-sm">
        {mission.desc}
      </div>

      <div className="grid grid-cols-2 gap-4 text-sm">
        <div className="flex items-center gap-2">
          <User size={18} />
          <span className="font-medium">開發工程師：</span>
          {mission.rd}
        </div>

        <div className="flex items-center gap-2">
          <Calendar size={18} />
          <span className="font-medium">開始日期：</span>
          {mission.start}
        </div>

        <div className="flex items-center gap-2">
          <CheckCircle2 size={18} />
          <span className="font-medium">狀態：</span>
          {mission.status}
        </div>

        <div className="flex items-center gap-2">
          <Calendar size={18} />
          <span className="font-medium">預計完成：</span>
          {mission.end}
        </div>
      </div>
    </div>
  );
}

