"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Eye, EyeOff } from "lucide-react";

export default function RegisterPage() {
  const router = useRouter();

  // 表單狀態
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    fullName: "",
    title: "",
    notificationEmail: "",
  });

  // UI 狀態
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // 密碼強度檢查
  const getPasswordStrength = (password: string) => {
    if (!password) return { level: 0, text: "", color: "" };

    let strength = 0;
    if (password.length >= 8) strength++;
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
    if (/\d/.test(password)) strength++;
    if (/[!@#$%^&*]/.test(password)) strength++;

    const levels = [
      { level: 1, text: "弱", color: "text-red-500" },
      { level: 2, text: "中等", color: "text-yellow-500" },
      { level: 3, text: "強", color: "text-green-500" },
      { level: 4, text: "非常強", color: "text-green-600" },
    ];

    return levels[strength - 1] || { level: 0, text: "", color: "" };
  };

  const passwordStrength = getPasswordStrength(formData.password);

  // 表單欄位更新
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    setError(""); // 清除錯誤訊息
  };

  // 表單驗證
  const validateForm = () => {
    if (!formData.email) {
      setError("請輸入 Email");
      return false;
    }

    if (!formData.email.includes("@")) {
      setError("Email 格式不正確");
      return false;
    }

    if (!formData.password) {
      setError("請輸入密碼");
      return false;
    }

    if (formData.password.length < 8) {
      setError("密碼至少需要 8 個字元");
      return false;
    }

    if (formData.password !== formData.confirmPassword) {
      setError("兩次輸入的密碼不一致");
      return false;
    }

    if (!formData.fullName) {
      setError("請輸入姓名");
      return false;
    }

    return true;
  };

  // 提交註冊
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);

    try {
      const requestBody = {
        email: formData.email,
        password: formData.password,
        fullName: formData.fullName,
        title: formData.title || undefined,
        notificationEmail: formData.notificationEmail || undefined,
      };

      // ⭐ 加入這些 Log
      console.log("發送註冊請求：", requestBody);
      console.log("URL：", "http://localhost:4000/api/users/register");

      const res = await fetch("http://localhost:4000/api/users/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestBody),
      });

      // ⭐ 加入這個 Log
      console.log("Response Status:", res.status);
      console.log("Response Headers:", res.headers);

      const data = await res.json();

      // ⭐ 加入這個 Log
      console.log("後端回應：", data);

      if (data.success) {
        alert("註冊成功！請前往登入頁面");
        router.push("/login");
      } else {
        setError(data.message || "註冊失敗，請稍後再試");
      }
    } catch (err) {
      console.error("註冊錯誤:", err);
      setError("伺服器連線錯誤，請稍後再試");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        {/* 標題 */}
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">建立新帳號</h2>
          <p className="text-sm text-gray-500 mt-2">填寫以下資訊完成註冊</p>
        </div>

        {/* 錯誤提示 */}
        {error && (
          <div className="bg-red-100 text-red-600 px-4 py-2 rounded mb-4 text-sm">
            {error}
          </div>
        )}

        {/* 註冊表單 */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
              placeholder="your.email@example.com"
              required
              disabled={isLoading}
            />
          </div>

          {/* 姓名 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              姓名 <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
              placeholder="請輸入您的姓名"
              required
              disabled={isLoading}
            />
          </div>

          {/* 職稱（選填） */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              職稱 <span className="text-gray-400 text-xs">(選填)</span>
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
              placeholder="例如：軟體工程師"
              disabled={isLoading}
            />
          </div>
          {/* ✅ 新增：通知 Email（選填） */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              通知 Email <span className="text-gray-400 text-xs">(選填)</span>
            </label>
            <input
              type="email"
              name="notificationEmail"
              value={formData.notificationEmail}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
              placeholder="接收通知的 Email(不填則使用登入 Email)"
              disabled={isLoading}
            />
            <p className="text-xs text-gray-500 mt-1">
              💡 若不填寫,系統將使用您的登入 Email 發送通知
            </p>
          </div>

          {/* 密碼 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              密碼 <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                value={formData.password}
                onChange={handleChange}
                className="w-full border rounded-lg px-3 py-2 pr-10 focus:ring-2 focus:ring-blue-400 focus:outline-none"
                placeholder="至少 8 個字元"
                required
                disabled={isLoading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            {/* 密碼強度提示 */}
            {formData.password && (
              <div className="mt-1 text-xs">
                密碼強度：
                <span className={`font-semibold ${passwordStrength.color}`}>
                  {passwordStrength.text}
                </span>
              </div>
            )}
          </div>

          {/* 確認密碼 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              確認密碼 <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type={showConfirmPassword ? "text" : "password"}
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                className="w-full border rounded-lg px-3 py-2 pr-10 focus:ring-2 focus:ring-blue-400 focus:outline-none"
                placeholder="再次輸入密碼"
                required
                disabled={isLoading}
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showConfirmPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            {/* 密碼一致性提示 */}
            {formData.confirmPassword && (
              <div className="mt-1 text-xs">
                {formData.password === formData.confirmPassword ? (
                  <span className="text-green-600">✓ 密碼一致</span>
                ) : (
                  <span className="text-red-600">✗ 密碼不一致</span>
                )}
              </div>
            )}
          </div>

          {/* 註冊按鈕 */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {isLoading ? "註冊中..." : "註冊"}
          </button>
        </form>

        {/* 登入連結 */}
        <p className="text-center text-sm text-gray-500 mt-4">
          已經有帳號了？{" "}
          <Link href="/login" className="text-blue-600 hover:underline">
            立即登入
          </Link>
        </p>
      </div>
    </div>
  );
}
