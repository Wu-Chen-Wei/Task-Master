"use client";
import Image from "next/image";
import { useState, useEffect } from "react";
import {
  User,    // ⭐ 新增：設定圖示
} from "lucide-react";
import Link from "next/link";


export default function LandingPage() {

  // ========= 輪播狀態 =========
  const [index, setIndex] = useState(0);

  const items = [
    {
      img: "/homepage_image/Dashboard.png",
      title: "All Your Work at a Glance",
      subtitle: "Gain full visibility of your projects, tasks, and performance metrics — all in one clean and intuitive dashboard.",
    },
    {
      img: "/homepage_image/Account.png",
      title: "Manage Teams with Confidence",
      subtitle: "Easily control user roles, permissions, and account settings to ensure your team operates smoothly and securely.",
    },
    {
      img: "/homepage_image/project.png",
      title: "Powerful Project Management Simplified",
      subtitle: "Plan, organize, and track project progress with clarity — from milestones to deliverables, everything stays on track.",
    },
    {
      img: "/homepage_image/notification.png",
      title: "Automation That Works for You",
      subtitle: "Set smart rules and receive timely notifications to reduce manual work and never miss important updates again.",
    },
  ];

    // ========= 自動輪播，每 5 秒切換 =========
  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % items.length);
    }, 10000);
    return () => clearInterval(timer);
  }, [items.length]);

  const prev = () => setIndex((index - 1 + items.length) % items.length);
  const next = () => setIndex((index + 1) % items.length);


  return (
    <div className="w-full h-[3609px] relative bg-white overflow-hidden">

      {/* top bar */}
      <div className="w-full px-10 py-6 absolute inline-flex justify-between items-center">
        <div className="inline-flex gap-2.5">
          <Image className="w-11 h-10" alt="logo background cut" src="/homepage_image/logo_background_cut.png" width={400} height={400}/>
          <div className="w-32 h-5 text-zinc-800 text-2xl font-bold font-['Poppins'] leading-normal tracking-wider">EasyTrack</div>
        </div>
        {/* <div className="p-3 flex justify-center items-center gap-14">
          <button className="justify-start text-zinc-800 text-xs font-normal font-['Poppins'] leading-normal tracking-wider hover:text-cyan-300">CONTACT</button>
          <div className="justify-start text-zinc-800 text-xs font-normal font-['Poppins'] leading-normal tracking-wider">TESTIMONIALS</div>
          <div className="justify-start text-zinc-800 text-xs font-normal font-['Poppins'] leading-normal tracking-wider">ABOUT</div>
          <div className="justify-start text-zinc-800 text-xs font-normal font-['Poppins'] leading-normal tracking-wider">TEAMS</div>
        </div> */}
        <Link
          href="/login"
          className="px-5 py-2.5 bg-cyan-300 rounded-[10px] flex justify-center hover:bg-cyan-400 gap-2"
          >
          <User size={24} /> <div className="w-full flex text-blue-600 hover:text-blue-800 font-medium">Login In</div>
        </Link>
      </div>

      {/* first section */}
      <div className="w-full top-[100px] absolute">
        <div className="w-full h-[900px] flex justify-between items-center px-12">
          {/* 左邊：文字 + 按鈕 */}
          <div className="w-[600px] flex flex-col justify-start gap-10">
            <div className="text-sky-900 text-8xl font-bold font-['Playfair_Display'] leading-[108px] tracking-widest">
              Your Best <br/>Project <br/>Management
            </div>
            <div className="text-neutral-600 text-2xl font-medium font-['Plus_Jakarta_Sans'] leading-9 tracking-wide">
              We are here to help you take care of your project with the best service especially for you.
            </div>
            <button className="w-48 h-20 px-9 py-7 bg-sky-900 rounded-lg inline-flex justify-center hover:bg-sky-800">
              <Link href="/register">
              <div className="text-stone-50 text-base font-bold font-['Plus_Jakarta_Sans']">
                GET STARTED
              </div>
              </Link>
            </button>
          </div>

          {/* 右邊：兩個重疊的圓 */}
          <div className="relative w-[811px] h-[811px] pl-50 shrink-0">
            <Image src="/homepage_image/notification_report1.png" width={600} height={600} alt="notification report" className="absolute top-50 left-50 z-10" />
            <div className="w-[811px] h-[811px] bg-blue-400/10 rounded-full absolute"/>
            <div className="w-[633.21px] h-[633.21px] bg-blue-400/10 rounded-full absolute right-70" />
            
          </div>

        </div>
      </div>

      {/* Why choose us */}
      <div className="w-full h-[700px] px-40 py-32 top-[1024px] absolute bg-sky-50 inline-flex flex-col justify-between items-center">
        <div className="w-[714px] flex flex-col gap-6">
          <div className="text-center text-black/50 text-5xl font-semibold font-['SF_Pro_Display'] leading-[56px]">Why you choose us?</div>
          <div className="p-1 flex flex-col">
            <div className="text-center text-slate-600 text-base font-medium font-['Plus_Jakarta_Sans'] leading-tight tracking-wide">With the core concept of lightweight, transparent, and easy to use, it allows teams to effectively manage projects and issues in the shortest time.</div>
          </div>
        </div>
        <div className="inline-flex gap-8">
          <div className="w-64 h-64 p-6 bg-neutral-50 rounded-lg shadow-[0px_18px_58px_16px_rgba(0,0,0,0.06)] inline-flex flex-colt gap-4">
            <div className="flex flex-col gap-2.5">
              <Image src="/homepage_image/Centralized.png" width={50} height={50} alt="Centralized management"/>
              <div className="w-44 text-neutral-700 text-xl font-bold font-['Playfair_Display'] leading-snug tracking-wide">Centralized management</div>
              <div className="w-52 text-neutral-400 text-sm font-normal font-['Plus_Jakarta_Sans'] leading-normal tracking-tight">Projects, tasks, and member information are integrated into a single platform.</div>
            </div>
          </div>
          <div className="w-64 h-64 p-6 bg-neutral-50 rounded-lg shadow-[0px_18px_58px_16px_rgba(0,0,0,0.06)] inline-flex flex-col gap-4">
            <div className="flex flex-col gap-2.5">
              <Image src="/homepage_image/Instant.png" width={48} height={48} alt="Instant collaboration"/>
              <div className="w-64 text-neutral-700 text-xl font-bold font-['Playfair_Display'] leading-snug tracking-wide">Instant<br/>collaboration</div>
              <div className="w-52 text-neutral-400 text-sm font-normal font-['Plus_Jakarta_Sans'] leading-normal tracking-tight">Task status transfer and notification reminders reduce communication gaps.<br/></div>
            </div>
          </div>
          <div className="w-64 h-64 p-6 bg-neutral-50 rounded-lg shadow-[0px_18px_58px_16px_rgba(0,0,0,0.06)] inline-flex flex-col gap-4">
            <div className="flex flex-col gap-8">
              <Image src="/homepage_image/Visual.png" width={50} height={50} alt="Visual tracking"/>
              <div className="text-neutral-700 text-xl font-bold font-['Playfair_Display'] leading-snug">Visual tracking</div>
              <div className="w-56 text-neutral-400 text-sm font-normal font-['Plus_Jakarta_Sans'] leading-normal tracking-tight">Dashboards and reports make progress clear at a glance.</div>
            </div>
          </div>
          <div className="w-64 h-64 p-6 bg-neutral-50 rounded-lg shadow-[0px_18px_58px_16px_rgba(0,0,0,0.06)] inline-flex flex-col gap-4">
            
            <div className="flex flex-col gap-8">
              <Image src="/homepage_image/Lower.png" width={50} height={50} alt="Lower cost support"/>
              <div className=" text-neutral-700 text-xl font-bold font-['Playfair_Display'] leading-snug">Lower cost support</div>
              <div className="w-56 text-neutral-400 text-sm font-normal font-['Plus_Jakarta_Sans'] leading-normal tracking-tight">Lightweight architecture, quick start, suitable for small and medium-sized teams.<br/></div>
            </div>
          </div>
        </div>
      </div>

      

      

      {/* Timeline */}
      <div className="w-full h-[500px] left-[3px] top-[2166px] absolute inline-flex justify-center items-center gap-16 bg-sky-50">
        <div className="w-[590px] py-10 bg-white/0 flex">
          <div className="flex-1 flex items-center gap-px">

            {/* Step 1 */}
            <div className="w-80 relative flex items-center gap-px">
              <div className="p-2.5 inline-flex flex-col items-center gap-2.5">
                <div className="w-12 h-12 flex justify-center items-center rounded-full bg-green-500 text-white animate-pulse text-2xl">
                  ✓
                </div>
                <div className="text-black text-lg font-normal font-['Microsoft_YaHei']">Create</div>
                <div className="text-black text-lg font-normal font-['Microsoft_YaHei']">2023-11-28</div>
              </div>

              <div className="flex-1 h-0 outline-1 outline-offset-[-0.50px] outline-black" />

              {/* Step 2 */}
              <div className="p-2.5 inline-flex flex-col items-center gap-2.5">
                <div className="w-12 h-12 flex justify-center items-center rounded-full bg-red-500 text-white animate-pulse text-2xl">
                  ✓
                </div>
                <div className="text-black text-lg font-normal font-['Microsoft_YaHei']">In Program</div>
                <div className="text-black text-lg font-normal font-['Microsoft_YaHei']">2023-12-01</div>
              </div>
            </div>

            <div className="w-24 h-0 outline-1 outline-offset-[-0.50px] outline-black"></div>

            {/* Step 3 (Clock) */}
            <div className="p-2.5 inline-flex flex-col items-center gap-2.5">
              <div className="w-12 h-12 flex justify-center items-center rounded-full bg-gray-500 text-white animate-pulse text-2xl">
                🕒
              </div>
              <div className="text-black text-lg font-normal font-['Microsoft_YaHei']">Finish</div>
              <div className="text-black text-lg font-normal font-['Microsoft_YaHei']">2023-12-10</div>
            </div>

          </div>
        </div>

        <div className="w-[540px] flex flex-col items-center gap-6">
          {/* 對話框 */}
          <div className="relative w-[476px] bg-white rounded-xl shadow-md p-6 animate-bubbleBreathing">
            <div className="text-zinc-800 text-lg font-medium font-['Poppins'] leading-7 text-center">
              Management, Tracking, and Team Collaboration
            </div>
            <div className="mt-2 text-neutral-600 text-sm font-normal font-['Poppins'] leading-normal tracking-wide text-center">
              EasyTrack is different from other large-scale project management systems. Its lightweight and visual design allows us to operate with minimal time and cost, and team collaboration is also smoother. It is a highly practical platform.
            </div>

            {/* 箭頭 */}
            <div className="absolute bottom-[-16px] left-1/2 transform -translate-x-1/2 
              w-0 h-0 border-l-[16px] border-r-[16px] border-t-[16px]
              border-l-transparent border-r-transparent border-t-white
              animate-arrowBounceSoft">
            </div>
          </div>

          {/* 頭像 + 姓名 */}
          <div className="inline-flex justify-start items-center gap-4">
            <Image className="w-14 h-14 rounded-full" width={200} height={200} alt="User" src="/homepage_image/user.jpg" />
            <div className="flex flex-col">
              <div className="text-neutral-900 text-lg font-bold font-['Inter'] leading-7">Sri Alam</div>
              <div className="text-zinc-800 text-sm font-normal font-['Inter'] leading-normal">
                CEO, Small and medium enterprises
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full h-120 left-0 top-[1724px] absolute overflow-hidden">
        <div className="w-full h-182 left-0 top-0 absolute bg-sky-900" />
        
      </div>

      {/* 數據統計 */}
      <div className="w-full top-[1800px] absolute inline-flex flex-col ">
        <div className="w-full flex justify-center relative">

      {/* ← 左右按鈕 → */}
      <button
        onClick={prev}
        className="absolute left-5 top-1/2 -translate-y-1/2 text-white text-3xl font-bold"
      >
        ‹
      </button>

      <button
        onClick={next}
        className="absolute right-5 top-1/2 -translate-y-1/2 text-white text-3xl font-bold"
      >
        ›
      </button>

      {/* ===== 輪播內容容器 ===== */}
      <div className="w-full max-w-6xl flex overflow-hidden relative">

        {/* ------------------ 每一頁 ------------------ */}
        {items.map((item, i) => (
          <div
            key={i}
            className="min-w-full flex flex-col lg:flex-row items-between transition-all duration-700 gap-20"
            style={{ transform: `translateX(${-index * 100}%)` }}
          >

            {/* 左側圖片 */}
            <div className="w-full lg:w-1/2 flex justify-center mb-10 lg:mb-0">
              <Image
                src={item.img}
                width={800}
                height={800}
                alt="stats image"
                className="rounded-2xl shadow-lg"
              />
            </div>

            {/* 右側你的文字（完全不動你原本內容） */}
            <div className="w-full lg:w-1/2 flex flex-col items-center lg:items-start">

              {/* 標題（保留你全部font設定） */}
              <div className="w-full text-center lg:text-left text-white text-5xl font-black font-['Playfair_Display'] leading-[64px] tracking-tight">
                {item.title}
              </div>

              {/* 子標題 */}
              <div className="text-center lg:text-left text-white text-lg font-normal font-['Poppins'] leading-loose tracking-wide mt-2">
                {item.subtitle}
              </div>

            </div>
          </div>
        ))}

      </div>
    </div>
      </div>

      {/* Partners Section */}
      <div className="w-full h-96 top-[2735px] absolute bg-white inline-flex flex-col justify-center gap-2">
        <div className="flex flex-col items-center gap-9">
          <div className="flex flex-col gap-2.5">
            <div className="self-stretch p-1 flex flex-col">
              <div className="text-center text-blue-950 text-5xl font-extrabold font-['Playfair'] leading-[54.72px] tracking-wide">Partners</div>
            </div>
            <div className="p-1 flex flex-col">
              <div className="text-center text-blue-800 text-xl font-extrabold font-['Playfair'] leading-snug tracking-wide">Integrate diverse global communication software</div>
            </div>
          </div>
          <div className="w-96 h-0 outline-1 outline-offset-[-0.50px] outline-zinc-300"></div>
        </div>
        <div className="mb-5 inline-flex">
          <div className="relative w-full py-8">
            <div className="flex items-center gap-20 animate-marquee whitespace-nowrap">

              <Image className="h-32 object-contain" width={200} height={200} alt="Slack" src="/homepage_image/Slack.png" />
              <Image className="h-32 object-contain" width={200} height={200} alt="Line" src="/homepage_image/Line.png" />
              <Image className="h-36 object-contain" width={200} height={200} alt="Gmail" src="/homepage_image/Gmail.png" />
              <Image className="h-45 object-contain" width={300} height={300} alt="Outlook" src="/homepage_image/Outlook.png" />
              <Image className="h-28 object-contain" width={200} height={200} alt="TeamPlus" src="/homepage_image/teams-logo.png" />

              {/* 無縫輪播複製區 */}
              <Image className="h-32 object-contain" width={200} height={200} alt="Slack" src="/homepage_image/Slack.png" />
              <Image className="h-32 object-contain" width={200} height={200} alt="Line" src="/homepage_image/Line.png" />
              <Image className="h-36 object-contain" width={200} height={200} alt="Gmail" src="/homepage_image/Gmail.png" />
              <Image className="h-45 object-contain" width={300} height={300} alt="Outlook" src="/homepage_image/Outlook.png" />
              <Image className="h-28 object-contain" width={200} height={200} alt="TeamPlus" src="/homepage_image/teams-logo.png" />
            </div>

            {/* 左右漸層遮罩 */}
            <div className=" pointer-events-none absolute inset-0 bg-gradient-to-r from-white via-white/0 to-white" />
          </div>
        </div>
      </div>
      
      {/* footer */}
      <div className="w-full h-[502px] py-0.5 top-[3109px] absolute bg-sky-900 inline-flex flex-col gap-2.5">
        <div className="flex-1 px-16 flex flex-col justify-center gap-16">
          <div className="self-stretch inline-flex justify-between">
            <div className="inline-flex flex-col items-start gap-4">
              <div className="text-center text-white text-xl font-bold font-['SVN-Gilroy'] leading-7 tracking-tight">Product</div>
              <div className="flex flex-col items-start gap-2">
                <div className="text-center text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Desktop Wallet</div>
                <div className="text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Mobile Wallet</div>
                <div className="text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Trezor Hardware Wallet</div>
                <div className="text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Exodus Crypto Apps</div>
              </div>
            </div>
            <div className="inline-flex flex-col items-start gap-4">
              <div className="text-white text-xl font-bold font-['SVN-Gilroy'] leading-7 tracking-tight">Support</div>
              <div className="flex flex-col items-start gap-2">
                <div className="text-center text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Support</div>
                <div className="text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Knowledge base</div>
                <div className="text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Legal Inquiries</div>
                <div className="text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Status</div>
                <div className="text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Videos</div>
                <div className="text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Blog</div>
              </div>
            </div>
            <div className="inline-flex flex-col items-start gap-4">
              <div className="text-white text-xl font-bold font-['SVN-Gilroy'] leading-7 tracking-tight">Company</div>
              <div className="flex flex-col items-start gap-2">
                <div className="text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">About us</div>
                <div className="text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Investors</div>
                <div className="text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Careers</div>
                <div className="text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Contact Us</div>
                <div className="text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Brand guidelines</div>
              </div>
            </div>
            <div className="w-72 h-40 relative">
              <div className="w-72 p-1 left-[-4px] top-[40px] absolute inline-flex gap-2.5">
                <div className="flex-1 text-white text-base font-medium font-['SVN-Gilroy'] leading-normal tracking-tight">Sign up to receive our newsletter with updates about your wallet.</div>
              </div>
              <div className="w-72 absolute text-white text-xl font-bold font-['SVN-Gilroy'] leading-7 tracking-tight">Subscribe to Peyme</div>
              <div className="w-44 px-6 py-2 top-[124px] absolute bg-white rounded outline-1 outline-offset-[-1px] outline-white/50 inline-flex justify-center">
                <div className="text-center text-black/50 text-sm font-bold font-['SVN-Gilroy'] leading-tight tracking-tight">Sign Up</div>
              </div>
            </div>
          </div>
          <div className="w-full h-24 flex justify-end items-end">
            <div className="w-full flex gap-9">
              <div className="text-white text-xl font-bold font-['Poppins'] tracking-wider">
                EasyTrack
              </div>
              <div className="h-6 border-l border-stone-300 opacity-70"></div>

              <div className="text-white text-xs font-semibold font-['SVN-Gilroy'] leading-tight text-center">
                Copyright © 2021 Payme Movement, Inc.
                <br />
                Payme was co-founded by Thanh Thien and Thanh Long.
              </div>
            </div>
          </div>
        </div>
      </div>
      

      

      
    </div>
  );
}

