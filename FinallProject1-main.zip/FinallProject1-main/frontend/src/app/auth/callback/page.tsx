"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

export default function AuthCallbackPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [status, setStatus] = useState("處理中...");

  useEffect(() => {
    const handleCallback = async () => {
      const token = searchParams.get("token");
      const error = searchParams.get("error");

      // 處理錯誤
      if (error) {
        setStatus(`登入失敗: ${error}`);
        setTimeout(() => {
          router.push("/login");
        }, 2000);
        return;
      }

      // 處理成功
      if (token) {
        try {
          setStatus("登入成功！正在取得使用者資訊...");
          
          console.log("✅ 收到 Token:", token);

          // 儲存 token
          localStorage.setItem("token", token);

          // 取得完整使用者資訊
          const res = await fetch("http://localhost:4000/api/auth/me", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });

          const data = await res.json();
          console.log("✅ 使用者資訊:", data);

          if (data.success) {
            // 儲存使用者資訊
            localStorage.setItem("user", JSON.stringify(data.user));
            
            // 觸發全域事件，通知 Sidebar 更新
            window.dispatchEvent(new Event("user-logged-in"));
            
            setStatus("登入成功！正在導向 Dashboard...");
            
            // 導向 Dashboard
            setTimeout(() => {
              router.push("/dashboard");
            }, 1000);
          } else {
            setStatus("無法取得使用者資訊");
            setTimeout(() => {
              router.push("/login");
            }, 2000);
          }
        } catch (err) {
          console.error("❌ 處理錯誤:", err);
          setStatus("登入失敗");
          setTimeout(() => {
            router.push("/login");
          }, 2000);
        }
      } else {
        setStatus("登入資訊不完整");
        setTimeout(() => {
          router.push("/login");
        }, 2000);
      }
    };

    handleCallback();
  }, [searchParams, router]);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-md text-center max-w-md">
        {/* Loading 動畫 */}
        <div className="mb-4">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-500 mx-auto"></div>
        </div>
        
        {/* 狀態訊息 */}
        <h2 className="text-xl font-semibold text-gray-800 mb-2">
          Google 登入
        </h2>
        <p className="text-gray-600">{status}</p>
      </div>
    </div>
  );
}
