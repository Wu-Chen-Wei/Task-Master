"use client";

/**
 * 認證相關的 Hook
 * 提供登入狀態、使用者資訊、角色檢查、權限控管
 */
import { useState, useEffect, useCallback } from "react";

// ==================== 型別定義 ====================

interface User {
  userID: number;
  Email: string;
  FullName: string;
  AvatarURL?: string;
  Title?: string;
  Status: string;
  EmailVerified: boolean;
  Roles?: string[];
}

export const ROLES = {
  ADMIN: "Admin",             // ✅ 改名
  ACCOUNT_ADMIN: "AccountAdmin",
  PM: "PM",
  RDL: "RDL",                 // ✅ 改名
  RD: "RD",
  QA: "QA",
} as const;

// ==================== Hook ====================

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // ==================== 載入使用者資訊 ====================
  
  const loadUser = useCallback(() => {
    try {
      const token = localStorage.getItem("token");
      const userStr = localStorage.getItem("user");

      if (token && userStr) {
        const userData = JSON.parse(userStr) as User;
        setUser(userData);
        setIsAuthenticated(true);
      } else {
        setUser(null);
        setIsAuthenticated(false);
      }
    } catch (error) {
      console.error("❌ 讀取使用者資訊失敗：", error);
      // 清除無效資料
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      setUser(null);
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // ==================== 初始化 ====================

  useEffect(() => {
    loadUser();

    // 監聽登入事件
    window.addEventListener("user-logged-in", loadUser);

    return () => {
      window.removeEventListener("user-logged-in", loadUser);
    };
  }, [loadUser]);

  // ==================== 登出 ====================

  const logout = useCallback(async () => {
    try {
      const token = localStorage.getItem("token");

      // ⭐ 呼叫後端登出 API
      if (token) {
        await fetch("http://localhost:4000/api/auth/logout", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
      }
    } catch (error) {
      console.error("❌ 登出 API 呼叫失敗：", error);
    } finally {
      // 無論 API 是否成功，都清除本地資料
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      setUser(null);
      setIsAuthenticated(false);
      window.location.href = "/login";
    }
  }, []);

  // ==================== 角色檢查 ====================

  /**
   * 檢查是否有特定角色
   */
  const hasRole = useCallback(
    (role: string): boolean => {
      if (!user?.Roles) return false;
      return user.Roles.includes(role);
    },
    [user]
  );

  /**
   * 檢查是否有任一角色
   */
  const hasAnyRole = useCallback(
    (roles: string[]): boolean => {
      if (!user?.Roles) return false;
      return roles.some((role) => user.Roles!.includes(role));
    },
    [user]
  );

  /**
   * 檢查是否有所有角色
   */
  const hasAllRoles = useCallback(
    (roles: string[]): boolean => {
      if (!user?.Roles) return false;
      return roles.every((role) => user.Roles!.includes(role));
    },
    [user]
  );

  // ==================== 角色快捷方法 ====================

  /**
   * 檢查是否為系統管理員
   */
  const isSystemAdmin = useCallback((): boolean => {
    return hasRole(ROLES.ADMIN);
  }, [hasRole]);

  /**
   * 檢查是否為帳號管理員
   */
  const isAccountAdmin = useCallback((): boolean => {
    return hasRole(ROLES.ACCOUNT_ADMIN);
  }, [hasRole]);

  /**
   * 檢查是否為任一管理員
   */
  const isAdmin = useCallback((): boolean => {
    return hasAnyRole([ROLES.ADMIN, ROLES.ACCOUNT_ADMIN]);
  }, [hasAnyRole]);

  /**
   * 檢查是否為 PM
   */
  const isPM = useCallback((): boolean => {
    return hasRole(ROLES.PM);
  }, [hasRole]);

  /**
   * 檢查是否為 RD Leader
   */
  const isRDLeader = useCallback((): boolean => {
    return hasRole(ROLES.RDL);
  }, [hasRole]);

  /**
   * 檢查是否為 RD
   */
  const isRD = useCallback((): boolean => {
    return hasRole(ROLES.RD);
  }, [hasRole]);

  /**
   * 檢查是否為 QA
   */
  const isQA = useCallback((): boolean => {
    return hasRole(ROLES.QA);
  }, [hasRole]);

  // ==================== 功能權限檢查 ====================

  /**
   * 是否可以管理使用者
   */
  const canManageUsers = useCallback((): boolean => {
    return hasAnyRole([ROLES.ADMIN, ROLES.ACCOUNT_ADMIN]);
  }, [hasAnyRole]);

  /**
   * 是否可以管理專案
   */
  const canManageProjects = useCallback((): boolean => {
    return hasAnyRole([ROLES.ADMIN, ROLES.PM, ROLES.RDL,ROLES.RD,ROLES.QA]);
  }, [hasAnyRole]);

  /**
   * 是否可以管理 Mission
   */
  const canManageMissions = useCallback((): boolean => {
    const result = hasAnyRole([
      ROLES.ADMIN,
      ROLES.PM,
      ROLES.RDL,
      ROLES.RD,
      ROLES.QA,
    ]);
    console.log('🔍 canManageMissions 檢查:', {
      userRoles: user?.Roles,
      result,
      isAuthenticated
    });
    return result;
  }, [hasAnyRole, user, isAuthenticated]);

  /**
   * 是否可以關閉 Issue（只有 QA 和 Admin）
   */
  const canCloseIssue = useCallback((): boolean => {
    return hasAnyRole([ROLES.ADMIN, ROLES.QA]);
  }, [hasAnyRole]);

  /**
   * 是否可以刪除專案（只有 SystemAdmin）
   */
  const canDeleteProject = useCallback((): boolean => {
    return hasRole(ROLES.ADMIN);
  }, [hasRole]);

  /**
   * 是否可以修改系統設定（只有 SystemAdmin）
   */
  const canManageSettings = useCallback((): boolean => {
    return hasRole(ROLES.ADMIN);
  }, [hasRole]);

  /**
   * 是否可以停用帳號（只有 SystemAdmin 和 AccountAdmin）
   */
  const canSuspendUser = useCallback((): boolean => {
    return hasAnyRole([ROLES.ADMIN, ROLES.ACCOUNT_ADMIN]);
  }, [hasAnyRole]);

  /**
   * 是否可以建立 Issue（需要 Email 驗證）
   */
  const canCreateIssue = useCallback((): boolean => {
    return user?.EmailVerified ?? false;
  }, [user]);

  // ==================== 使用者狀態檢查 ====================

  /**
   * Email 是否已驗證
   */
  const isEmailVerified = useCallback((): boolean => {
    return user?.EmailVerified ?? false;
  }, [user]);

  /**
   * 帳號是否啟用
   */
  const isActive = useCallback((): boolean => {
    return user?.Status === "Active";
  }, [user]);

  /**
   * 帳號是否被停用
   */
  const isSuspended = useCallback((): boolean => {
    return user?.Status === "Suspended";
  }, [user]);

  /**
   * 更新使用者資訊（不重新登入）
   */
  const updateUser = useCallback((updatedUser: User) => {
    setUser(updatedUser);
    localStorage.setItem("user", JSON.stringify(updatedUser));
    window.dispatchEvent(new Event("user-logged-in"));
  }, []);

  // ==================== 回傳 ====================

  return {
    // 基本資訊
    user,
    isAuthenticated,
    isLoading,

    // 操作方法
    logout,
    updateUser,
    loadUser,

    // 角色檢查
    hasRole,
    hasAnyRole,
    hasAllRoles,

    // 角色快捷方法
    isSystemAdmin,
    isAccountAdmin,
    isAdmin,
    isPM,
    isRDLeader,
    isRD,
    isQA,

    // 功能權限
    canManageUsers,
    canManageProjects,
    canManageMissions,
    canCloseIssue,
    canDeleteProject,
    canManageSettings,
    canSuspendUser,
    canCreateIssue,

    // 使用者狀態
    isEmailVerified,
    isActive,
    isSuspended,
  };
};