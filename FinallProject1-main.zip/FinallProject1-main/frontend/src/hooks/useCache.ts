import { useState, useEffect, useRef } from 'react';

// 全域快取物件
const globalCache = new Map<string, { data: any; timestamp: number }>();

// 快取有效期（5分鐘）
const CACHE_DURATION = 5 * 60 * 1000;

export function useCache<T>(key: string, fetcher: () => Promise<T>, deps: any[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const fetcherRef = useRef(fetcher);

  // 更新 fetcher 引用
  useEffect(() => {
    fetcherRef.current = fetcher;
  }, [fetcher]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // 檢查快取
        const cached = globalCache.get(key);
        const now = Date.now();
        
        if (cached && (now - cached.timestamp) < CACHE_DURATION) {
          setData(cached.data);
          setLoading(false);
          return;
        }

        // 快取過期或不存在，重新獲取
        setLoading(true);
        const result = await fetcherRef.current();
        
        // 更新快取
        globalCache.set(key, { data: result, timestamp: now });
        setData(result);
        setError(null);
      } catch (err) {
        setError(err as Error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [key, ...deps]);

  // 清除快取的函數
  const clearCache = () => {
    globalCache.delete(key);
  };

  return { data, loading, error, clearCache };
}

// 清除所有快取
export const clearAllCache = () => {
  globalCache.clear();
};